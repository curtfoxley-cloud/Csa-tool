---
title: "BOM Comparator — User Guide"
subtitle: "Configuration Status Accounting Tool · for build v191 and Delta tool v3.9 · November 2026"
toc-title: "Contents"
---

# 1. What Comparator Is

Comparator is a **Configuration Status Accounting (CSA)** tool. It answers the fundamental configuration-management question for a build program: **does what we built match what we designed, and can we prove it?** It does this by reconciling your Engineering Bill of Materials (the design) against your Manufacturing Bill of Materials (the plan) and your As-Built Bill of Materials (the physical record), then layering in change history, work orders, nonconformances, variances, and your Configuration Items list.

The tool is a **single file that runs entirely in your web browser**. Nothing is uploaded to any server — your BOMs never leave your computer. There is no installation: open the HTML file in a modern browser (Chrome or Edge recommended) and you are running it. It works with no network connection at all.

### The one-sentence version of what it computes

For every line in your EBOM, Comparator asks: *is this part accounted for in the plan (MBOM), and physically embodied in the article (ABOM) — directly, as a parent assembly, or through a reconciled ancestor — in the right quantity, under closed work orders?* Everything on the dashboard is some rollup or breakdown of that question.

# 2. Quick Start

- **Open the HTML file** in Chrome or Edge.

- **Choose a comparison mode** (EBOM↔MBOM, EBOM↔ABOM, MBOM↔ABOM, or the combined three-way). The mode controls which upload zones are active.

- **Load your files** into the upload zones (Section 01). At minimum, load the two or three BOMs your mode requires. Add CHP, WO5, NCR, CI, RFV, and ACN files for richer traceability — each unlocks additional columns, cards, and reports.

- **Check the column mapping** if your files use a non-standard layout (see 3.2).

- **Run the comparison.** The KPI sections, charts, and the Detailed View table populate.

- **Read the dashboard** top-down: headline percentages first, then the issue cards, then drill into anything by clicking its card, and finally work the row-level detail in Section 03.

- **Export** what you need (Section 9) and **save your session** (Section 10) so you can return to exactly this state later.

# 3. Loading Your Data

## 3.1 The ten data sources

Each upload zone accepts an Excel file. The three BOMs drive the reconciliation; the other seven enrich it. The tenth, ME ADJ, is loaded after a run, inside the Adjudication Workbench (3.6). A zone that your comparison mode does not use is disabled.

| Zone | File | What it contributes |
| --- | --- | --- |
| EBOM | Engineering BOM | The as-designed baseline. Every reconciliation is anchored to EBOM line items. |
| MBOM | Manufacturing BOM | The as-planned build structure. Answers “was it planned?” |
| ABOM | As-Built BOM | The as-built record. Answers “was it physically embodied, and under what work orders?” |
| CHP | Change Pedigree | Change history traced to part: DCN (release approval for the design data), ECN (the change commitment list) and ECR (the request that generated the data). Feeds the Drawing and change columns. |
| WO5 | Installed/Removed Report | Work-order install/remove actions with serials and dates. |
| NCR | Nonconformance Records | Discrepant parts, dispositions, cause and defect codes; feeds the NCR columns, charts, and CI cards. |
| CI | Configuration Items List | The acquirer-designated CI list (CI ID, PN, Next Higher), or the Excel export of the CI Index tool (3.2). Unlocks the entire CI Status section. |
| RFV | Request for Variance | Approved deviations/waivers. Unlocks RFV coverage cards and the RFV report. |
| ACN | Authorized Clearance Notice | Qualification/conditional-use status. Unlocks the ACN section and report, and the ACN Level, ACN Record Number and ACN Record Revision columns (6.1). |
| ME ADJ | Manufacturing Eng. adjudications | Adjudication claims decided in an external tool, imported as pending claims (3.6). |

## 3.2 Column mappings

EBOM and ABOM support preset layouts (**Mapping 1**, **Mapping 2**) and a **Manual** remapper; MBOM, CHP, NCR, CI, RFV, ACN, and ME ADJ support a Default layout plus a Manual map. The CI zone has a third choice, **CI Index**, for the CI Index tool's export (below). If your file’s columns are in different positions than the default, set the mapping before running — the tool reads by position, not by header name. Your chosen mappings, including the ME ADJ manual map (from v178) and the CI and RFV manual maps (from v186), are saved and restored with the session.

Each Manual map opens the same window. Type the column letter that holds each field. A field marked with a red star is required. Leave an optional field blank to read it from its default position. If the file is already loaded, the new map applies at once, so there is nothing to re-upload. **Default** returns the zone to the default layout.

**CAGE code (from v189).** The EBOM carries a CAGE code for each line. Mapping 1 reads it from column Q. Mapping 2 reads it from column G. In the EBOM Manual window, **CAGE Code** is an optional field: type its column letter, or leave it blank to read column Q. CAGE code is display information. No reconciliation pass, status, KPI or certificate hash reads it. It appears in the Comparison Summary (6.1), the EBOM Full tab, and the reports listed in section 9. Comparator shows a code exactly as the file holds it. Excel stores an all-digit code as a number, so 07482 arrives as 7482; format that column as text in the source export to keep the zero.

**Headings over a re-arranged file.** A Manual map, or Mapping 2, re-arranges each row of your file into Comparator’s default column positions as it loads. From v187, wherever those rows are shown (the EBOM, MBOM, ABOM, Change Pedigree and NCR tabs, and the raw sheets of the Excel export) each column is headed by the name of the field it holds, such as **Part Number**. A column that no field uses is empty and is headed **—**. A file loaded in its own layout keeps its own headings, exactly as before. Before v187 the file’s own headings were printed over the re-arranged columns, so they sat over the wrong data.

**The column-letter box** in each mapping window is wide enough to show its placeholder in full, for example DEFAULT: BZ, so you can see each field’s default column before you type over it (from v187).

Which fields are required depends on the zone:

| Zone | Required fields | Why |
| --- | --- | --- |
| CI | CI Identifier, Part Number, Next Higher Part Number | Together they identify a Configuration Item. The CI cards and reports join it to the EBOM and ABOM on Part Number + Next Higher. A row with no part number is skipped. |
| RFV | RFV Number | It identifies the variance. A row with no RFV number is skipped. A variance reaches a line item by any of three keys: Part Number + Next Higher (P1), NCR Disposition Number (P2) and Work Order Number (P3). Map the ones your file carries. |

**CI Index export (from v191).** The CI zone can read the Excel file the CI Index tool exports. Press **CI Index** on the zone, then load the file. Comparator reads the sheet named **CI Index** (the export puts an About sheet first) and the **PN Variants** sheet. It finds each column by its heading, so the column order does not matter. It needs the **CI ID**, **PIN** and **NH PIN** columns, and it also reads **Status**, **CI Type** and **Other Installed Positions**.

One CI can sit in more than one place, and Comparator counts a CI as one CI ID + Part Number + Next Higher. So each position becomes its own row:

- the CI's first position: its PIN in its NH PIN;
- each entry in Other Installed Positions, such as *CI-0040 in MF-2210-001, Qty 2*;
- each PN Variants row: the variant PIN in the variant's NH PIN, or the CI's when the variant leaves it blank, and in the variant's other positions, or the CI's.

A position that repeats a CI ID, PIN and NH PIN already loaded counts once. Two CI IDs at the same PIN and NH PIN are two CIs.

Some rows are left out on purpose:

| Row | What happens |
| --- | --- |
| Status Active, or blank | Loads. |
| Any other Status (Proposed, De-designated, Superseded) | Left out, with its PN Variants rows. |
| CI Type Collector | Left out, with its PN Variants rows. A collector groups other CIs and has no part of its own. |
| NH PIN of N/A (the top-level CI) | Loads with a blank next higher, so it can match the EBOM's top line. |
| No PIN | The CI row loads nothing. Its PN Variants rows still load. |

Only the three keys come across. CI Name, CAGE, Control Tier and the other CI Index columns are not read. Under the row count, the zone shows how many CIs loaded and how many rows were left out. Hover that line for the full account.

The layouts do not mix. Default and Manual refuse a CI Index export and tell you to press CI Index. CI Index refuses a workbook with no CI Index sheet. If you change the layout while a CI file is loaded and the new layout cannot read it, Comparator removes the file and asks you to load the right one. The layout is saved with the session, and Reset returns the zone to Default.

The CI Index tool's own **In-line Other Positions View** sheet leaves out a variant whose CI has one position and no installation of its own, because its row would look like the CI's. Comparator loads that variant: its PIN is a different part at that position.

Which Change Pedigree fields the Manual map requires depends on the Change Pedigree Alignment setting (3.7): Part Number and Next Higher under the default, Document/Drawing Number and ECR under the drawing rule.

*A note on documentation:* wherever this guide or the tool cites a column letter (for example “EBOM column D”), that letter describes the **default Mapping 1 layout**. If you use Mapping 2 or a manual map, the letters in your file will differ.

## 3.3 Proc code behavior (ABOM)

Every as-built row carries a **proc code** that tells the engine what the row did to the build: added a part, removed one, or temporarily removed and reinstalled it. Comparator ships with the proc codes of the program it was originally built for. Other programs use different codes, so the set is editable.

The **Proc Code Behavior** panel sits directly beneath the three BOM upload zones. Load an ABOM and it lists every distinct proc code found in that file — deduplicated, so a code written inconsistently (BR, br, “BR”) appears once with the combined row count. Tag the codes that mean removal or swap. Everything you leave untagged is treated as an install.

| Behavior | What it means to the engine |
| --- | --- |
| **Install** | Adds its quantity to the build. This is the default for any code you do not tag, including codes the tool has never seen and rows with no proc code at all. |
| **Remove** | Subtracts its quantity. If every as-built record for a line is a removal, the line is flagged ⬇ PROC REMOVED and drops out of the embodied count. |
| **Swap** | Removed and reinstalled within the same work order — net zero. A line whose only records are swaps is treated as present, not removed. |

The tool cannot tell a removal code from an install code by looking at it — only someone on the program knows. That is why untagged means install: it is the safe, unchanged default rather than a guess. The panel offers no inference of its own; it shows evidence and leaves the judgement to you. Alongside each code it lists up to three of the distinct **job numbers** that code appears under, one per line, with a count of any others. Job numbering schemes often carry a hint about the work being performed, so a few real examples are usually the fastest way to recognise an unfamiliar code.

Three things are worth knowing about how the panel behaves:

- **Changes apply on the next run, not on upload.** Unlike a column mapping, proc codes are read when you press Run Comparison, so you never need to re-upload a file. If results are already on screen, the panel reminds you to run again.

- **Your tagging travels with the session.** It is written into the session JSON and restored on import, so a re-imported session reproduces the same numbers. Reset returns to the shipped baseline.

- **Non-default tagging is disclosed.** The panel header shows Program baseline or a profile name, the panel border is highlighted, and the profile is stamped on the Audit Certificate sheet of the exports.

**Sharing a profile.** Rather than have everyone on a program tag the same codes independently — and risk disagreeing — one person can tag once and use **⬇ Export profile** to write a small JSON file. Everyone else loads it with **⬆ Load profile** and never sees the panel again. Profiles are plain files: no server, nothing stored in your browser.

If your program uses the original code set, this panel needs no attention. Open it, confirm your codes are already tagged, and carry on.

## 3.4 EBOM indenture scope

Most programs use the top one or two EBOM indenture levels as conceptual roll-ups — an apex row for the end item, perhaps a major-assembly level beneath it — rather than as real parts to be built and reconciled. Comparator therefore treats indenture **A** and **B** as structural by default: those rows appear in the Comparison Summary with a **COLLECTOR (INDENTURE)** badge and are excluded from reconciliation counts and every percentage.

Not every program works that way. The **EBOM Indenture Scope** panel sits beside Proc Code Behavior and lets you say which levels are structural on your program. Tick or untick A through E:

- **Default (A + B excluded)** — the behavior of every build before v160.

- **Nothing excluded** — every level reconciles, including the apex. Use this if your EBOM carries real parts all the way to the top.

- **A only** — the apex is a roll-up but B holds real parts that should reconcile.

The setting behaves like proc code tagging in every respect that matters: changes apply on the next run rather than on upload, it travels in the session JSON so a re-imported session reproduces the same numbers, it cannot be changed while a report is frozen, and it is stamped on the Audit Certificate as **EBOM Indenture Scope**. That last point matters — two people comparing the same files under different scope settings will get different answers, so the artefact records which rule produced it. From v178 the scope is also inside the certificate's integrity hash (10.2).

One difference from proc codes: **Reset leaves the indenture scope as it is.** It is a program convention rather than a per-run choice, so you do not have to re-tick it after every reset.

**Numeric indenture values.** Some programs write indenture as numbers rather than letters. Comparator reads **1 as A, 2 as B, 3 as C** and so on through 26, so a numeric EBOM reconciles identically to the same structure written in letters, and the scope setting above applies either way. You do not need to convert anything before uploading. Values outside 1–26 are left exactly as they appear in your file.

## 3.5 Comparison modes

**EBOM↔MBOM** measures planning coverage. **EBOM↔ABOM** measures physical embodiment. **EBOM↔MBOM↔ABOM** runs both against the same EBOM baseline. **MBOM↔ABOM** compares plan to build without a design anchor; in this mode the EBOM-anchored passes and sections are disabled.

## 3.6 Importing adjudications from another tool

If Manufacturing Engineering adjudicates in a separate system, their export can be loaded rather than re-keyed. The **ME ADJ** zone sits inside the **Adjudication Workbench**, between the Candidates Helpers and the Claim Ledger — not in the upload grid at the top of the page. An export is a batch of claims *about a completed run*, not a tenth data source, and the workbench does not appear until a comparison has run. Comparator turns each row into a normal adjudication claim, so everything downstream behaves identically: ⚑ badges, KPI effects, the freeze certificate, the session file, and the delta comparison.

**Their export usually carries less than Comparator needs.** A typical export names the part and who decided, but not *where* in the tree, *how much*, or *which leg*. Comparator infers all three:

| Missing | How it is resolved |
| --- | --- |
| Next higher | Looked up in the EBOM, restricted to positions that actually fail reconciliation. A part sitting at four positions where only one is broken needs no input from you. |
| Quantity | The line’s EBOM quantity — the claim makes the line whole. |
| Leg | Whichever legs actually fail. A claim is **not** filed against a leg that already reconciles, so nobody is recorded as adjudicating something they did not. |

**The zone only appears after a run**, which is the point: claims are resolved against reconciliation results, so there is nothing to adjudicate until the run exists. It appears after *any* completed run, including a clean one — a run with no candidates of its own is exactly when you may still want ME’s view on lines you disagree about.

**Every imported row lands in one of four buckets**, and all four are reported in the review panel that appears once the file is read:

- **Applied automatically** — one failing position, nothing to decide.

- **Needs a decision** — the part fails at several positions. These go to a picker.

- **No action needed** — the part already reconciles everywhere. Usually a sign the export was taken against a different tail or an older run.

- **Rejected** — the part is not in this EBOM.

**The picker shows the narrative.** Because narrative text often names the next higher, work order or job somewhere inside a paragraph, Comparator searches it for the specific values in play and shows you the sentence it found them in. Where the prose names exactly one candidate, that position is highlighted as a suggestion. Where it names more than one, **nothing is suggested** — narrative frequently rules a position out in words (“…under 88421-7, *not* 88421-9 as originally routed”), and no automatic match can read that. You get the sentences; you make the call.

**The review panel is built around the exceptions.** A production export can run to several thousand rows, and the great majority usually resolve without input. Those get a count. The four buckets are tabs; the ones needing you are the point of the screen. Press **Stage** when the queue is clear, and the claims are added as pending.

**Imported claims arrive pending.** They do not change any number until you press **Process Adjudications** in the **Claim Ledger** below, exactly like claims filed inside Comparator.

**An ME import never touches CI-to-NCR tracing.** That work belongs to Configuration Management: a different organisation answering a different question, and out of scope for a Manufacturing Engineering adjudication. Comparator protects it on two independent checks — the claim’s origin *and* its type — so an imported batch cannot withdraw a CI-to-NCR trace even if its provenance were wrong. The panel names the count of protected claims each time you import.

**Re-importing replaces the previous batch.** Load a newer export and the earlier imported claims are discarded in favour of it — including any that ME has since withdrawn, whose rows revert to their raw status. Claims you filed *inside* Comparator, CI-to-NCR traces especially, are untouched: you can keep stacking your own tracing work on top of an imported batch and re-import as often as you like.

## 3.7 Change Pedigree alignment

Most programs send a full Change Pedigree extract. Each row names a part number, its next higher, and the DCN, ECN and ECR behind it, and Comparator attaches the row to the EBOM line with the same part number and next higher. That is the default, and it is how every build before v182 worked.

A few programs send a much thinner extract: a **drawing number** and an **ECR** on every row, with DCN and ECN often blank. For those programs the ECR belongs to a drawing, and the drawing is what links it to EBOM line items. The **Change Pedigree Alignment** panel, beside EBOM Indenture Scope, lets you say which kind of extract your program sends.

| Rule | A Change Pedigree row attaches to | Use it for |
| --- | --- | --- |
| **Part number + next higher** (default) | The EBOM line with the same part number and next higher. If there is none, any line with the same part number. | A full Change Pedigree extract. |
| **Drawing number** | **Every** EBOM line whose drawing number matches. Optionally drawing number + revision. | An extract that carries only drawing numbers and ECRs. |

**If your program uses the default, this panel needs no attention.** It reads **Default**, and nothing about your results, exports or certificate changes.

**Setting up the drawing rule.** Choose **Drawing number**. Then:

- **Pick the EBOM drawing number column.** The list shows your EBOM file's own column headers, with three sample values from the column you pick, so you can confirm it holds drawing numbers. This choice is separate from Mapping 1, Mapping 2 and Manual, so none of them change.
- **Choose what to match on.** *Drawing number only* is the usual choice. *Drawing number + revision* also asks for the EBOM revision column. Use it only if the EBOM revision and the Change Pedigree drawing revision are the same thing, written the same way: the EBOM's Drawing PL Rev may be a parts-list revision. After a run in this mode the panel reports how many rows matched on drawing number but not on revision.
- **Map the Change Pedigree file.** Its Document/Drawing Number and ECR fields are read through the Change Pedigree zone's Manual map (3.2). Under this rule the file does not need a part number; rows are kept when they carry a drawing number. Changing the rule re-reads a loaded Change Pedigree file, so there is nothing to re-upload.

**Run Comparison is refused until the setup is complete,** with a message saying what is missing. A run that matched nothing would look like a program with no change history at all.

**The match is exact** after trimming spaces and ignoring letter case: `d-100` matches `D-100`, but `D100` does not. Comparator does not guess that two spellings are the same drawing. If your two files write drawing numbers differently, raise it so an explicit, visible cleanup rule can be added.

**Read the results with the rule in mind.** A drawing often defines many parts. Under this rule an ECR attaches to **every** EBOM line on its drawing, including parts the change may not have touched. That answers "does this line's drawing have change history?" It does not answer "did this ECR change this part?" The History badge (6.3) adds two states for this rule, **ECR ONLY** and **NO DRAWING**, and its tooltip names the drawing the history came through. The Drawing column shows the EBOM line's own drawing number. After a run the panel reports how many Change Pedigree rows matched an EBOM drawing and how many drawings are not in the EBOM.

**The ECN reports** (9.3) need ECNs. If the extract carries none, both say *Not available* instead of producing an empty report that would read as a clean result. If it does carry ECNs, an ECN's footprint is every EBOM line on its drawings, and the report says so.

The setting behaves like the other two program settings in most respects: it applies on the next run, travels in the session JSON, cannot be changed while a report is frozen, and is named on the Audit Certificate as **Change Pedigree Alignment**, inside the integrity hash (10.2). Two differences:

- **It is recorded only when it is not the default.** A default session and certificate are written exactly as before v182.
- **Reset returns it to the default.** Indenture scope survives Reset; this setting does not, because forgetting it would drop a whole program's change history. A program on the drawing rule sets it again after Reset, or gets it back by opening its saved session.

If you change the setting after a run, freezing the report (10.2) is refused until you run the comparison again, so the certificate always names the rule the results were computed under.

# 4. How the Reconciliation Works (Read This Once)

Five ideas explain almost everything you will see on screen. Ten minutes here saves hours of misreading later.

## 4.1 The three passes

Every active EBOM line item is tested three independent ways against the target BOM. An item can satisfy more than one pass.

| Pass | Question it asks | Plain reading |
| --- | --- | --- |
| Pass 1 — Direct | Does an exact Part Number + Next Higher match exist, with sufficient quantity? | The part is there, as its own line, where the design says, in the right amount. |
| Pass 2 — Used-On | Does the part’s number appear as a *parent assembly* (Used-On) value? | The part is present as an assembly that other parts were built into. |
| Pass 3 — Ancestor | Is a parent up the indenture chain reconciled? | The part itself isn’t listed, but a higher assembly containing it is accounted for. |

Quantity is checked at Pass 1 only. Passes 2 and 3 establish presence/coverage, not amounts.

## 4.2 Closed vs. open work orders (ABOM side)

The as-built record is split into two pools: rows under **CLOSED** work orders and rows under any other status. The three passes run against the **closed** pool — embodiment only “counts” when the paperwork is finished. Items found only under open work orders are surfaced separately (the “WO Not Closed” cards and statuses) so you can see work in progress without letting it inflate closure numbers. “Missing” means the item failed every path against *both* pools.

## 4.3 ABOM quantities: Roll Up vs. per WO

One part under one assembly may have many as-built records — installs, removals, swaps across work orders. The engine computes a **net** quantity per line (adds minus removes; a swap with no other add counts as an add). Which codes count as removals and swaps is set by the Proc Code Behavior panel (3.3). That net is the **“Roll Up”** figure and is what all quantity checks use. The individual raw records are preserved and shown as **“per WO”** values, each aligned with its own work order, proc code, WO status, and Job Number. The per-WO values will *not* always sum to the Roll Up when removals or swaps are present — that is correct, and both views are shown so you can see why.

## 4.4 Duplicate EBOM lines are merged — and numbered

The summary table shows **one row per unique Part Number + Next Higher combination**. If your EBOM contains the same part under the same assembly on two lines (e.g., two find numbers), those lines are **merged into a single row**: its EBOM Qty is their **sum** (and all quantity checks compare against that sum), and its Part Qty Text shows whichever duplicate appeared *last* in the file. Its CAGE Code cell lists *every distinct* code the merged lines carry, in file order, separated by “; ” (from v189). To keep the original lines visible, every physical EBOM row is assigned a permanent **EBOM Line #** at load time; a merged row carries all of its source numbers (e.g., “12; 47”) in the Excel exports.

## 4.5 What the statuses mean

| Status / badge | Meaning |
| --- | --- |
| RECONCILED / DIRECT RECONCILED / DIRECT EMBODIED / SUB/AR OK | Pass 1 success. “Flex” means the line is SUB or AR — any quantity is acceptable by design. |
| PN USED-ON MATCH / PN EMBODIED AS USED-ON / EMBODIED AS USED ON | Pass 2 success — the part is present as a parent assembly. |
| PARENT IND. MATCH / PARENT IND. EMBODIED | Pass 3 success — reconciled through an indenture ancestor. |
| ⚠ QTY MISMATCH | Found directly, but the target quantity is short of the EBOM quantity. Only shortfalls flag; surplus does not. |
| ⚠ WO NOT CLOSED | Present in the ABOM, but only under a work order that is not closed. In-progress, not final. |
| ⬇ PROC REMOVED | Every as-built record for the line nets to a removal — it was taken out and nothing effective remains. Which proc codes mean removal is configurable (3.3). |
| ✗ MISSING | Failed all three passes against both WO pools. |
| COLLECTOR (INDENTURE) | A structural indenture row — a roll-up level rather than a real part, including the top-level apex. Outside reconciliation scope. Which levels count as structural is set per program in **EBOM Indenture Scope** (3.4); the default is A and B. |
| ⚑ ADJ | The status was set or affected by a manual SME adjudication claim (Section 8). The ⚑ marker always means “a human decided this.” |

Structural rows (collectors, REFERENCE / BULK MATL part types, REF-quantity lines, removal-instruction blocks) are shown for context but **excluded from every percentage and KPI count**.

Green badges carry no symbol: green already says the line is fine. Symbols are kept for states that need a second look — ⚠, ✗, ⊘ (removal item), ⬇ (proc removed) and ⚑ (adjudicated). Hover any badge for the exact wording of its explanation.

# 5. Reading the Dashboard (Section 02 — Configuration coverage metrics)

The header carries **Jump to** links — EBOM·MBOM, EBOM·ABOM, Adjudication, CI Status and ACN — that scroll straight to each section; the link for the section you are reading is underlined. CI Status and ACN appear only when their sections are on screen, which means when a CI or ACN file is loaded. The theme menu and the build number sit at the top right.

Each KPI section has an **Explanation** button in its header that opens a plain-language description of every card — the authoritative in-tool reference. This chapter is the tour.

**Card conventions:** clickable cards show a hand cursor and lift on hover — clicking opens a drill-down list of the exact rows behind the number. Cards that are not clickable give no hover cue. In the default dark theme, green = reconciled (three tiers for the three passes), amber = quantity short or removed from the build, orange = work order not closed, red = missing, and RFV and NCR each carry their own hue; light mode uses the same scheme at lower saturation, and Black & White drops it in favour of the card label. A card shows its number and label only: there is no progress bar, because a card reports a finding about the configuration, not progress towards a target. In every theme, **the ⚑ marker = manual adjudication**, and structural or informational rows are muted. A dashed sub-line on a card shows how much of its number came from SME claims.

## 5.1 EBOM → MBOM section (planning coverage)

- **% EBOM Line-Items Directly Accounted For** — the strict number: Pass 1 only. The most audit-defensible planning figure.

- **% Accounted For (Any Path)** — Pass 1, 2, or 3. The gap between this and 100% decomposes exactly into the Missing, Qty Mismatch, and SUB/AR cards below it.

- **Direct / Used-On / Parent Indenture counts** — the same coverage split out by pass.

- **Missing in MBOM** — failed every path. Click for the row list; the modal also links to adjudication candidates.

- **EBOM-MBOM Part Qty Mismatch** — planned quantity short of design quantity.

- **SUB/AR Items Not Used** — flex-quantity lines absent everywhere. Informational: absence may be by design.

- **Missing APEX Assemblies** — top-of-tree assemblies with no plan presence; these gate everything beneath them.

## 5.2 EBOM → ABOM section (physical embodiment)

The same structure as the MBOM section, measured against closed-work-order as-built records, plus ABOM-only cards:

- **% EBOM Line-Items Directly Embodied** and **% Embodied (Any Path)** — the Physical Configuration Audit closure numbers. SME-adjudicated items count as reconciled in both; the dashed sub-line shows the claim-derived share.

- **Part WO Status: Not Closed** — present in the ABOM (either pool role) but gated by an unfinished work order. This is your “waiting on paperwork” list.

- **Used-On WO Not Closed** — the parent-assembly version of the same. Together with “Embodied as Used On Parts,” the two sum to the total used-on population.

- **Proc Code: Removed from Build** (⬇) — items whose as-built records net to removal, per the proc code behavior in force (3.3).

- **Missing in ABOM / Qty Mismatch / SUB/AR / APEX** — as in the MBOM section, but against the build record.

## 5.3 CI Status section

Everything here counts **distinct Configuration Items** (CI ID + PN + Next Higher rows from your CI file) rather than EBOM lines. A CI Index export loads one row per position and per PN variant (3.2), so there CI Scope counts positions, not CI IDs. The section appears whenever a CI file is loaded, in any comparison mode (from v190).

Which cards show depends on what else is loaded:

| Cards | Need |
|---|---|
| CI Scope, CIs Missing from EBOM | The CI file and the EBOM |
| CI · MBOM — Planned block | An MBOM, in a mode that includes it (EBOM↔MBOM or Full) |
| The ABOM cards, the two NCR cards, the four RFV cards | An ABOM, in a mode that includes it (EBOM↔ABOM or Full) |

The NCR cards need an ABOM because CIs are linked to NCRs through ABOM work orders. Two of the three RFV passes use ABOM work orders too. In Full mode both blocks show, the MBOM block first, and the ABOM block is headed **CI · ABOM — Embodied**.

**CI · MBOM — Planned** (from v190) answers whether the plan captures each CI. It uses exactly the rules of the EBOM·MBOM section, applied to the CI population:

- **% CI Line-Items Directly Planned** and **CI Line-Items Directly Planned** — the CI's PN + Next Higher is an MBOM line item, with the planned quantity satisfied (Pass 1).
- **% CIs Planned (Any Path)** — Pass 1, 2 or 3.
- **CIs Planned as Used On Parts** — the CI part number is an MBOM Used On value (Pass 2).
- **CIs Parent Indenture Planned** — a reconciled MBOM ancestor covers the CI (Pass 3). The drill-down names the ancestor.
- **CIs Missing in MBOM** — no path succeeded.
- **CIs — MBOM Part Qty Mismatch** — in the MBOM, but planned short of the EBOM quantity.

Every card opens a list of its CIs. The MBOM has no work-order closure, so this block has no open-WO card. In Full mode the engine looks for an MBOM parent only when a part is absent from both the MBOM and the ABOM, so a CI that is a direct ABOM line but absent from the MBOM counts as Missing in MBOM there, exactly as on the EBOM·MBOM cards.

**CI · ABOM — Embodied:**

- **% CIs Directly Embodied** and **% CIs Embodied (Any Path)** — CI-scoped versions of the ABOM headline numbers.

- **Coverage tier** (Direct / Used On / Higher Parent) and **issue tier** (CIs Missing in ABOM, CIs — Open WOs, CIs — ABOM Part Qty Mismatch). The issue cards use independent per-leg tests and may overlap.

- **CI Scope** — the denominator: distinct CIs in your file. Not clickable.

- **CIs Missing from EBOM** — CIs whose PN + Next Higher combination never appears in the design baseline; a data-quality alarm.

- **CIs with Closed / Open NCR Dispositions** — CIs linked to nonconformances via the automated two-path join *plus manual SME traces* you record in the Adjudication Workbench.

- **The four RFV cards** (marked ◈, ordered Any | P1 | P2 | P3) — CIs with variance coverage directly (P1), via an NCR disposition (P2), or via a work order (P3). Manual SME traces contribute to these too, and are tagged Adjudicated in the drill-downs.

## 5.4 Charts

- **WO status roll-up** — unique ABOM work orders by status (a WO’s status is taken from its first appearance in the file). One thin strip shows each status as its share of all work orders, closed first. A list beneath it gives each status with its count and percent. On a non-closed status, a separate segment of the strip and a ◈ count in the list flag WOs that are RFV-authorized — documented open status, lower chase priority.

- **NCR by cause code**, **NCR by disposition code** and **NCR disposition status** — the shape of your nonconformance population. All three are count lists, side by side. Below a window width of about 900px they stack.

- **NCR by cause code** (a list from v188; before that, a bar chart of the top 6) lists every Cause Code, with its description, and the number of NCR disposition entries that carry it. Codes are compared after trimming spaces and ignoring letter case. Where one code carries more than one description in your file, the first one found is shown. An entry with no cause code is listed as UNSPECIFIED, always last.

- **NCR by disposition code** (from v186) lists every Disposition Code with the number of NCR disposition entries that carry it. It counts the same entries as the cause code list: matched NCR rows, each disposition row counted once per pool, cancelled NCRs left out. So the two cards add up to the same total. Codes are compared after trimming spaces and ignoring letter case, so “uai” and “UAI” are one code. An entry with no code is listed as UNSPECIFIED, always last. Under the default mapping the code is read from NCR column BZ. The card is for reading; it is not clickable.

- **EBOM traceability funnel** — the stepwise ladder from total scope to fully-closed, with a delta column comparing the MBOM and ABOM funnels. Beneath it, **Reference — full per-leg KPI totals** repeats the per-leg Part Qty Mismatch and Part WO Not Closed totals. Each bar’s length is its share of Active Scope, and its label reads the count and that percent.

## 5.5 ACN section

When an ACN file is loaded: embodiment of level 4–7 ACN parts and their open-NCR exposure, with per-WO detail in the drill-downs and the ACN report. The Comparison Summary also gains ACN Level, ACN Record Number and ACN Record Revision columns for every line (6.1).

# 6. The Detailed View (Section 03)

This is the row-level truth the cards summarize: one row per unique PN + Next Higher (see 4.4), every reconciliation leg visible. The **Explanation** button at the right end of the tab strip opens the in-tool guide to reading this table. Tabs switch between the comparison summary and raw views of each loaded file.

## 6.1 Column guide

Columns appear left to right in data-source blocks, each with a colored header stripe identifying its source. Columns for files you have not loaded are absent.

| Column(s) | How to read them |
| --- | --- |
| Ind. / Part Number / Description / Next Higher / Part Type | EBOM identity. Structural part types (COLLECTOR, REFERENCE, BULK MATL) carry a ◆ badge. |
| EBOM Qty / Part Qty Text (EBOM) | Design quantity. On a merged-duplicates row, Qty is the SUM of the source lines and Qty Text shows the last duplicate’s text — when they disagree, the numeric sum is what the engine used. |
| CAGE Code (EBOM) | From v189. The CAGE code on the EBOM line, exactly as the file holds it (3.2). Display only: it plays no part in reconciliation. On a merged-duplicates row it lists every distinct code, separated by “; ”. A dash means the EBOM line has no code. |
| Δ EBOM-ABOM Part Qty | Signed shortfall for quantity-mismatch rows (ABOM qty − EBOM qty; negative = short). In three-way mode the header reads Δ EBOM−MBOM/ABOM and cells prefix MD:/AD: when both deltas exist. A “→ n adj” note shows an SME-accepted residual. |
| MBOM Traceability / MBOM Reconciliation Notes / MBOM Job Number | Which pass(es) the plan satisfied; the distinct MBOM Job Numbers for the line (stacked when plural); and issue badges. |
| MBOM Direct Qty | Planned quantity. Shows **“↑ parent”** in muted italic when the line has no direct quantity of its own. Why it has none is stated in words by the Reconciliation badge on the same row — **↑ PARENT IND. EMBODIED** means it is reconciled through an indenture ancestor; **COLLECTOR (INDENTURE)** means it is a structural row outside reconciliation. Read the badge, not the colour. |
| ABOM Traceability / Reconciliation Notes | The build-side pass results and issue badges. ⚑ badges mark adjudicated legs. |
| ABOM Direct Qty (Roll Up) / ABOM Direct NH | The engine’s net as-built quantity (what checks use) and the Next Higher actually found. A highlighted NH means the part was found under a different parent than designed — expected in many programs, not automatically a defect. |
| ABOM Direct Job Number / WO# / Qty (per WO) / Proc Code / WO Status | The raw as-built records, one embedded line each, aligned across all five columns: each Job Number sits beside its own WO, its raw quantity, its proc code, and that WO’s status. A ⚑ line is an SME-linked WO from a claim. |
| ABOM Used On Job Number / WO# / WO Status | The parent-assembly (Pass 2) work orders, stacked, each Job Number aligned with its WO. One status applies to the whole stack — the engine fills this list from one WO pool at a time. |
| Drawing / Drawing PL Rev / DCN / ECN / ECR (+ statuses) / CHP History | Change-pedigree columns (CHP file). Drawing PL Rev comes from the EBOM. Drawing comes from the CHP file, or from the EBOM under the drawing rule (3.7). CHP History reports DCN release state — see 6.3. |
| ACN Level / ACN Record Number / ACN Record Revision | From the ACN file, to the right of CHP History. An ACN record attaches to every line with its part number, the same join the ACN cards use; an ACN file has no next higher, so a part at several positions shows the same records at each. A part on several ACN records shows one line per record, stacked, with each level beside its own record number and revision. A new revision of the same record is a line of its own. |
| WO Action / WO Serial-Meta | Install/remove actions and serials from the WO5 file. |
| NCR Direct … / NCR Used On … | Nonconformances where this part is the discrepant part (pool 1) or the assembly it was found on (pool 2), with disposition detail. |
| RFV Links / Adj Claims / Overall | ◈ variance links; ⚑ claim badges; and the worst-to-best rollup of every leg. |

## 6.2 Working the table

- **Filter chips and search** narrow rows by status, and the **⚑ Adjudicated** filter appears once any claim is applied.

- **Contextual search** re-frames the table around one part — its ancestors and descendants — with a Relationship column, and has its own Excel export.

- **Click a row to mark it.** The row stays highlighted with a coloured left edge while you scroll sideways, so you do not lose your place on a wide table. Click it again to clear. The mark survives paging and filtering. *(v157)*

- **Hover any badge for an explanation.** Every badge carries a tooltip giving the same description as the Badge Guide. On adjudicated badges the explanation comes first, followed by that row’s specifics — who claimed it, when, the rationale, the WO and NCR numbers. *(v158)*

- **Stacked cells**: multiple values inside one cell (WOs, jobs, per-WO quantities) are embedded rows, aligned line-for-line across neighboring columns so each as-built record reads straight across.

## 6.3 Reading the CHP History badge

The History column reports one thing: whether the product definition data for the line item has been released. That is a question only the **DCN** answers, so only the DCN drives it.

| Badge | What it means |
| --- | --- |
| **RELEASED ⟨date⟩** | Every DCN on the line item carries a release date. With more than one DCN the most recent date is shown, with the count. |
| **NO DCN** | Change history exists but no DCN. Normal, not a defect: a DCN is raised for program-owned IP, and COTS parts appearing on its parts list hold no DCN of their own — they are released by the parent that owns it. |
| **NO HISTORY** | The row matched a reconciled EBOM line, but no DCN, ECN or ECR was found for it. |
| **✗ NO MATCH** | The row has no reconciliation result at all — the part appears in the Change Pedigree extract but corresponds to no reconciled EBOM line. This is about *matching*, not about release; check your extract scope and the Part Number / Next Higher pairing. |
| **⚠ DCN NOT RELEASED** | A DCN carries no usable release date. If your Change Pedigree extract is scoped to released DCNs this cannot occur — so when it fires, the finding is about the extract rather than the part. |
| **ECR ONLY** | Drawing rule only (3.7). Change history was found on this line's drawing, but only an ECR: no DCN or ECN. That is what drawing + ECR extracts carry, so it is not a warning. |
| **NO DRAWING** | Drawing rule only (3.7). The EBOM line has no drawing number in the chosen column, so no change history can be linked to it. Typical of COTS parts. |

Hover the badge for the full DCN / ECN / ECR list with dates and statuses. Under the drawing rule the tooltip also names the drawing the history came through.

**ECN and ECR status never affect this badge.** They answer different questions. An ECN is the change commitment list and closes only after CM has performed CSA, so an open ECN is the expected state for anything you are using Comparator to verify — it is not a defect. An ECR records which request generated the data, which is provenance rather than a problem. Both appear in the tooltip as context.

**Comparator never treats ECN status as evidence of embodiment.** It derives embodiment from the reconciliation itself. That separation is what makes the report in 9.3 possible.

# 7. Drill-Down Windows

Clicking any clickable card opens a window listing the exact rows behind its number — the count in the title always matches the card. Every list window gives you the same three tools:

- **Type-to-filter bar** — filters rows live across every table in the window by any visible text (part number, WO, CI, status), with an “N of M rows match” count. Note rows are never hidden.

- **⬇ Export XLSX** — exports the window’s table(s) to Excel.

- **✕ Close / Esc / click-outside** — Esc closes one layer at a time when windows are stacked.

Issue windows (Missing, Qty Mismatch) also carry a per-row **⚑ Adjudicate** action that opens the claim form pre-filled for that row (Section 8).

# 8. Making Claims — the Adjudication Workbench

The engine reports what the data supports. When you, as the subject-matter expert, know something the data doesn’t show — a part embodied under a work order the ABOM missed, an acceptable quantity variance, a CI-to-NCR relationship — you record it as a **claim**. Claims never alter your raw data or the engine’s raw results; they form a reviewable overlay, and everything they touch is marked **⚑** and tagged “Manual SME” wherever it appears.

## 8.1 The claim workflow

- **Find candidates.** The Workbench’s helper cards surface likely matches: dash-variant part numbers, next-higher near-matches, NCRs lacking an EBOM trace, MBOM/ABOM parts absent from the EBOM. Helpers are informational — nothing happens without your review.

- **File the claim** from a helper row, from an issue window’s ⚑ Adjudicate button, or from the Manual CI Trace form (up to 6 CIs per NCR disposition). Enter your name/role and rationale; claims can carry an SME-linked work order.

- **Process Adjudications.** Claims apply as a batch, rebuilding the overlay from the untouched raw results plus every claim. You can revert to raw at any time.

## 8.2 Where claims show up

Applied claims surface anywhere a status is read: ⚑ badges in the summary table, adjudicated traceability variants, dashed “from SME claims” sub-lines on the cards, the ⚑ filter — and in the Excel reports: the CI report’s two claims sheets, the RFV report’s SME-tagged rows, the Change Commitment reports (closed *or* adjudicated, and carrying no open NCR disposition), and the Planned Not Installed qualifying set and residuals. Headline percentages count adjudicated legs as reconciled.

*Interpretation rule:* the ⚑ marker means a human decision. Auditors can separate machine findings from SME judgment at a glance, and the claims export lists every claim with its author and rationale.

# 9. Reports & Exports

## 9.1 The main comparison exports

**Excel (Comparison Summary, Issues Only, WO Status Not Closed — plus an Audit Certificate sheet once the session is frozen), CSV, and a standalone HTML report.** Once frozen, the CSV and the HTML report open with the same certificate. The Excel and CSV mirror the Detailed View’s columns; the HTML report mirrors the on-screen presentation with stacked cells. One exception: the ACN Level, ACN Record Number and ACN Record Revision columns (from v183 and v184) are in the Excel exports and the context-search export, not yet in the CSV or the HTML report. Where a line has several ACN records, the Excel cells list them separated by semicolons, in the same order in all three columns. The **CAGE Code (EBOM)** column (from v189) is in all of them: the three Excel sheets, the CSV, the HTML report and the context-search export, directly right of Part Qty Text (EBOM). If you open the CSV in Excel, a code such as 1E234 may be read as a number; the Excel export does not have that problem.

**Include raw sheets** adds one sheet per loaded file. Each sheet holds the rows as Comparator read them. For a file loaded through a Manual map or Mapping 2, those rows are in Comparator’s default column positions, and the heading row names the field in each column (3.2).

**Row fanning — read this before counting anything.** Excel cells cannot stack, so the exports *fan*: one row per as-built record, with used-on work orders and MBOM Job Numbers fanned in parallel (a line’s row count is the longest of its lists, times its NCR entries). Two leading columns keep this honest:

- **EBOM Line #** — the permanent line number(s) from your EBOM file. Repeats on every fanned row of the same line; “12; 47” marks a merged duplicate; gaps are excluded lines. On the full Comparison Summary sheet, the highest number equals your EBOM’s true data-row count.

- **Export Row (not a qty)** — reads “Row 2 of 4”: this row’s position within its line’s fan. **Never a quantity.** Filter to “Row 1 of” for one row per line, or pivot on EBOM Line #.

## 9.2 The specialty reports

| Report | What it answers |
| --- | --- |
| CI Traceability Report | The full CSA pedigree per Configuration Item across ~15 sheets: per-line detail, one-row-per-CI summary, embodiment paths, NCR/drawing/change traces, and the two processed-claims sheets. From v189 three sheets carry the EBOM CAGE code: **CI - EBOM Parts Mapping** (CAGE Code, between Part Qty Text and Next Higher Part Number; one row per EBOM line, each with its own code), **CI Traceability Detail** (EBOM CAGE Code, right of EBOM Part Qty Text) and **CSA Pedigree Summary** (EBOM CAGE Code(s), right of EBOM Present; every distinct code across the CI’s part number / next higher combinations). The CI Traceability tab shows the same column. |
| CI As-Built Records Guide | A per-CI yes/no flag matrix (columns F–M) indexing the Traceability Report: physical presence by path, NCR and RFV linkage, manual-trace flags, and overall presence. The legend on the sheet explains each column and how it relates to the dashboard KPIs. |
| RFV Traceability Report | Four sheets: variances matched by part (A), via NCR disposition (B), via work order — physical and SME-linked (C), and unmatched (D). |
| Planned Not Installed | Items complete in the plan (including SME-adjudicated legs) but missing or short in the build — your open-work list. From v189 it carries EBOM CAGE Code, right of EBOM Qty. |
| Unplanned Not Installed | The complement: design lines never planned. Together the two reports partition the gaps. From v189 it carries EBOM CAGE Code, right of EBOM Qty Text. |
| Change Commitment List | ECNs whose entire EBOM footprint is embodied — every affected item under a closed WO or SME-adjudicated, with no open NCR disposition. Recommended closures. See 9.3. |
| ACN Report | Level 4–7 ACN embodiment with per-WO detail and open-NCR exposure. |
| WO5/ABOM Discrepancy, Apex, Ranked WOs, and others | Focused lists exported from their cards and windows; the Ranked Non-Closed WOs report orders open work by how many residual items each WO is gating. |

## 9.3 The two change commitment reports

Both answer questions about ECNs, and both derive embodiment from the reconciliation rather than from what the ECN says about itself.

**Change Commitment List — Recommended Closures.** ECNs that are ready to close. An ECN qualifies only if every item in its footprint is embodied under a closed work order or SME-adjudicated, and carries no open NCR disposition. One open item anywhere excludes the whole ECN.

**Premature ECN Closures — Closed Without Embodiment.** The inverse, and the one that catches process problems: ECNs whose recorded status says closed while their footprint is not fully embodied. Each was closed without the evidence CSA is meant to establish. One row per blocking item, showing the WO status, ABOM status and open dispositions that contradict the closure.

Two things about the footprint are worth knowing:

- **COTS children are included.** A DCN is raised for program-owned IP and its parts list carries COTS parts with no pedigree of their own. Those items inherit the ECN of their nearest ancestor through the EBOM indenture tree, so an unembodied COTS child now blocks its parent ECN. The ECN Linkage column shows whether each item was linked directly or inherited, and from where.

- **ECN status is displayed but never used.** The column is labelled as such. In the first report it is ignored entirely; in the second it is the claim being audited, not an input. An ECN that is correctly closed appears in neither report.

Both need the Change Pedigree and ABOM files loaded. Under the drawing rule of Change Pedigree Alignment (3.7) they need ECNs in the extract: without any, both say *Not available* rather than export an empty report. With ECNs, the footprint is every EBOM line on the ECN's drawings, which can hold an ECN back but never makes a footprint look complete early.

# 10. Saving Your Work — Sessions and the Audit Certificate

## 10.1 Session export / import

**Export Session** writes one JSON file containing everything: your uploaded data, the full results, every claim, your column mappings, your proc code behavior, your indenture scope and, when it is not the default, your Change Pedigree alignment (3.7) and the CI zone's CI Index layout (3.2). From v178 it also records the exact Comparator build that wrote it; sessions saved by v142 through v177 all say “v142”, whichever build actually saved them. **Import Session** restores it exactly — including on a different computer. Very large sessions import in a streaming mode (the tool tells you; allow a minute or two). Sessions saved by older builds import cleanly and gain newer features, such as EBOM line numbers, automatically. One limit: a session saved before v189 under EBOM Mapping 2 or a Manual map shows a blank CAGE Code until you upload the EBOM again and re-run; a session saved under Mapping 1 shows it at once.

## 10.2 Finalize & Freeze

When the reconciliation is done and claims are processed, **Finalize & Freeze** locks the session and produces a **Certificate of Configuration Audit**: auditor name, timestamp, comparison mode, the **build** that computed it, the proc code profile and the removal and swap codes in force, the **EBOM indenture scope**, the **Change Pedigree Alignment** when it is not the default (3.7), the number of claims, and a cryptographic hash. The hash covers the raw results, the effective (adjudicated) results, every claim (including what each claim targets and the quantity it credits), the proc code table, the indenture scope and a non-default Change Pedigree alignment. A certificate from a program on the default alignment has no alignment row and is built exactly as before v182. The build is printed beside the hash rather than inside it: it records where the certificate came from, not what it attests to. Certificates frozen before v178 show the build as “not recorded”. The certificate is identical everywhere it is printed: the Excel exports' Audit Certificate sheet, the top of the CSV export and the HTML report. Two auditors with the same files can reach different numbers if they classified proc codes differently, so that classification is part of what the certificate attests to. A frozen session disables further uploads and re-runs, making the exported record defensible — any change to data or claims after freezing would no longer match the certificate.

# 11. Comparing Two Sessions or Two EBOMs — the Delta Tool

The **Delta tool** is a separate single-file page that ships alongside Comparator. It answers the question a single session cannot: **what changed between two runs, and why?** Like Comparator, it runs entirely in your browser; no data leaves your computer.

The tool has two modes, chosen at the top of the page. **Two sessions** compares two Comparator session files, as described in 11.1 to 11.3. **Two EBOM files** compares two EBOM spreadsheets directly, with no Comparator run (11.4).

In the sessions mode, load the older session as **A** and the newer one as **B** (use ⇄ swap if you load them the wrong way round), press **Run Delta**, and export the report with **⬇ Export Delta Report XLSX**. Sessions of any size open, including very large ones, which stream in the same way they do in Comparator (allow a minute or two).

## 11.1 The six sheets

| Sheet | What it answers |
| --- | --- |
| Summary | The headline numbers for each session side by side, under the same names as the dashboard cards. Percentages show one decimal place here; the dashboard rounds them to whole percent. |
| Build Progress | Every line whose reconciliation status moved, with a **Direction** (Improved / Regressed / Changed) and a **Cause**: Build data, SME adjudication, Both, or Unresolved. |
| EBOM Changes | Design changes: added, removed, re-parented (the same part under a new next higher, reported once rather than as a removal plus an addition), and quantity changes. To compare two EBOM files themselves, with more fields and no Comparator run, use the EBOM mode (11.4). |
| Change Pedigree Delta | New, changed and dropped DCN / ECN / ECR records. The Value Meaning column says whether a value is a DCN release date or an ECN/ECR status. When either session used the drawing rule (3.7), a Via Drawing column names the drawing each record came through. |
| Claims Delta | Claims added, removed or modified, with an **Origin** column so ME-imported claims can be told apart from claims filed in Comparator. A claim counts as modified if anything the Audit Certificate would attest changed: its target, reason, quantity, linked work order row or dispositions, not only its wording. |
| NCR Disposition Delta | New NCRs, new dispositions, status changes and Disposition Code changes, flagged when they trace to an in-scope line item. From the Delta tool’s v3.6 a disposition whose code changed is listed, and an Old Disposition Code column shows the code it had in session A. Codes are compared as the dashboard card compares them: spaces trimmed, letter case ignored. |

## 11.2 When the two sessions are not directly comparable

- **Different comparison modes** stop the delta from running. Statuses from different modes do not mean the same thing.
- **Different proc code tables** or **different indenture scopes** produce a warning, and are named on the Summary. Rows that could have moved because of the rule change rather than the build are marked Cause **Unresolved**, shown in amber rather than the purple kept for human decisions.
- **Different Change Pedigree alignment rules** (3.7) produce a warning, name both rules on the Summary, and put a note on the Change Pedigree Delta sheet: its records can move because of the rule rather than the pedigree. Reconciliation statuses do not depend on the rule, so Build Progress is unaffected. When both sessions use the default, the Summary has no alignment row at all.
- **Session A exported after session B** produces a warning. The delta still runs.

## 11.3 Which build wrote each session

The Summary names the Comparator build behind each session. Sessions saved from v178 onward carry their exact build. Older files show a range — “v142–v177 (exact build not recorded)” — because those builds all wrote the same fixed stamp, and the real build cannot be recovered from the file.

## 11.4 Comparing two EBOM files

Choose **Two EBOM files** at the top of the Delta tool. Load the older EBOM as **A** and the newer one as **B**. Each card has its own **Column mapping**: Mapping 1, Mapping 2 or Manual…, the same choices as Comparator’s EBOM zone (3.2). For Manual…, type the column letter of each field and press **Apply mapping**. Changing a mapping re-reads a loaded file, so there is nothing to re-upload. Press **Run EBOM Delta**, and export with **⬇ Export EBOM Delta XLSX**.

**Each file is read the way Comparator reads an EBOM.** A row with no part number is skipped. Lines with the same part number and next higher are merged into one line item: the quantities are added, the quantity text is the last one in the file, the indenture and drawing PL rev are the first ones, and the CAGE code is every distinct code on the merged lines (from Delta v3.9). So a line item here is the same line item as in Comparator’s Comparison Summary, and line numbers are Comparator’s EBOM Line # (4.4).

**What counts as a change:**

| Change type | Meaning |
| --- | --- |
| Removed | The part number + next higher is in A, not in B. |
| Re-parented | The part moved to a different next higher. It is reported once, not as a removal plus an addition. If a part is under several next highers, positions are matched one to one, in file order. |
| Changed | The same part number + next higher in both files, with a different quantity, quantity text, indenture, drawing PL rev or CAGE code. **Fields Changed** names which. From Delta v3.9 the **Old CAGE Code** and **New CAGE Code** columns show both values; the same set of codes in another order or letter case is not a change. |
| Added | The part number + next higher is in B, not in A. |

A re-parented line also lists any of those four fields that changed with the move. Spelling that Comparator reads as the same is not a change: letter case and spaces in part numbers, 3 written for C in the indenture, or “ar” for AR in the quantity text. **Description is shown but not compared**, so a reworded description is not reported.

**Panels.** Above the tables, a row of panels gives the **Similarity** and the counts: line items that differ, removed, re-parented, changed, added, and change apexes. A strip beneath them shows each kind as its share of all line items. A count of zero stays grey.

**Similarity** is the share of line items that are identical in both files, out of all distinct line items in the two files: unchanged + changed + re-parented + removed + added. A re-parented part counts once. It shows one decimal place, and it never reads 100.0% while anything differs. For example, 7 identical line items out of 13 distinct ones reads 53.8%.

**The report** has three sheets, and the same three tables appear on screen.

- **Summary** names both files and their mappings. It gives the similarity and counts the rows read, line items, each change type, each changed field and the change apexes.
- **EBOM Changes** has one row per line item that differs. Each row has the old and new value of every compared field, the line numbers in each file, and its change apex.
- **Change Apexes** has one row per apex, with what its changed subtree holds (below).

**Row order.** EBOM Changes lists rows in BOM order. That is file B's line order, with each removed line placed just after the line it followed in file A. Several removed lines after the same line keep file A's order. A removed line with nothing before it in A comes first.

**Indenture.** Every row shows **Old Indenture** (file A) and **New Indenture** (file B), as Comparator reads them, so a file that writes 3 shows C. An added line has no old value, and a removed line has no new value.

**Change apex.** This works like Comparator's apex for missing items (5.1), applied to changes. For each line that differs, the tool walks up its next higher, then that line's next higher, and so on, as long as the parent also differs in any way. The highest line it reaches is the **change apex**: the top of that changed subtree. The rules:

- A removed line walks file A's tree. Every other line walks file B's.
- A parent part number at more than one position counts as differing when any of its lines differs.
- The walk stops at an unchanged parent. It also stops at the top of the tree, after 50 levels, or on a part it has already passed, so a malformed tree cannot loop.

On EBOM Changes, **Change Apex** and **Change Apex Next Higher** name each row's apex. **Is Apex** reads Y on the apex's own row. The **Change Apexes** sheet lists each apex in BOM order, with its own change, the number of lines changed in its subtree, and how many of those were removed, re-parented, changed and added. Start a review at the apexes: each one stands for every change beneath it.

If a file has no row with a part number in the mapped column, the tool says so and does not run. That usually means the wrong column mapping is selected.

# 12. Interpreting What You See — Common Questions

### “I only want to know how the EBOM changed between two releases.”

Use the Delta tool’s **Two EBOM files** mode (11.4). It needs only the two EBOM spreadsheets: no MBOM, ABOM or Comparator run.


### “The Excel export has far more rows than my EBOM.”

That is the row fanning (9.1). Count with EBOM Line #, never by counting rows.

### “Two columns disagree about quantity on one row.”

Probably a merged-duplicates row (4.4): EBOM Qty is the sum of the merged lines; Part Qty Text is one line’s text. The sum is what the engine used.

### “A part shows a different Next Higher than designed.”

Manufacturing structure legitimately need not mirror design structure. The parentage highlight is information, not automatically a defect.

### “This program uses proc codes Comparator doesn’t recognize.”

Open the Proc Code Behavior panel under the upload zones (3.3). It lists every proc code in your ABOM; tag the removals and swaps and leave the rest. Until you do, unrecognized codes are treated as installs — which is what the tool has always done — so a removal code left untagged will make parts look present when they were taken out. If someone on your program has already done this, ask them for the profile file and load it.

### “This program’s Change Pedigree has only drawing numbers and ECRs.”

Set **Change Pedigree Alignment** to **Drawing number** (3.7), pick the EBOM column that holds the drawing number, and map the Change Pedigree file's Drawing Number and ECR columns with its Manual map. Expect **ECR ONLY** on most lines and **NO DRAWING** on COTS parts. Remember that an ECR then attaches to every part on its drawing.

### “The per-WO quantities don’t add up to the Roll Up.”

Removals and swaps net out (4.3). The per-WO column shows raw history; the Roll Up shows the effective net.

### “An item is on the WO Not Closed card — is it missing?”

No. It is physically present but its work order isn’t closed. It moves to embodied when the WO closes. A ◈ means the open WO is RFV-authorized — documented, lower priority to chase.

### “Why is a CI on the Missing list when the Guide says it’s present?”

The Guide’s presence columns ignore work-order status; the dashboard’s missing KPI requires a *closed*-WO ancestor. A CI covered only by an open-WO ancestor is “present” in the Guide and still “missing” (pending) on the dashboard — the drill-down flags exactly these.

### “The top-level aircraft row shows COLLECTOR (INDENTURE) — is that a problem?”

No — provided your program does use A and B as roll-up levels. Structural rows are context, deliberately outside reconciliation scope and excluded from every percentage. If your program puts **real parts** at A or B, change which levels are treated as structural in **EBOM Indenture Scope** (3.4) and re-run; those rows will then reconcile like any other.

### “Numbers changed after I processed claims.”

That is the point: adjudicated legs count as reconciled. Every affected surface shows ⚑ provenance, and Revert restores the raw view.

# 13. Symbol & Color Glossary

The **symbols and badge text below are identical in all three themes**. The colour names describe the default dark theme only. In light mode the same categories are rendered in a lower-saturation palette, and in Black & White they are not colour-coded at all — there, the badge label is the identifier. Read the symbol and the words, not the hue, and the table holds everywhere.

| Symbol / color | Meaning — everywhere in the tool |
| --- | --- |
| Green (three tiers) | Reconciled — direct, used-on, ancestor. |
| Amber | Quantity short, or removed from the build by proc code. |
| Orange | Work order not closed (⚠ WO NOT CLOSED). In progress, not final. |
| Red | Missing / failed every path. |
| Purple ⚑ | Manual SME adjudication — a human decision, always attributed. |
| Teal ◈ | RFV — variance coverage or RFV-authorized work orders. |
| Rose | NCR — nonconformance linkage. |
| Gray ◆ | Structural — collectors and excluded part types; outside all counts. |
| ⬇ PROC REMOVED | Proc-removed — net removal from the build, per the proc code behavior in force (3.3). |
| RELEASED / NO DCN | CHP History badge. Design data released (with date), or no DCN on the item — normal for COTS parts released by their parent (6.3). |
| ⚠ DCN NOT RELEASED | CHP History badge. A DCN has no usable release date. On a scoped extract this points at the extract, not the part (6.3). |
| ECR ONLY / NO DRAWING | CHP History badges under the drawing rule only (3.7). History on the line's drawing with no DCN or ECN; or no drawing number on the line to look up. |
| Default / Drawing number | Change Pedigree Alignment panel header (3.7). **Default** = part number + next higher. **Drawing number** = the drawing rule is in force; the panel border turns amber and the rule is named on the certificate. |
| Program baseline / Custom | Proc Code Behavior panel header. **Program baseline** = the shipped proc codes are in force. A profile name or **Custom** = this program has tagged its own; the panel border turns amber and the profile is stamped on exports (3.3). |
| SEE SUMMARY | Raw BOM views. The line has an unresolved reconciliation outcome; open the Comparison Summary for the specific reason. Deliberately neutral rather than a warning — two of the outcomes it covers (SUB/AR absence, proc-code removal) are by design. |
| ✗ NO MATCH | Change Pedigree view. The row has **no reconciliation result at all** — the part is in the CHP extract but does not correspond to any reconciled EBOM line. Distinct from NO HISTORY, which means the row did match but carries no change documents. |
| RECONCILED / OK | Green, no glyph. The line reconciles cleanly — a direct match across the compared BOM legs. As of v157 green badges carry no symbol: green already says “fine”, so glyphs are reserved for states that need a second look. |
| ⊘ REMOVAL ITEM | A removal-scope line, shown for context and outside reconciliation. Before v155 these rows incorrectly showed a green tick. |
| ✓ MATCHED / — UNMATCHED | WO5 and NCR views. Whether the row was matched to a reconciled EBOM line. UNMATCHED points at extract scope or the Part Number / Next Higher pairing. |
| ▲ INSTALLED / ▼ REMOVED | A work-order action on this part, sourced from the ABOM I/R records. |
| ? UNKNOWN | Should never appear. The engine returned a status this build has no label for — please report it with the session file. |
| ⬇ | Export / download, on buttons and menus. As a badge, ⬇ PROC REMOVED means the part was taken out of the build. |
| ↑ parent (muted italic) | The line has no direct quantity of its own on that BOM side. One style on both sides — the reason is in the Reconciliation badge beside it (6.1). Before v155 this carried two colours and the in-tool note described them wrongly. |
| “Roll Up” / “per WO” | Engine net quantity vs. raw per-record quantity (4.3). |
| “Row n of m” | Export fan position — never a quantity (9.1). |

## 13.1 Themes

Comparator ships three themes — **Dark**, **Light** and **Black & White** — chosen from the menu at the top right. The choice affects only your browser: it is not saved in the session file and does not change the Audit Certificate. Themes change nothing about the numbers, the passes, or what any badge means — only how the screen is drawn.

**Dark** is the default, and is what the colour names in the glossary above refer to.

**Light** uses the same category structure in a lower-saturation palette intended for a bright room or a projector. Record-type markers — WO, NCR, CI, RFV — are deliberately quieter there than findings are, because they tell you where a row came from rather than that something is wrong with it.

**Black & White** is black on white. Category colour is dropped almost entirely: every badge is black text in a black rule, and the label alone identifies it. **✗ MISSING** is the one exception — it keeps a fill and a heavier rule, so it cannot be skimmed past. Where a shape has no room for a word — the coverage ladder, the WO status roll-up, the residual block — grey is used as an ordered scale, lightest for clean through darkest for missing, rather than as a set of categories.

Because Black & White identifies by label, it is the theme to use when a result has to survive being printed, photocopied, or read by someone who cannot rely on hue.

# Appendix A — What changed since v155

| Build | Change you will notice |
| --- | --- |
| v156 | One badge size everywhere — OVERALL badges no longer render larger than the ones beside them. **NO HISTORY** is a badge rather than bare text. Three greens, one per embodiment pathway, matching the reconciliation cards. Visible row separators. Bold reserved for the Part Number column and badges. Two text tiers: white for what you compare (part numbers, next highers, quantities, WO numbers and statuses, disposition numbers and statuses, RFV numbers), dim for context. |
| v157 | **Click a row to mark it** while scrolling sideways (6.2). Charts redraw on resize and no longer blur. Green badges lost their glyphs. |
| v158 | **Hover any badge for an explanation** (6.2). The Badge Guide and the tooltips now read the same text, so they cannot disagree. |
| v159 | CI Traceability Report: the two NCR disposition sheets lead with the reader-facing columns and use shortened names — *Disposition Number*, *Disp. Status*, *Disp. Type*, *Disp. Code*, *Defect Code Description*. |
| v160–v161 | **EBOM Indenture Scope** (3.4) — choose which indenture levels are structural roll-ups rather than reconcilable parts; the default A + B is unchanged. Numeric indenture values (1, 2, 3…) are read as A, B, C, so a numeric EBOM behaves identically to an alpha one. The structural badge is now **COLLECTOR (INDENTURE)** rather than COLLECTOR (A/B), since the levels are no longer fixed. |
| v162–v163 | **ME adjudication import** (3.6) — a tenth zone, with manual column mapping, that loads adjudication claims decided in another tool. Position, quantity and leg are inferred from the reconciliation; ambiguous parts go to a picker that shows the relevant narrative sentence. A review panel sorts every row into four buckets and reports the exceptions. Imported claims arrive pending, re-importing replaces the batch, and CI-to-NCR tracing is protected from both. |
| v164 | Fixes a defect that prevented comparisons running at all: a helper added in v160 was missing from the bundle sent to the background worker. Upload zone tags and the column-mapping help icon are uniform across all ten zones again. |
| v165 | Fixes staged import claims leaving **Process Adjudications** greyed out: staging now opens and refreshes the Adjudication Workbench the same way a claim filed inside Comparator does. |
| v166 | The adjudication import moved out of the upload grid and into the **Adjudication Workbench**, between the Candidates Helpers and the newly-named **Claim Ledger**. It is a batch of claims about a completed run, not a tenth BOM source, and the workbench does not exist until a run has happened — so the ordering is now enforced by where the control lives. |
| v167–v168 | **Job Number search** on the Comparison Summary, MBOM and ABOM tables. A **Has RFV** filter, and the RFV pass badges made uniform and documented for the first time. The Imported Claims block enclosed and made responsive, with re-staging that preserves already-applied claims. Column-mapping notes no longer overflow their modal. The funnel legend now draws real colour swatches taken from the chart’s own tokens — five of its six emoji swatches were wrong, including reference bars shown as coloured when they are deliberately neutral. |
| v169–v170 | Fixes from checkout: the **Has RFV** filter now appears whenever any line carries variance coverage, and shows its count like every other filter — it had been gated on the RFV file being loaded rather than on there being anything to find. The MATCH PASS badges in the RFV Information view are now dim to match the rest, except the SME-linked pass, which keeps the manual-provenance purple used throughout the tool. A duplicated Candidates Helpers heading removed. |
| v171 | The import review panel now updates when claims are processed, reverted or removed. It had reported “none applied yet” indefinitely because nothing refreshed it after **Process Adjudications**. |
| v172 | Fixes a defect that removed the counts from **every** filter button in the Comparison Summary and prevented the **Has RFV**, **Removal Items** and **Proc Removed** filters from appearing at all. |
| v173 | Every colour in the build routes through the theme palette rather than being written into a rule, so light and high contrast (now labelled Black & White) stop inheriting dark-mode values. |
| v174 | **Light mode redrawn**: panels lift off the page, the palette is desaturated, and section headings drop from TRACKED CAPITALS to sentence case. Twenty-eight places that still carried dark-mode colour were corrected, including the exported report, which had been frozen in the dark palette. |
| v175 | **High contrast reworked** (the theme now labelled Black & White). Badges are black on white and identified by their label; ✗ MISSING alone keeps a fill. Filled shapes moved to their own palette entries so charts and ladders stay readable without making badge text illegible. Fourteen tooltips that named a colour — “teal ◈”, “shown in purple” — now name the marker or the tag instead. |
| v176 | Removes a chart renderer that stopped being called at v47.1 and had been carried unused since. |
| v177 | **A calmer screen.** KPI cards show the number and its label only: the bar under each percentage is gone, because these cards report a finding about the configuration, not progress towards a target. The header's Jump to links are plain text, with the current section underlined. Panels, toolbars and labels share one consistent style. |
| v178 | **Provenance you can trust.** Session files and the Audit Certificate record the exact build that produced them; sessions saved by v142 through v177 all said “v142”, and the Delta tool now labels those as “v142–v177 (exact build not recorded)”. The Audit Certificate sheet is identical in every export and includes the build (the CI Traceability Report's copy had listed the indenture scope twice and left out the proc code rows). The certificate's integrity hash covers every claim field and the indenture scope. The ME ADJ column mapping is saved with the session. ME-imported claims show “ME adjudication import” as their source in the CI Traceability Report. The Proc Removed window uses the same ⬇ as its badge. The Delta tool, from its v3.4, opens sessions of any size, compares claims on every field the certificate attests, shows each claim's origin, and names its numbers as the dashboard does. |
| v179 | The CSV export and the HTML report now carry the full certificate — build, proc code profile, removal and swap codes, indenture scope — not only auditor, date, mode and code. Seven small labels (the loaded tick on each upload zone, “Column mapping”, the re-upload hint, the proc code panel's column headings and “spellings merged” note, the column-map status tags, and “View adjudication candidates”) are one size larger and easier to read. |
| v180 | **Easier to read throughout.** Every small label now uses one shared text scale with an 11px minimum, so no panel can fall below it — this lifts the EBOM traceability funnel, the Proc Code Behavior and EBOM Indenture Scope panels, the restore-a-session hint, the ranked non-closed WOs card, the Claim Ledger buttons, the Exports & Reports menu and the SME adjudication banner. The faintest grey has been removed, so all secondary text is readable in every theme; faded funnel labels and faded pass-2 cells in the Comparison Summary are no longer faded; counts on coloured bars stay readable in the light theme; and the funnel’s grey reference bars now have an outline so they can be seen. The Comparison Summary table is wider as a result and scrolls further sideways. |
| v181 | **Funnel bar counts are readable at every bar length.** The percentage and count on the Direct, Used-On and Ancestor bars were grey on green on shorter bars. The count now sits on the bar in a dark (or, in light and Black & White, white) ink when it fits, and just past the end of the bar in normal text colour when it does not; which one applies is worked out from the actual width, so it stays correct when the window is resized. On very narrow windows, where there is room for neither, the figures are in the bar’s hover tooltip. Hovering a bar now outlines it instead of brightening it. |
| v182 | **Change Pedigree Alignment** (3.7). A per-program setting for programs whose Change Pedigree extract carries only drawing numbers and ECRs: an ECR attaches to every EBOM line on its drawing, matched exactly on the drawing number (optionally drawing number + revision), with the EBOM drawing column picked from the file's own headers. Two new History badges, **ECR ONLY** and **NO DRAWING**. The ECN reports say *Not available* when the extract has no ECNs. The rule travels in the session, is named on the certificate and inside its hash, returns to the default on Reset, and is compared by the Delta tool from its v3.5. **Programs on the default rule see no change:** every output was compared with v181 and is identical, and the certificate carries no new row. Inside the build, the twelve places that each worked out the Change Pedigree join now share one module. |
| v183 | **ACN Level and ACN Record Number** in the Comparison Summary, to the right of CHP History, whenever an ACN file is loaded. The same two columns are in the Excel export's Comparison Summary, Issues Only and WO Status Not Closed sheets and in the context-search export. They use the part-number join the ACN cards already used. Nothing else changes: with no ACN file loaded, every output is identical to v182. |
| v184 | **ACN Record Revision** added as a third ACN column, to the right of ACN Record Number, on screen and in the same Excel exports. A new revision of the same ACN record is listed as its own entry. With no ACN file loaded, every output is identical to v183. |
| v185 | **Three display fixes.** In the funnel’s Reference — full per-leg KPI totals, the Part Qty Mismatch and Part WO Not Closed bars are now drawn as a share of Active Scope, and each reads its count and percent of scope. The NCR Disp # and RFV # search boxes on the Comparison Summary lost their coloured outlines, so every search box there looks the same. The WO status roll-up bar chart is replaced by one thin strip and a short list of statuses with counts, percents and RFV-authorized counts; it takes far less space. No result, export or report changes. |
| v186 | **NCR by disposition code** (5.4): a new card between NCR by cause code and NCR disposition status that counts NCR disposition entries for each Disposition Code. **Manual column mapping on the CI and RFV zones** (3.2), with the same Default / Manual control and window as NCR and ACN; the maps travel in the session and return to Default on Reset. The Delta tool, from its v3.6, reports Disposition Code changes. With the CI and RFV zones on Default, every output is identical to v185. |
| v187 | **Headings that match the data.** Under a Manual map or Mapping 2, the EBOM, MBOM, ABOM, Change Pedigree and NCR tabs and the Excel export’s raw sheets now head each column with the field it holds, and **—** where no field sits (3.2). They had printed the file’s own headings over the re-arranged columns. The column-letter box in every mapping window is wider, so its default letter can be read. A file loaded in its own layout shows no change, and every default output is identical to v186. |
| v188 | **NCR by cause code is a count list** like NCR by disposition code (5.4): every cause code, with its description and count, instead of a bar chart of the top 6. The three NCR cards now stay side by side down to a window width of about 900px. The NCR disposition status colours now follow a theme change at once; they had kept the previous theme’s colours until the next run. The build file is now named **comparator_offline84.html**. No result, export or report changes. |
| v188 + Delta v3.7 | **The Delta tool compares two EBOM files** (11.4): load two EBOM spreadsheets, with no Comparator run, and get the line items removed, re-parented, changed (quantity, quantity text, indenture, drawing PL rev) and added. Comparator itself does not change. |
| v188 + Delta v3.8 | **EBOM delta: panels, similarity, BOM order and change apexes** (11.4). Panels with the change counts and a similarity percentage; EBOM Changes in BOM order; each row’s change apex (the top of its changed subtree) and a Change Apexes sheet. |
| v189 | **CAGE code** (3.2), with Delta tool v3.9. The EBOM’s CAGE code is read from column Q (Mapping 1), column G (Mapping 2) or a column you pick in the Manual window. It appears in the Comparison Summary right of Part Qty Text (EBOM) and in its context-search export; on all three sheets of the Excel export, in the CSV and in the HTML report; on the CI - EBOM Parts Mapping, CI Traceability Detail and CSA Pedigree Summary sheets and the CI Traceability tab; on the EBOM Full tab; and in the Planned and Unplanned Not Installed reports. It is display information: results, KPIs and the certificate hash do not change. The Delta tool’s EBOM comparison reports a CAGE code change. |
| v190 | **CI Status without an ABOM** (5.3). The CI Status section now appears whenever a CI file is loaded. Before v190 it needed an ABOM too, so in EBOM↔MBOM mode even CI Scope and CIs Missing from EBOM were hidden. A new **CI · MBOM — Planned** block shows whether the plan captures each CI, by the EBOM·MBOM section’s own rules; in Full mode it sits above the ABOM block. The ABOM, NCR and RFV CI cards show only with an ABOM. Fixed with it: the **NCR Dispositions Without EBOM Trace Helper** card (Adjudication Workbench) appeared only when both a CI file and an ABOM were loaded, and the **CI Status** link in the header could point at a hidden section. No result, export, report or certificate changes. |
| v191 | **The CI zone reads the CI Index tool's export** (3.2). A **CI Index** button beside Default and Manual reads the CI Index and PN Variants sheets by heading. Each Active CI loads once per position and per PN variant. Proposed, retired and Collector CIs are left out, and an NH PIN of N/A loads blank. Default and Manual refuse the export and point to the button. Nothing changes for a CI list read by Default or Manual: every default output is identical to v190. |

*Guide prepared against build v191 and Delta tool v3.9, November 2026. The in-tool Explanation buttons are updated with every build and are the authoritative reference where this document and the tool ever differ.*
