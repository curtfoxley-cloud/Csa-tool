#!/usr/bin/env node
/**
 * comparator-tests.js — complete, self-contained test harness for Comparator.
 *
 *   node comparator-tests.js [path-to-build.html]
 *
 * Finds the highest-numbered ./comparator_offline*.html, then ../ .
 * Node only: no install, no network, no other files. 94 tests.
 *
 * WHY ONE FILE: Comparator ships as a single self-contained HTML, and this
 * harness follows suit so it can live in a Project alongside it. An earlier
 * split-file version was lost between sessions, taking 72 tests with it.
 *
 * HOW IT WORKS: the build's testable functions are lifted out of the HTML by
 * marker, then evaluated in a per-suite sandbox that stubs the browser globals
 * they touch (document, state, COL, XLSX...). Each suite gets its own sandbox
 * because the modules expect different COL shapes.
 *
 * IF EXTRACTION FAILS: the error names the marker that moved. The build was
 * refactored; update the marker below. Failing loudly is deliberate — an empty
 * module would let every suite pass while testing nothing.
 */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');

// Explicit argument or env var wins. Otherwise find the HIGHEST-numbered
// comparator_offline*.html in ./ or ../ — so a version bump does not require
// editing this harness, and a stale older build sitting beside a new one is
// not silently picked up. The version-pin test still catches a wrong build.
function discover(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => /^comparator_offline\d+\.html$/.test(f))
      .sort((a, b) => parseInt(b.match(/\d+/)[0], 10) - parseInt(a.match(/\d+/)[0], 10))
      .map(f => path.join(dir, f));
  } catch (e) { return []; }
}
// v179 — flags are not paths. --browser adds the browser suite (see below).
const ARGS = process.argv.slice(2);
const BROWSER_RUN = ARGS.includes('--browser');
const CANDIDATES = [ARGS.find(a => !a.startsWith('--')), process.env.COMPARATOR_BUILD].filter(Boolean)
  .concat(discover(__dirname), discover(path.join(__dirname, '..')));
const BUILD = CANDIDATES.find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
if (!BUILD) {
  console.error('Build HTML not found. Looked for comparator_offline*.html in:\n  ' +
                __dirname + '\n  ' + path.join(__dirname, '..') +
                '\nPass one: node comparator-tests.js path/to/comparator_offline54.html');
  process.exit(1);
}
const SRC = fs.readFileSync(BUILD, 'utf8');

// The delta tool is a SECOND shipped file that carries its own copy of
// PROC_CODE_BASELINE. Nothing checked the two for drift until v154.
function discoverDelta(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => /^comparator_delta_v[\d_]+\.html$/.test(f))
      .sort((a, b) => (b.match(/[\d_]+/)[0].replace(/_/g, '.') * 1) -
                      (a.match(/[\d_]+/)[0].replace(/_/g, '.') * 1))
      .map(f => path.join(dir, f));
  } catch (e) { return []; }
}
const DELTA = [process.env.COMPARATOR_DELTA].filter(Boolean)
  .concat(discoverDelta(path.dirname(BUILD)), discoverDelta(__dirname),
          discoverDelta(path.join(__dirname, '..')))
  .find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
if (!DELTA) {
  console.error('Delta tool not found. Looked for comparator_delta_v*.html beside the build.\n' +
                'Set COMPARATOR_DELTA=path to point at it.');
  process.exit(1);
}
console.log('Delta tool under test: ' + DELTA);
const DSRC = fs.readFileSync(DELTA, 'utf8');
console.log('Build under test: ' + BUILD + '\n');

// ── extraction ─────────────────────────────────────────────────────────────
// EVERY boundary goes through at() / lastAt() / span(). A raw SRC.indexOf that
// misses returns -1, and -1 silently becomes a zero-length or inverted slice —
// which is the empty module this harness exists to prevent. v154 closed four
// such holes; the 'Tier 2 — extraction integrity' suite keeps them closed.
function at(marker, from) {
  const i = typeof marker === 'string'
    ? SRC.indexOf(marker, from || 0)
    : (function () { const m = SRC.slice(from || 0).match(marker); return m ? m.index + (from || 0) : -1; })();
  if (i < 0) throw new Error('BUILD MARKER MOVED: ' + marker);
  return i;
}
function lastAt(marker, before, label) {
  const i = SRC.lastIndexOf(marker, before);
  if (i < 0) throw new Error('BUILD MARKER MOVED (searching backwards from ' +
                             (label || before) + '): ' + marker);
  return i;
}
// A named slice that refuses a degenerate result. `label` is what gets printed,
// so a failure says which module lost its boundary rather than surfacing later
// as "P is not defined" inside an unrelated suite.
const MIN_SPAN = 200;
function span(a, b, label) {
  if (b <= a) throw new Error('BUILD MARKERS CROSSED for ' + label + ': end (' + b +
    ') is not after start (' + a + '). The build was reordered — fix the markers.');
  const s = SRC.slice(a, b);
  if (s.length < MIN_SPAN) throw new Error('MODULE SLICE TOO SMALL for ' + label +
    ': ' + s.length + ' chars, expected at least ' + MIN_SPAN + '.');
  return s;
}
function grabFrom(src, name, label) {
  const i = src.indexOf('function ' + name + '(');
  if (i < 0) throw new Error('BUILD MARKER MOVED in ' + (label || 'build') +
                             ': function ' + name);
  let d = 0, k = src.indexOf('{', i);
  if (k < 0) throw new Error('NO BODY FOUND for function ' + name);
  for (;; k++) {
    if (k >= src.length) throw new Error('UNBALANCED BRACES while reading function ' + name);
    if (src[k] === '{') d++; else if (src[k] === '}') { d--; if (!d) break; }
  }
  return src.slice(i, k + 1);
}
function grabFn(name) { return grabFrom(SRC, name, 'main build'); }
function grabDelta(name) { return grabFrom(DSRC, name, 'delta tool'); }
const MOD = {};
try {
{ // proc code table + behaviour panel
  const a = at('const PROC_CODE_BASELINE = {');
  const g = at('function getProcBehavior');
  const b = at('}', at('return PROC_CODE_EXCEPTIONS', g)) + 1;
  const m1 = at(/\/\/ ═+\n\/\/ v\d+ — PROC CODE BEHAVIOR PANEL/);
  const m2 = at('// ── EBOM manual column mapping (proof of concept)', m1);
  MOD.proc = span(a, b, 'proc:table') + '\n' + span(m1, m2, 'proc:panel') + `
globalThis.P = { abomProcCodeInventory, _procRowHtml, _procHeaderRow, PROC_JOB_SAMPLES,
  get PROC_CODE_EXCEPTIONS(){return PROC_CODE_EXCEPTIONS;},
  get PROC_CODE_BASELINE(){return PROC_CODE_BASELINE;},
  get dirty(){return _procDirtySinceRun;}, set dirty(v){_procDirtySinceRun=v;},
  setProcCodeMap, setProcCodeBehavior, getProcBehavior, isProcMapCustom,
  _procProfileLabel, _procCodesWithBehavior, _procCodeListText,
  exportProcProfile, importProcProfile, resetProcCodesToBaseline, _procMapEqualsBaseline,
  toggleProcCodePanel, renderProcCodePanel };`;
}
// v154 — buildEbomIndentureMap is now lifted from the build. It used to be a
// six-line stand-in written into the sandbox, and the ECN inheritance suites
// were certifying that stand-in rather than the shipping function. The two
// diverge on a self-referencing row (PN === NH), which is a real extract defect.
// v159 — the reconciliation ENGINE, plus every builder needed to feed it. The
// engine is pure (one params object in, results out, no globals, no DOM) and
// was completely untested until now: 543 lines deciding whether a part is
// reconciled, with every existing suite testing only the code AROUND it.
MOD.engine = (function () {
  // The status sets the rollup consults, lifted with the functions that use them.
  const sets = ['_STATUS_DIRECT_OK', '_STATUS_COVERED', '_STATUS_ADJUDICATED_LEAF']
    .map(n => { const a = at('const ' + n + ' = new Set([');
                return SRC.slice(a, at(']);', a) + 3); }).join('\n');
  // v159 — the engine's priority ladder, isolated so it can be compared with the
  // copy in computeEffectiveResults. Bounded at the Pass 3 fallback, which is
  // NOT part of the ladder: it depends on pool membership, not on leg statuses.
  const eng = grabFn('runReconciliationCore');
  const la = eng.indexOf('var legs = [];');
  const lb = eng.indexOf('// Pass 3 fallback', la);
  if (la < 0 || lb < la) throw new Error('BUILD MARKER MOVED: the engine rollup ladder');
  const ladder = 'function engineLadder(ms, as_, msUsedOn, asUsedOn) { var overall;' +
                 eng.slice(la, lb) + '\nreturn overall; }';
  return sets + '\n' +
    ['normPN', 'normIndenture', 'buildQtyMap', 'buildAbomMap', 'buildEbomIndentureMap',
     'buildAbomUsedOnMap', 'buildMbomUsedOnMap', 'getProcBehavior',
     'runReconciliationCore', 'computeEffectiveResults'].map(grabFn).join('\n') +
    '\n' + ladder +
    '\nglobalThis.E = { normPN, normIndenture, buildQtyMap, buildAbomMap, buildEbomIndentureMap,' +
    ' buildAbomUsedOnMap, buildMbomUsedOnMap, runReconciliationCore,' +
    ' computeEffectiveResults, engineLadder,' +
    ' get _STATUS_DIRECT_OK(){return _STATUS_DIRECT_OK;} };';
})();
// The delta tool's pure comparison layer. Its own file, its own baseline copy.
MOD.delta = (function () {
  // `var` here, `const` in the main build — hence the tolerant marker.
  const m = DSRC.match(/(?:var|const|let)\s+PROC_CODE_BASELINE\s*=\s*\{/);
  if (!m) throw new Error('BUILD MARKER MOVED in delta tool: PROC_CODE_BASELINE');
  const i = m.index;
  const j = DSRC.indexOf('}', i) + 1;
  // Status/column constants the report layer depends on.
  function constBlock(name) {
    const m = DSRC.match(new RegExp('(?:var|const|let)\\s+' + name + '\\s*=\\s*\\{'));
    if (!m) throw new Error('BUILD MARKER MOVED in delta tool: ' + name);
    const end = DSRC.indexOf('}', m.index);
    if (end < 0) throw new Error('unterminated ' + name + ' in delta tool');
    return DSRC.slice(m.index, end + 1) + ';';
  }
  const FNS = ['dNorm', 'normPN', 'pct', 'procTableOf', 'procProfileLabel', 'procTableDiff',
               'claimSig', 'claimRow', 'claimsDelta',
               'fscope', 'modeHasMbom', 'modeHasAbom', 'computeKpis', 'countByType',
               'ebomChanges', 'chpBom', 'ncrDispositionDelta',
               'collectorLevelsOf', 'collectorScopeLabel', 'indentureScopeDiff',
               'indentureContext'];
  return DSRC.slice(i, j) + ';\n' +
    ['DIRECT_OK', 'COVERED_OK', 'SCOPE_EXCLUDED', 'NCR_COL'].map(constBlock).join('\n') + '\n' +
    FNS.map(grabDelta).join('\n') +
    '\nglobalThis.D = { ' + FNS.join(', ') + ',' +
    ' get PROC_CODE_BASELINE(){return PROC_CODE_BASELINE;},' +
    ' get NCR_COL(){return NCR_COL;} };';
})();

// v159 — session restore. importSessionJson is async and DOM-heavy, but the
// STATE RESTORE — the part that reconstitutes an audit artefact — is the first
// 96 lines and runs unmodified against a stub document. Extracted as a function
// so the real code is exercised rather than a paraphrase of it.
// v162 — ME adjudication import. Pure planning layer: rows + results in, a plan
// out. Extracted with the overlay so a plan can be driven all the way through
// computeEffectiveResults in one sandbox.
MOD.adjimport = (function () {
  const a = at('// ── v162 — ME ADJUDICATION IMPORT');
  const b = at('// ── v162 — ME ADJUDICATION IMPORT: UI');
  const colA = at('const COL = {');
  const colB = at('};', colA) + 2;
  const sets = ['_STATUS_DIRECT_OK', '_STATUS_COVERED', '_STATUS_ADJUDICATED_LEAF']
    .map(n => { const i = at('const ' + n + ' = new Set(['); return SRC.slice(i, at(']);', i) + 3); }).join('\n');
  return SRC.slice(colA, colB) + '\n' + sets + '\n' + grabFn('normPN') + '\n' +
    SRC.slice(a, b) + '\n' + grabFn('computeEffectiveResults') +
    '\nglobalThis.IMP = { COL, scanNarrative, resolveImportedAdjRow, buildImportedClaims,' +
    ' replaceImportedClaims, partitionClaims, isImportedClaim, indexResultsByPn,' +
    ' planAdjImport, finalizeAdjImport, computeEffectiveResults };';
})();

MOD.session = (function () {
  const imp = grabFn('importSessionJson');
  const a = imp.indexOf('state.mode = payload.mode');
  const b = imp.indexOf('clearNearMatchCache()');
  if (a < 0 || b < a) throw new Error('BUILD MARKER MOVED: the session restore block');
  return grabFn('_cloneResultRow') + '\n' +
    'function restoreSession(payload) {' + imp.slice(a, b) + '}\n' +
    'globalThis.SS = { restoreSession };';
})();

// CHP release-state badge. Pure, and it drives a user-visible warning plus the
// release date printed on the freeze certificate.
MOD.chp = grabFn('_chpParseReleaseDate') + '\n' + grabFn('formatDcnDate') + '\n' +
  grabFn('chpReleaseState') + '\n' + grabFn('chpStateClass') + '\n' +
  '\nglobalThis.C = { _chpParseReleaseDate, formatDcnDate, chpReleaseState, chpStateClass };';
{ // ECN footprints
  const hit = at(/\/\/ v\d+ — ECN FOOTPRINT \(B1 \/ B2 \/ B4\)/);
  const a = lastAt('// ═══', hit, 'ECN FOOTPRINT header');
  MOD.ecn = span(a, at('function exportChangeCommitmentClosures()'), 'ecn:footprints') + '\n' +
    span(at('function _ecnStatusLooksClosed('), at('function exportPrematureEcnClosures('), 'ecn:status') +
    '\nglobalThis.B = { buildEcnFootprints, _chpEcnItemIndex, _ecnOpenDispositions, _ecnStatusLooksClosed };';
}
// v182 — CHANGE PEDIGREE ALIGNMENT. The one place that reads the CHP join
// columns, plus the worker-safe drawing builder that sits just above it. Taken
// as a span, so everything the build puts between the two markers is tested.
// grabFn('chpTraceTooltip') and friends come along because the history badge
// wrapper calls them.
MOD.chpalign = span(at('// ── v182 — CHANGE PEDIGREE ALIGNMENT: DRAWING RULE (worker-safe)'),
                    at('// ── v182 — CHANGE PEDIGREE ALIGNMENT: END'), 'chpalign') + '\n' +
  ['buildChpTraceMap', 'chpTraceTooltip', 'colIndexToLetter', 'getModeRequired', '_suppManualFieldDefsBase',
   // v187 — the CHP tab headings go through the shared re-laid-rows heading.
   'sourceHeaderLabel', '_sourceIsReLaid', '_sourceFieldDefs', '_ebomFieldDefs', '_bomManualFieldDefs'].map(grabFn).join('\n') +
  '\nglobalThis.CA = { CHP_ALIGN_DEFAULT, chpAlignRule, isChpAlignCustom, _chpAlignSanitize,' +
  ' _chpAlignForSession, _chpAlignRuleLabel, _chpAlignLabel, _chpIngestKeyCol, _chpRequiredMapKeys,' +
  ' _ebomSourceRows, chpAlignRunBlocker, chpEbomDrawingIndex, chpAlignEnginePlan, chpAttachVia,' +
  ' _chpDwgKey, buildChpTraceMap, buildChpTraceMapByDrawing, chpEntry, chpDrawingForLine,' +
  ' chpEntriesForCiTrace, chpEntriesForLineExact, chpEntriesForPn, chpResultForChpRow,' +
  ' chpEcnItemIndex, chpEcnItemKeysOf, chpDocLookup, chpEcnReportUnavailable, chpHistoryState,' +
  ' chpHistoryTooltip, chpAlignStats, chpAlignFreezeBlocker, chpAlignMarkRun, chpViaText,' +
  ' setChpAlignRule, setChpAlignCol, setChpAlignMatchRev, resetChpAlign, renderChpAlignPanel,' +
  ' _chpResultsAreDrawingRule, chpRowSearchText, chpAlignMarkImported, chpTabHeaderLabel };';
// v191 — the CI INDEX LAYOUT: the pure reader of a CI Index export, from its
// marker to the UI marker, so everything the build puts between them is tested.
MOD.ciindex = span(at('// ── v191 — CI INDEX LAYOUT ──'), at('// ── v191 — CI INDEX LAYOUT: UI'), 'ciindex') + '\n' +
  grabFn('normPN') +
  '\nglobalThis.CX = { CI_INDEX_COPY, CI_INDEX_HEADINGS, CI_INDEX_REQUIRED, CI_INDEX_ACTIVE, CI_INDEX_COLLECTOR,' +
  ' ciIndexSheetNames, ciIndexHeader, ciIndexLooksLikeExport, buildCiRowsFromCiIndex,' +
  ' ciIndexSummaryText, ciIndexSummaryLine };';
{ // untraced NCR dispositions
  const a = at('function computeUntracedNcrs()');
  const b = at(/\/\/ ── v\d+ — NCR DISPOSITIONS WITHOUT EBOM TRACE \(EXPORT\)/, a);
  const c = at('function exportUntracedNcrDispositions()');
  MOD.ncr = span(a, b, 'ncr:helper') + '\n' + span(c, at('// ── ACN KPI HELPER', c), 'ncr:export') +
    '\nglobalThis.N = { computeUntracedNcrs, exportUntracedNcrDispositions };';
}
} catch (e) {
  // Fail loudly, in words, and stop. A partial extraction is worse than no run:
  // in v153 a moved marker produced "21 passed, 5 failed" while 33 tests never
  // executed at all — a plausible-looking summary hiding a third of the suite.
  console.error('═'.repeat(60));
  console.error('EXTRACTION FAILED — NO TESTS WERE RUN.');
  console.error('');
  console.error('  ' + e.message);
  console.error('');
  console.error('The build was refactored and a marker in this harness needs');
  console.error('updating. This is not a fault in the build. Fix the marker in');
  console.error('the extraction block near the top of comparator-tests.js.');
  console.error('═'.repeat(60));
  process.exit(1);
}

// v154 — REAL stylesheet blocks. The old code used SRC.indexOf('<style'),
// which matches `<style:master-page` — an OpenDocument XML tag inside the
// vendored SheetJS library on line 28. The "stylesheet" every CSS test scanned
// was therefore ~58KB of minified JavaScript with the real CSS appended. That
// is where the mysterious -2 brace baseline came from: JS object literals, not
// CSS. Requiring `>` or whitespace after the tag name excludes the XML tags.
const STYLE_BLOCKS = (function () {
  const out = [];
  const re = /<style(?:\s[^>]*)?>([\s\S]*?)<\/style>/g;
  let m;
  while ((m = re.exec(SRC))) out.push({ css: m[1], at: m.index,
                                        line: SRC.slice(0, m.index).split('\n').length });
  if (!out.length) throw new Error('NO STYLE BLOCK FOUND — the build has no <style> tag?');
  return out;
})();

// Comment- and string-aware brace scan. Returns the LINE NUMBERS of unmatched
// braces rather than a net delta, so a failure says where to look. A net delta
// can also be zero when one stray `{` and one stray `}` cancel out.
// ── Palettes ────────────────────────────────────────────────────────────────
// v173. The build ships three: :root (dark, the source of truth) plus a
// [data-theme=...] block per alternative. Every colour test below reads from
// here rather than scanning the stylesheet flat, because a flat scan silently
// takes the LAST definition of each token — with three palettes in the file
// that is whichever theme happens to be written last, and every assertion
// about "the palette" would then be an assertion about the mono greys.
const PALETTES = (function () {
  const css = STYLE_BLOCKS.map(b => b.css).join('\n');
  const read = (sel, label) => {
    const k = css.indexOf(sel);
    if (k < 0) throw new Error('PALETTE MISSING: ' + label + ' (' + sel + ')');
    let d = 0, s = css.indexOf('{', k);
    if (s < 0) throw new Error('PALETTE HAS NO BODY: ' + label);
    for (let i = s; i < css.length; i++) {
      if (css[i] === '{') d++;
      else if (css[i] === '}' && --d === 0) {
        const body = css.slice(s, i);
        const t = {};
        for (const m of body.matchAll(/(--[\w-]+)\s*:\s*(#[0-9a-fA-F]{6})\b/g))
          t[m[1]] = m[2].toLowerCase();
        if (Object.keys(t).length < 20)
          throw new Error('PALETTE TOO SMALL: ' + label + ' defines only ' +
                          Object.keys(t).length + ' colour tokens');
        return t;
      }
    }
    throw new Error('UNBALANCED PALETTE BLOCK: ' + label);
  };
  return { dark: read(':root', 'dark'),
           light: read('[data-theme="light"]', 'light'),
           mono: read('[data-theme="mono"]', 'mono') };
})();
// Reads the exported-palette list out of the build rather than restating it
// here, so the two cannot disagree without the parity test noticing.
function PALETTE_TOKENS_IN_BUILD() {
  const m = SRC.match(/const PALETTE_TOKENS = \[([\s\S]*?)\];/);
  if (!m) throw new Error('BUILD MARKER MOVED: const PALETTE_TOKENS');
  return [...m[1].matchAll(/'(--[\w-]+)'/g)].map(x => x[1]);
}
const LUM = h => 0.2126 * parseInt(h.slice(1, 3), 16) +
                 0.7152 * parseInt(h.slice(3, 5), 16) +
                 0.0722 * parseInt(h.slice(5, 7), 16);
// v180 — WCAG contrast ratio between two #rrggbb colours (1 to 21). LUM
// above is a rough 0-255 brightness used for ordering; this is the real ratio.
const CONTRAST = (a, b) => {
  if (!a || !b || !/^#[0-9a-f]{6}$/i.test(a) || !/^#[0-9a-f]{6}$/i.test(b)) return NaN;
  const rl = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255)
    .map(c => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4))
    .reduce((acc, c, i) => acc + c * [0.2126, 0.7152, 0.0722][i], 0);
  const x = rl(a), y = rl(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
};
// v180 — the type-scale tokens the exported report is given alongside the palette.
function TYPE_SCALE_TOKENS_IN_BUILD() {
  const m = SRC.match(/const TYPE_SCALE_TOKENS = \[([^\]]*)\]/);
  return m ? [...m[1].matchAll(/'(--[\w-]+)'/g)].map(x => x[1]) : [];
}

function scanCss(text) {
  let i = 0, line = 1; const open = [], close = [];
  while (i < text.length) {
    const c = text[i];
    if (c === '\n') { line++; i++; continue; }
    if (c === '/' && text[i + 1] === '*') {                       // comment
      const e = text.indexOf('*/', i + 2);
      line += (text.slice(i, e < 0 ? text.length : e).match(/\n/g) || []).length;
      i = e < 0 ? text.length : e + 2; continue;
    }
    if (c === '"' || c === "'") {                                 // quoted string
      const q = c; i++;
      while (i < text.length && text[i] !== q) {
        if (text[i] === '\\') i++;
        if (text[i] === '\n') line++;
        i++;
      }
      i++; continue;
    }
    if (c === '{') { open.push(line); i++; continue; }
    if (c === '}') { open.length ? open.pop() : close.push(line); i++; continue; }
    i++;
  }
  return { unmatchedOpen: open, unmatchedClose: close,
           balanced: !open.length && !close.length };
}

// What each module must contain and must define once evaluated. Checked by the
// 'Tier 2 — extraction integrity' suite, so a module that extracts to something
// plausible-but-wrong is caught before its suite quietly passes.
const MODULE_CONTRACT = {
  proc:   { min: 6000, global: 'P',
            needs: ['PROC_CODE_BASELINE', 'function setProcCodeMap', 'function exportProcProfile'],
            exports: ['setProcCodeMap', 'exportProcProfile', '_procProfileLabel', 'getProcBehavior'] },
  engine: { min: 12000, global: 'E',
            needs: ['function normPN', 'function buildAbomMap', 'function buildEbomIndentureMap',
                    'function runReconciliationCore'],
            exports: ['normPN', 'buildAbomMap', 'buildEbomIndentureMap',
                      'buildQtyMap', 'runReconciliationCore',
                      'computeEffectiveResults', 'engineLadder'] },
  ecn:    { min: 2000, global: 'B',
            needs: ['function buildEcnFootprints', 'function _ecnStatusLooksClosed'],
            exports: ['buildEcnFootprints', '_ecnStatusLooksClosed'] },
  ncr:    { min: 2000, global: 'N',
            needs: ['function computeUntracedNcrs', 'function exportUntracedNcrDispositions'],
            exports: ['computeUntracedNcrs', 'exportUntracedNcrDispositions'] },
  delta:  { min: 1500, global: 'D',
            needs: ['PROC_CODE_BASELINE', 'function claimSig', 'function procTableDiff'],
            exports: ['procTableOf', 'procTableDiff', 'claimSig', 'claimsDelta', 'dNorm',
                      'ebomChanges', 'computeKpis', 'ncrDispositionDelta', 'chpBom'] },
  adjimport:{ min: 3000, global: 'IMP',
            needs: ['function planAdjImport', 'function scanNarrative', 'function buildImportedClaims'],
            exports: ['planAdjImport', 'finalizeAdjImport', 'scanNarrative',
                      'resolveImportedAdjRow', 'buildImportedClaims', 'replaceImportedClaims'] },
  session:{ min: 2000, global: 'SS',
            needs: ['function restoreSession', 'payload.procOverrides'],
            exports: ['restoreSession'] },
  chpalign: { min: 12000, global: 'CA',
            needs: ['function buildChpTraceMapByDrawing', 'function chpHistoryState',
                    'function chpDrawingForLine', 'function renderChpAlignPanel'],
            exports: ['chpAlignRule', 'buildChpTraceMapByDrawing', 'chpHistoryState',
                      'chpDrawingForLine', 'chpEntriesForCiTrace', 'chpDocLookup'] },
  chp:    { min: 1500, global: 'C',
            needs: ['function chpReleaseState', 'function formatDcnDate'],
            exports: ['chpReleaseState', 'formatDcnDate', '_chpParseReleaseDate', 'chpStateClass'] },
  ciindex:{ min: 6000, global: 'CX',
            needs: ['// ── COPIED: CI INDEX ──', 'function aiParse(', 'function buildCiRowsFromCiIndex',
                    'function ciIndexHeader', 'function normPN'],
            exports: ['buildCiRowsFromCiIndex', 'ciIndexHeader', 'ciIndexSheetNames', 'ciIndexLooksLikeExport',
                      'ciIndexSummaryText', 'ciIndexSummaryLine'] },
};

// ── sandbox ────────────────────────────────────────────────────────────────
function el() { return { textContent:'', innerHTML:'', value:'',
  classList:{ c:new Set(), toggle(n,v){v?this.c.add(n):this.c.delete(n);}, add(n){this.c.add(n);}, remove(n){this.c.delete(n);} } }; }
function sandbox(extra, mods) {
  const els = {};
  const ctx = Object.assign({
    console, JSON, Math, Date, Set, Map, Array, Object, String, Number, Boolean,
    RegExp, Error, isNaN, parseFloat, parseInt, Buffer, prompt: () => 'Test',
    document: { getElementById: id => (els[id] = els[id] || el()), querySelectorAll: () => [] },
    toast: () => {}, showError: () => {}, applySheetFont: () => {},
    // Captures what a download would have contained, so a test can read the
    // exported payload rather than merely confirm a call happened.
    Blob: class { constructor(parts, opts) {
      this.parts = parts || []; this.type = (opts || {}).type || '';
      this.text = this.parts.join(''); } },
    tsFilename: (b, e) => b + '.' + e, downloadFile: () => {}, FileReader: class { readAsText(f){ this.onload({target:{result:f._text}}); } },
    _STATUS_ADJUDICATED_LEAF: new Set(['adj_ok']),
    // NOTE: buildEbomIndentureMap used to be stubbed here. It is now extracted
    // from the build in MOD.engine, so any suite needing it must load 'engine'.
    __els: els,
  }, extra);
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  (mods || []).forEach(m => vm.runInContext(MOD[m], ctx, { filename: m + '.js' }));
  return ctx;
}

// ── runner ─────────────────────────────────────────────────────────────────
let TP = 0, TF = 0; const FAILED = [];
// v178 — per-suite counts, so HARNESS.md's coverage table can be checked row by row.
const SUITE_COUNTS = {};
function suite(name, fn) {
  console.log('── ' + name + ' ' + '─'.repeat(Math.max(0, 56 - name.length)));
  let pass = 0, fail = 0;
  const t = (n, f) => { try { f(); console.log('  PASS  ' + n); pass++; }
                        catch (e) { console.log('  FAIL  ' + n + '\n        ' + e.message); fail++; } };
  const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b))
    throw new Error((m || '') + ' expected ' + JSON.stringify(b) + ' got ' + JSON.stringify(a)); };
  try { fn(t, eq); }
  catch (e) { console.log('  FAIL  SUITE CRASHED — its remaining tests did NOT run\n        ' + e.message); fail++; }
  console.log('  ' + pass + ' passed, ' + fail + ' failed\n');
  TP += pass; TF += fail; if (fail) FAILED.push(name);
  SUITE_COUNTS[name] = (SUITE_COUNTS[name] || 0) + pass + fail;
}


suite('Engine — tagging changes reconciliation output', (t, eq) => {
  const ctx = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,procOverrides:null,procProfileName:null} },
    ['proc','engine']);
  const P = ctx.P, buildAbomMap = ctx.E.buildAbomMap;
  // usedOn=8 pn=9 procCode=12 qty=13 woNo=35 woStatus=36
  const arow=(pn,nh,proc,qty,wo)=>{const r=new Array(40).fill('');
    r[8]=nh;r[9]=pn;r[12]=proc;r[13]=qty;r[35]=wo||'WO1';r[36]='CLOSED';return r;};
  const build = rows => buildAbomMap(rows, 9, 8, 13, 35, 36, 12);
  const K='P100||A1';

  console.log('\n== A new program\'s removal code, before and after tagging ==');
  t('untagged XR behaves as an install', ()=>{
    P.setProcCodeMap(null);
    const m=build([arow('P100','A1','XR',2)]);
    eq(m[K].allProcsAreRemovalOrSwap,false); eq(m[K].qty,2);
  });
  t('tagging XR as remove flips the same rows to proc-removed', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const m=build([arow('P100','A1','XR',2)]);
    eq(m[K].allProcsAreRemovalOrSwap,true,'flagged:'); eq(m[K].qty,-2,'net qty:');
  });
  t('an install row alongside the removal nets out', ()=>{
    const m=build([arow('P100','A1','AI',3),arow('P100','A1','XR',1)]);
    eq(m[K].allProcsAreRemovalOrSwap,false); eq(m[K].qty,2);
  });

  console.log('\n== Swap semantics on a user-tagged code ==');
  t('swap-only key is treated as present, not removed', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('TSW','swap');
    const m=build([arow('P100','A1','TSW',4)]);
    eq(m[K].allProcsAreRemovalOrSwap,false,'swap-only must not read as removed:');
    eq(m[K].qty,4);
  });
  t('swap alongside an install is net-zero', ()=>{
    const m=build([arow('P100','A1','AI',5),arow('P100','A1','TSW',5)]);
    eq(m[K].qty,5); eq(m[K].allProcsAreRemovalOrSwap,false);
  });

  console.log('\n== The founding program is unaffected ==');
  t('baseline codes produce identical maps', ()=>{
    P.setProcCodeMap(null);
    const m=build([arow('P1','A','BR',2),arow('P1','A','AI',5),arow('P2','A','DR',3),
                   arow('P3','A','MR',1),arow('P4','A','OTHER',7)]);
    eq(m['P1||A'].qty,3,'5 installed - 2 removed:');
    eq(m['P2||A'].allProcsAreRemovalOrSwap,false,'swap-only present:');
    eq(m['P3||A'].allProcsAreRemovalOrSwap,true,'removal-only:');
    eq(m['P4||A'].qty,7,'unknown code installs:');
  });
  t('untagging one default changes that code and nothing else', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('BR','add');
    const m=build([arow('P1','A','BR',2),arow('P2','A','MR',2)]);
    eq(m['P1||A'].qty,2); eq(m['P2||A'].allProcsAreRemovalOrSwap,true,'MR still removes:');
  });

  console.log('\n== Dedup reaches the engine ==');
  t('mixed-case spellings of a tagged code are all classified', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const m=build([arow('P100','A1','xr',1),arow('P100','A1',' XR ',1)]);
    eq(m[K].allProcsAreRemovalOrSwap,true); eq(m[K].qty,-2);
  });

  console.log('\n== Worker stays in lockstep ==');
  t('the serialized worker table is the ACTIVE table', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const decl='const PROC_CODE_EXCEPTIONS = '+JSON.stringify(P.PROC_CODE_EXCEPTIONS)+';';
    if(!decl.includes('"XR":"remove"')) throw new Error('worker would not see XR');
    const box={}; new Function('o', decl+' o.map = PROC_CODE_EXCEPTIONS;')(box);
    eq(box.map['XR'],'remove'); eq(box.map['BR'],'remove','defaults carried:');
  });
});

suite('Proc code panel — job number samples', (t, eq) => {
  const ctx = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,procOverrides:null,procProfileName:null} }, ['proc']);
  const T = ctx.P, state = ctx.state, els = ctx.__els;
  // Mapping 1 row: job at 5, desc at 10, proc at 12
  const row=(proc,job,desc)=>{const r=new Array(40).fill('');r[12]=proc;r[5]=job||'';r[10]=desc||'';return r;};
  const load=rows=>{state.boms.abom={data:rows};};
  const jobsOf=c=>[...(T.abomProcCodeInventory().codes.find(x=>x.code===c)||{jobs:new Set()}).jobs];

  console.log('\n== Job numbers collected and deduplicated ==');
  t('distinct job numbers only', ()=>{
    load([row('XR','J100'),row('XR','J100'),row('XR','J200'),row('XR','J100')]);
    eq(jobsOf('XR'),['J100','J200']);
  });
  t('job numbers are kept verbatim (no normalising)', ()=>{
    load([row('XR',' J-100/A ')]);
    eq(jobsOf('XR'),['J-100/A'],'trimmed but not uppercased:');
  });
  t('blank job numbers are skipped, not stored as empty', ()=>{
    load([row('XR',''),row('XR','   '),row('XR','J1')]);
    eq(jobsOf('XR'),['J1']);
  });
  t('each proc code keeps its own job set', ()=>{
    load([row('XR','J1'),row('TSW','J2'),row('XR','J3')]);
    eq(jobsOf('XR'),['J1','J3']); eq(jobsOf('TSW'),['J2']);
  });

  console.log('\n== Panel renders at most 3, one per line ==');
  function cell(html){const m=html.match(/<span class="pcm-jobs">([\s\S]*?)<\/span><span class="pcm-seg">/);return m?m[1]:'';}
  t('exactly 3 shown when more exist, with overflow count', ()=>{
    load([1,2,3,4,5,6,7].map(i=>row('XR','J'+i)));
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    const shown=(c.match(/class="pcm-job"/g)||[]).length;
    eq(shown,3,'job lines rendered:');
    if(!c.includes('+4 more')) throw new Error('overflow missing: '+c);
  });
  t('fewer than 3 renders only what exists, no overflow', ()=>{
    load([row('XR','J1'),row('XR','J2')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,2);
    if(c.includes('more')) throw new Error('false overflow');
  });
  t('exactly 3 shows no overflow', ()=>{
    load([row('XR','J1'),row('XR','J2'),row('XR','J3')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,3);
    if(c.includes('more')) throw new Error('false overflow at exactly 3');
  });
  t('each job is its own element (stacks as a row)', ()=>{
    load([row('XR','J1'),row('XR','J2')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq(c.match(/<span class="pcm-job">/g).length,2,'separate elements:');
  });
  t('no job numbers on the rows says so', ()=>{
    load([row('XR','')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    if(!c.includes('No job number')) throw new Error(c);
  });
  t('a code absent from the file says so', ()=>{
    load([row('XR','J1')]);
    const c=cell(T._procRowHtml({code:'BR',rows:0,jobs:new Set(),variants:new Set()}));
    if(!c.includes('Not present in this ABOM')) throw new Error(c);
  });
  t('job numbers are HTML-escaped', ()=>{
    load([row('XR','<script>x</script>')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    if(c.includes('<script>')) throw new Error('unescaped');
    if(!c.includes('&lt;script&gt;')) throw new Error('not escaped: '+c);
  });

  console.log('\n== The removed hint is gone ==');
  t('no removal hint anywhere in the rendered row', ()=>{
    load([row('XR','J1','PANEL, REMOVABLE, LH'),row('XR','J2','COVER, REMOVABLE')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(/desc says removal|removalish/i.test(h)) throw new Error('hint still present');
  });
  t('description is not rendered at all', ()=>{
    load([row('XR','J1','BRACKET, SUPPORT, LH')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(h.includes('BRACKET')) throw new Error('description still shown');
  });
  t('spellings-merged note survives (moved onto the code cell)', ()=>{
    load([row('XR','J1'),row('xr','J2')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(!h.includes('2 spellings merged')) throw new Error('lost the variant note');
  });

  console.log('\n== Mapping 2: description is blank, job numbers are not ==');
  t('panel still informative under Mapping 2 (desc always empty)', ()=>{
    // Mapping 2 sets COL.abom.desc = '' but populates jobNo from source col A.
    load([row('XR','J900',''),row('XR','J901','')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,2,'jobs present where desc never was:');
  });

  console.log('\n== Header aligns to the grid ==');
  t('header has the same 4 cells as a row', ()=>{
    const hd=T._procHeaderRow();
    eq((hd.match(/<span/g)||[]).length,4);
    if(!hd.includes('Job Numbers (samples)')) throw new Error('title wrong: '+hd);
  });
});

// ── TIER 1 ─────────────────────────────────────────────────────────────────
// Regression guards for two defects found in v153 and fixed in v154.
//
//   A. exportProcProfile()'s Cancel guard was dead code. `(prompt(...) || '')
//      .trim()` turned a null return into '' BEFORE the `=== null` check ran,
//      so pressing Cancel still downloaded a file and still overwrote
//      state.procProfileName with 'Unnamed profile'.
//
//   B. setProcCodeMap(map, profileName) ignored profileName on the `!map`
//      path and hard-set state.procProfileName = null. The session importer
//      calls exactly that path, so a profile NAME did not survive an export →
//      import round-trip even though the proc code BEHAVIOUR did. A re-opened
//      session reported 'Program baseline' where the original said the
//      program's name.
//
// The name is provenance; the overrides are the deviation. These tests pin
// that separation, because both defects were failures of exactly that
// distinction.
suite('Tier 1 — proc code profile name is provenance', (t, eq) => {
  // The two lines the session exporter writes and the one line the importer
  // reads. Lifted verbatim so that REWIRING the session — not just breaking
  // setProcCodeMap — also fails this suite.
  const SESSION_WRITE = ['procOverrides:   state.procOverrides   || null',
                         'procProfileName: state.procProfileName || null'];
  const SESSION_READ  = 'setProcCodeMap(payload.procOverrides || null, ' +
                        'payload.procProfileName || null)';

  let DL = [], PROMPT = null;
  const ctx = sandbox({
    COL: { abom: { procCode: 12, desc: 10, jobNo: 5 } },
    state: { boms:{abom:null}, results:[], isLocked:false,
             procOverrides:null, procProfileName:null },
    prompt: () => PROMPT,
    downloadFile: (n, b) => DL.push({ name: n, text: b && b.text }),
  }, ['proc']);
  const P = ctx.P, state = ctx.state;

  const reset = () => { DL = []; PROMPT = null; P.setProcCodeMap(null); };
  const payloadOf = () => JSON.parse(DL[0].text);
  // Push state through JSON exactly as a session file does, then restore it
  // the way the importer does, in a context that has been wiped first.
  function roundTrip() {
    ctx.__j = JSON.stringify({ procOverrides:   state.procOverrides   || null,
                               procProfileName: state.procProfileName || null });
    P.setProcCodeMap(null);                       // a fresh browser
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
  }
  ctx.__run = src => require('vm').runInContext(src, ctx, { filename: 'session.js' });

  console.log('\n== Defect A: Cancel must export nothing and change nothing ==');
  t('Cancel downloads no file', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = null;                                 // user pressed Cancel
    P.exportProcProfile();
    eq(DL.length, 0, 'files written on Cancel:');
  });
  t('Cancel leaves the existing profile name untouched', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    PROMPT = null;
    P.exportProcProfile();
    eq(state.procProfileName, 'Program Falcon', 'name after Cancel:');
  });
  t('confirming an EMPTY name still exports, as Unnamed profile', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = '';                                   // user pressed OK on a blank box
    P.exportProcProfile();
    eq(DL.length, 1, 'blank-but-confirmed must still export:');
    eq(payloadOf().profileName, 'Unnamed profile');
  });
  t('a real name reaches the payload and the state', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = '  Program Falcon  ';                 // and is trimmed
    P.exportProcProfile();
    eq(payloadOf().profileName, 'Program Falcon');
    eq(state.procProfileName, 'Program Falcon');
    eq(payloadOf().basedOn, 'custom', 'a tagged table is a deviation:');
  });

  console.log('\n== Defect B: the name survives a session round-trip ==');
  t('the session still carries both proc fields', () => {
    SESSION_WRITE.forEach(s => {
      if (!SRC.includes(s)) throw new Error('exporter no longer writes: ' + s); });
    if (!SRC.includes(SESSION_READ)) throw new Error('importer no longer reads it');
  });
  t('a CUSTOM profile keeps its name through export and import', () => {
    reset(); P.setProcCodeMap({ XR:'remove', TSW:'swap' }, 'Program Falcon');
    roundTrip();
    eq(state.procProfileName, 'Program Falcon', 'name after round-trip:');
    eq(P.PROC_CODE_EXCEPTIONS.XR, 'remove', 'and the behaviour came with it:');
    eq(P.isProcMapCustom(), true);
  });
  t('a BASELINE-EQUAL profile keeps its name through export and import', () => {
    // importProcProfile drops the custom flag but keeps the name when the
    // shared file happens to match the baseline. That is the exact shape that
    // hit the null path in setProcCodeMap and lost the name.
    reset();
    P.importProcProfile({ _text: JSON.stringify({
      schema: 'bom-comparator-proc-profile', profileName: 'Program Falcon',
      procCodes: P.PROC_CODE_BASELINE }) });
    eq(P.isProcMapCustom(), false, 'baseline-equal is not a deviation:');
    eq(state.procProfileName, 'Program Falcon', 'but the name is kept:');
    roundTrip();
    eq(state.procProfileName, 'Program Falcon', 'and survives the session:');
    eq(P.isProcMapCustom(), false, 'still not a deviation:');
  });
  t('a session with no proc fields at all restores as clean baseline', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = '{}';                                // a pre-v153 session file
    P.setProcCodeMap(null);
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq([state.procProfileName, state.procOverrides], [null, null]);
    eq(P.PROC_CODE_EXCEPTIONS.BR, 'remove', 'baseline is live:');
  });

  console.log('\n== The name/override split, stated directly ==');
  t('setProcCodeMap(null, name) keeps the name; setProcCodeMap(null) clears it', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.setProcCodeMap(null, 'Program Falcon');
    eq([state.procProfileName, state.procOverrides], ['Program Falcon', null],
       'named null-path:');
    P.setProcCodeMap(null);
    eq(state.procProfileName, null, 'bare null-path still clears:');
  });
  t('untagging back to baseline keeps the name, but Reset clears it', () => {
    // Two different acts. Editing your way back is not the same as declaring
    // you are done with the profile, and only the second should erase it.
    reset();
    P.setProcCodeMap(P.PROC_CODE_BASELINE, 'Program Falcon');
    P.setProcCodeBehavior('XR', 'remove');
    eq(P.isProcMapCustom(), true, 'tagging forks the table:');
    P.setProcCodeBehavior('XR', 'add');            // untag it again
    eq(P.isProcMapCustom(), false, 'back to baseline, flag dropped:');
    eq(state.procProfileName, 'Program Falcon', 'name held:');
    P.resetProcCodesToBaseline();
    eq(state.procProfileName, null, 'explicit Reset clears it:');
  });
  t('the freeze certificate label is identical before and after a round-trip', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    const before = P._procProfileLabel();
    roundTrip();
    eq(P._procProfileLabel(), before, 'label drift:');
    eq(before, 'Program Falcon');
  });
  t('an unnamed custom table reads as Custom, not as the baseline', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P._procProfileLabel(), 'Custom');
    roundTrip();
    eq(P._procProfileLabel(), 'Custom', 'and stays Custom after a round-trip:');
  });
  t('a rejected profile file changes nothing', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.importProcProfile({ _text: JSON.stringify({ schema: 'something-else',
      profileName: 'Hostile', procCodes: { BR:'swap' } }) });
    eq(state.procProfileName, 'Program Falcon', 'name untouched:');
    eq(P.PROC_CODE_EXCEPTIONS.XR, 'remove', 'table untouched:');
  });
});

// ── TIER 2 ─────────────────────────────────────────────────────────────────
// Until v154 the sandbox defined its own six-line buildEbomIndentureMap and the
// ECN inheritance suites tested THAT. The real function is ~60 lines and returns
// three structures, not one. They agree on clean data and diverge on a
// self-referencing row. These tests exercise the shipping function.
suite('Tier 2 — EBOM indenture map (the real one)', (t, eq) => {
  const ctx = sandbox({}, ['engine']);
  const build = ctx.E.buildEbomIndentureMap;
  // indenture=0, pn=1, nh=3 — the shape COL.ebom uses elsewhere in this file.
  const row = (ind, pn, nh) => { const r = new Array(10).fill('');
    r[0] = ind; r[1] = pn; r[3] = nh; return r; };
  const map  = rows => build(rows, 0, 1, 3);
  const kids = (m, k) => (m.keyInfo[k] ? [...m.keyInfo[k].childKeys].sort() : '(no such key)');

  console.log('\n== Structure the build actually consumes ==');
  t('returns all three structures, not just keyInfo', () => {
    const m = map([row('A', 'TOP', '')]);
    eq(Object.keys(m).sort(), ['keyInfo', 'pnToIndenture', 'pnToNh']);
  });
  t('a clean three-level tree links each level to the next, not transitively', () => {
    const m = map([row('A','TOP',''), row('B','MID','TOP'), row('C','LEAF','MID')]);
    eq(kids(m, 'TOP||'),     ['MID||TOP'], 'top:');
    eq(kids(m, 'MID||TOP'),  ['LEAF||MID'], 'middle:');
    eq(kids(m, 'LEAF||MID'), [], 'leaf:');
  });
  t('a deep chain stays one link per level', () => {
    const rows = [row('A','L0','')];
    for (let i = 1; i <= 8; i++) rows.push(row('B','L'+i,'L'+(i-1)));
    const m = map(rows);
    for (let i = 0; i < 8; i++)
      eq(kids(m, 'L'+i+'||'+(i ? 'L'+(i-1) : '')), ['L'+(i+1)+'||L'+i], 'level '+i+':');
  });
  t('a PN under two different NHs makes the child a child of BOTH keys', () => {
    const m = map([row('A','TOP',''), row('B','P1','TOP'), row('B','P1','OTHER'), row('C','KID','P1')]);
    eq(kids(m, 'P1||TOP'),   ['KID||P1'], 'first parent key:');
    eq(kids(m, 'P1||OTHER'), ['KID||P1'], 'second parent key:');
  });

  console.log('\n== Where the old stand-in was wrong ==');
  t('a self-referencing row (PN === NH) becomes its own child', () => {
    // A part listed as its own next-higher assembly — a real extract defect.
    // The shipping function creates a self-loop here. The old stand-in excluded
    // self and reported ["Y||X"], so this behaviour was invisible to the harness.
    const m = map([row('A','X','X'), row('B','Y','X')]);
    eq(kids(m, 'X||X'), ['X||X', 'Y||X'], 'self-loop is real:');
  });
  t('the ECN inheritance walk terminates on that self-loop and still inherits', () => {
    const c = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3}, chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
      state:{results:[], boms:{ebom:null, chp:null}} }, ['proc','engine','chp','chpalign','ecn']);
    const R = (pn, nh, ecn) => ({ key: pn+'||'+nh, pn, nh, overall:'ok', as:'ok',
      woStatus:'closed', woValues:['W1'],
      trace: ecn ? { dcn:new Map(), ecn:new Map(ecn), ecr:new Map() } : null,
      ncrEntriesPool1:[], ncrEntriesPool2:[] });
    c.state.results = [R('X','X',[['E1','']]), R('Y','X',null)];
    c.state.boms.ebom = { data:[row('A','X','X'), row('B','Y','X')] };
    const e = c.B.buildEcnFootprints().ecnMap.get('E1');   // must return, not hang
    eq(e.items.length, 2, 'child inherited across the self-loop:');
    eq(e.items.map(x => x.r.key).sort(), ['X||X', 'Y||X']);
    // Y holds no ECN of its own — it must be marked as inherited from X.
    const y = e.items.find(x => x.r.key === 'Y||X');
    eq(y.inheritedVia, 'X||X', 'inheritance provenance:');
    eq(e.items.find(x => x.r.key === 'X||X').inheritedVia, '', 'the anchor is direct:');
  });

  console.log('\n== Indexing rules ==');
  t('a row with a blank NH is indexed but never linked as a child', () => {
    const m = map([row('A','TOP',''), row('B','ORPHAN','')]);
    eq(kids(m, 'TOP||'), [], 'a blank NH must not read as "child of everything":');
    if (!m.keyInfo['ORPHAN||']) throw new Error('the orphan row was dropped from keyInfo');
  });
  t('a row with a blank PN is skipped entirely', () => {
    const m = map([row('A','TOP',''), row('B','','TOP')]);
    eq(Object.keys(m.keyInfo).sort(), ['TOP||']);
  });
  t('pnToIndenture keeps the FIRST occurrence and does not overwrite', () => {
    const m = map([row('B','P1','TOP'), row('E','P1','OTHER')]);
    eq(m.pnToIndenture['P1'], 'B', 'later rows must not win:');
  });
  t('pnToNh keeps the FIRST occurrence and does not overwrite', () => {
    const m = map([row('B','P1','TOP'), row('B','P1','OTHER')]);
    eq(m.pnToNh['P1'], 'TOP');
  });
  t('case and whitespace variants collapse to one key', () => {
    const m = map([row('a',' top ',''), row('b','MID','TOP'), row('b','mid','top')]);
    eq(Object.keys(m.keyInfo).sort(), ['MID||TOP', 'TOP||'], 'normalised:');
    eq(kids(m, 'TOP||'), ['MID||TOP']);
  });
});

// The harness's own safety net. HARNESS.md promises that a moved marker "fails
// loudly and names it" — before v154 that was true only for markers routed
// through at(). Four boundaries used raw indexOf, where a miss returns -1 and
// produces a silently EMPTY module: every suite green, nothing tested.
suite('Tier 2 — extraction integrity', (t, eq) => {
  const DEPS = { proc:['proc'], engine:['engine'],
                 ecn:['proc','engine','chp','chpalign','ecn'], ncr:['ncr'], chp:['chp'], delta:['delta'],
                 session:['chpalign','session'], adjimport:['adjimport'],
                 chpalign:['engine','chp','chpalign'],   // v182
                 ciindex:['ciindex'] };                  // v191

  t('every module is substantial and contains what it claims', () => {
    Object.keys(MODULE_CONTRACT).forEach(name => {
      const c = MODULE_CONTRACT[name], src = MOD[name];
      if (!src || src.length < c.min)
        throw new Error(name + ': ' + (src ? src.length : 0) + ' chars, expected >= ' + c.min);
      c.needs.forEach(n => { if (!src.includes(n))
        throw new Error(name + ' is missing ' + JSON.stringify(n) + ' — wrong slice'); });
    });
  });
  t('every module defines its global once evaluated', () => {
    Object.keys(MODULE_CONTRACT).forEach(name => {
      const c = MODULE_CONTRACT[name];
      const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3}, abom:{procCode:12,desc:10,jobNo:5},
        chp:{pn:3,nh:5,ecn:18}, ncr:{ncrNum:60,dispNo:71}},
        state:{results:[], boms:{}, isLocked:false, procOverrides:null, procProfileName:null} },
        DEPS[name]);
      if (!ctx[c.global]) throw new Error(name + ' did not define globalThis.' + c.global);
      c.exports.forEach(fn => { if (typeof ctx[c.global][fn] !== 'function')
        throw new Error(name + '.' + c.global + '.' + fn + ' is not a function'); });
    });
  });
  t('no global exists without its module — an empty run cannot pass', () => {
    const c = sandbox({}, []);
    ['P','E','B','N'].forEach(g => { if (c[g])
      throw new Error(g + ' exists with no module loaded'); });
  });

  console.log('\n== The guards themselves ==');
  const throws = (fn, want, label) => {
    let msg = null;
    try { fn(); } catch (e) { msg = e.message; }
    if (msg === null) throw new Error(label + ' did not throw');
    if (msg.indexOf(want) < 0) throw new Error(label + ' threw the wrong thing: ' + msg);
  };
  t('a missing marker throws and names itself', () => {
    throws(() => at('NO SUCH MARKER IN THIS BUILD'), 'BUILD MARKER MOVED', 'at()');
    throws(() => at('NO SUCH MARKER IN THIS BUILD'), 'NO SUCH MARKER', 'at() naming');
  });
  t('a backwards marker search is guarded too', () => {
    throws(() => lastAt('NO SUCH MARKER IN THIS BUILD', 5000, 'probe'),
           'BUILD MARKER MOVED', 'lastAt()');
  });
  t('crossed boundaries are refused, not silently emptied', () => {
    // This is the exact shape a raw indexOf miss produced: end before start.
    throws(() => span(1124358, 400, 'probe'), 'BUILD MARKERS CROSSED', 'span()');
  });
  t('a suspiciously small slice is refused', () => {
    throws(() => span(0, 50, 'probe'), 'MODULE SLICE TOO SMALL', 'span()');
  });
  t('grabFn refuses a function that is not there', () => {
    throws(() => grabFn('thisFunctionDoesNotExistAnywhere'), 'BUILD MARKER MOVED', 'grabFn()');
  });

  console.log('\n== The worker bundle must be self-contained ==');
  t('every function the worker bundle calls is also IN the bundle', () => {
    // The worker is built by serialising a hand-listed set of functions with
    // .toString(). A function that calls another top-level function which is
    // NOT on that list throws inside the worker and kills every comparison run.
    // This has now happened twice: buildEbomLineNoMap in v145, and
    // normIndenture in v160 — which shipped broken through v163 because every
    // suite here loads functions directly and never exercises the worker path.
    const i = at('const fns = [');
    const listSrc = SRC.slice(i + 13, at('].map(fn => fn.toString())', i));
    const bundled = new Set([...listSrc.replace(/\/\/[^\n]*/g, '')
      .matchAll(/\b([a-zA-Z_$][\w$]*)\b/g)].map(m => m[1]));
    if (bundled.size < 15) throw new Error('only found ' + bundled.size + ' bundled functions');
    const topLevel = new Set([...SRC.matchAll(/^function (\w+)\s*\(/gm)].map(m => m[1]));
    const missing = [];
    bundled.forEach(fn => {
      let src;
      try { src = grabFn(fn); } catch (e) { return; }
      // Bare calls only: a preceding '.' makes it a method, not a global.
      [...src.matchAll(/(^|[^.\w$])([a-zA-Z_$][\w$]*)\s*\(/g)].forEach(m => {
        const c = m[2];
        if (c === fn || !topLevel.has(c) || bundled.has(c)) return;
        missing.push(fn + '() calls ' + c + '()');
      });
    });
    if (missing.length)
      throw new Error('the worker would throw on:\n        ' +
                      [...new Set(missing)].join('\n        '));
  });
  t('normIndenture specifically is in the bundle', () => {
    // Named because it is the one that shipped broken, and because the failure
    // is invisible to every other test in this file.
    const i = at('const fns = [');
    const listSrc = SRC.slice(i + 13, at('].map(fn => fn.toString())', i))
      .replace(/\/\/[^\n]*/g, '');
    if (!/\bnormIndenture\b/.test(listSrc))
      throw new Error('normIndenture is missing from the worker bundle again');
  });

  console.log('\n== The build is still what it claims to be ==');
  t('no external script or stylesheet — the file is genuinely offline', () => {
    const ext = [...SRC.matchAll(/<script[^>]*\ssrc\s*=/gi)].length +
                [...SRC.matchAll(/<link[^>]*rel=["']stylesheet["']/gi)].length;
    if (ext) throw new Error(ext + ' external reference(s) — the build is no longer self-contained');
  });
  t('HARNESS.md reports the same test count as the harness', () => {
    // v163 — the header count had been stale since 262 tests: every update
    // since was rewriting a phrase that no longer matched, and silently doing
    // nothing. Documentation that quietly stops tracking is worse than none.
    const fs2 = require('fs'), pth = require('path');
    const candidates = [pth.join(__dirname, 'HARNESS.md'),
                        pth.join(__dirname, '..', 'HARNESS.md')];
    const f = candidates.find(p => { try { return fs2.statSync(p).isFile(); } catch (e) { return false; } });
    if (!f) return;                       // not shipped alongside: nothing to check
    const md = fs2.readFileSync(f, 'utf8');
    const m = md.match(/(\d+)\s+tests\./);
    if (!m) throw new Error('HARNESS.md no longer states a test count');
    // EXPECTED_TESTS is declared at the foot of this file, after every suite has
    // run, so it cannot be referenced here. Read the literal from source.
    const self = fs2.readFileSync(__filename, 'utf8');
    const want = parseInt(self.match(/EXPECTED_TESTS = (\d+)/)[1], 10);
    if (parseInt(m[1], 10) !== want)
      throw new Error('HARNESS.md says ' + m[1] + ' tests, the harness expects ' + want);
  });
  t('the file read is the file reported', () => {
    eq(fs.readFileSync(BUILD, 'utf8').length, SRC.length);
    if (!/^<!DOCTYPE html/i.test(SRC.trim())) throw new Error('not an HTML document');
  });
});

// ── TIER 3 ─────────────────────────────────────────────────────────────────
// The CHP release badge. Pure logic, user-visible warning, and the release date
// it produces is printed on the freeze certificate — an audit artefact.
suite('Tier 3 — CHP release state', (t, eq) => {
  const C = sandbox({}, ['chp']).C;
  const trace = (dcn, ecn, ecr) => ({
    dcn: new Map(dcn || []), ecn: new Map(ecn || []), ecr: new Map(ecr || []) });
  const st = (...a) => C.chpReleaseState(trace(...a));

  console.log('\n== No history, and history without a DCN ==');
  t('a null trace reads as NO HISTORY, not as a warning', () => {
    const s = C.chpReleaseState(null);
    eq([s.state, s.label, s.warn, s.dcnCount], ['none', 'NO HISTORY', false, 0]);
  });
  t('a trace with three empty maps also reads as NO HISTORY', () => {
    eq(st([], [], []).state, 'none');
  });
  t('an ECN with no DCN reads as NO DCN and is NOT a warning', () => {
    // Expected for COTS parts: release is held by the parent that owns the DCN.
    const s = st([], [['E1', 'Open']], []);
    eq([s.state, s.label, s.warn], ['no_dcn', 'NO DCN', false]);
  });
  t('an ECR alone also reads as NO DCN', () => {
    eq(st([], [], [['R1', '']]).state, 'no_dcn');
  });

  console.log('\n== Released ==');
  t('one dated DCN reads as RELEASED with no count suffix', () => {
    const s = st([['D1', '2024-03-15']]);
    eq([s.state, s.warn, s.dcnCount], ['released', false, 1]);
    eq(s.label, 'RELEASED MARCH 15, 2024');
  });
  t('several dated DCNs report the LATEST date and the count', () => {
    const s = st([['D1', '2024-01-05'], ['D2', '2024-06-30'], ['D3', '2024-03-15']]);
    eq(s.date, 'JUNE 30, 2024', 'latest wins:');
    eq(s.label, 'RELEASED JUNE 30, 2024 \u00b7 3 DCNs');
    eq(s.dcnCount, 3);
  });
  t('order of arrival does not change which date wins', () => {
    const a = st([['D1', '2024-06-30'], ['D2', '2024-01-05']]).date;
    const b = st([['D1', '2024-01-05'], ['D2', '2024-06-30']]).date;
    eq(a, b);
  });

  console.log('\n== Unreleased: the warning that matters ==');
  t('an undated DCN raises the warning and names the offender', () => {
    const s = st([['D1', 'Unknown']]);
    eq([s.state, s.warn, s.label], ['unreleased', true, '\u26a0 DCN NOT RELEASED']);
    eq(s.undated, ['D1']);
    if (!s.note.includes('D1')) throw new Error('the note must name the DCN');
  });
  t('ONE undated DCN outweighs any number of dated ones', () => {
    // The safe direction: a partially-scoped extract must not read as released.
    const s = st([['D1', '2024-03-15'], ['D2', ''], ['D3', '2024-06-30']]);
    eq([s.state, s.warn], ['unreleased', true]);
    eq(s.undated, ['D2']);
  });
  t('every undated DCN is listed, not just the first', () => {
    eq(st([['D1', ''], ['D2', 'TBD'], ['D3', '2024-03-15']]).undated, ['D1', 'D2']);
  });
  t('unparseable text counts as undated, not as a date', () => {
    ['Unknown', 'TBD', 'N/A', 'RELEASED', '   ', ''].forEach(v => {
      eq(C.chpReleaseState(trace([['D1', v]])).state, 'unreleased', JSON.stringify(v) + ':');
    });
  });

  console.log('\n== Date shapes the extract actually produces ==');
  t('a Date object from cellDates:true is accepted', () => {
    eq(st([['D1', new Date(2024, 2, 15)]]).date, 'MARCH 15, 2024');
  });
  t('a stringified Date is accepted — this is the real path', () => {
    // buildChpTraceMap does String(row[...]) before storing, so the Date object
    // branch is mostly bypassed in practice.
    eq(st([['D1', String(new Date(2024, 2, 15))]]).date, 'MARCH 15, 2024');
  });
  t('ISO, slash and DD-MON forms all give the same calendar date', () => {
    ['2024-03-15', '2024-03-15T08:30:00Z', '2024-03-15 08:30:00',
     '3/15/2024', '15-MAR-2024'].forEach(v => {
      eq(C.formatDcnDate(v), 'MARCH 15, 2024', JSON.stringify(v) + ':');
    });
  });
  t('an invalid Date object is treated as undated', () => {
    eq(st([['D1', new Date('nonsense')]]).state, 'unreleased');
  });

  console.log('\n== Defect C: the same day everywhere on earth ==');
  t('the displayed date does not depend on the reader\'s timezone', () => {
    // v153 read UTC components off a date built at LOCAL midnight, so a DCN
    // released 15 March showed as MARCH 14 in Tokyo, Sydney and Kolkata.
    // Node reads process.env.TZ at first Date use, so this runs a child.
    const cp = require('child_process');
    const probe = 'const v=process.argv[1];' + MOD.chp +
      ';console.log(formatDcnDate(v==="obj"?new Date(2024,2,15):v));';
    ['2024-03-15', '3/15/2024', '15-MAR-2024', 'obj'].forEach(shape => {
      ['UTC', 'America/New_York', 'Asia/Tokyo', 'Australia/Sydney', 'Asia/Kolkata',
       'Pacific/Kiritimati'].forEach(tz => {
        const got = cp.execFileSync(process.execPath, ['-e', probe, shape],
                     { env: Object.assign({}, process.env, { TZ: tz }) }).toString().trim();
        if (got !== 'MARCH 15, 2024')
          throw new Error(shape + ' in ' + tz + ' -> ' + got);
      });
    });
  });
  t('no UTC component read survives in the date formatter', () => {
    if (/getUTC(Month|Date|FullYear)/.test(MOD.chp))
      throw new Error('formatDcnDate is reading UTC components again');
  });

  console.log('\n== Badge styling ==');
  t('only the unreleased state is styled as a warning', () => {
    // v156 — 'none' used to return '', so NO HISTORY rendered as bare text
    // beside four real badges in the same column. It now gets the neutral badge.
    // Every state is a badge; only 'unreleased' is a WARNING badge.
    eq(C.chpStateClass('unreleased'), 'badge badge-chp-warn');
    eq(C.chpStateClass('none'), 'badge badge-neutral', 'no history must still be a badge:');
    eq(C.chpStateClass('released'), 'badge badge-history');
    eq(C.chpStateClass('no_dcn'), 'badge badge-history', 'NO DCN is not a warning:');
  });
  t('every state chpReleaseState can return has a class', () => {
    ['none', 'no_dcn', 'released', 'unreleased'].forEach(s => {
      if (typeof C.chpStateClass(s) !== 'string')
        throw new Error('no class for state ' + s);
    });
  });
});

// The proc code table under adversarial conditions: a frozen report, a
// hand-edited profile file, and a session carrying someone else's provenance.
suite('Tier 3 — proc table under lock, bad input, and session reuse', (t, eq) => {
  const SESSION_READ = 'setProcCodeMap(payload.procOverrides || null, ' +
                       'payload.procProfileName || null)';
  const ctx = sandbox({
    COL: { abom: { procCode: 12, desc: 10, jobNo: 5 } },
    state: { boms:{abom:null}, results:[], isLocked:false,
             procOverrides:null, procProfileName:null },
  }, ['proc']);
  const P = ctx.P, state = ctx.state;
  ctx.__run = src => require('vm').runInContext(src, ctx, { filename: 'session.js' });
  const reset = () => { state.isLocked = false; state.results = []; P.dirty = false;
                        P.setProcCodeMap(null); };
  const profile = o => ({ _text: JSON.stringify(Object.assign(
    { schema: 'bom-comparator-proc-profile' }, o)) });

  console.log('\n== A frozen report must not move ==');
  t('tagging a code is refused while the report is locked', () => {
    reset(); state.isLocked = true;
    P.setProcCodeBehavior('XR', 'remove');
    eq([P.isProcMapCustom(), state.procOverrides], [false, null], 'table changed under lock:');
  });
  t('reset to baseline is refused while the report is locked', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    state.isLocked = true;
    P.resetProcCodesToBaseline();
    eq([P.isProcMapCustom(), state.procProfileName], [true, 'Program Falcon'], 'reset ran anyway:');
  });
  t('unlocking restores both operations', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P.getProcBehavior('XR'), 'remove');
    P.resetProcCodesToBaseline();
    eq(P.isProcMapCustom(), false);
  });

  console.log('\n== A hand-edited profile file ==');
  t('a wrong schema is rejected and changes nothing', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.importProcProfile(profile({ schema:'something-else', procCodes:{ BR:'swap' } }));
    eq([P.PROC_CODE_EXCEPTIONS.XR, state.procProfileName], ['remove', 'Program Falcon']);
  });
  t('an invalid behaviour value is dropped, not installed', () => {
    reset();
    P.importProcProfile(profile({ profileName:'Bad', procCodes:{ XR:'remove', TSW:'delete' } }));
    eq(P.getProcBehavior('XR'), 'remove', 'the valid entry survives:');
    eq(P.getProcBehavior('TSW'), 'add', '"delete" is not a behaviour:');
  });
  t('an empty procCodes map installs a table with no removal codes', () => {
    // A deliberate act — every code untagged — not the same as the baseline.
    reset();
    P.importProcProfile(profile({ profileName:'Nothing', procCodes:{} }));
    eq(P.isProcMapCustom(), true, 'still a deviation:');
    eq(P.getProcBehavior('BR'), 'add', 'baseline BR no longer removes:');
  });
  t('a profile identical to the baseline keeps its name but drops the flag', () => {
    reset();
    P.importProcProfile(profile({ profileName:'Program Falcon',
                                  procCodes: P.PROC_CODE_BASELINE }));
    eq([P.isProcMapCustom(), state.procProfileName], [false, 'Program Falcon']);
  });

  console.log('\n== Defect D: provenance must not leak between loads ==');
  t('an unnamed custom session does NOT inherit the previous profile name', () => {
    // v153: setProcCodeMap fell back to `|| state.procProfileName`, so loading
    // "Program Falcon" and then importing an unnamed session left the freeze
    // certificate still claiming Falcon.
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = JSON.stringify({ procOverrides:{ TSW:'swap' }, procProfileName:null });
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq(state.procProfileName, null, 'stale name survived:');
    eq(P._procProfileLabel(), 'Custom');
  });
  t('a named session overwrites the previous name rather than merging', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = JSON.stringify({ procOverrides:{ TSW:'swap' }, procProfileName:'Program Kestrel' });
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq(state.procProfileName, 'Program Kestrel');
  });
  t('a baseline session clears a previously loaded profile entirely', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = '{}';
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq([state.procProfileName, state.procOverrides], [null, null]);
    eq(P.getProcBehavior('BR'), 'remove', 'baseline is live again:');
  });

  console.log('\n== The stale-results flag ==');
  t('tagging with no results on screen does not raise the dirty flag', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P.dirty, false, 'nothing to invalidate yet:');
  });
  t('tagging AFTER a run marks the results stale', () => {
    reset(); state.results = [{}];
    P.setProcCodeBehavior('XR', 'remove');
    eq(P.dirty, true);
  });
  t('resetting after a run also marks the results stale', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, null); state.results = [{}];
    P.resetProcCodesToBaseline();
    eq(P.dirty, true);
  });
  t('a locked report cannot be made dirty', () => {
    reset(); state.results = [{}]; state.isLocked = true;
    P.setProcCodeBehavior('XR', 'remove');
    P.resetProcCodesToBaseline();
    eq(P.dirty, false);
  });
});

// ── TIER 4 ─────────────────────────────────────────────────────────────────
// The delta tool: a second shipped file with no coverage at all until v154.
// Its whole job is to tell two sessions apart, so a field it fails to compare
// is a wrong answer, not a missing feature.
suite('Tier 4 — delta tool', (t, eq) => {
  const D = sandbox({}, ['delta']).D;
  const P = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,
           procOverrides:null,procProfileName:null} }, ['proc']).P;

  console.log('\n== The duplicated baseline ==');
  t('the delta tool\'s PROC_CODE_BASELINE matches the main build\'s, key for key', () => {
    // The delta tool ships its own copy. Its own comment says it "mirrors the
    // main build's shipped proc code table" — nothing enforced that. If the
    // main build gains a code and this copy does not, the delta tool reports
    // two sessions as agreeing on proc codes when they do not.
    const a = P.PROC_CODE_BASELINE, b = D.PROC_CODE_BASELINE;
    const ka = Object.keys(a).sort(), kb = Object.keys(b).sort();
    const onlyMain = ka.filter(k => !(k in b)), onlyDelta = kb.filter(k => !(k in a));
    if (onlyMain.length || onlyDelta.length)
      throw new Error('BASELINES HAVE DRIFTED — only in main build: [' + onlyMain +
                      ']; only in delta tool: [' + onlyDelta + ']');
    const differ = ka.filter(k => a[k] !== b[k]).map(k => k + ' (' + a[k] + ' vs ' + b[k] + ')');
    if (differ.length) throw new Error('BEHAVIOURS HAVE DRIFTED: ' + differ.join(', '));
  });
  t('both copies still classify every code as remove or swap', () => {
    Object.keys(D.PROC_CODE_BASELINE).forEach(k => {
      const v = D.PROC_CODE_BASELINE[k];
      if (v !== 'remove' && v !== 'swap') throw new Error(k + ' is "' + v + '"');
    });
  });

  console.log('\n== procTableOf and procTableDiff ==');
  t('a session with no overrides runs under the baseline', () => {
    eq(D.procTableOf({ procOverrides: null }), D.PROC_CODE_BASELINE);
    eq(D.procTableOf(null), D.PROC_CODE_BASELINE, 'a missing session too:');
  });
  t('overrides replace the baseline outright, they do not merge into it', () => {
    const tbl = D.procTableOf({ procOverrides: { XR: 'remove' } });
    eq(Object.keys(tbl), ['XR']);
    eq(tbl.BR, undefined, 'baseline BR must not leak through:');
  });
  t('codes are normalised and invalid behaviours dropped', () => {
    const tbl = D.procTableOf({ procOverrides: { ' xr ': 'REMOVE', TSW: 'delete', '': 'swap' } });
    eq(tbl, { XR: 'remove' });
  });
  t('two identical sessions report no proc difference', () => {
    eq(D.procTableDiff({ procOverrides: null }, { procOverrides: null }).same, true);
  });
  t('absent means install, so a code added on one side is a difference', () => {
    const d = D.procTableDiff({ procOverrides: { XR:'remove' } },
                              { procOverrides: { XR:'remove', TSW:'swap' } });
    eq(d.same, false);
    eq(d.codes, [{ code:'TSW', a:'install', b:'swap' }]);
  });
  t('a code reclassified from remove to swap is reported with both sides', () => {
    const d = D.procTableDiff({ procOverrides:{ XR:'remove' } }, { procOverrides:{ XR:'swap' } });
    eq(d.codes, [{ code:'XR', a:'remove', b:'swap' }]);
  });
  t('differences are sorted so the sheet is stable between runs', () => {
    const d = D.procTableDiff({ procOverrides:{} },
                              { procOverrides:{ ZZ:'swap', AA:'remove', MM:'swap' } });
    eq(d.codes.map(c => c.code), ['AA', 'MM', 'ZZ']);
  });
  t('a baseline session versus a custom one is a difference, not a match', () => {
    eq(D.procTableDiff({ procOverrides:null }, { procOverrides:{ XR:'remove' } }).same, false);
  });

  console.log('\n== procProfileLabel agrees with the main build ==');
  t('the two tools label the same session identically', () => {
    [[null, null], [{ XR:'remove' }, null], [{ XR:'remove' }, 'Program Falcon'],
     [null, 'Program Falcon']].forEach(([ov, nm]) => {
      P.setProcCodeMap(ov, nm);
      const main = P._procProfileLabel();
      const delta = D.procProfileLabel({ procOverrides: ov, procProfileName: nm });
      if (main !== delta)
        throw new Error('label drift for ' + JSON.stringify([ov, nm]) +
                        ': main says ' + JSON.stringify(main) +
                        ', delta says ' + JSON.stringify(delta));
    });
  });

  console.log('\n== Defect E: displayed but not compared ==');
  const claim = o => Object.assign({ id:'adj_1', type:'ebom_ncr_trace', mode:'embodiment',
    leg:'A', rowKey:'P1||TOP', reason:'ebom_ncr_trace', sme:'J.Doe',
    rationale:'traced', applied:false }, o);
  t('a changed NCR disposition number is reported as a modification', () => {
    // v3.1 compared c.dispNo only. On ebom_ncr_trace claims — the ones the
    // main build actually creates — the field is ncrDispNo, so this change
    // was invisible and the claim was omitted from the Claims sheet.
    const rows = D.claimsDelta({ adjudications:[claim({ ncrDispNo:'DISP-100' })] },
                               { adjudications:[claim({ ncrDispNo:'DISP-999' })] });
    eq(rows.length, 1, 'modification missed:');
    eq(rows[0].Change, 'Modified');
    eq(rows[0]['NCR Disp No'], 'DISP-999');
  });
  t('a claim moving from pending to applied is reported', () => {
    const rows = D.claimsDelta({ adjudications:[claim({ applied:false })] },
                               { adjudications:[claim({ applied:true })] });
    eq(rows.length, 1);
    eq(rows[0].Applied, 'yes');
  });
  t('every field the Claims sheet prints is a field the signature compares', () => {
    // The rule the defect broke. Vary one field at a time and require the
    // signature to move. Timestamp is excluded deliberately — see HARNESS.md.
    const base = claim({ ncrDispNo:'D1', woNo:'W1', claimedQty:2, ciKey:'C1',
                         smeRole:'Lead', rowKeys:['a','b'] });
    const vary = { type:'other', leg:'B', rowKey:'X||Y', ciKey:'C2', ncrDispNo:'D2',
                   woNo:'W2', claimedQty:5, sme:'A.Nother', smeRole:'Peer',
                   rationale:'different', applied:true };
    Object.keys(vary).forEach(f => {
      const changed = Object.assign({}, base); changed[f] = vary[f];
      if (D.claimSig(base) === D.claimSig(changed))
        throw new Error('claimSig ignores "' + f + '", which claimRow displays');
    });
  });
  t('an unchanged claim produces no row at all', () => {
    eq(D.claimsDelta({ adjudications:[claim({ ncrDispNo:'D1' })] },
                     { adjudications:[claim({ ncrDispNo:'D1' })] }).length, 0);
  });

  console.log('\n== claimsDelta bookkeeping ==');
  t('added, removed and modified claims are each labelled', () => {
    const A = { adjudications:[claim({ id:'a1' }), claim({ id:'a2', rationale:'old' })] };
    const B = { adjudications:[claim({ id:'a2', rationale:'new' }), claim({ id:'a3' })] };
    const rows = D.claimsDelta(A, B);
    eq(rows.map(r => r.Change + ':' + r['Claim ID']).sort(),
       ['Added in B:a3', 'Modified:a2', 'Removed in B:a1']);
  });
  t('claims with no id are ignored rather than crashing', () => {
    eq(D.claimsDelta({ adjudications:[{ rationale:'orphan' }] },
                     { adjudications:[] }).length, 0);
  });
  t('a session with no adjudications key is treated as empty', () => {
    eq(D.claimsDelta({}, {}).length, 0);
    eq(D.claimsDelta({}, { adjudications:[claim({ id:'z' })] }).length, 1);
  });

  console.log('\n== v3.3: the indenture scope must be surfaced, not silently diffed ==');
  t('a session without the field is read as the pre-v160 A/B rule', () => {
    // Sessions written before the setting existed ran under the fixed A/B rule.
    // Defaulting to an empty list would claim every level reconciled.
    eq(D.collectorLevelsOf({}), ['A', 'B']);
    eq(D.collectorLevelsOf(null), ['A', 'B']);
    eq(D.collectorLevelsOf({ collectorLevels: 'nonsense' }), ['A', 'B'], 'and junk too:');
  });
  t('the scope label reads the way the main build words it', () => {
    eq(D.collectorScopeLabel({ collectorLevels: ['A','B'] }), 'A + B excluded');
    eq(D.collectorScopeLabel({ collectorLevels: [] }), 'All levels reconcile');
    eq(D.collectorScopeLabel({ collectorLevels: ['A'] }), 'A excluded');
  });
  t('two sessions on the same scope report no difference', () => {
    eq(D.indentureScopeDiff({ collectorLevels:['A','B'] },
                            { collectorLevels:['A','B'] }).same, true);
    eq(D.indentureScopeDiff({}, { collectorLevels:['A','B'] }).same, true,
       'an old session matches an explicit default:');
  });
  t('order does not fake a difference', () => {
    eq(D.indentureScopeDiff({ collectorLevels:['B','A'] },
                            { collectorLevels:['A','B'] }).same, true);
  });
  t('a genuine scope difference is reported and explained', () => {
    const ctx = D.indentureContext({ collectorLevels:['A','B'] }, { collectorLevels:[] });
    eq(ctx.diff.same, false);
    if (!ctx.warning) throw new Error('a scope mismatch must produce a warning');
    ['A + B excluded', 'All levels reconcile'].forEach(x => {
      if (ctx.warning.indexOf(x) < 0) throw new Error('the warning must name both scopes');
    });
    if (ctx.warning.indexOf('build') < 0)
      throw new Error('the warning must say the change may not be a build change');
  });
  t('matching scopes produce no warning', () => {
    eq(D.indentureContext({ collectorLevels:['A','B'] }, {}).warning, '');
  });
  t('the scope appears as a provenance row and a load-time warning', () => {
    if (!/line\('EBOM indenture scope'/.test(DSRC))
      throw new Error('the summary does not report the scope');
    if (!/indentureContext\(state\.A, state\.B\)/.test(DSRC))
      throw new Error('the load-time guard does not check the scope');
    // It must not be gated on a leg being present — the scope governs the EBOM
    // side, which every comparison mode has.
    const seg = DSRC.slice(DSRC.indexOf("line('EBOM indenture scope'") - 400,
                           DSRC.indexOf("line('EBOM indenture scope'"));
    if (/if \(!procCtx \|\| procCtx\.relevant\)/.test(seg))
      throw new Error('the scope row is gated behind the ABOM-leg check');
  });
  t('scope exclusion is still driven by status, not by indenture level', () => {
    // The delta tool excludes on the 'collector' STATUS, so it inherits the
    // main build's setting automatically. If it ever started reading indenture
    // letters itself, that would be a second copy of the rule to keep in sync.
    if (/indenture\s*===?\s*'[A-Z]'/.test(DSRC))
      throw new Error('the delta tool now derives the collector rule itself');
    eq(D.fscope([{ overall:'collector' }, { overall:'ok' }]).length, 1);
  });

  console.log('\n== Small helpers ==');
  t('dNorm and normPN normalise identically to the main build', () => {
    ['  p1 ', 'p1', 'P1', '', null, undefined, 0, 123].forEach(v => {
      eq(D.dNorm(v), D.normPN(v), JSON.stringify(v) + ':');
    });
    eq(D.dNorm('  abc '), 'ABC');
  });
  t('pct guards against divide-by-zero', () => {
    eq(D.pct(1, 0), '\u2014', 'zero denominator:');
    eq(D.pct(1, 4), '25.0%');
    eq(D.pct(0, 4), '0.0%');
  });
  t('the delta tool reports a version consistent with its filename', () => {
    const m = DSRC.match(/<title>([^<]*)<\/title>/);
    const fileV = DELTA.match(/v([\d_]+)\.html$/)[1].replace(/_/g, '.');
    if (m[1].indexOf(fileV) < 0)
      throw new Error('title says ' + JSON.stringify(m[1]) +
                      ' but the file is v' + fileV);
  });
});

// ── TIER 6 ─────────────────────────────────────────────────────────────────
// The delta tool's report assembly: the two-pass EBOM matcher, the KPI counters
// and the NCR disposition diff. Tier 4 covered the comparison layer; this is
// what actually fills the sheets.
suite('Tier 6 — delta tool report assembly', (t, eq) => {
  const D = sandbox({}, ['delta']).D;
  const row = (pn, nh, o) => Object.assign({ key: pn + '||' + nh, pn, nh, eq: 1 }, o);
  const sess = (rows, o) => Object.assign({ results: rows }, o);
  const changes = (a, b) => D.ebomChanges(sess(a), sess(b));
  const typesOf = rows => rows.map(r => r['Change Type'] + ':' + r['Part Number']);

  console.log('\n== The four EBOM change types ==');
  t('an unchanged BOM produces no rows at all', () => {
    const r = [row('P1','TOP'), row('P2','TOP')];
    eq(changes(r, r).length, 0);
  });
  t('a quantity change is reported with both old and new values', () => {
    const out = changes([row('P1','TOP',{eq:2})], [row('P1','TOP',{eq:5})]);
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Old Qty'], out[0]['New Qty']], ['Qty Changed','2','5']);
  });
  t('eqText wins over eq, so display text drives the comparison', () => {
    // A row carrying '2 EA' as text must not read as quantity 2.
    const out = changes([row('P1','TOP',{eq:2, eqText:'2 EA'})],
                        [row('P1','TOP',{eq:2, eqText:'3 EA'})]);
    eq([out.length, out[0]['Old Qty'], out[0]['New Qty']], [1, '2 EA', '3 EA']);
  });
  t('a part only in B is Added, a part only in A is Removed', () => {
    const out = changes([row('GONE','TOP')], [row('NEW','TOP')]);
    eq(typesOf(out), ['Removed:GONE', 'Added:NEW']);
  });
  t('the same PN under a new parent is ONE Re-parented row, not add plus remove', () => {
    const out = changes([row('P1','OLD')], [row('P1','NEW')]);
    eq(out.length, 1, 'must not double-report:');
    eq([out[0]['Change Type'], out[0]['Old Next Higher'], out[0]['New Next Higher']],
       ['Re-parented', 'OLD', 'NEW']);
  });
  t('re-parenting carries the quantity change across with it', () => {
    const out = changes([row('P1','OLD',{eq:2})], [row('P1','NEW',{eq:7})]);
    eq([out[0]['Old Qty'], out[0]['New Qty']], ['2', '7']);
  });
  t('rows are ordered Removed, Re-parented, Qty Changed, Added', () => {
    const out = changes(
      [row('AGONE','T'), row('BMOVE','OLD'), row('CQTY','T',{eq:1})],
      [row('BMOVE','NEW'), row('CQTY','T',{eq:9}), row('DNEW','T')]);
    eq(out.map(r => r['Change Type']),
       ['Removed', 'Re-parented', 'Qty Changed', 'Added']);
  });

  console.log('\n== The greedy matcher\'s edges ==');
  t('two removals and one addition of the same PN leave one Removed row', () => {
    const out = changes([row('P1','A'), row('P1','B')], [row('P1','C')]);
    eq(typesOf(out).sort(), ['Re-parented:P1', 'Removed:P1']);
  });
  t('one removal and two additions of the same PN leave one Added row', () => {
    const out = changes([row('P1','A')], [row('P1','B'), row('P1','C')]);
    eq(typesOf(out).sort(), ['Added:P1', 'Re-parented:P1']);
  });
  t('a PN whose case or padding differs still matches as re-parented', () => {
    const out = changes([row(' p1 ','OLD')], [row('P1','NEW')]);
    eq(out[0]['Change Type'], 'Re-parented', 'normPN must drive the pairing:');
  });
  t('duplicate keys keep the FIRST row, matching the main build convention', () => {
    const out = changes([row('P1','TOP',{eq:1}), row('P1','TOP',{eq:99})],
                        [row('P1','TOP',{eq:1})]);
    eq(out.length, 0, 'the second duplicate must be ignored:');
  });
  t('EBOM line numbers are joined for the sheet', () => {
    const out = changes([row('P1','T',{eq:1})],
                        [row('P1','T',{eq:2, ebomLineNos:[10,20]})]);
    eq(out[0]['EBOM Line No(s)'], '10; 20');
    const bare = changes([row('P2','T',{eq:1})], [row('P2','T',{eq:2})]);
    eq(bare[0]['EBOM Line No(s)'], '', 'absent line numbers give an empty cell:');
  });

  console.log('\n== KPI counters ==');
  const kpiRow = (o) => Object.assign({ overall:'ok', ms:'ok', as:'ok' }, o);
  t('structural rows are excluded from the KPI scope', () => {
    const k = D.computeKpis(sess([kpiRow({}), kpiRow({overall:'pt_collector'}),
      kpiRow({overall:'pt_reference'}), kpiRow({overall:'pt_bulk'}),
      kpiRow({overall:'pt_removal'}), kpiRow({overall:'collector'})],
      { mode:'ebom_mbom_abom' }));
    eq(k.scopeTotal, 1, 'only the real line item counts:');
  });
  t('direct, covered and used-on all count toward "any", but only direct counts as direct', () => {
    const k = D.computeKpis(sess([
      kpiRow({ ms:'ok' }), kpiRow({ ms:'covered' }),
      kpiRow({ ms:'missing', msUsedOn:'pn_as_usedon' }), kpiRow({ ms:'missing' })],
      { mode:'ebom_mbom' }));
    eq([k.mbomDirect, k.mbomAny, k.mbomMissing], [1, 3, 2]);
  });
  t('adjudicated statuses count as satisfied', () => {
    const k = D.computeKpis(sess([kpiRow({ms:'direct_adjudicated'}),
      kpiRow({ms:'qty_mismatch_accepted'}), kpiRow({ms:'flex_ok'}),
      kpiRow({ms:'covered_adjudicated'})], { mode:'ebom_mbom' }));
    eq([k.mbomDirect, k.mbomAny], [3, 4]);
  });
  t('ABOM-only counters are reported separately', () => {
    const k = D.computeKpis(sess([kpiRow({as:'wo_open'}), kpiRow({as:'proc_removed'}),
      kpiRow({as:'qty_mismatch'})], { mode:'ebom_abom' }));
    eq([k.abomOpen, k.abomProcRemoved, k.abomQty], [1, 1, 1]);
    eq(k.mbomDirect, undefined, 'MBOM counters must be absent in an ABOM-only session:');
  });
  t('claims are counted and their applied state reported', () => {
    eq(D.computeKpis(sess([], { mode:'ebom_mbom' })).claims, 0);
    const k = D.computeKpis(sess([], { mode:'ebom_mbom',
      adjudications:[{id:'a'},{id:'b'}], adjudicationsApplied:true }));
    eq([k.claims, k.claimsApplied], [2, 'applied']);
  });

  console.log('\n== Mode vocabulary must not drift between the two files ==');
  t('the delta tool agrees with the main build about every mode it knows', () => {
    // Same class of risk as the duplicated PROC_CODE_BASELINE: the main build
    // owns the mode vocabulary in getModeRequired's table, and the delta tool
    // re-states it as two negative tests. Add a fifth mode to the main build
    // and the delta tool would silently report both MBOM and ABOM KPIs for it.
    const start = at('const modeZones = {');
    const block = SRC.slice(start, at('};', start));
    const modes = [...block.matchAll(/'([a-z_]+)':\s*\[([^\]]*)\]/g)]
      .map(m => ({ mode: m[1], zones: m[2].split(',').map(z => z.trim().replace(/'/g, '')) }));
    if (modes.length < 4) throw new Error('only found ' + modes.length + ' modes — table moved?');
    modes.forEach(({ mode, zones }) => {
      eq(D.modeHasMbom(mode), zones.indexOf('mbom') >= 0, mode + ' MBOM:');
      eq(D.modeHasAbom(mode), zones.indexOf('abom') >= 0, mode + ' ABOM:');
    });
  });
  t('a session with no mode recorded reports both sides rather than neither', () => {
    // Fail-open. Documented, not necessarily desirable: an old session missing
    // `mode` shows a full set of zeroed MBOM KPIs as though everything failed.
    eq([D.modeHasMbom(undefined), D.modeHasAbom(undefined)], [true, true]);
  });

  console.log('\n== Pre-rename sessions and missing files ==');
  t('the CHP zone is read under both its old and new key', () => {
    // v3.1 renamed 'cp' -> 'chp'. Sessions exported before that carry the old one.
    eq(D.chpBom({ boms:{ chp:{ data:[1] } } }).data, [1], 'new key:');
    eq(D.chpBom({ boms:{ cp:{ data:[2] } } }).data, [2], 'old key:');
    eq(D.chpBom({ boms:{} }), null, 'neither:');
    eq(D.chpBom(null), null, 'no session:');
  });
  t('a new-key CHP wins over a stale old-key one', () => {
    eq(D.chpBom({ boms:{ chp:{ data:['new'] }, cp:{ data:['old'] } } }).data, ['new']);
  });
  t('a missing NCR file returns a note naming which session lacked it', () => {
    const only = D.ncrDispositionDelta({ boms:{} }, { boms:{ ncr:{ data:[] } } });
    if (!only.note || only.note.indexOf('Session A') < 0)
      throw new Error('must name Session A: ' + JSON.stringify(only.note));
    const both = D.ncrDispositionDelta({ boms:{} }, { boms:{} });
    if (both.note.indexOf('Session A or Session B') < 0)
      throw new Error('must name both: ' + JSON.stringify(both.note));
  });
  t('NCR rows without a number are skipped rather than counted', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    // `results` is mandatory throughout the delta tool — inScopeSet, fscope and
    // computeKpis all read it unguarded, so a session without it is malformed.
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('', 'D1'), mk('N1', 'D1')]),
                                      s([mk('N1', 'D1')]));
    if (out.note) throw new Error('unexpected note: ' + out.note);
    eq(out.rows.length, 0, 'the blank-numbered row must not appear as a change:');
  });
  t('a disposition status change is reported with both statuses', () => {
    const N = D.NCR_COL;
    const mk = st => { const r = []; r[N.ncrNum] = 'N1'; r[N.dispNo] = 'D1';
                       r[N.dispStatus] = st; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('OPEN')]), s([mk('CLOSED')])).rows;
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Old Disposition Status'],
        out[0]['New Disposition Status']],
       ['Disposition status changed', 'OPEN', 'CLOSED']);
  });
  t('a brand new NCR is distinguished from a new disposition on an existing one', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('N1','D1')]),
                                      s([mk('N1','D1'), mk('N1','D2'), mk('N2','D9')])).rows;
    const byType = {}; out.forEach(r => { byType[r['Change Type']] = r['NCR Number']; });
    eq(byType['New disposition on existing NCR'], 'N1');
    eq(byType['New NCR'], 'N2');
  });
  t('a disposition present in A but not B is flagged for investigation', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('N1','D1'), mk('N1','D2')]), s([mk('N1','D1')])).rows;
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Disposition No']],
       ['Dropped from B — investigate', 'D2']);
  });

  // v3.6 — the main build counts NCR entries by Disposition Code (v186), so a
  // disposition whose code moved has to show up here, or a shift between two
  // sessions' code counts cannot be traced to anything.
  console.log('\n== Disposition code changes (v3.6) ==');
  const dmk = (st, code) => { const N = D.NCR_COL; const r = []; r[N.ncrNum] = 'N1'; r[N.dispNo] = 'D1';
                              r[N.dispStatus] = st; r[N.dispCode] = code; return r; };
  const ds = b => ({ results: [], boms:{ ncr:{ data:b } } });
  t('a disposition code change is reported with the old and the new code', () => {
    const out = D.ncrDispositionDelta(ds([dmk('OPEN', 'REWORK')]), ds([dmk('OPEN', 'UAI')])).rows;
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Old Disposition Code'], out[0]['Disposition Code'],
        out[0]['Old Disposition Status'], out[0]['New Disposition Status']],
       ['Disposition code changed', 'REWORK', 'UAI', 'OPEN', 'OPEN']);
  });
  t('a code that differs only in letter case or spaces is not a change', () => {
    eq(D.ncrDispositionDelta(ds([dmk('OPEN', 'uai ')]), ds([dmk('OPEN', 'UAI')])).rows.length, 0);
  });
  t('a status and a code change together are one row that carries the old code', () => {
    const out = D.ncrDispositionDelta(ds([dmk('OPEN', '')]), ds([dmk('CLOSED', 'SCRAP')])).rows;
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Old Disposition Code'], out[0]['Disposition Code']],
       ['Disposition status changed', '(blank)', 'SCRAP'], 'a blank old code is named, not left empty:');
    const same = D.ncrDispositionDelta(ds([dmk('OPEN', 'UAI')]), ds([dmk('CLOSED', 'UAI')])).rows;
    eq(same[0]['Old Disposition Code'], '', 'no code change, no old code:');
  });
  t('the Summary counts disposition code changes, in the order of the sheet', () => {
    const b = grabDelta('buildSummaryRows');
    if (!/disp status changes \/ disp code changes \/ NCR status changes/.test(b)) throw new Error('the Summary label does not name code changes');
    const i = b.indexOf("nc['Disposition status changed']"), j = b.indexOf("nc['Disposition code changed']"), k = b.indexOf("nc['NCR status changed']");
    if (!(i >= 0 && i < j && j < k)) throw new Error('the counts are not in the label order');
  });
});

// ── TIER 7 ─────────────────────────────────────────────────────────────────
// Detailed View markers and raw-BOM badges. These are rendering rules, so the
// tests lift the real expressions out of the build and evaluate them rather
// than restating the logic — a restatement would drift the way the v149
// explanation modal drifted from the code it described.
suite('Tier 7 — Detailed View markers and raw-BOM badges', (t, eq) => {
  const _STATUS_COVERED = new Set(['covered', 'covered_adjudicated']);
  const lift = re => { const m = SRC.match(re);
    if (!m) throw new Error('BUILD MARKER MOVED: ' + re);
    return m[0].trim().replace(/^const /, 'var '); };

  const mbomCell = new Function('r', '_STATUS_COVERED',
    'var mDirActive = r.inMbomDirectPool;' +
    lift(/const mIsParentMark\s*=[\s\S]{0,160}?;/) +
    lift(/const mDirCls\s*=[\s\S]{0,260}?;/) +
    lift(/const mDirQty\s*=[\s\S]{0,160}?;/) +
    'return { cls: mDirCls, qty: mDirQty };');
  const abomCell = new Function('r', '_STATUS_COVERED',
    'var aDirActive = r.inAbomDirectPool || (r.as === "wo_open" && r.aq !== null);' +
    lift(/const aIsParentMark\s*=[\s\S]{0,160}?;/) +
    lift(/const aDirCls\s*=[\s\S]{0,200}?;/) +
    lift(/const aDirQty\s*=[\s\S]{0,160}?;/) +
    'return { cls: aDirCls, qty: aDirQty };');
  const M = (ms, o) => mbomCell(Object.assign({ ms, mq:null, inMbomDirectPool:false }, o), _STATUS_COVERED);
  const A = (as, o) => abomCell(Object.assign({ as, aq:null, inAbomDirectPool:false }, o), _STATUS_COVERED);
  const MARK = '\u2191 parent';

  console.log('\n== The marker carries exactly ONE style ==');
  t('every MBOM row showing the marker uses the same class', () => {
    const styles = new Set();
    ['covered', 'covered_adjudicated', 'collector'].forEach(ms => {
      [false, true].forEach(nh => {
        const c = M(ms, { nhMismatchMbom: nh });
        if (c.qty === MARK) styles.add(c.cls);
      });
    });
    eq([...styles], ['td-parent-mark'], 'distinct MBOM marker styles:');
  });
  t('every ABOM row showing the marker uses the same class', () => {
    const styles = new Set();
    ['covered', 'covered_adjudicated', 'collector'].forEach(as => {
      const c = A(as, { nhMismatchAbom: true });
      if (c.qty === MARK) styles.add(c.cls);
    });
    eq([...styles], ['td-parent-mark'], 'distinct ABOM marker styles:');
  });
  t('an NH mismatch no longer overrides the marker style', () => {
    // The v149 defect: nhMismatchMbom was tested first, so a covered row with
    // an NH mismatch rendered hl-parentage — a grey block, a third look.
    eq(M('covered', { nhMismatchMbom: true }).cls, 'td-parent-mark');
    eq(M('collector', { nhMismatchMbom: true }).cls, 'td-parent-mark');
  });
  t('the NH-mismatch highlight still applies to rows that show a real value', () => {
    // The flag must keep working where it is not competing with the marker.
    eq(M('ok', { nhMismatchMbom: true }).cls, 'hl-parentage');
    eq(M('missing', { nhMismatchMbom: true }).cls, 'hl-missing', 'missing still wins:');
  });
  t('a row with a real direct quantity shows the number, never the marker', () => {
    const c = M('covered', { mq: 4, inMbomDirectPool: true });
    eq([c.qty, c.cls], [4, ''], 'a real qty must not be styled as a marker:');
    eq(A('covered', { aq: 7, inAbomDirectPool: true }).qty, 7);
  });
  t('rows with no coverage show an em dash, not the marker', () => {
    ['missing', 'qty_mismatch', 'ok'].forEach(s => eq(M(s).qty, '\u2014', s + ':'));
  });
  t('the retired two-style classes are gone from the stylesheet and the code', () => {
    const live = SRC.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
    ['td-covered', 'td-collector'].forEach(c => {
      if (live.includes(c)) throw new Error(c + ' still referenced outside comments');
    });
  });

  console.log('\n== The explanation modal must match the code ==');
  t('the modal no longer claims two styles', () => {
    if (/carries exactly two styles/.test(SRC))
      throw new Error('the erroneous v149 explanation is still shipping');
  });
  t('the modal points the reader at the badge rather than a colour', () => {
    const p = SRC.match(/<p><strong>The "\u2191 parent" marker<\/strong>[\s\S]{0,900}?<\/p>/);
    if (!p) throw new Error('the marker explanation paragraph is gone');
    ['one style', 'PARENT IND. EMBODIED', 'COLLECTOR (A/B)'].forEach(s => {
      if (p[0].indexOf(s) < 0) throw new Error('explanation no longer mentions ' + JSON.stringify(s));
    });
    if (/green italic/.test(p[0])) throw new Error('still describes a green style');
  });

  console.log('\n== Raw-BOM view badges ==');
  const badgeFor = new Function('overall', '_STATUS_COVERED', `
    var result = { overall: overall };
    var issueKeys = new Set(['X']);
    var hasIssue = !(overall === 'pt_collector' || overall === 'pt_reference' ||
                     overall === 'pt_bulk' || overall === 'pt_removal') &&
                   overall !== 'ok' && overall !== 'covered' && overall !== 'collector' &&
                   overall !== 'flex_ok' && overall !== 'pn_as_usedon';
    ` + lift(/const isPtExclResult\s*=[\s\S]{0,260}?;/) + `
    var coveredLike = result && (_STATUS_COVERED.has(result.overall) ||
                       result.overall === 'collector' || result.overall === 'pn_as_usedon');
    if (isPtExclResult) return 'PT-BADGE';
    if (coveredLike) return 'COVERED-BADGE';
    if (!hasIssue) return 'OK';
    return 'CATCH-ALL';`);
  t('removal-scope rows no longer render a green tick', () => {
    // v154 and earlier: pt_removal was absent from isPtExclResult, so it fell
    // to the "no issue" branch and showed ✓ OK — a pass mark on a line that is
    // out of scope rather than one that passed.
    eq(badgeFor('pt_removal', _STATUS_COVERED), 'PT-BADGE');
  });
  t('the other part-type exclusions are unchanged', () => {
    ['pt_collector', 'pt_reference', 'pt_bulk'].forEach(s =>
      eq(badgeFor(s, _STATUS_COVERED), 'PT-BADGE', s + ':'));
  });
  t('genuinely clean rows still show OK', () => {
    ['ok', 'flex_ok'].forEach(s => eq(badgeFor(s, _STATUS_COVERED), 'OK', s + ':'));
  });
  t('every status reaching the catch-all is an unresolved outcome', () => {
    const caught = ['missing', 'qty_mismatch', 'flex_missing', 'wo_open', 'proc_removed']
      .filter(s => badgeFor(s, _STATUS_COVERED) === 'CATCH-ALL');
    eq(caught.length, 5, 'all five still route to the catch-all:');
  });
  t('the catch-all badge is neutral, not a warning', () => {
    // Two of the five statuses it covers are BY DESIGN — SUB/AR absence and
    // proc-code removal — so a ⚠ treatment flags correct rows as defects.
    const live = SRC.replace(/^\s*\/\/.*$/gm, '');
    if (live.includes('CHECK EBOM'))
      throw new Error('the old CHECK EBOM badge is still shipping');
    // Anchor on the final `} else {` of the chain — matching the first
    // statusBadge assignment would test the ✓ OK branch instead.
    // v158 — the assignment became a template literal when the tooltip went in;
    // accept either quoting so the test tracks the requirement, not the syntax.
    const m = SRC.match(/\}\s*else\s*\{\s*(?:\/\/[^\n]*\n\s*)*statusBadge = [`']<span class="badge ([\w-]+)"[^>]*>([^<$]+)<\/span>[`'];/);
    if (!m) throw new Error('the catch-all badge assignment moved');
    eq([m[1], m[2]], ['badge-neutral', 'SEE SUMMARY']);
    if (/\u26a0/.test(m[2])) throw new Error('the warning glyph is back');
  });
  t('badge-neutral is defined in the stylesheet', () => {
    if (!/\.badge-neutral\s*\{/.test(STYLE_BLOCKS.map(b => b.css).join('\n')))
      throw new Error('badge-neutral has no rule');
  });
});

// ── TIER 8 ─────────────────────────────────────────────────────────────────
// CI Traceability Report columns. Removing a column from a sheet means editing
// the header AND every row builder; miss one and XLSX writes the rows anyway,
// silently shifting every value after it into the wrong column. Nothing in the
// export path validates that, so the harness does.
suite('Tier 8 — CI Traceability Report columns', (t, eq) => {
  const FN = (() => {
    const a = at('function exportCIReport()');
    return SRC.slice(a, at('// ── ACN KPI HELPER', a) > a ? at('// ── ACN KPI HELPER', a) : a + 130000);
  })();
  // Split an array literal into its top-level elements, respecting strings,
  // parentheses and nested brackets. A naive split on ',' breaks any header
  // containing a comma — 'Part Qty (ABOM, per WO)' became two columns — which
  // silently miscounts and produces confusing failures.
  function splitTop(body) {
    // v158 — strip comments FIRST. A `// A  CI ID` note is harmless, but
    // `// If the discrepant part is this CI's own part number` contains an
    // apostrophe that opens a phantom string and swallows the rest of the
    // array, and any comma in a comment splits a column in two. Both produce a
    // wrong count that looks like a real header/row mismatch.
    body = body.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/[^\n]*/g, '$1');
    const out = []; let d = 0, q = null, cur = '';
    for (let i = 0; i < body.length; i++) {
      const c = body[i];
      if (q) { cur += c; if (c === '\\') { cur += body[++i]; continue; } if (c === q) q = null; continue; }
      if (c === '"' || c === "'" || c === '`') { q = c; cur += c; continue; }
      if (c === '(' || c === '[' || c === '{') d++;
      else if (c === ')' || c === ']' || c === '}') d--;
      if (c === ',' && d === 0) { out.push(cur.trim()); cur = ''; continue; }
      cur += c;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  }
  function items(body) { return splitTop(body).length; }
  function bracket(src, from) {
    const a = src.indexOf('[', from);
    if (a < 0) throw new Error('no array literal after offset ' + from);
    let d = 0, i = a;
    for (;; i++) {
      if (i >= src.length) throw new Error('unbalanced array literal');
      if (src[i] === '[') d++; else if (src[i] === ']') { d--; if (!d) break; }
    }
    return src.slice(a + 1, i);
  }
  function headerList(name) {
    const m = FN.match(new RegExp('const ' + name + '\\s*=\\s*\\['));
    if (!m) throw new Error('BUILD MARKER MOVED: ' + name);
    return splitTop(bracket(FN, m.index))
      .map(x => x.replace(/^\s*['"]|['"]\s*$/g, ''));
  }

  console.log('\n== The parser this suite depends on ==');
  t('header parsing survives commas inside a column name', () => {
    // 'Part Qty (ABOM, per WO)' is a real header. A naive comma split turned it
    // into two columns, which would miscount every sheet that still uses it.
    eq(splitTop("'A', 'Part Qty (ABOM, per WO)', 'B'").length, 3);
    eq(splitTop("'CI as \"Used On\" Number', 'B'").length, 2, 'embedded quotes:');
    eq(splitTop("'A', ['x','y'], 'B'").length, 3, 'nested arrays:');
    eq(splitTop("'A', f(1, 2), 'B'").length, 3, 'calls:');
    eq(splitTop("'A', 'B',").length, 2, 'trailing comma:');
  });
  t('a header containing a comma is still counted as one column', () => {
    // Sheet 6 carried 'Part Qty (ABOM, per WO)' until v155 and other sheets
    // still do, so this is live behaviour, not a hypothetical.
    const withComma = headerList('embHigherHdr').filter(c => c.indexOf(',') >= 0);
    withComma.forEach(c => { if (!/^[^,]*\(.*,.*\)[^,]*$/.test(c))
      throw new Error('suspicious split: ' + JSON.stringify(c)); });
  });

  console.log('\n== No sheet may write more values than it has headers ==');
  t('every header width matches every one of its row builders', () => {
    const hdrs = [...FN.matchAll(/const (\w+Hdr)\s*=\s*\[/g)];
    if (hdrs.length < 10) throw new Error('only found ' + hdrs.length + ' sheets — report restructured?');
    const bad = [];
    hdrs.forEach(m => {
      const want = items(bracket(FN, m.index));
      const rowsVar = m[1].replace(/Hdr$/, 'Rows');
      [...FN.matchAll(new RegExp(rowsVar + '\\.push\\(', 'g'))].forEach(p => {
        const got = items(bracket(FN, p.index + p[0].length - 1));
        if (got !== want) bad.push(m[1] + ': header ' + want + ' vs row ' + got);
      });
    });
    if (bad.length) throw new Error('COLUMN COUNT MISMATCH — data will be shifted:\n        ' +
                                    bad.join('\n        '));
  });

  console.log('\n== #13 / #14: the Part Qty Text column is gone ==');
  t('CI EBOM Drawings + Change Ped no longer carries Part Qty Text', () => {
    const h = headerList('ciChpHdr');
    if (h.indexOf('Part Qty Text') >= 0) throw new Error('still present');
    eq(h.slice(0, 3), ['CI ID', 'Part Number', 'Next Higher Part Number'], 'columns A–C:');
  });
  t('CI Next-Higher Change Pedigree no longer carries Part Qty Text', () => {
    const h = headerList('nhChpHdr');
    if (h.indexOf('Part Qty Text') >= 0) throw new Error('still present');
    eq(h.slice(0, 3), ['CI ID', 'Next Higher Part Number', 'Drawing Number'], 'columns A–C:');
  });
  t('neither sheet still reads partQtyText into a row', () => {
    ['ciChpRows', 'nhChpRows'].forEach(v => {
      [...FN.matchAll(new RegExp(v + '\\.push\\(', 'g'))].forEach(p => {
        if (bracket(FN, p.index + p[0].length - 1).includes('partQtyText'))
          throw new Error(v + ' still pushes partQtyText');
      });
    });
  });

  console.log('\n== #15: column B says what it actually holds ==');
  t('the Next-Higher sheet labels column B as Next Higher Part Number', () => {
    // It has always pushed t.nh; the label said 'Part Number'.
    eq(headerList('nhChpHdr')[1], 'Next Higher Part Number');
    const p = FN.match(/nhChpRows\.push\(\[\s*t\.ciId\|\|'—',\s*t\.nh\|\|'—'/);
    if (!p) throw new Error('column B no longer pushes t.nh — the label may now be wrong again');
  });

  console.log('\n== #16 / #17 / #18: work-order columns named for what they are ==');
  t('CIs Embodied as Used On Parts — columns C to G', () => {
    eq(headerList('embUsedOnHdr').slice(2, 7),
       ['CI as "Used On" Number', 'Work Order Part Number', 'Work Order Part Qty',
        'Work Order Number', 'Work Order Status']);
  });
  t('CIs Embodied via Higher Parts — columns D, F, H, I', () => {
    const h = headerList('embHigherHdr');
    eq([h[3], h[5], h[7], h[8]],
       ['Work Order Part Number', 'Work Order Part Qty',
        'Work Order Number', 'Work Order Status']);
  });
  t('CIs Embodied via Higher Parts — C, E, G deliberately unchanged', () => {
    // These are EBOM-side or used-on values, not work-order values.
    const h = headerList('embHigherHdr');
    eq([h[2], h[4], h[6]],
       ['CI EBOM Part Indenture', 'Part Indenture (EBOM)', 'Used On Number (ABOM)']);
  });
  t('CIs Embodied as WO Parts — columns C to G', () => {
    eq(headerList('embWoHdr').slice(2, 7),
       ['Work Order Part Number', '"Used On" Number', 'Work Order Part Qty',
        'Work Order Number', 'Work Order Status']);
  });
  t('no renamed sheet still carries an (ABOM) suffix on a work-order column', () => {
    ['embUsedOnHdr', 'embHigherHdr', 'embWoHdr', 'abomClaimsHdr'].forEach(n => {
      const stale = headerList(n).filter(c => /^(Part Number|Part Qty|Work Order Number|Work Order Status) \(ABOM/.test(c));
      if (stale.length) throw new Error(n + ' still has: ' + stale.join(', '));
    });
  });

  console.log('\n== NCR disposition sheets: the reader-facing column order ==');
  t('CI Discrep Part w Used On Match leads with the reader-facing columns', () => {
    eq(headerList('ncrDispHdr').slice(0, 12),
       ['CI ID', 'CI Part Number', 'Originating Work Order', 'Discrepant Part Qty',
        'NCR Number', 'NCR Status', 'Defect Code Description', 'Disposition Number',
        'Disp. Status', 'Disp. Type', 'Disp. Code',
        'RFV Linked to NCR Disp# (RFV File)']);
  });
  t('CIs as Used On NCRs leads with the same columns plus the discrepant PN', () => {
    eq(headerList('cisUsedOnHdr').slice(0, 13),
       ['CI ID', 'CI Part Number', 'Originating Work Order', 'Discrepant Part Number',
        'Discrepant Part Qty', 'NCR Number', 'NCR Status', 'Defect Code Description',
        'Disposition Number', 'Disp. Status', 'Disp. Type', 'Disp. Code',
        'RFV Linked to NCR Disp# (RFV File)']);
  });
  t('the shortened disposition names replaced the NCR-prefixed ones', () => {
    // Every column on these two sheets is an NCR column, so the prefix carried
    // no information. The prefix survives where it still distinguishes —
    // 'NCR Cause Code' sits beside a defect code, for instance.
    ['ncrDispHdr', 'cisUsedOnHdr'].forEach(n => {
      const stale = headerList(n).filter(c =>
        /^NCR Disp(#| Status| Type| Code)$/.test(c) || c === 'NCR Defect Code Desc');
      if (stale.length) throw new Error(n + ' still has: ' + stale.join(', '));
    });
  });
  t('no other sheet was renamed by accident', () => {
    // Seven header arrays carried disposition columns; only two were in scope.
    // These five keep whatever they had — note noAbomNcrHdr spells them out in
    // full ('NCR Disposition #'), which is a third convention nobody asked to
    // change. Worth knowing it exists; not worth changing unasked.
    // FOUR conventions are in use across the report — worth knowing, not worth
    // changing unasked: 'NCR Disp#' (detail, csa, claims), 'NCR Disposition #'
    // (noAbomNcr), 'Disposition #' (adj), and the two sheets v158 moved to
    // 'Disposition Number'. Pinned so a future rename is a decision, not a drift.
    const expect = { detailHdr: 'NCR Disp#', csaHdr: 'NCR Disp#',
                     noAbomNcrHdr: 'NCR Disposition #',
                     adjHdr: 'Disposition #', claimsHdr: 'NCR Disp#' };
    Object.keys(expect).forEach(n => {
      if (headerList(n).indexOf(expect[n]) < 0)
        throw new Error(n + ' lost its ' + JSON.stringify(expect[n]) +
                        ' column — that sheet was not in scope');
    });
  });

  console.log('\n== Paired sheets must label identical data identically ==');
  t('CI ABOM Claims Processed matches CIs Embodied as WO Parts, columns A to G', () => {
    // These are the SME-adjudicated and auto-detected halves of one idea. The
    // As-Built Records Guide states the pairing outright, so renaming one and
    // not the other would leave the same workbook disagreeing with itself.
    eq(headerList('abomClaimsHdr').slice(0, 7), headerList('embWoHdr').slice(0, 7));
  });
  t('the As-Built Records Guide still names both sheets it aligns to', () => {
    // The guide's alignment notes reference report sheets by NAME and describe
    // their semantics, not their column letters — so v155's column edits left
    // them accurate. This test fails if a sheet is ever renamed, which WOULD
    // break them.
    const guide = SRC.slice(at('function exportCIAsBuiltGuide()'),
                            at('XLSX.utils.book_append_sheet(wb, ws, \'CI As-Built Records Guide\')'));
    ['CIs Embodied as WO Parts', 'CIs Embodied as Used On Parts',
     'CIs Embodied via Higher Parts', 'CI ABOM Claims Processed',
     'NCR CI Claims Processed'].forEach(name => {
      if (guide.indexOf(name) < 0)
        throw new Error('the guide no longer references the sheet ' + JSON.stringify(name));
      if (SRC.indexOf("book_append_sheet(wb, ") < 0 || SRC.indexOf("'" + name + "'") < 0)
        throw new Error('the guide references a sheet that no longer exists: ' + name);
    });
  });
});

// ── TIER 9 ─────────────────────────────────────────────────────────────────
// The MBOM column trio appears on FOUR surfaces — the on-screen Detailed View,
// the context export, the CSV export and the XLSX export — each with its own
// header list and its own row builder. Move a header without its row builder
// and every column after it shifts silently. These tests pin header and data
// order together, on every surface.
suite('Tier 9 — MBOM column order across every surface', (t, eq) => {
  const HDR_NEW = /'MBOM Traceability'\s*,\s*'MBOM Reconciliation Notes'\s*,\s*'MBOM Job Number'/g;
  const HDR_OLD = /'MBOM Traceability'\s*,\s*'MBOM Job Number'/g;
  const ROW_NEW = /mbomTraceabilityText\(r\),\s*mbomNotesText\(r\),\s*\(_mJobs/g;
  const ROW_OLD = /mbomTraceabilityText\(r\),\s*\(_mJobs/g;

  console.log('\n== #3: Job Number sits right of Reconciliation Notes ==');
  t('no surface still carries the old order', () => {
    eq((SRC.match(HDR_OLD) || []).length, 0, 'headers in old order:');
    eq((SRC.match(ROW_OLD) || []).length, 0, 'row builders in old order:');
  });
  t('all four header lists and the banner grouping use the new order', () => {
    // 4 header pushes (screen, context, CSV, XLSX) + the mbomCols silo list.
    eq((SRC.match(HDR_NEW) || []).length, 5);
  });
  t('all three export row builders use the new order', () => {
    // The fourth surface is the on-screen table, which emits <td> directly.
    eq((SRC.match(ROW_NEW) || []).length, 3);
  });
  t('every surface with a Job Number header also builds a Job Number cell', () => {
    // The failure this guards: a header list moved, its row builder forgotten.
    // Count ONLY pushes that carry the Job Number — the HTML report pushes the
    // Traceability/Notes PAIR and has never had a Job Number column, so it is
    // correctly excluded rather than counted and subtracted.
    const withJob = (SRC.match(/(?:hdr|cols)\.push\('MBOM Traceability'[^;]*'MBOM Job Number'/g) || []).length;
    const rows    = (SRC.match(ROW_NEW) || []).length;
    eq(withJob, 4, 'header lists carrying Job Number (screen + 3 exports):');
    eq(withJob - rows, 1, 'the unmatched one must be the on-screen table:');
  });
  t('the HTML report still carries the pair and no Job Number column', () => {
    const m = SRC.match(/thdr\.push\('MBOM Traceability'[^;]*;/);
    if (!m) throw new Error('the HTML report header moved');
    if (m[0].indexOf('MBOM Job Number') >= 0)
      throw new Error('the HTML report gained a Job Number column without a row builder');
    if (m[0].indexOf('MBOM Reconciliation Notes') < 0)
      throw new Error('the HTML report lost Reconciliation Notes');
  });
  t('the on-screen cells are emitted in the same order as the header', () => {
    const td = SRC.match(/html \+= `<td class="td-gutter-l">\$\{buildMbomTraceability\(r\)\}<\/td>[\s\S]{0,260}?`;/);
    if (!td) throw new Error('the MBOM cell block moved');
    const order = ['buildMbomTraceability', 'buildMbomNotes', 'mJobHtml']
      .map(k => td[0].indexOf(k));
    if (order.some(i => i < 0)) throw new Error('a cell is missing: ' + td[0]);
    eq(order.slice().sort((a, b) => a - b), order,
       'screen order must be Traceability, Notes, Job:');
  });
  t('the gutter still falls on the first MBOM column', () => {
    // The left border marks where the MBOM silo begins. Traceability stayed
    // first, so it must still be the gutter column.
    const m = SRC.match(/const gutterCols = \[([\s\S]{0,600}?)\]/);
    if (!m) throw new Error('gutterCols moved');
    if (m[1].indexOf("'MBOM Traceability'") < 0)
      throw new Error('MBOM Traceability is no longer the gutter column');
    if (m[1].indexOf("'MBOM Job Number'") >= 0)
      throw new Error('the gutter moved onto the Job Number column');
  });

  console.log('\n== The prose describing the order ==');
  t('no comment or modal still says Job Number sits between the pair', () => {
    if (/Traceability\s*→\s*HERE\s*→\s*Reconciliation Notes/.test(SRC))
      throw new Error('the v149 design note still describes the old position');
    const modal = SRC.match(/<strong>MBOM Job Number<\/strong>[\s\S]{0,400}?\./);
    if (!modal) throw new Error('the Job Number modal paragraph is gone');
    if (modal[0].indexOf('right of MBOM Reconciliation Notes') < 0)
      throw new Error('the modal does not state the new position');
  });
});

// ── TIER 10 ────────────────────────────────────────────────────────────────
// The badge guide against the badge maps. A guide that drifts from the code is
// worse than no guide: it teaches the reader a vocabulary the tool no longer
// speaks. This suite derives the expected entries FROM the maps, so adding a
// badge without documenting it fails the build.
suite('Tier 10 — badge guide completeness', (t, eq) => {
  const GUIDE = (() => {
    const a = at('function showBadgeGuide()');
    return SRC.slice(a, at('_setReportHtml(html)', a));
  })();
  // Every [class, label] pair in the three status→badge maps.
  function mapLabels(fn) {
    const a = at('function ' + fn + '(');
    const blk = SRC.slice(a, SRC.indexOf('\n}', a));
    return [...blk.matchAll(/\[\s*'([\w\- ]+)'\s*,\s*'([^']+)'\s*\]/g)].map(m => m[2]);
  }
  const ALL = [...new Set([].concat(mapLabels('badgeBom'), mapLabels('badgeAbom'),
                                    mapLabels('badgeOverall')))];
  // Guide entries, glyphs stripped — the guide writes some labels without them.
  const bare = x => x.replace(/^[^A-Za-z0-9]+/, '').trim();
  const documented = new Set([...GUIDE.matchAll(/row\('([^']+)'/g)].map(m => bare(m[1])));

  console.log('\n== Every badge the maps can emit is documented ==');
  t('the three badge maps are all reachable', () => {
    eq(mapLabels('badgeBom').length > 15, true, 'badgeBom entries:');
    eq(ALL.length > 15, true, 'distinct labels across all three maps:');
  });
  t('no status-map badge is missing from the guide', () => {
    const missing = ALL.filter(l => !documented.has(bare(l)));
    if (missing.length)
      throw new Error('undocumented badge(s): ' + missing.join(', '));
  });

  console.log('\n== The guide shows the same badge the code renders ==');
  t('every guide entry uses the class the code actually emits', () => {
    // v157 — #3/#4/#5. v156 moved the used-on badges to --success-2 but left the
    // guide on badge-ok, so three entries showed the wrong green. The old test
    // compared LABELS with glyphs stripped, so a wrong class — or a wrong glyph —
    // passed silently. This compares class and exact label.
    const code = {};
    ['badgeBom', 'badgeAbom', 'badgeOverall'].forEach(fn => {
      const a = at('function ' + fn + '(');
      [...SRC.slice(a, SRC.indexOf('\n}', a)).matchAll(/\[\s*'([\w\- ]+)'\s*,\s*'([^']+)'\s*\]/g)]
        .forEach(m => { code[m[2]] = m[1]; });
    });
    [...SRC.matchAll(/dge\('(badge-[\w\-]+)',\s*'([^']+)'/g)].forEach(m => { code[m[2]] = m[1]; });
    const bad = [];
    [...GUIDE.matchAll(/row\('([^']+)',\s*'([\w\- ]+)'/g)].forEach(m => {
      const [, lbl, cls] = m;
      if (code[lbl] && code[lbl] !== cls)
        bad.push(lbl + ': guide says ' + cls + ', code emits ' + code[lbl]);
    });
    if (bad.length) throw new Error('guide/code class drift:\n        ' + bad.join('\n        '));
  });
  t('every badge the code emits appears in the guide with its exact label', () => {
    // Glyph-insensitive matching is what let the guide drift. Exact only.
    const labels = new Set();
    ['badgeBom', 'badgeAbom', 'badgeOverall'].forEach(fn => {
      const a = at('function ' + fn + '(');
      [...SRC.slice(a, SRC.indexOf('\n}', a)).matchAll(/\[\s*'[\w\- ]+'\s*,\s*'([^']+)'\s*\]/g)]
        .forEach(m => labels.add(m[1]));
    });
    const documented = new Set([...GUIDE.matchAll(/row\('([^']+)'/g)].map(m => m[1]));
    const missing = [...labels].filter(l => !documented.has(l));
    if (missing.length)
      throw new Error('label(s) not documented verbatim: ' + missing.join(' | '));
  });
  t('green badges carry no glyph; attention states keep theirs', () => {
    // v157 — #6. Green already says "fine"; a tick adds nothing. Glyphs are
    // reserved for states that need a second look.
    const GREEN = ['badge-ok', 'badge-usedon', 'badge-covered'];
    const bad = [];
    [...SRC.matchAll(/\[\s*'([\w\- ]+)'\s*,\s*'([^']+)'\s*\]/g)].forEach(m => {
      if (GREEN.indexOf(m[1]) >= 0 && /^[^A-Z0-9]/.test(m[2])) bad.push(m[1] + ' -> ' + m[2]);
    });
    if (bad.length) throw new Error('green badge(s) still glyphed: ' + bad.join(', '));
    // And the attention states must NOT have been stripped along with them.
    ['⚠ QTY MISMATCH', '✗ MISSING', '⊘ REMOVAL ITEM'].forEach(l => {
      if (SRC.indexOf("'" + l + "'") < 0)
        throw new Error('an attention badge lost its glyph: ' + l);
    });
  });

  console.log('\n== #6/#7/#8: the views that had no entries at all ==');
  t('the guide covers the whole Detailed View, not just the summary', () => {
    // badgeBom / badgeAbom are used ONLY by renderFullBom, so their vocabulary
    // never reached a guide scoped to the Comparison Summary. That is why
    // CHECK EBOM and NO MATCH had no explanation anywhere.
    if (!/Detailed View — Badge Guide/.test(SRC))
      throw new Error('the guide is still titled for the Comparison Summary only');
    ['EBOM / MBOM / ABOM Full View', 'Change Pedigree View'].forEach(s => {
      if (GUIDE.indexOf(s) < 0) throw new Error('no section for ' + s);
    });
  });
  t('the raw BOM badges are documented', () => {
    ['SEE SUMMARY', 'OK', 'ADJ DIRECT', 'REMOVAL ITEM'].forEach(l => {
      if (!documented.has(bare(l))) throw new Error(l + ' is not documented');
    });
  });
  t('every CHP release state is documented', () => {
    // Sourced from chpReleaseState, so a new state fails this test.
    const chp = sandbox({}, ['chp']).C;
    const trace = (d, e) => ({ dcn: new Map(d || []), ecn: new Map(e || []), ecr: new Map() });
    const states = [
      chp.chpReleaseState(null).label,
      chp.chpReleaseState(trace([], [['E1', '']])).label,
      chp.chpReleaseState(trace([['D1', '2024-03-15']])).label.split(' ')[0],
      chp.chpReleaseState(trace([['D1', 'Unknown']])).label,
    ];
    // A documented entry may be a MORE informative form of the emitted label —
    // the badge renders 'RELEASED MARCH 15, 2024' and the guide writes
    // 'RELEASED ⟨date⟩'. Prefix matching accepts that; it still fails if a
    // state is absent entirely.
    const docs = [...documented];
    states.concat(['NO MATCH']).forEach(l => {
      const b = bare(l);
      if (!docs.some(d => d === b || d.indexOf(b + ' ') === 0))
        throw new Error(l + ' is not documented');
    });
  });
  t('NO MATCH and NO HISTORY are distinguished, not conflated', () => {
    // v158 — the text moved into BADGE_HELP, which now feeds both the guide and
    // the hover tooltip. The requirement is unchanged: the two must be told
    // apart wherever a reader meets them.
    const help = SRC.slice(at('const BADGE_HELP = {'), at('function _badgeHelp'));
    const m = help.match(/'✗ NO MATCH':\s*'([^']*)'/);
    if (!m) throw new Error('✗ NO MATCH has no BADGE_HELP entry');
    if (m[1].indexOf('NO HISTORY') < 0)
      throw new Error('the NO MATCH explanation must contrast itself with NO HISTORY');
    if (!/'NO HISTORY':\s*'[^']+'/.test(help))
      throw new Error('NO HISTORY has no explanation of its own');
  });

  console.log('\n== One source for the guide and the tooltips ==');
  t('every badge the code renders carries a hover explanation', () => {
    // v158 — #7. The tooltip and the guide read the same BADGE_HELP strings, so
    // a badge cannot be explained in one place and silent in the other.
    const help = SRC.slice(at('const BADGE_HELP = {'), at('function _badgeHelp'));
    const keys = new Set([...help.matchAll(/'((?:[^'\\]|\\.)+)':\s*'/g)].map(m => m[1]));
    const missing = ALL.filter(l => !keys.has(l.replace(/'/g, "\\'")));
    if (missing.length)
      throw new Error('badge(s) with no hover explanation: ' + missing.join(' | '));
  });
  t('every badge span with a documented label carries a tooltip', () => {
    // v158 — this test used to name four helpers I had found by hand, so it
    // passed while tracBadge — the helper the Traceability and Reconciliation
    // Notes columns actually use — rendered every badge with no tooltip at all.
    // The rule is now DERIVED: scan every badge span in the build, and if its
    // label is one BADGE_HELP explains, it must carry a title. A hand-written
    // list of call sites can only ever be as complete as the person writing it.
    const help = SRC.slice(at('const BADGE_HELP = {'), at('function _badgeHelp'));
    const known = new Set([...help.matchAll(/'((?:[^'\\]|\\.)+)':\s*'/g)]
      .map(m => m[1].replace(/\\'/g, "'")));
    // The badge guide renders a SAMPLE of each badge with its description in the
    // next cell. A tooltip repeating that text would be noise, so the guide's own
    // preview is exempt — by position, not by a blanket rule.
    const guideFrom = at('function showBadgeGuide()'), guideTo = at('_setReportHtml(html)', guideFrom);
    const bad = [];
    [...SRC.matchAll(/<span class="badge[^"]*"([^>]{0,180}?)>([^<]{0,60})<\/span>/g)].forEach(m => {
      const attrs = m[1], label = m[2].trim();
      if (m.index >= guideFrom && m.index < guideTo) return;
      if (attrs.indexOf('title=') >= 0) return;
      // Dynamic labels resolve at runtime; the helper is what must be present.
      if (label.indexOf('${') >= 0) {
        if (attrs.indexOf('_badgeHelp') < 0)
          bad.push('dynamic label at offset ' + m.index + ' has no _badgeHelp');
        return;
      }
      if (known.has(label))
        bad.push(JSON.stringify(label) + ' is documented but renders with no tooltip');
    });
    if (bad.length) throw new Error(bad.length + ' untooltipped badge(s):\n        ' + bad.join('\n        '));
  });
  t('every helper that builds a badge span consults BADGE_HELP', () => {
    // Catches a NEW helper being added without tooltips, before it ships a label.
    const helpers = [...SRC.matchAll(/function (\w+)\s*\(([^)]*)\)\s*\{/g)]
      .filter(m => /\blabel\b|\blbl\b/.test(m[2]));
    const bad = helpers.filter(m => {
      const body = SRC.slice(m.index, SRC.indexOf('\n}', m.index));
      return /<span class="badge/.test(body) && body.indexOf('_badgeHelp(') < 0;
    }).map(m => m[1]);
    if (bad.length) throw new Error('badge helper(s) with no tooltip: ' + bad.join(', '));
  });
  t('the trace badge keeps its row-specific detail below the explanation', () => {
    // Those badges already carried adjudication metadata in their title. The
    // explanation is prepended, not substituted for it.
    const a = at('function adjTracBadge');
    const body = SRC.slice(a, SRC.indexOf('\n}', a));
    if (!/lines\.unshift\(_help/.test(body))
      throw new Error('the explanation must be prepended to the existing detail');
    if (body.indexOf("lines.join('\\n')") < 0)
      throw new Error('the multi-line title was lost');
  });
  t('the guide no longer carries its own copy of the text', () => {
    const rows = [...GUIDE.matchAll(/row\('(?:[^'\\]|\\.)*',\s*'[\w\- ]+',/g)];
    if (rows.length)
      throw new Error(rows.length + ' guide row(s) still pass their own description');
    if (GUIDE.indexOf('BADGE_HELP[badge]') < 0)
      throw new Error('the guide does not read BADGE_HELP');
  });

  console.log('\n== The guide describes only badges that exist ==');
  t('no guide entry names a label absent from the build', () => {
    const outside = SRC.slice(0, at('function showBadgeGuide()')) +
                    SRC.slice(at('_setReportHtml(html)', at('function showBadgeGuide()')));
    const stale = [...documented].filter(l => l && l !== 'RELEASED ⟨date⟩' &&
                                               l !== 'UNKNOWN' && outside.indexOf(l) < 0);
    if (stale.length) throw new Error('guide documents nonexistent badge(s): ' + stale.join(', '));
  });
  t('the unknown-status fallback is documented', () => {
    // badgeOverall renders '? ' + status for any label it does not know.
    if (!/'\? ' \+ String\(status/.test(SRC))
      throw new Error('the fallback changed shape');
    if (!documented.has('UNKNOWN'))
      throw new Error('the ? UNKNOWN fallback is not documented');
  });
});

// ── TIER 11 ────────────────────────────────────────────────────────────────
// The dashboard's charts, run. While making the v155 fix a ReferenceError
// landed in the cause code chart and all 228 tests then stayed green, because
// nothing had ever executed a renderer; this suite exists to run them.
// v188 — the last canvas chart, NCR by cause code, became an HTML count list
// like NCR by disposition code (v186). The canvas crispness tests (buffer
// parity, reflow, pixel snapping) went with the canvas: nothing on the page
// draws to one now, and a test below keeps it that way.
suite('Tier 11 — dashboard charts and NCR lists', (t, eq) => {
  const vm = require('vm');
  const ABOM = [['W1','CLOSED'],['W2','OPEN'],['W3','CLOSED'],['W4','IN WORK'],['W5','CANCELLED']];
  // v185 — the WO status roll-up is no longer a canvas chart. It is an HTML
  // status strip (the whole population, split by share) and a count list, so
  // one status can no longer fill the card with a single 270px block. These
  // tests run it against an element stub and read the markup it writes.
  const woHtml = (abom, rfvWos) => {
    const box = { innerHTML: '' };
    const c = sandbox({ document: { getElementById: () => box, querySelectorAll: () => [] },
      state: { boms: { abom: { data: abom } }, woRollup: null }, COL: { abom: { woNo: 0, woStatus: 1 } },
      getRfvCoveredWoSet: () => new Set(rfvWos || []), esc: s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;') }, []);
    vm.runInContext(grabFn('buildWoRollup') + '\n' + grabFn('drawWoStatusRollup') +
      '\nstate.woRollup = buildWoRollup(state.boms.abom.data, 0, 1); drawWoStatusRollup("wo-rollup-chart");', c);
    return box.innerHTML;
  };
  t('drawWoStatusRollup writes a strip and one list row per status', () => {
    const h = woHtml(ABOM);
    eq((h.match(/class="wo-strip-row"/g) || []).length, 4, 'statuses CLOSED, OPEN, IN WORK, CANCELLED:');
    eq((h.match(/class="wo-seg"/g) || []).length, 4, 'strip segments:');
    if (!/<strong>5<\/strong> work orders/.test(h) || !/<strong>40%<\/strong> closed/.test(h)) throw new Error('headline: ' + h.slice(0, 160));
    if (h.indexOf('wo-st">CLOSED') > h.indexOf('wo-st">OPEN')) throw new Error('Closed is not listed first');
  });
  t('segment widths are the counts, so one status is one full strip, not a block', () => {
    const one = woHtml([['W1', 'CLOSED'], ['W2', 'CLOSED']]);
    eq((one.match(/flex-grow:(\d+)/g) || []), ['flex-grow:2'], 'a single segment:');
    if (/height:\s*\d{3}px/.test(one)) throw new Error('a tall block again');
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const m = css.match(/\.wo-strip\s*\{[^}]*height:\s*(\d+)px/);
    if (!m || +m[1] > 20) throw new Error('the strip is not a thin bar: ' + (m && m[1]));
  });
  t('RFV-authorized WOs are their own share of a non-closed status, and named in the list', () => {
    const h = woHtml([['W1', 'CLOSED'], ['W2', 'OPEN'], ['W3', 'OPEN'], ['W4', 'OPEN']], ['W2', 'W1']);
    if (!/flex-grow:1;background:var\(--rfv-fill\)/.test(h)) throw new Error('no RFV share in the strip');
    if (!/flex-grow:2;background:var\(--warn-fill\)/.test(h)) throw new Error('the bare open share is wrong');
    if (h.indexOf('\u25c8 1 RFV-authorized') < 0) throw new Error('the list does not name the RFV count');
    if (/CLOSED[^]*?wo-rfv">\u25c8/.test(h.slice(0, h.indexOf('wo-st">OPEN')))) throw new Error('a closed WO counted as RFV-authorized');
  });
  t('no data: a caption, not an error', () => {
    const box = { innerHTML: '' };
    const c = sandbox({ document: { getElementById: () => box }, state: { woRollup: null } }, []);
    vm.runInContext(grabFn('drawWoStatusRollup') + '\ndrawWoStatusRollup("x")', c);
    if (box.innerHTML.indexOf('No ABOM work order data') < 0) throw new Error(box.innerHTML);
  });

  // v186 — the owner asked for a count of entries per Disposition Code, beside
  // the cause code chart. Decided by poll: disposition entries (the cause
  // chart's population), a count list, three across, display only.
  // v188 — the cause code chart became the same kind of list. Both go
  // through _ncrEntryCodeCounts and _ncrCodeListHtml.
  const LISTFNS = ['_ncrEntryCodeCounts', '_ncrDispCodeCounts', '_ncrCauseCodeCounts', '_ncrCodeListHtml',
                   'drawNcrDispCodeList', 'drawNcrCauseCodeList'];
  const runList = (fn, results) => {
    const box = { innerHTML: '' };
    const c = sandbox({ document: { getElementById: () => box }, R: results,
      esc: s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;') }, []);
    vm.runInContext(LISTFNS.map(grabFn).join('\n') + '\n' + fn + '("x", R);' +
      ' globalThis.C = ' + (fn === 'drawNcrDispCodeList' ? '_ncrDispCodeCounts' : '_ncrCauseCodeCounts') + '(R);', c);
    const rows = [...box.innerHTML.matchAll(/ncr-code-name">([^<]*)(?:<span class="ncr-code-desc">: ([^<]*)<\/span>)?<\/span><span class="ncr-code-n">(\d+)</g)]
      .map(m => m[2] === undefined ? [m[1], +m[3]] : [m[1], +m[3], m[2]]);
    return { html: box.innerHTML, rows, counts: c.C };
  };
  const codeList = r => runList('drawNcrDispCodeList', r);
  const causeList = r => runList('drawNcrCauseCodeList', r);
  console.log('\n== v186: NCR by disposition code ==');
  const ent = (code, o) => Object.assign({ dispCode: code, ncrStatus: 'OPEN' }, o);
  t('every entry is counted by its code: both pools, cancelled left out, case and spaces merged', () => {
    const { rows, html } = codeList([
      { ncrEntriesPool1: [ent('UAI'), ent('REWORK')], ncrEntriesPool2: [ent('UAI')] },
      { ncrEntriesPool1: [ent('uai '), ent('SCRAP', { ncrStatus: ' Cancelled ' }), ent('')] }]);
    eq(rows, [['UAI', 3], ['REWORK', 1], ['UNSPECIFIED', 1]]);
    if (!/<strong>5<\/strong> entries · <strong>2<\/strong> codes/.test(html)) throw new Error('headline: ' + html.slice(0, 160));
  });
  t('every code is listed, not a top 6, and UNSPECIFIED is always last', () => {
    const many = 'ABCDEFGH'.split('').map((c, i) => ent('C' + c));
    const { rows } = codeList([{ ncrEntriesPool1: many.concat([ent(''), ent(''), ent(''), ent('CA')]) }]);
    eq(rows.length, 9, 'eight codes and UNSPECIFIED:');
    eq(rows[0], ['CA', 2], 'the largest code first:');
    eq(rows[rows.length - 1], ['UNSPECIFIED', 3], 'UNSPECIFIED last although it is the largest:');
    eq(rows.slice(1, 8).map(r => r[0]), ['CB', 'CC', 'CD', 'CE', 'CF', 'CG', 'CH'], 'ties in code order:');
  });
  t('no data: a caption; codes are escaped', () => {
    if (codeList([]).html.indexOf('No NCR disposition data') < 0) throw new Error('no caption');
    if (codeList([{ ncrEntriesPool1: [ent('A<B')] }]).html.indexOf('A&lt;B') < 0) throw new Error('code not escaped');
  });

  console.log('\n== v188: NCR by cause code, a list like it ==');
  const cz = (code, desc, o) => Object.assign({ causeCode: code, causeCodeDesc: desc, ncrStatus: 'OPEN' }, o);
  t('every entry is counted by cause code, with its description: both pools, cancelled left out, case and spaces merged', () => {
    const { rows, html } = causeList([
      { ncrEntriesPool1: [cz('C04', 'Workmanship'), cz('C11', 'Supplier escape')], ncrEntriesPool2: [cz('c04 ', 'Workmanship')] },
      { ncrEntriesPool1: [cz('C02', 'Handling', { ncrStatus: 'CANCELLED' }), cz('', 'no code given')] }]);
    eq(rows, [['C04', 2, 'Workmanship'], ['C11', 1, 'Supplier escape'], ['UNSPECIFIED', 1]]);
    if (!/<strong>4<\/strong> entries · <strong>2<\/strong> codes/.test(html)) throw new Error('headline: ' + html.slice(0, 160));
  });
  t('every cause code is listed, not the old top 6, and UNSPECIFIED is always last', () => {
    const e = 'ABCDEFGH'.split('').map(c => cz('C' + c, 'd' + c));
    const { rows } = causeList([{ ncrEntriesPool1: e.concat([cz(''), cz(''), cz('', 'x')]) }]);
    eq(rows.length, 9, 'eight codes and UNSPECIFIED:');
    eq(rows[8], ['UNSPECIFIED', 3], 'UNSPECIFIED last although it is the largest:');
  });
  t('one code with two descriptions is one line, showing the first description found', () => {
    const { rows } = causeList([{ ncrEntriesPool1: [cz('C07', ''), cz('C07', 'Engineering drawing error'), cz('c07', 'Drawing error')] }]);
    eq(rows, [['C07', 3, 'Engineering drawing error']]);
    const plain = causeList([{ ncrEntriesPool1: [cz('C09', '')] }]).rows;
    eq(plain, [['C09', 1]], 'no description, no colon:');
    if (causeList([{ ncrEntriesPool1: [cz('C1', 'A<B')] }]).html.indexOf(': A&lt;B') < 0) throw new Error('description not escaped');
  });
  t('the two lists count the same entries, so their totals agree', () => {
    const R = [{ ncrEntriesPool1: [ent('UAI', { causeCode: 'C1' }), ent('', { causeCode: 'C2' }), ent('X', { causeCode: 'C1', ncrStatus: 'CANCELLED' })],
                 ncrEntriesPool2: [ent('UAI', { causeCode: '' })] },
               { ncrEntriesPool1: [ent('RTV', { causeCode: 'C3' })] }];
    const a = codeList(R), b = causeList(R);
    eq(a.counts.total, b.counts.total, 'disposition code total vs cause code total:');
    eq(b.rows.reduce((x, r) => x + r[1], 0), b.counts.total, 'the cause rows add up to the total shown:');
    eq(a.counts.total, 4);
    // One counter: the two lists cannot drift apart on the population rule.
    ['_ncrDispCodeCounts', '_ncrCauseCodeCounts'].forEach(f => {
      if (!/return _ncrEntryCodeCounts\(results,/.test(grabFn(f))) throw new Error(f + ' does not use the shared counter');
    });
    ['drawNcrDispCodeList', 'drawNcrCauseCodeList'].forEach(f => {
      if (!/el\.innerHTML = _ncrCodeListHtml\(rows, total\);/.test(grabFn(f))) throw new Error(f + ' does not use the shared markup');
    });
  });

  console.log('\n== The row, and no canvas ==');
  t('the NCR row is three count lists, cause code first, three across down to 900px', () => {
    const i = at('id="secondary-charts-row"');
    const row = SRC.slice(i - 80, at('ADJUDICATION WORKBENCH (unified)', i));
    if (!/class="charts-row charts-row-3col" id="secondary-charts-row"/.test(SRC)) throw new Error('the NCR row is not three across');
    const a = row.indexOf('id="ncr-cause-code-list"'), b = row.indexOf('id="ncr-disp-code-list"'), c = row.indexOf('id="ncr-disp-status-list"');
    if (!(a >= 0 && a < b && b < c)) throw new Error('order: cause ' + a + ', code ' + b + ', status ' + c);
    const css = STYLE_BLOCKS.map(x => x.css).join('\n');
    const three = /\.charts-row-3col\s*\{\s*grid-template-columns:\s*minmax\(0,\s*1\.4fr\)\s*minmax\(0,\s*1fr\)\s*minmax\(0,\s*1fr\)/;
    if (!three.test(css)) throw new Error('three columns at full width');
    const m1400 = css.slice(css.indexOf('@media (max-width: 1400px)'), css.indexOf('@media (max-width: 900px)'));
    if (!three.test(m1400)) throw new Error('between 900 and 1400px the row is not three across (the .charts-row rule there makes it two)');
    if (/grid-column:\s*1 \/ -1/.test(m1400)) throw new Error('the cause card still takes a row of its own');
    const m900 = css.slice(css.indexOf('@media (max-width: 900px)'));
    if (!/\.charts-row-3col\s*\{\s*grid-template-columns:\s*minmax\(0,\s*1fr\);/.test(m900.slice(0, 600))) throw new Error('below 900px the row is not one column');
    if (!/drawNcrCauseCodeList\('ncr-cause-code-list', r\)/.test(SRC) || !/drawNcrDispCodeList\('ncr-disp-code-list', r\)/.test(SRC)) throw new Error('a list is never drawn');
    if (/onclick/.test(row.slice(0, c))) throw new Error('a code card is clickable; the lists are display only');
  });
  t('nothing draws to a canvas: the canvas helpers went with the last canvas chart', () => {
    const code = stripComments(SRC.slice(SRC.indexOf('<body')));
    if (/<canvas\b/.test(code)) throw new Error('a <canvas> is in the page');
    ['setupHiDpiCanvas', 'registerChartRedraw', 'redrawAllCharts', '_crisp', 'drawNcrCauseCodeChart'].forEach(f => {
      if (new RegExp('\\b' + f + '\\b').test(code)) throw new Error(f + ' is still in the build');
    });
    if (/getContext\(\s*['"]2d['"]\s*\)/.test(code)) throw new Error('something still draws to a 2D context');
    if (/\.chart-card canvas/.test(STYLE_BLOCKS.map(x => x.css).join('\n'))) throw new Error('a stylesheet rule for chart canvases survives');
  });
});

// ── TIER 12 ────────────────────────────────────────────────────────────────
// Colour discipline. The build has a good token system; the problem was that
// 99 inline declarations bypassed it, including a SECOND muted grey 15
// luminance from the real one and a SECOND teal for RFV while --rfv already
// existed. Individually invisible, collectively the "haphazard" impression.
suite('Tier 12 — colour tokens', (t, eq) => {
  const CSS = STYLE_BLOCKS.map(b => b.css).join('\n');
  const BODY = SRC.slice(at('</style>'));
  const TOKENS = {};
  [...CSS.matchAll(/(--[\w-]+)\s*:\s*(#[0-9a-fA-F]{6})/g)]
    .forEach(m => { TOKENS[m[1]] = m[2].toLowerCase(); });
  const byValue = {};
  Object.keys(TOKENS).forEach(k => { (byValue[TOKENS[k]] = byValue[TOKENS[k]] || []).push(k); });
  const lum = h => { const n = i => parseInt(h.slice(1 + i * 2, 3 + i * 2), 16);
    return 0.2126 * n(0) + 0.7152 * n(1) + 0.0722 * n(2); };

  console.log('\n== Nothing bypasses the tokens ==');
  // WHY THIS IS BROADER THAN IT LOOKS (v174): the guard this replaces checked
  // BODY only, matched `color:` only, and did not recognise rgba(). All three
  // blind spots were occupied. #21262d sat in a border-bottom inside the
  // stylesheet; ten dark-mode row tints sat in rgba() inside render functions.
  // Both themes shipped carrying dark colours for six versions. Narrow the
  // property list or the notation list again and the same class of bug returns.
  const COLOUR_PROPS = 'color|background|background-color|border|border-color|' +
                       'border-top|border-right|border-bottom|border-left|' +
                       'outline|outline-color|fill|stroke|box-shadow|text-shadow';
  const LITERAL = '(#[0-9a-fA-F]{3,8}\\b|rgba?\\([^)]*\\))';
  const scanRaw = (text) =>
    [...text.matchAll(new RegExp('(?:' + COLOUR_PROPS + ')\\s*:\\s*[^;{}"\'`]*?' +
                                 LITERAL, 'gi'))].map(m => m[1]);

  t('no inline style sets a raw colour', () => {
    // One deliberate exception: the KPI render-error banner. It reports that
    // rendering has failed, so it must not depend on the stylesheet resolving —
    // tokenising it would risk an invisible error message. The exception is
    // narrow and asserted below, not a blanket allowance.
    const EXEMPT = /id="kpi-render-error-banner"[^>]*>/;
    const banner = BODY.match(EXEMPT);
    if (!banner) throw new Error('the render-error banner moved — re-check this exemption');
    const raw = scanRaw(BODY.replace(banner[0], ''));
    if (raw.length)
      throw new Error(raw.length + ' raw colour(s) outside the token system: ' +
                      [...new Set(raw)].join(', '));
  });
  t('no stylesheet rule sets a raw colour outside the palette blocks', () => {
    // The palette blocks are where literals belong; everything after them must
    // go through var(). Strip the four known blocks, then scan what is left.
    let css = STYLE_BLOCKS.map(b => b.css).join('\n');
    for (const sel of [':root', '[data-theme="light"]', '[data-theme="mono"]',
                       '[data-theme="dark"]']) {
      const k = css.indexOf(sel);
      if (k < 0) continue;
      let d = 0, start = css.indexOf('{', k);
      for (let i = start; i < css.length; i++) {
        if (css[i] === '{') d++;
        else if (css[i] === '}' && --d === 0) {
          css = css.slice(0, k) + css.slice(i + 1);
          break;
        }
      }
    }
    // @font-face and keyframes carry no palette colours; comments are noise.
    css = css.replace(/\/\*[\s\S]*?\*\//g, '');
    const raw = scanRaw(css);
    if (raw.length)
      throw new Error(raw.length + ' raw colour(s) in the stylesheet: ' +
                      [...new Set(raw)].slice(0, 12).join(', '));
  });
  t('the render-error banner stays self-contained on purpose', () => {
    const banner = BODY.match(/id="kpi-render-error-banner"[^>]*>/)[0];
    if (banner.indexOf('var(--') >= 0)
      throw new Error('the emergency banner now depends on CSS variables resolving');
    if (!/background:#[0-9a-f]{6}/i.test(banner) || !/color:#[0-9a-f]{3,6}/i.test(banner))
      throw new Error('the emergency banner lost its literal colours');
  });
    t('every badge fill keeps its own text legible', () => {
    // The real mono defect in v173 was not that the greys were close, it was
    // that --ci-dim, --surface2 and --cert-bg were the SAME value, so a CI
    // badge had no fill against the panel behind it. Checked per theme because
    // a token pair can pass in dark and collapse in light.
    const lum = h => {
      const f = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
      return 0.2126 * f(parseInt(h.slice(1, 3), 16)) +
             0.7152 * f(parseInt(h.slice(3, 5), 16)) +
             0.0722 * f(parseInt(h.slice(5, 7), 16));
    };
    const ratio = (a, b) => { const x = lum(a), y = lum(b);
      return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
    const PAIRS = ['--accent', '--success', '--warn', '--danger', '--wo-open',
                   '--adj', '--wo5', '--ncr', '--ci', '--rfv'];
    const bad = [];
    for (const [theme, pal] of Object.entries(PALETTES))
      for (const k of PAIRS) {
        const fg = pal[k], bg = pal[k + '-dim'];
        if (!fg || !bg) continue;
        const r = ratio(fg, bg);
        if (r < 4.5) bad.push(theme + ' ' + k + ' ' + r.toFixed(2) + ':1');
      }
    if (bad.length) throw new Error('badge text below 4.5:1 on its own fill: ' + bad.join(', '));
  });
  t('no theme collapses two tokens onto one value by accident', () => {
    // --bg and --on-accent legitimately coincide in the light themes: the page
    // is white and text on a filled accent is white. Everything else sharing a
    // value means one of the two is invisible wherever they meet.
    // mono also merges --accent onto --text on purpose: the high-contrast mode
    // is black on white by definition, and accent elements are distinguished
    // there by rule and underline rather than by hue.
    // v181 — the funnel count inks are dedicated copies, so they may equal the
    // general tokens they started from: ink = page (dark) or white (light,
    // mono); track text = body text. Owning a copy is the point — either can
    // be retuned without moving any other text.
    const ALLOWED = [['--bg', '--on-accent'], ['--surface', '--on-accent'],
                     ['--accent', '--text'], ['--funnel-count-ink', '--on-accent'],
                     ['--funnel-count-ink', '--bg'], ['--funnel-count-ink', '--surface'],
                     ['--funnel-count-track', '--text'], ['--funnel-count-track', '--accent']];
    const ok = (a, b) => ALLOWED.some(p => p.indexOf(a) >= 0 && p.indexOf(b) >= 0);
    // Two deliberate mono collapses, each asserted by its own test above:
    // outline chips share white with the surface, and --success-fill shares a
    // value with --danger-fill because a ladder bar and a residual segment
    // never appear in the same shape group.
    const MONO_OUTLINE = /^(--bg|--surface|--on-accent|.*-dim)$/;
    const MONO_FILL_PAIR = ['--success-fill', '--danger-fill'];
    const bad = [];
    for (const [theme, pal] of Object.entries(PALETTES)) {
      const byVal = {};
      for (const [k, v] of Object.entries(pal)) (byVal[v] = byVal[v] || []).push(k);
      for (const [v, ks0] of Object.entries(byVal)) {
        let ks = ks0;
        if (theme === 'mono' && v === '#ffffff') ks = ks.filter(k => !MONO_OUTLINE.test(k));
        if (theme === 'mono' && ks.length === 2 &&
            MONO_FILL_PAIR.every(k => ks.indexOf(k) >= 0)) continue;
        // Compare within a namespace only: a -fill paints a shape, everything
        // else inks a letter or draws a rule. The two sharing a grey in mono
        // is not a collision anyone can see.
        const inks = ks.filter(k => !/-fill$/.test(k));
        const fills = ks.filter(k => /-fill$/.test(k));
        [inks, fills].forEach(group => {
          // Every pair in the group must be allowed (v181: groups of three occur
          // now that the funnel count inks are dedicated copies).
          const pairsOk = group.every((a, i) => group.slice(i + 1).every(b => ok(a, b)));
          if (group.length > 1 && !pairsOk)
            bad.push(theme + ' ' + v + ' = ' + group.join(' & '));
        });
      }
    }
    if (bad.length) throw new Error('colliding tokens: ' + bad.join('; '));
  });
  t('no script hands out a palette colour as a bare string', () => {
    // The property-anchored scans above cannot see these: the literal is
    // returned from a helper and only reaches a style attribute later. Three
    // shipped this way until v174, which is why the exported report and the
    // RFV match table stayed dark-mode-coloured under every theme.
    const banner = BODY.match(/id="kpi-render-error-banner"[^>]*>/)[0];
    // tok() keeps one literal on purpose: it is the fallback for a token that
    // fails to resolve, so it must not itself depend on a token resolving.
    const TOK_FALLBACK = "v || '#8b949e'";
    if (BODY.indexOf(TOK_FALLBACK) < 0)
      throw new Error('the tok() fallback moved - re-check this exemption');
    const darkValues = new Set(Object.values(PALETTES.dark));
    const found = [...BODY.replace(banner, '').replace(TOK_FALLBACK, '').matchAll(/['"`](#[0-9a-fA-F]{6})['"`]/g)]
      .filter(v => darkValues.has(v));
    if (found.length)
      throw new Error(found.length + ' script literal(s) pinned to the dark palette: ' +
                      [...new Set(found)].join(', '));
  });
  t('the -fill tokens exist in every theme; dark aliases, light and mono may carry their own ramp', () => {
    // WHY THESE EXIST (v175): the category tokens are text far more than fill
    // - --success is a text colour 74 times and a fill 18 times - so they
    // cannot double as a lightness ramp for shapes. Making --success a light
    // grey to separate the chart bars would have blanked 74 text sites. The
    // -fill tokens carry the shapes; the category tokens stay legible.
    const NAMES = ['--success-fill','--success-2-fill','--success-3-fill',
                   '--warn-fill','--danger-fill','--rfv-fill','--muted-fill'];
    const PARENT = { '--success-fill':'--success', '--success-2-fill':'--success-2',
                     '--success-3-fill':'--success-3', '--warn-fill':'--warn',
                     '--danger-fill':'--danger', '--rfv-fill':'--rfv',
                     '--muted-fill':'--text-muted' };
    for (const sel of [':root', '[data-theme="light"]', '[data-theme="mono"]']) {
      const k = STYLE_BLOCKS[0].css.indexOf(sel);
      if (k < 0) throw new Error('palette block missing: ' + sel);
      const body = STYLE_BLOCKS[0].css.slice(k, STYLE_BLOCKS[0].css.indexOf('}', k));
      for (const n of NAMES) {
        const m = body.match(new RegExp(n.replace(/-/g, '\\-') + '\\s*:\\s*([^;]+);'));
        if (!m) throw new Error(sel + ' does not define ' + n);
        const v = m[1].trim();
        // v180 — light carries a darker ladder ramp so white counts on it are
        // legible; the ink contrast is asserted in 'text drawn on a fill'.
        if (sel === '[data-theme="mono"]' || (sel === '[data-theme="light"]' && /^--success(-\d)?-fill$/.test(n))) {
          if (!/^#[0-9a-f]{6}$/i.test(v) && v !== 'var(' + PARENT[n] + ')')
            throw new Error(sel + ' ' + n + ' should be a literal or alias its parent, got ' + v);
        } else if (v !== 'var(' + PARENT[n] + ')') {
          throw new Error(sel + ' ' + n + ' should alias ' + PARENT[n] + ', got ' + v);
        }
      }
    }
  });
  t('the mono fill ramp keeps competing shapes apart', () => {
    // Three places draw filled shapes that sit next to each other. Within each
    // group every fill must be visibly separated; across groups they may share
    // a value, because they never appear together.
    const GROUPS = {
      'funnel ladder':   ['--success-fill','--success-2-fill','--success-3-fill'],
      'WO roll-up':      ['--success-fill','--warn-fill','--muted-fill','--rfv-fill'],
      'funnel residual': ['--danger-fill','--warn-fill','--muted-fill'],
    };
    const mono = PALETTES.mono;
    const lvl = h => parseInt(h.slice(1, 3), 16);   // grey, so one channel is enough
    const bad = [];
    for (const [g, names] of Object.entries(GROUPS))
      for (let i = 0; i < names.length; i++)
        for (let j = i + 1; j < names.length; j++) {
          const d = Math.abs(lvl(mono[names[i]]) - lvl(mono[names[j]]));
          if (d < 24) bad.push(g + ': ' + names[i] + ' vs ' + names[j] + ' only ' + d + ' apart');
        }
    if (bad.length) throw new Error(bad.join('; '));
  });
  t('the ladder fills stay dark enough for the count printed on them', () => {
    // .funnel-bar-inline-count draws in var(--bg), which is white in mono.
    const mono = PALETTES.mono;
    for (const n of ['--success-fill','--success-2-fill','--success-3-fill']) {
      const g = parseInt(mono[n].slice(1, 3), 16);
      if (g > 0x60) throw new Error(n + ' is too light for white text: ' + mono[n]);
    }
  });
  t('mono chips are outlines except the one that must not be missed', () => {
    // The contract that replaces ten greys: the LABEL identifies the category,
    // so every chip is black on white - except MISSING, which keeps a fill and
    // a heavier rule. Collapsing the -dim tokens onto white is the design, not
    // drift, which is why the collision test below exempts them.
    const mono = PALETTES.mono;
    // --accent-dim is the selected/active state, not a category chip.
    const filled = Object.keys(mono).filter(
      k => /-dim$/.test(k) && k !== '--accent-dim' && mono[k] !== '#ffffff');
    if (filled.length !== 1 || filled[0] !== '--danger-dim')
      throw new Error('expected only --danger-dim to be filled, got: ' + filled.join(', '));
    const rule = STYLE_BLOCKS[0].css;
    if (rule.indexOf('[data-theme="mono"] .badge,') < 0)
      throw new Error('the mono chip ink rule is gone - chip text would fall back to the category grey');
  });
  t('no user-facing copy names a colour', () => {
    // Five strings said "teal" or "green" until v175. That is accurate in dark
    // and wrong in the other two themes, where RFV is a muted brass or a grey.
    // Comments may name colours; anything the user reads may not.
    const WORDS = /\b(teal|amber|purple|crimson|magenta)\b/i;
    const bad = [];
    // HTML comments may name colours too, including ones written mid-line.
    BODY.replace(/<!--[\s\S]*?-->/g, '').split('\n').forEach((line, i) => {
      const t = line.trim();
      if (!t || t.startsWith('//') || t.startsWith('*') || t.startsWith('/*')) return;
      if (WORDS.test(t)) bad.push('line ~' + (i + 1) + ': ' + t.slice(0, 70));
    });
    if (bad.length) throw new Error(bad.length + ' colour word(s) in user copy: ' + bad[0]);
  });
  t('the deleted renderer stayed deleted', () => {
    // drawBarChart was dead for 128 versions and every palette change had to
    // maintain its colour map anyway. If it comes back, it comes back with a
    // call site and a test, not by accident.
    if (SRC.indexOf('function drawBarChart') >= 0)
      throw new Error('drawBarChart is back without a call site');
  });
  t('the token palette is defined once and is not itself duplicated', () => {
    // Scoped to :root deliberately. The dark palette is the source of truth and
    // two names sharing a value there is drift — that is the v155 guard and it
    // still applies. It CANNOT apply to the other themes: in the mono palette
    // --bg and --on-accent are both #ffffff on purpose, because a white page
    // and a foreground sitting on a near-black accent fill really are the same
    // white. Structural parity across themes is asserted separately below.
    // v181 — one named exception: the funnel count tokens are dedicated copies
    // of --bg and --text by the owner's decision, so the ladder counts can be
    // retuned without moving any other text. They are checked on their own
    // (contrast on the fill and on the track), not as drift.
    const DEDICATED = { '--funnel-count-ink': '--bg', '--funnel-count-track': '--text' };
    const byValue = {};
    Object.keys(PALETTES.dark).filter(k => !(k in DEDICATED)).forEach(k => {
      (byValue[PALETTES.dark[k]] = byValue[PALETTES.dark[k]] || []).push(k); });
    const dupes = Object.keys(byValue).filter(v => byValue[v].length > 1)
      .map(v => v + ' = ' + byValue[v].join(' and '));
    if (dupes.length) throw new Error('two tokens share a value: ' + dupes.join('; '));
  });
  t('every theme defines every token the dark palette defines', () => {
    // -fill tokens are excluded: in dark and light they are declared as
    // var(--parent) aliases, which PALETTES cannot see because it reads hex.
    // They get their own contract test immediately below.
    // The failure this catches is the one a half-written theme produces: a
    // white background with the dark theme's near-black status fills still on
    // it, because the theme covered the seven chrome tokens and left the
    // twenty-two semantic ones to fall through to :root.
    const want = Object.keys(PALETTES.dark).filter(k => !/-fill$/.test(k)).sort();
    ['light', 'mono'].forEach(name => {
      const got = Object.keys(PALETTES[name]).filter(k => !/-fill$/.test(k)).sort();
      const missing = want.filter(k => !PALETTES[name][k]);
      const extra = got.filter(k => !PALETTES.dark[k]);
      if (missing.length)
        throw new Error(name + ' does not define: ' + missing.join(', '));
      if (extra.length)
        throw new Error(name + ' defines tokens the dark palette does not: ' + extra.join(', '));
    });
  });
  t('no theme leaves a token pointing at another theme’s value', () => {
    // A token copied across unchanged is almost always an oversight rather
    // than a decision — a dark-theme fill surviving into the light palette.
    // Neutrals are exempt: pure black and pure white legitimately recur.
    const neutral = v => v === '#000000' || v === '#ffffff';
    ['light', 'mono'].forEach(name => {
      const shared = Object.keys(PALETTES.dark)
        .filter(k => PALETTES[name][k] === PALETTES.dark[k] && !neutral(PALETTES.dark[k]));
      if (shared.length)
        throw new Error(name + ' reuses the dark value for: ' + shared.join(', '));
    });
  });
  t('the mono palette is actually monochrome', () => {
    // What makes this mode useful on a photocopied audit packet. Asserted, so
    // a later token added to mono cannot quietly reintroduce a hue.
    const coloured = Object.keys(PALETTES.mono).filter(k => {
      const v = PALETTES.mono[k];
      return !(v.slice(1, 3) === v.slice(3, 5) && v.slice(3, 5) === v.slice(5, 7));
    });
    if (coloured.length)
      throw new Error('mono tokens carrying a hue: ' +
                      coloured.map(k => k + ' ' + PALETTES.mono[k]).join(', '));
  });
  t('the summary table uses two text tiers and only two', () => {
    // v156 — #8. White marks what a reader compares or acts on; dim is context.
    // --text-faint survives for chrome (chart captions, funnel footnotes) but
    // must not appear in a table cell, where a third tier re-creates the mush.
    const TABLE = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    if (/<td[^>]*var\(--text-faint\)/.test(TABLE))
      throw new Error('a table cell uses the chrome-only faint tier');
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/td\s*\{[^}]*color:\s*var\(--text-muted\)/.test(css))
      throw new Error('td no longer defaults to dim');
    if (!/td\.cell-key\s*\{[^}]*color:\s*var\(--text\)/.test(css))
      throw new Error('.cell-key no longer marks the white tier');
  });
  t('every column on the white list is marked, and no others', () => {
    const TABLE = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    const marked = (TABLE.match(/<td class="cell-key/g) || []).length;
    // Next Higher, EBOM Qty, Δ Qty, MBOM Direct Qty, ABOM Direct Qty, ABOM
    // Direct NH, ABOM Direct WO#, per-WO Qty, WO Status, Used-On WO#,
    // Used-On WO Status. Part Number is white via .pn-col; NCR disposition
    // numbers and statuses and RFV numbers carry their own semantic colour.
    eq(marked, 11, 'cells marked white:');
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/\.pn-col\s*\{[^}]*color:\s*var\(--text\)/.test(css))
      throw new Error('the Part Number column is no longer white');
  });
  t('there are two text tiers, and --text-faint is retired', () => {
    // v180 — --text-faint survived v156 for chart captions and funnel
    // footnotes. At #484f58 it was 2.1:1 against the dark panel, and this test
    // REQUIRED it to sit 40 luminance steps below --text-muted — which on a
    // dark page forces a third grey below any legible contrast. The rule was
    // the defect. Two tiers, each legible (next test).
    if (/--text-faint/.test(stripComments(SRC.slice(at('</script>')))))
      throw new Error('--text-faint is still defined or used');
    ['dark', 'light', 'mono'].forEach(name => {
      const p = PALETTES[name];
      if (!p['--text'] || !p['--text-muted']) throw new Error(name + ' lacks a text tier');
      if (!(Math.abs(LUM(p['--bg']) - LUM(p['--text'])) > Math.abs(LUM(p['--bg']) - LUM(p['--text-muted']))))
        throw new Error(name + ': --text-muted is not quieter than --text');
    });
  });
  t('both text tiers clear 4.5:1 against the page and the panel in every theme', () => {
    // WCAG AA for normal text. Checked against --bg AND --surface: panels are
    // where most small text sits.
    const bad = [];
    ['dark', 'light', 'mono'].forEach(name => {
      const p = PALETTES[name];
      ['--text', '--text-muted'].forEach(t => ['--bg', '--surface'].forEach(b => {
        const c = CONTRAST(p[t], p[b]);
        if (c < 4.5) bad.push(name + ' ' + t + ' on ' + b + ' ' + c.toFixed(2));
      }));
    });
    if (bad.length) throw new Error(bad.join('; '));
  });
  t('text drawn on a coverage fill clears 4.5:1 in every theme', () => {
    // v180 — the ladder's inline counts were drawn in --bg, which is only dark
    // in the dark theme: 2.9:1 on the light theme's lightest green. v180 gave
    // them --on-fill; v181 renamed it --funnel-count-ink (funnel counts only).
    // PALETTES reads hex only; dark (and light, for some tokens) declares
    // aliases as var(--x). Follow them in the raw palette block.
    const css0 = STYLE_BLOCKS[0].css;
    const blockOf = sel => { const k = css0.indexOf(sel); return css0.slice(k, css0.indexOf('}', k)); };
    const SEL = { dark: ':root', light: '[data-theme="light"]', mono: '[data-theme="mono"]' };
    const val = (name, k, depth) => {
      const hex = PALETTES[name][k];
      if (hex) return hex;
      const m = blockOf(SEL[name]).match(new RegExp(k.replace(/-/g, '\\-') + '\\s*:\\s*var\\((--[\\w-]+)\\)'));
      return m && (depth || 0) < 5 ? val(name, m[1], (depth || 0) + 1) : undefined;
    };
    // v181 — and the count that sits beside a short bar is on the empty track,
    // whose background is --bg. It has its own token, checked against that.
    const bad = [];
    ['dark', 'light', 'mono'].forEach(name => {
      ['--success-fill', '--success-2-fill', '--success-3-fill'].forEach(f => {
        const c = CONTRAST(val(name, '--funnel-count-ink'), val(name, f));
        if (!(c >= 4.5)) bad.push(name + ' ink on ' + f + ' ' + (c ? c.toFixed(2) : 'unresolved'));
      });
      const t = CONTRAST(val(name, '--funnel-count-track'), val(name, '--bg'));
      if (!(t >= 4.5)) bad.push(name + ' track text ' + (t ? t.toFixed(2) : 'unresolved'));
    });
    if (bad.length) throw new Error(bad.join('; '));
    if (!/\.funnel-bar-track\s*\{[^}]*background:\s*var\(--bg\)/.test(css0))
      throw new Error('the track is no longer --bg; re-point the track-text check');
  });
  t('a ladder count is coloured by the two funnel count tokens and nothing else', () => {
    // v181 — v180 checked the base rule only. A .light modifier, applied to every
    // bar between 18% and 39%, drew the count in --text-muted: about 1.1:1 on
    // the dark theme's green. The owner photographed it. Every colour a ladder
    // count can take must come from these two tokens.
    const css = STYLE_BLOCKS[0].css;
    const rules = [...css.matchAll(/([^{}]*funnel-bar-inline-count[^{}]*)\{([^}]*)\}/g)]
      .filter(m => /(^|;|\s)color\s*:/.test(m[2]));
    const colours = rules.map(m => (m[2].match(/(?:^|;|\s)color\s*:\s*([^;]+)/) || [])[1].trim());
    const stray = colours.filter(c => c !== 'var(--funnel-count-ink)' && c !== 'var(--funnel-count-track)');
    if (stray.length) throw new Error('ladder count coloured by ' + stray.join(', '));
    ['var(--funnel-count-ink)', 'var(--funnel-count-track)'].forEach(k => {
      if (colours.indexOf(k) < 0) throw new Error('no ladder-count rule uses ' + k);
    });
    // Dedicated means dedicated: nothing else is drawn in them.
    const other = [...css.matchAll(/([^{}]*)\{([^}]*var\(--funnel-count-(?:ink|track)\)[^}]*)\}/g)]
      .map(m => m[1].trim()).filter(sel => sel.indexOf('funnel-bar-inline-count') < 0);
    if (other.length) throw new Error('the count tokens also colour: ' + other.join(', '));
    if (/funnel-bar-inline-count light/.test(SRC)) throw new Error('the .light modifier is back');
  });
  t('hovering a ladder bar does not change its fill colour', () => {
    // v181 — brightness(1.18) on hover lifted the light theme's darkest green
    // enough to pull the white count under 4.5:1. Hover is shown by an outline.
    const css = STYLE_BLOCKS[0].css;
    const m = css.match(/\.funnel-ladder-stage:hover \.funnel-bar-fill-cov\s*\{([^}]*)\}/);
    if (m && /filter|opacity|background/.test(m[1])) throw new Error('hover alters the fill: ' + m[1].trim());
    // And hover is still shown somehow (review: the check above passes silently
    // if the selector is renamed).
    if (!/\.funnel-ladder-stage:hover \.funnel-bar-track\.cov\s*\{[^}]*box-shadow/.test(css))
      throw new Error('a hovered ladder bar has no outline');
  });
  t('a ladder bar takes its length from --pct, set per bar in the markup', () => {
    // v181 review — the length moved from an inline width to a rule. Deleting
    // that rule would draw every Direct/Used-On/Ancestor bar at zero length and
    // pass every other test.
    if (!/\.funnel-bar-fill-cov\s*\{[^}]*width:\s*var\(--pct\)/.test(STYLE_BLOCKS[0].css))
      throw new Error('.funnel-bar-fill-cov does not take width from --pct');
    const cov = grabFn('renderFunnelPanel');
    if (!/class="funnel-bar-track cov" style="--pct:\$\{pctVal\}%"/.test(cov))
      throw new Error('the track no longer sets --pct from the bar percentage');
  });
  t('reference bars are visible against their panel', () => {
    // v180 — the reference bars' fill was 1.2-1.3:1 against the panel in every
    // theme: context, but invisible. They keep the quiet fill and gain an
    // outline in --text-muted, which clears 3:1 (the non-text minimum).
    if (!/\.funnel-bar-fill-ref \{[^}]*box-shadow:\s*inset 0 0 0 1px var\(--text-muted\)/.test(STYLE_BLOCKS[0].css))
      throw new Error('reference bars have no visible edge');
    ['dark', 'light', 'mono'].forEach(name => {
      const p = PALETTES[name];
      if (CONTRAST(p['--text-muted'], p['--surface']) < 3) throw new Error(name + ' reference bar edge below 3:1');
    });
  });
  t('anything inactive is dimmed by one token, --disabled-opacity', () => {
    // v180 — disabled buttons and inactive cards used 0.3, 0.35, 0.4 and 0.5.
    const app = SRC.slice(at('</script>'));
    const js = [...app.matchAll(/style\.opacity\s*=\s*([^;\n]+)/g)].map(m => m[1])
      .filter(v => /'0?\.\d+'/.test(v));
    if (js.length) throw new Error('script sets a literal opacity: ' + js.slice(0, 4).join(' | '));
    const css = STYLE_BLOCKS[0].css;
    const dis = [...css.matchAll(/([^{}]*:disabled[^{}]*)\{([^}]*)\}/g)]
      .filter(m => /opacity:\s*0?\.\d/.test(m[2])).map(m => m[1].trim());
    if (dis.length) throw new Error('disabled rule with a literal opacity: ' + dis.join(', '));
    if (!/--disabled-opacity:\s*0?\.\d+/.test(css)) throw new Error('--disabled-opacity is not defined');
    // v180 review — the two checks above missed four inactive controls written as
    // inline markup (0.3, 0.35, 0.4), and 0.78–0.85 fades on Comparison Summary
    // cells that measured 3.97:1 in light. So: no literal opacity anywhere in app
    // code, except these four, none of which fades text a reader must read.
    const ALLOWED = [
      /\.btn-primary:hover\s*\{[^}]*$/,        // hover feedback on the whole button
      /@keyframes lock-pulse[^\n]*$/,            // a pulse animation
      /\.explain-btn::before\s*\{[^}]*$/,        // the decorative ⓘ glyph
      /\.funnel-curve-path\s*\{[^}]*$/,          // an SVG stroke, not text
    ];
    const lit = [];
    for (const m of app.matchAll(/(?<![\w-])opacity\s*:\s*0?\.\d+/g)) {
      const before = app.slice(Math.max(0, m.index - 200), m.index);
      if (ALLOWED.some(r => r.test(before))) continue;
      lit.push(m[0] + ' @' + SRC.slice(0, SRC.indexOf(app) + m.index).split('\n').length);
    }
    if (lit.length) throw new Error('literal opacity outside the token: ' + lit.slice(0, 6).join(', '));
  });
  t('no funnel text is faded with opacity', () => {
    // A tier is a token, not an opacity: .75 on the delta percentages and a 50%
    // mix on the light inline count were a third and fourth grey by other means.
    const css = STYLE_BLOCKS[0].css;
    const bad = [...css.matchAll(/(\.funnel[\w-]*[^{]*)\{([^}]*)\}/g)]
      // Text rules only: a rule that sets a font size or a text colour. The
      // coverage curve's SVG stroke is drawn translucent on purpose.
      .filter(m => /font-size|(^|;|\s)color:/.test(m[2]))
      .filter(m => /opacity:\s*0?\.\d|color-mix\(in srgb, var\(--text\) \d+%/.test(m[2])).map(m => m[1].trim());
    if (bad.length) throw new Error('faded: ' + bad.join(', '));
  });
  t('every theme keeps body text legible against its own background', () => {
    // A theme is free to choose its greys, but not to choose ones nobody can
    // read. The dark palette clears this by 219; the bar is set well below
    // that so it catches a mistake rather than a preference.
    ['dark', 'light', 'mono'].forEach(name => {
      const p = PALETTES[name];
      const d = Math.abs(LUM(p['--bg']) - LUM(p['--text']));
      if (d < 120)
        throw new Error(name + ' body text is only ' + Math.round(d) + ' from its background');
    });
  });

  console.log('\n== A standalone download carries its own palette ==');
  t('the exported report writes the type scale into its own :root', () => {
    // v180 review — the test below trusts TYPE_SCALE_TOKENS as "emitted"; if
    // exportPaletteCss() stopped writing them it would still pass, and every
    // var(--fs-*) in the download would fall back to browser defaults. Run it.
    const fn = new Function('PALETTE_TOKENS', 'TYPE_SCALE_TOKENS', 'tok',
      grabFn('exportPaletteCss') + '; return exportPaletteCss();');
    const out = fn(['--bg'], TYPE_SCALE_TOKENS_IN_BUILD(), k => 'X');
    const miss = TYPE_SCALE_TOKENS_IN_BUILD().filter(k => out.indexOf(k + ':') < 0);
    if (!TYPE_SCALE_TOKENS_IN_BUILD().length) throw new Error('TYPE_SCALE_TOKENS not found in the build');
    if (miss.length) throw new Error('the download does not define: ' + miss.join(', '));
  });
  t('every var() in the exported report has a definition to resolve against', () => {
    // The live defect this fixes. The second style block belongs to a file the
    // user downloads and opens on its own; it referenced 52 tokens and shipped
    // no :root. An unresolvable var() on `color` computes to unset, which for
    // an inherited property means inherit, which bottoms out at black — so the
    // report rendered black text on a near-black background.
    //
    // Scanning only the export's <style> block is not enough: most of those 52
    // references are in inline styles on the rows and the certificate, in the
    // body of the template. Take the whole template, bounded at both ends —
    // an unbounded slice runs to EOF and reports the main application's tokens
    // as if the report used them.
    const tpl = span(at('const html = `<!DOCTYPE html>'),
                     at("downloadFile(tsFilename('bom_comparison_report'"),
                     'exported HTML report template');
    const used = [...new Set([...tpl.matchAll(/var\((--[\w-]+)\)/g)].map(m => m[1]))];
    if (used.length < 5) throw new Error('only ' + used.length + ' tokens found — the template moved');
    if (tpl.indexOf('exportPaletteCss()') < 0)
      throw new Error('the exported report no longer emits a :root block');
    const emitted = new Set(PALETTE_TOKENS_IN_BUILD().concat(TYPE_SCALE_TOKENS_IN_BUILD()));
    const missing = used.filter(k => !emitted.has(k));
    if (missing.length)
      throw new Error('the download references tokens it does not define: ' + missing.join(', '));
  });
  t('the exported palette list has not drifted from the stylesheet', () => {
    // The list is written by hand, so it is exactly the kind of thing that
    // rots. Derive the truth from :root and compare, rather than trusting it.
    const listed = PALETTE_TOKENS_IN_BUILD().slice().sort();
    const defined = Object.keys(PALETTES.dark).sort();
    const missing = defined.filter(k => listed.indexOf(k) < 0);
    const extra = listed.filter(k => defined.indexOf(k) < 0);
    if (missing.length) throw new Error('PALETTE_TOKENS omits: ' + missing.join(', '));
    if (extra.length) throw new Error('PALETTE_TOKENS names tokens :root does not define: ' + extra.join(', '));
  });
  t('the exported report holds no colour literal of its own', () => {
    // v137 tried to solve this by inlining hex, which is what left the report
    // frozen in the dark palette while the rest of the build gained themes.
    const exp = STYLE_BLOCKS[1].css;
    const hex = [...new Set(exp.match(/#[0-9a-fA-F]{3,8}/g) || [])]
      .filter(h => !/^#\{/.test(h));
    if (hex.length) throw new Error('literal colour(s) in the export stylesheet: ' + hex.join(', '));
  });

  console.log('\n== The palette is a view, not a record ==');
  t('the theme is not written into the session or the certificate', () => {
    // Two auditors opening the same frozen session must compute the same hash
    // whatever palette each is looking at. The theme is a viewing preference
    // and belongs in browser storage only.
    const exporter = grabFrom(SRC, 'exportSessionJson', 'session exporter');
    if (/theme/i.test(exporter))
      throw new Error('the session exporter mentions the theme');
    const setT = grabFrom(SRC, 'setTheme', 'theme switch');
    if (!/localStorage/.test(setT))
      throw new Error('setTheme does not persist to localStorage');
    if (/auditCert|state\.\w*[Hh]ash/.test(setT))
      throw new Error('setTheme touches the audit certificate');
  });
  t('dark is the absence of a theme attribute, not a fourth palette', () => {
    // :root is the default. If dark were also a [data-theme="dark"] block there
    // would be two definitions of the same palette to keep in step.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (/\[data-theme="dark"\]/.test(css))
      throw new Error('a dark theme block exists alongside :root');
    const setT = grabFrom(SRC, 'setTheme', 'theme switch');
    if (setT.indexOf('removeAttribute') < 0)
      throw new Error('setTheme does not clear the attribute for the default palette');
  });
  t('every canvas colour equals a defined token value', () => {
    // A 2D context silently ignores an unresolvable fillStyle and keeps the
    // previous colour, so these must stay hex — but they must not DRIFT from
    // the palette. #39c5cf was an RFV teal while --rfv was #2dd4bf.
    const canvas = [...BODY.matchAll(/fillStyle\s*=\s*'(#[0-9a-fA-F]{6})/g)]
      .concat([...BODY.matchAll(/return\s*'(#[0-9a-fA-F]{6})'/g)])
      .map(m => m[1].toLowerCase());
    const orphan = [...new Set(canvas)].filter(v => !byValue[v]);
    if (orphan.length)
      throw new Error('canvas colour(s) with no matching token: ' + orphan.join(', '));
  });
  t('no canvas fillStyle tries to use a CSS variable', () => {
    if (/fillStyle\s*=\s*['"`]?\s*var\(/.test(BODY))
      throw new Error('canvas cannot resolve var() — the colour would silently not change');
  });
  t('RFV is one colour, not two', () => {
    // v173 — read from the dark palette explicitly. A flat scan of the
    // stylesheet now returns whichever theme is written last, so this used to
    // compare the RFV teal against the mono grey and fail for no reason.
    const rfv = PALETTES.dark['--rfv'];
    if (!rfv) throw new Error('--rfv is not defined');
    const teals = [...new Set([...BODY.matchAll(/#(3[0-9a-f]c[0-9a-f]{3}|2dd4bf)/gi)]
      .map(m => m[0].toLowerCase()))];
    if (teals.length)
      throw new Error('a second RFV teal is in use: ' + teals.join(', ') +
                      ' (--rfv is ' + rfv + ', and canvas colours go through tok())');
  });
  t('no chart renderer holds a colour literal', () => {
    // v173 — replaces the old "every canvas hex equals a token value". That
    // rule matched `fillStyle = '#hex'` and `return '#hex'`, so it never saw a
    // colour sitting in an OBJECT LITERAL. Three did: the WO status map (which
    // is how the second muted grey #7d8590 survived v155), the stacked-bar
    // segment list, and colorForStatus's fallback. Renderers now resolve every
    // colour through tok(), so the contract is simply that none of them
    // contains a hex at all — a rule with nowhere to hide.
    // drawBarChart left this list in v176 along with the function itself.
    const RENDERERS = ['drawNcrDispStatusChart', 'drawWoStatusRollup', 'drawNcrDispCodeList',   // v186
                       'drawNcrCauseCodeList', '_ncrCodeListHtml'];   // v188 — drawNcrCauseCodeChart is gone
    RENDERERS.forEach(name => {
      const src = grabFrom(SRC, name, 'chart renderers');
      const hex = [...new Set((src.match(/'#[0-9a-fA-F]{3,8}'/g) || []))];
      if (hex.length)
        throw new Error(name + ' holds colour literal(s): ' + hex.join(', '));
    });
  });
  t('tok() resolves through the live palette and cannot return empty', () => {
    // The whole reason canvas colours were literal: a 2D context given an
    // unresolvable fillStyle does not throw, it KEEPS THE PREVIOUS COLOUR. So
    // tok() returning '' would not fail loudly, it would silently draw the
    // last bar's colour over the next one.
    const src = grabFrom(SRC, 'tok', 'token reader');
    if (!/getComputedStyle/.test(src))
      throw new Error('tok() no longer reads the live document');
    if (!/\|\|\s*'#[0-9a-fA-F]{6}'/.test(src))
      throw new Error('tok() has no fallback — an unknown token would return empty');
    if (!/getPropertyValue/.test(src))
      throw new Error('tok() is not reading a custom property');
  });
  t('a palette change re-themes every chart with no redraw: they colour through CSS variables', () => {
    // v173 to v187 this test required a redraw, because a canvas holds
    // resolved hex. v188 — no canvas is left, so the contract is the other way
    // round: nothing that draws a chart may write a resolved colour into its
    // markup, since nothing re-renders it on a theme change. v187's disposition
    // status list did exactly that (tok() into an inline style) and kept the
    // old theme's colours until the next run.
    const src = grabFrom(SRC, 'setTheme', 'theme switch');
    if (src.indexOf('clearTokenCache(') < 0) throw new Error('setTheme does not clear the token cache');
    ['drawNcrDispStatusChart', 'drawWoStatusRollup', 'drawNcrDispCodeList', 'drawNcrCauseCodeList', '_ncrCodeListHtml'].forEach(f => {
      if (/\btok\(/.test(stripComments(grabFrom(SRC, f, 'chart renderers')))) throw new Error(f + ' writes a resolved colour (tok) into its markup');
    });
    if (!/'CLOSED': 'var\(--success\)'/.test(grabFn('drawNcrDispStatusChart'))) throw new Error('the status list does not colour CLOSED through --success');
  });
});

// ── TIER 13 ────────────────────────────────────────────────────────────────
// The Comparison Summary type scale, plus a syntax check of the whole build.
// v155 stripped 26 inline font-size overrides out of renderSummaryTable with a
// regex; a regex loose enough to do that is loose enough to break a template
// literal, and nothing here would have noticed.
suite('Tier 13 — summary table type scale', (t, eq) => {
  const CSS = STYLE_BLOCKS.map(b => b.css).join('\n');
  const TABLE = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
  const rule = sel => {
    const m = CSS.match(new RegExp('(?:^|\\})\\s*' + sel + '\\s*\\{([^}]*)\\}', 'm'));
    if (!m) throw new Error('rule not found: ' + sel);
    return m[1].split('\n').join(' ').replace(/\s+/g, ' ');
  };
  const px = decl => { const m = decl.match(/font-size:\s*(?:var\((--[\w-]+)\)|(\d+)px)/);
    return m ? (m[1] || m[2] + 'px') : null; };
  // v180 — tokens may alias the type scale (--fs-cell: var(--fs-sm)), so follow the chain.
  const token = n => { const m = CSS.match(new RegExp(n + '\\s*:\\s*([^;]+);'));
    if (!m) throw new Error(n + ' is not defined');
    const v = m[1].trim(), a = v.match(/^var\((--[\w-]+)\)$/);
    return a ? token(a[1]) : parseFloat(v); };

  console.log('\n== The build still parses ==');
  t('every inline script block is syntactically valid', () => {
    const cp = require('child_process'), fs2 = require('fs'), os = require('os'), pth = require('path');
    const blocks = [...SRC.matchAll(/<script(?![^>]*\ssrc=)[^>]*>([\s\S]*?)<\/script>/g)]
      .map(m => m[1]).filter(b => b.length > 50);
    if (blocks.length < 2) throw new Error('expected at least 2 script blocks, found ' + blocks.length);
    blocks.forEach((b, i) => {
      const f = pth.join(os.tmpdir(), 'cmp-syntax-' + process.pid + '-' + i + '.js');
      fs2.writeFileSync(f, b);
      const r = cp.spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
      fs2.unlinkSync(f);
      if (r.status !== 0)
        throw new Error('script block ' + i + ' does not parse:\n        ' +
                        String(r.stderr).split('\n').slice(0, 4).join('\n        '));
    });
  });
  t('no style attribute was left malformed', () => {
    // Scoped to style attributes: `;;` is ordinary JavaScript — `for(;;)` and
    // SheetJS's own escaping account for 11 legitimate occurrences file-wide.
    const attrs = [...SRC.matchAll(/style="([^"]*)"/g)].map(m => m[1]);
    const bad = attrs.filter(a => /^\s*;/.test(a) || /;;/.test(a) || /^\s*$/.test(a));
    if (bad.length)
      throw new Error(bad.length + ' malformed style attribute(s), e.g. ' +
                      JSON.stringify(bad[0].slice(0, 60)));
  });

  console.log('\n== One size for every cell ==');
  t('the scale is declared as tokens, not repeated literals', () => {
    eq(px(rule('td')), '--fs-cell', 'td:');
    eq(px(rule('th')), '--fs-head', 'th:');
  });
  t('no cell in the summary table overrides the base size', () => {
    const over = TABLE.match(/font-size:\s*\d+px/g);
    if (over) throw new Error(over.length + ' inline override(s) remain: ' +
                              [...new Set(over)].join(', '));
  });
  t('no stylesheet rule re-sizes a table cell either', () => {
    const bad = [];
    ['td.td-indenture', 'td.ctx-rel', '.badge-ncr-none'].forEach(sel => {
      const p = px(rule(sel));
      if (p && p !== '--fs-cell') bad.push(sel + ' = ' + p);
    });
    if (bad.length) throw new Error(bad.join('; '));
  });

  console.log('\n== Weight is not an emphasis channel ==');
  t('no data cell in the summary table sets its own weight', () => {
    // v156 — #7. Weight belongs to the Part Number column and to badges. It was
    // also on NCR numbers, part-type codes, quantity deltas and adjudication
    // glyphs — emphasis with no shared rule. Colour already carries all of it.
    const TABLE = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    const bold = TABLE.match(/font-weight:\s*[67]00/g);
    if (bold) throw new Error(bold.length + ' inline bold declaration(s) remain in the table');
  });
  t('the two places weight IS allowed still have it', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/\.pn-col\s*\{[^}]*font-weight:\s*600/.test(css))
      throw new Error('the Part Number column lost its weight');
    if (!/\.badge\s*\{[^}]*font-weight:\s*700/.test(css))
      throw new Error('badges lost their weight');
  });

  console.log('\n== Row separation ==');
  t('rows are separated by a visible line', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const m = css.match(/--row-line:\s*#([0-9a-fA-F]{8})/);
    if (!m) throw new Error('--row-line is not defined as an 8-digit hex');
    const alpha = parseInt(m[1].slice(6), 16);
    if (alpha < 0x18) throw new Error('row separator alpha is 0x' + m[1].slice(6) +
      ' — too faint to locate a row on a wide scrolled table');
    if (!/border-bottom:\s*1px solid var\(--row-line\)/.test(css))
      throw new Error('td no longer uses --row-line');
  });

  console.log('\n== Headers and badges ==');
  t('the header is smaller than the cell, not larger', () => {
    // A header is a label, not content. It is already distinguished by
    // uppercase, letter-spacing, a surface fill and muted colour, and it is
    // sticky — so enlarging it would cost permanent vertical space.
    const head = token('--fs-head'), cell = token('--fs-cell');
    if (head >= cell) throw new Error('head ' + head + 'px vs cell ' + cell + 'px');
    ['text-transform: uppercase', 'letter-spacing'].forEach(sig => {
      if (rule('th').indexOf(sig) < 0)
        throw new Error('the header lost a non-size signal: ' + sig);
    });
  });
  t('every badge is one size, set in one place', () => {
    // v155 matched badges to cell text. On review that made OVERALL badges
    // larger than the trace-column badges beside them in the same row, because
    // the trace columns carried an inline 9px override. v156 makes the smaller
    // size the rule and removes the overrides — one token, no exceptions.
    eq(px(rule('\\.badge')), '--fs-badge');
    const inline = SRC.match(/class="badge[^"]*"[^>]{0,80}font-size:\s*\d+px/g);
    if (inline) throw new Error(inline.length + ' badge(s) still override the size: ' +
                                inline[0].slice(0, 80));
    const cls = [...STYLE_BLOCKS.map(b => b.css).join('\n')
      .matchAll(/\.(badge-[\w-]+)\s*\{[^}]*font-size:\s*(\d+)px/g)].map(m => m[1]);
    if (cls.length) throw new Error('badge class(es) re-size themselves: ' + cls.join(', '));
  });
  t('badge tracking stays tight', () => {
    // Size and tracking compound. At 0.12em, matching cell size widened the two
    // stacked-badge columns by about a third in a table that already scrolls.
    // v180: tracking is a token now, so resolve var() before measuring.
    const m = rule('\\.badge').match(/letter-spacing:\s*(var\((--[\w-]+)\)|([\d.]+)em)/);
    if (!m) throw new Error('badge letter-spacing is gone');
    const em = m[2] ? parseFloat(String(token(m[2]))) : parseFloat(m[3]);
    if (!(em > 0)) throw new Error('badge tracking token ' + m[2] + ' does not resolve');
    if (em > 0.05)
      throw new Error('tracking is ' + em + 'em — too wide at ' + token('--fs-cell') + 'px');
  });
  t('badges keep a non-size difference from the cell text', () => {
    // The user asked for same size, different style. Weight and case carry it.
    const b = rule('\\.badge');
    ['font-weight: 700', 'text-transform: uppercase'].forEach(sig => {
      if (b.indexOf(sig) < 0) throw new Error('badge lost ' + sig);
    });
  });
});

// ── TIER 14 ────────────────────────────────────────────────────────────────
// Detailed View table structure. .table-wrap is overflow-x/y auto with a
// max-height, so anything placed inside it scrolls away from the reader and
// slides under the sticky header row — and attachTopScrollbar inserts its
// mirror as the wrap's previous sibling, so a caption inside the wrap pushes
// the horizontal scrollbar above the caption instead of onto the table.
// Exactly two of the eight views did that, and they are the two that were
// reported as looking different.
suite('Tier 14 — Detailed View table structure', (t, eq) => {
  const VIEWS = ['renderSummaryTable', 'renderFullBom', 'renderChpTable', 'renderWo5Table',
                 'renderWo5DiscrepancyView', 'renderNcrTable', 'renderCITraceTable',
                 'renderRFVTable'];
  const body = fn => { const a = at('function ' + fn);
    const b = SRC.indexOf('\nfunction ', a + 10);
    return SRC.slice(a, b > 0 ? b : a + 26000); };

  console.log('\n== Every view is wired the same way ==');
  t('every Detailed View renderer targets a .table-wrap and attaches a top scrollbar', () => {
    VIEWS.forEach(fn => {
      const b = body(fn);
      const m = b.match(/getElementById\(([^)]+)\)\.innerHTML = html/);
      if (!m) throw new Error(fn + ' does not fill a wrapper');
      if (b.indexOf('attachTopScrollbar') < 0)
        throw new Error(fn + ' has no top scrollbar');
    });
  });
  t('every wrapper element carries the table-wrap class', () => {
    ['summary', 'ebom', 'chp', 'wo5', 'wo5disc', 'ncr', 'ci', 'rfv'].forEach(k => {
      const re = new RegExp('<div[^>]*id="' + k + '-table-wrap"[^>]*>');
      const m = SRC.match(re);
      if (!m) throw new Error(k + '-table-wrap is not declared');
      if (m[0].indexOf('table-wrap') < 0)
        throw new Error(k + ' wrapper lost its class: ' + m[0]);
    });
  });

  console.log('\n== #11 / #12: nothing but the table inside the scroller ==');
  t('no renderer puts a caption inside the scroll container', () => {
    const bad = VIEWS.filter(fn => {
      const b = body(fn);
      const i = b.indexOf('<table');
      return i > 0 && /html\s*\+?=\s*[`'"]<div/.test(b.slice(0, i));
    });
    if (bad.length)
      throw new Error('caption inside .table-wrap in: ' + bad.join(', ') +
                      ' — it will scroll sideways with the table and sit under the sticky header');
  });
  t('both captions are written to elements outside their wrapper', () => {
    [['wo5disc', 'renderWo5DiscrepancyView'], ['rfv', 'renderRFVTable']].forEach(([k, fn]) => {
      const cap = SRC.indexOf('id="' + k + '-table-caption"');
      const wrap = SRC.indexOf('id="' + k + '-table-wrap"');
      if (cap < 0) throw new Error(k + '-table-caption is not declared');
      if (cap > wrap) throw new Error(k + ' caption is declared after its wrapper');
      if (body(fn).indexOf("setTableCaption('" + k + "-table-caption'") < 0)
        throw new Error(fn + ' no longer writes its caption');
    });
  });
  t('the caption helper writes outside the wrapper, not into it', () => {
    const h = SRC.slice(at('function setTableCaption'), at('function attachTopScrollbar'));
    if (h.indexOf('table-wrap') >= 0)
      throw new Error('setTableCaption touches the scroll container');
    if (h.indexOf('innerHTML') < 0) throw new Error('setTableCaption stopped writing');
  });
  t('.table-caption is styled and collapses when empty', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/\.table-caption\s*\{/.test(css)) throw new Error('.table-caption has no rule');
    if (!/\.table-caption:empty\s*\{[^}]*display:\s*none/.test(css))
      throw new Error('an empty caption must not leave a gap above the table');
  });

  console.log('\n== Row selection survives re-render ==');
  t('every summary row carries its key and a click handler', () => {
    const T = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    if (!/data-rk="\$\{esc\(r\.key\)\}"/.test(T))
      throw new Error('rows no longer carry their key');
    if (!/onclick="selectSummaryRow\(this\)"/.test(T))
      throw new Error('rows are not clickable');
  });
  t('the selection lives in state, not only in the DOM', () => {
    // A DOM-only highlight would vanish on paging, filtering or any re-render —
    // exactly when a reader most needs to keep their place.
    if (!/summarySelectedKey:\s*null/.test(SRC))
      throw new Error('state has no summarySelectedKey');
    const T = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    if (!/state\.summarySelectedKey === r\.key/.test(T))
      throw new Error('render does not re-apply the stored selection');
  });
  t('clicking the selected row clears it, and only one row is ever selected', () => {
    const h = SRC.slice(at('function selectSummaryRow'), at('function renderSummaryTable'));
    if (!/state\.summarySelectedKey === key/.test(h))
      throw new Error('no toggle-off path');
    if (!/querySelectorAll\('tr\.row-selected'\)/.test(h))
      throw new Error('a previous selection is not cleared');
  });
  t('selection paints the cells, so an inline row background cannot hide it', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/tbody tr\.row-selected > td\s*\{[^}]*background[^}]*!important/.test(css))
      throw new Error('selection must paint td with !important — rows carry inline status backgrounds');
    if (!/tbody tr\.row-selected > td:first-child\s*\{[^}]*box-shadow/.test(css))
      throw new Error('the left marker is gone');
  });

  console.log('\n== Pagination is uniform ==');
  t('every paginated view uses the shared PAGE_SIZE and page-bar', () => {
    VIEWS.filter(fn => fn !== 'renderCITraceTable').forEach(fn => {
      const b = body(fn);
      if (b.indexOf('PAGE_SIZE') < 0) throw new Error(fn + ' does not use PAGE_SIZE');
      if (b.indexOf('class="page-bar"') < 0) throw new Error(fn + ' has no page-bar');
      ['← Prev', 'Next →'].forEach(lbl => {
        if (b.indexOf(lbl) < 0) throw new Error(fn + ' is missing the ' + lbl + ' control');
      });
    });
  });
  t('the CI Traceability view is the one deliberate exception', () => {
    // Documented rather than silently tolerated: it renders every row. If it
    // ever gains pagination, this test fails and the exception list shrinks.
    const b = body('renderCITraceTable');
    if (b.indexOf('class="page-bar"') >= 0)
      throw new Error('renderCITraceTable now paginates — move it into the rule above');
  });
});

// ── TIER 15 ────────────────────────────────────────────────────────────────
// The reconciliation engine. 543 lines that decide whether a part is
// reconciled, and until v159 not one test executed it — every other suite
// tested the code AROUND it: the proc table that feeds it, the badges that
// display its output, the exports that format it.
//
// Fixtures go through the REAL map builders, never hand-built. Building them by
// hand got the shapes wrong twice while this suite was being written: a Map
// where the engine wants a plain object, and an object where primaryQtyMap
// wants a bare number. Both times the engine ran without error and returned
// plausible-but-wrong results. A fixture that lies is worse than no test.
suite('Tier 15 — reconciliation engine', (t, eq) => {
  const E = sandbox({ PROC_CODE_EXCEPTIONS: { BR:'remove', 'BR-S':'remove', RS:'remove',
    CR:'remove', FR:'remove', MR:'remove', DR:'swap', 'DR-S':'swap', TRRI:'swap', PIP:'swap' } },
    ['engine']).E;

  // EBOM row: [indenture, pn, desc, nh, qty]. Indenture C = a real line item;
  // A and B are structural collector levels and are excluded from scope.
  const eb = (pn, nh, q, ind) => { const r = new Array(6).fill('');
    r[0] = ind || 'C'; r[1] = pn; r[3] = nh; r[4] = String(q); return r; };
  // ABOM row: [pn, usedOn, qty, woNo, woStatus, procCode]
  const ab = (pn, uo, q, wo, st, pc) => [pn, uo, String(q), wo, st || 'CLOSED', pc || ''];

  function run(ebom, mbom, abom, extra) {
    const closed = (abom || []).filter(r => String(r[4]).toUpperCase() === 'CLOSED');
    const open   = (abom || []).filter(r => String(r[4]).toUpperCase() !== 'CLOSED');
    return E.runReconciliationCore(Object.assign({
      mode: 'ebom_mbom_abom', required: ['ebom', 'mbom', 'abom'], serializeMaps: false,
      // v160 — the collector rule is now a parameter. The default matches the
      // shipped default; tests that vary it pass their own.
      collectorLevels: ['A', 'B'],
      primaryQtyMap: E.buildQtyMap(ebom, 1, 3, 4, true),
      mbomMap: mbom ? E.buildQtyMap(mbom, 1, 3, 4) : null,
      abomMap: abom ? E.buildAbomMap(closed, 0, 1, 2, 3, 4, 5) : null,
      openAbomMap: abom ? E.buildAbomMap(open, 0, 1, 2, 3, 4, 5) : null,
      mbomUsedOnMap: mbom ? E.buildMbomUsedOnMap(mbom, 1, 3, 4) : null,
      abomUsedOnMap: abom ? E.buildAbomUsedOnMap(closed, 0, 1, 2, 3, 4, 5) : null,
      openAbomUsedOnMap: abom ? E.buildAbomUsedOnMap(open, 0, 1, 2, 3, 4, 5) : null,
      abomWoToUsedOns: {}, ebomFlex: {}, ebomRef: {}, removalScope: {}, ptTypeMap: {},
      ebomLineNoMap: {}, ebomQtyTextMap: {},
      indentureInfo: E.buildEbomIndentureMap(ebom, 0, 1, 3),
      chpTrace: {}, chpPnTrace: {}, ncrByDiscPn: {}, ncrByOrigWo: {}, wo5Map: {},
    }, extra || {}));
  }
  const row = (res, key) => res.find(r => r.key === (key || 'P1||TOP'));
  const legs = (res, key) => { const r = row(res, key);
    if (!r) throw new Error('no row for ' + (key || 'P1||TOP'));
    return [r.ms, r.as, r.overall]; };

  console.log('\n== The fixture builders agree with the engine ==');
  t('buildQtyMap produces the bare-number shape the engine reads', () => {
    // `var eq = primaryMap[key]` — the value IS the quantity. Wrapping it in an
    // object makes every comparison silently false.
    const m = E.buildQtyMap([eb('P1', 'TOP', 2)], 1, 3, 4, true);
    eq(m['P1||TOP'], 2);
    if (typeof m['P1||TOP'] !== 'number') throw new Error('not a number');
  });
  t('buildAbomMap produces the fields the engine destructures', () => {
    const m = E.buildAbomMap([ab('P1', 'TOP', 2, 'W1')], 0, 1, 2, 3, 4, 5);
    ['qty', 'woValues', 'allProcsAreRemovalOrSwap'].forEach(k => {
      if (!(k in m['P1||TOP'])) throw new Error('buildAbomMap no longer emits ' + k);
    });
    eq(Array.isArray(m['P1||TOP'].woValues), true, 'woValues must be an array:');
  });

  console.log('\n== Pass 1 — direct match ==');
  t('a line present and equal on all three legs reconciles', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')])),
       ['ok', 'ok', 'ok']);
  });
  t('a line absent from both target legs is missing', () => {
    eq(legs(run([eb('P1','TOP',2)], [], [])), ['missing', 'missing', 'missing']);
  });
  t('each leg is judged independently', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [])),
       ['ok', 'missing', 'missing'], 'planned but not built:');
  });

  console.log('\n== Quantity: a shortfall, not any difference ==');
  t('less in the target than the EBOM is a mismatch', () => {
    eq(legs(run([eb('P1','TOP',3)], [eb('P1','TOP',3)], [ab('P1','TOP',1,'W1')]))[1],
       'qty_mismatch');
    eq(legs(run([eb('P1','TOP',3)], [eb('P1','TOP',1)], [ab('P1','TOP',3,'W1')]))[0],
       'qty_mismatch', 'MBOM side too:');
  });
  t('MORE in the target than the EBOM is NOT a mismatch', () => {
    // Deliberate: the rule is `aq < eq`. An overage is not a reconciliation
    // failure — the design quantity is satisfied.
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',5)], [ab('P1','TOP',5,'W1')])),
       ['ok', 'ok', 'ok']);
  });
  t('exact equality is not a mismatch', () => {
    eq(legs(run([eb('P1','TOP',7)], [eb('P1','TOP',7)], [ab('P1','TOP',7,'W1')])),
       ['ok', 'ok', 'ok']);
  });

  console.log('\n== Work order status and proc codes ==');
  t('an open work order is wo_open, not ok and not missing', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1','OPEN')]))[1],
       'wo_open');
  });
  t('a REMOVE proc code on every record reads as proc_removed', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1','CLOSED','BR')]))[1],
       'proc_removed');
  });
  t('an install alongside a removal nets out rather than reading as removed', () => {
    const r = run([eb('P1','TOP',2)], [eb('P1','TOP',2)],
                  [ab('P1','TOP',2,'W1','CLOSED'), ab('P1','TOP',2,'W2','CLOSED','BR')]);
    if (row(r).as === 'proc_removed')
      throw new Error('a key with an effective install must not read as proc_removed');
  });
  t('a SWAP code is not a removal', () => {
    // DR is net-zero by design — removed then reinstalled before the WO closes.
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1','CLOSED','DR')]))[1],
       'ok');
  });

  console.log('\n== Scope exclusions ==');
  t('indenture A and B rows are structural collectors, not line items', () => {
    const r = run([eb('TOP','',1,'A'), eb('P1','TOP',2)], [eb('P1','TOP',2)],
                  [ab('P1','TOP',2,'W1')]);
    eq(legs(r, 'TOP||'), ['collector', 'collector', 'collector']);
    eq(legs(r), ['ok', 'ok', 'ok'], 'the real line item beneath it is unaffected:');
  });
  t('a REF line is excluded from the results entirely', () => {
    const r = run([eb('P1','TOP',2)], [], [], { ebomRef: { 'P1||TOP': true } });
    eq(r.length, 0, 'REF lines must not appear as rows at all:');
  });
  t('a removal-scope line is reported as pt_removal, not as missing', () => {
    eq(legs(run([eb('P1','TOP',2)], [], [], { removalScope: { 'P1||TOP': true } })),
       ['pt_removal', 'pt_removal', 'pt_removal']);
  });
  t('a SUB/AR flex line absent from the target is flex_missing, and overall ok', () => {
    // Any quantity satisfies a flex line, and absence is expected — so the leg
    // records flex_missing while the rollup stays clean.
    const l = legs(run([eb('P1','TOP',2)], [], [], { ebomFlex: { 'P1||TOP': true } }));
    eq([l[0], l[2]], ['flex_missing', 'ok']);
  });

  console.log('\n== The overall rollup takes the worst leg ==');
  t('missing beats qty_mismatch', () => {
    eq(legs(run([eb('P1','TOP',3)], [eb('P1','TOP',1)], []))[2], 'missing');
  });
  t('qty_mismatch beats wo_open', () => {
    const r = run([eb('P1','TOP',3)], [eb('P1','TOP',1)], [ab('P1','TOP',3,'W1','OPEN')]);
    eq(row(r).overall, 'qty_mismatch');
  });
  t('wo_open beats ok', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1','OPEN')]))[2],
       'wo_open');
  });
  t('overall is only ok when no leg is worse', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')]))[2], 'ok');
  });

  console.log('\n== Keys, normalisation and multiple rows ==');
  t('the key is part number plus next higher, not part number alone', () => {
    const r = run([eb('P1','TOP',2), eb('P1','OTHER',3)],
                  [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')]);
    eq(r.length, 2, 'the same PN under two parents is two rows:');
    eq(legs(r, 'P1||TOP')[0], 'ok');
    eq(legs(r, 'P1||OTHER')[0], 'missing', 'the second parent is unplanned:');
  });
  t('case and padding differences still match', () => {
    eq(legs(run([eb(' p1 ', 'top', 2)], [eb('P1', 'TOP', 2)], [ab('P1', 'TOP', 2, 'W1')])),
       ['ok', 'ok', 'ok']);
  });
  t('every EBOM line in scope produces exactly one row', () => {
    const r = run([eb('P1','TOP',1), eb('P2','TOP',1), eb('P3','TOP',1)],
                  [eb('P1','TOP',1)], [ab('P2','TOP',1,'W1')]);
    eq(r.length, 3);
    // Each row is judged on its own evidence: P1 is planned only, P2 is built
    // only, P3 is in neither. All three roll up to missing, by different routes.
    eq([row(r,'P1||TOP').ms, row(r,'P1||TOP').as], ['ok', 'missing'], 'planned, not built:');
    eq([row(r,'P2||TOP').ms, row(r,'P2||TOP').as], ['missing', 'ok'], 'built, not planned:');
    eq([row(r,'P3||TOP').ms, row(r,'P3||TOP').as], ['missing', 'missing'], 'neither:');
  });
  t('an empty EBOM produces no rows and does not throw', () => {
    eq(run([], [], []).length, 0);
  });
});

// ── TIER 16 ────────────────────────────────────────────────────────────────
// computeEffectiveResults applies SME claims on top of raw engine output. Its
// own comments say Phase C "mirrors runReconciliationCore's priority rollup" —
// the same shape of risk as the duplicated PROC_CODE_BASELINE in the delta
// tool, which did drift. Nothing enforced the agreement until now.
suite('Tier 16 — effective results and the duplicated rollup', (t, eq) => {
  const E = sandbox({ state: { results: [], adjudications: [] },
                      PROC_CODE_EXCEPTIONS: {} }, ['engine']).E;
  const CE = (rows, claims) => E.computeEffectiveResults(rows, claims || []);
  const raw = o => Object.assign({ key:'P1||TOP', pn:'P1', nh:'TOP',
    ms:'ok', as:'ok', msUsedOn:'n/a', asUsedOn:'n/a', overall:'ok' }, o);

  console.log('\n== The two rollups must agree, exhaustively ==');
  t('both ladders return the same overall for every leg combination', () => {
    // 12 statuses across 4 legs = 20,736 combinations. Each row is fed the
    // overall the ENGINE produced, because that is the real precondition —
    // Phase C reads the existing overall to decide whether to skip a row.
    const V = ['ok','missing','qty_mismatch','wo_open','proc_removed','covered',
               'pn_as_usedon','n/a','flex_ok','flex_missing','collector','wo_cancelled'];
    // A claim MUST be supplied: computeEffectiveResults returns early when the
    // claim list is empty, so comparing with no claims would skip Phase C
    // entirely and pass without testing anything. The claim targets a row that
    // does not exist, so it changes no leg — it only gets us past the guard.
    const wake = [{ id: 'probe', rowKey: 'NOSUCH||ROW', leg: 'mbom',
                    reason: 'direct', applied: true }];
    const diff = [];
    V.forEach(ms => V.forEach(as => V.forEach(mu => V.forEach(au => {
      const engine = E.engineLadder(ms, as, mu, au);
      const eff = CE([raw({ ms, as, msUsedOn: mu, asUsedOn: au, overall: engine })], wake)[0].overall;
      if (engine !== eff) diff.push(ms + '/' + as + '/' + mu + '/' + au +
                                    ': engine=' + engine + ' effective=' + eff);
    }))));
    if (diff.length)
      throw new Error(diff.length + ' of 20736 combinations disagree, e.g.\n        ' +
                      diff.slice(0, 5).join('\n        '));
  });
  t('the worst-leg order is identical in both copies', () => {
    // Compare the ladders as code, not only as behaviour: a reordering that
    // happens to be behaviourally equivalent today is still drift.
    const rungs = src => (src.match(/'(missing|qty_mismatch|wo_open|proc_removed)'/g) || [])
      .map(x => x.replace(/'/g, '')).filter((v, i, a) => a.indexOf(v) === i);
    const engSrc = SRC.slice(at('var legs = [];'), at('// Pass 3 fallback'));
    const effA = at('// ── Phase C');
    const effSrc = SRC.slice(effA, SRC.indexOf('return effective', effA));
    eq(rungs(effSrc), rungs(engSrc), 'rung order:');
    eq(rungs(engSrc), ['missing', 'qty_mismatch', 'wo_open', 'proc_removed']);
  });

  console.log('\n== With no claims, nothing changes ==');
  t('an empty claim list is a pass-through', () => {
    const rows = [raw({}), raw({ key:'P2||TOP', pn:'P2', ms:'missing', overall:'missing' })];
    const out = CE(rows, []);
    eq(out.length, 2);
    eq(out.map(r => r.overall), ['ok', 'missing']);
  });
  t('the raw rows are not mutated', () => {
    // The audit trail depends on raw and effective staying separable — the
    // session exports both.
    const rows = [raw({ ms:'missing', overall:'missing' })];
    CE(rows, [{ id:'a1', rowKey:'P1||TOP', leg:'mbom', reason:'direct',
                type:'row', applied:true }]);
    eq(rows[0].ms, 'missing', 'the raw row must survive untouched:');
    eq(rows[0].overall, 'missing');
  });
  t('structural rows are never re-rolled', () => {
    ['pt_collector', 'pt_reference', 'pt_bulk', 'pt_removal', 'collector'].forEach(st => {
      const out = CE([raw({ ms:'missing', as:'missing', overall: st })]);
      eq(out[0].overall, st, st + ' must pass through untouched:');
    });
  });

  console.log('\n== Adjudicated statuses roll up as their plain equivalents ==');
  t('an adjudicated direct leg counts as a direct-OK leg', () => {
    eq(CE([raw({ ms:'direct_adjudicated', as:'ok', overall:'ok' })])[0].overall,
       E.engineLadder('ok', 'ok', 'n/a', 'n/a'));
  });
  t('an accepted quantity mismatch no longer rolls up as a mismatch', () => {
    const out = CE([raw({ ms:'qty_mismatch_accepted', as:'ok', overall:'ok' })])[0];
    if (out.overall === 'qty_mismatch')
      throw new Error('an accepted mismatch must not still read as a mismatch');
  });
  t('Phase C does not run at all when there are no claims', () => {
    // `if (!adjudications || !adjudications.length) return effective;` — an
    // early return before Phase C. So adjudicated leg statuses in the raw rows
    // are NOT re-rolled unless a claim exists. Correct (an adjudicated status
    // cannot appear without a claim) but easy to misread: every test of the
    // promotion branch must supply a claim or it silently tests nothing.
    const out = CE([raw({ ms:'covered_adjudicated', as:'covered_adjudicated',
                          overall:'covered' })], []);
    eq(out[0].overall, 'covered', 'unchanged, because Phase C was skipped:');
  });
  t('with a claim present, an adjudicated covered leg is surfaced at overall', () => {
    const out = CE([raw({ ms:'covered_adjudicated', as:'covered_adjudicated',
                          overall:'covered' })],
                   [{ id:'a1', rowKey:'OTHER||ROW', leg:'mbom', reason:'direct',
                      applied:true }]);
    eq(out[0].overall, 'covered_adjudicated');
  });
  t('a mix of covered and covered_adjudicated surfaces the adjudication', () => {
    const out = CE([raw({ ms:'covered', as:'covered_adjudicated', overall:'covered' })],
                   [{ id:'a1', rowKey:'OTHER||ROW', leg:'mbom', reason:'direct',
                      applied:true }]);
    eq(out[0].overall, 'covered_adjudicated');
  });
  t('plain covered legs stay plain', () => {
    eq(CE([raw({ ms:'covered', as:'covered', overall:'covered' })])[0].overall, 'covered');
  });

  console.log('\n== Malformed input must not corrupt the audit trail ==');
  t('a claim naming a row that does not exist is ignored', () => {
    const out = CE([raw({})], [{ id:'x', rowKey:'NOSUCH||ROW', leg:'mbom',
                                 reason:'direct', applied:true }]);
    eq([out.length, out[0].overall], [1, 'ok']);
  });
  t('a claim with no rowKey does not throw', () => {
    eq(CE([raw({})], [{ id:'x', leg:'mbom', reason:'direct', applied:true }]).length, 1);
  });
  t('an empty result set returns an empty array', () => {
    eq(CE([], [{ id:'x', rowKey:'K', leg:'mbom' }]).length, 0);
  });
});

// ── TIER 17 ────────────────────────────────────────────────────────────────
// Session restore. The session file IS the audit artefact — it is what gets
// re-opened months later to answer "what did we certify, and on what basis".
// A field that fails to restore is a silently wrong answer, not a crash.
suite('Tier 17 — session restore', (t, eq) => {
  const el = () => ({ style:{}, classList:{ add(){}, remove(){}, toggle(){} },
    textContent:'', value:'', innerHTML:'', disabled:false,
    querySelectorAll: () => [], appendChild(){} });
  const fresh = () => ({ mode:'ebom_mbom', boms:{}, results:[], resultsRaw:[],
                         adjudications:[] });
  function load(payload) {
    const ctx = sandbox({
      document: { getElementById: el, querySelector: el, querySelectorAll: () => [] },
      state: fresh(), COL: { ebom:{ pn:1, nh:3 } },
      deserializeResults: r => r,
      setProcCodeMap: function (m, n) { ctx.state.procOverrides = m || null;
                                        ctx.state.procProfileName = n || null; },
      buildEbomLineNoMap: () => ({}), setMode: () => {}, clearNearMatchCache: () => {},
    }, ['chpalign', 'session']);   // v182 — the importer restores the alignment rule
    ctx.SS.restoreSession(payload);
    return ctx.state;
  }

  console.log('\n== The exporter and the importer agree on every field ==');
  t('every key the importer reads is a key the exporter writes', () => {
    // The one exception is cpManualMap — a deliberate back-compat read for
    // sessions written before the cp → chp rename. Anything else appearing here
    // means a field that can never restore, however carefully it was saved.
    const exp = SRC.slice(at('const head = {'), at('downloadFile', at('const head = {')));
    const written = new Set(
      [...exp.matchAll(/parts\.push\('?,?"(\w+)"/g)].map(m => m[1])
      .concat([...exp.matchAll(/^\s{6}(\w+):/gm)].map(m => m[1])));
    const imp = grabFn('importSessionJson');
    const read = [...new Set([...imp.matchAll(/payload\.(\w+)/g)].map(m => m[1]))];
    const orphan = read.filter(k => !written.has(k) && k !== 'cpManualMap');
    if (orphan.length)
      throw new Error('read but never written: ' + orphan.join(', '));
  });
  t('a session with no schema is refused', () => {
    const imp = grabFn('importSessionJson');
    if (!/payload\.schema !== 'bom-comparator-session'/.test(imp))
      throw new Error('the schema gate is gone — any JSON would be accepted');
    if (imp.indexOf('showError') < 0) throw new Error('a refusal must tell the user');
  });

  console.log('\n== A complete session restores completely ==');
  t('every audit-relevant field comes back', () => {
    const st = load({ mode:'ebom_abom', boms:{ ebom:{ data:[] } }, isLocked:true,
      abomColumnMapping:2, ebomColumnMapping:2, adjudicationsApplied:true,
      adjudications:[{ id:'a1' }, { id:'a2' }],
      procOverrides:{ XR:'remove' }, procProfileName:'Program Falcon',
      auditCert:{ hash:'abc123' }, woRollup:{ total:5 } });
    eq(st.mode, 'ebom_abom', 'mode:');
    eq(st.isLocked, true, 'the frozen flag:');
    eq([st.abomColumnMapping, st.ebomColumnMapping], [2, 2], 'column mappings:');
    eq(st.adjudications.length, 2, 'claims:');
    eq(st.adjudicationsApplied, true, 'whether they were applied:');
    eq(st.procProfileName, 'Program Falcon', 'proc profile provenance:');
    eq(st.auditCert.hash, 'abc123', 'the certificate:');
  });
  t('the lock survives, so a frozen report reopens frozen', () => {
    eq(load({ isLocked:true }).isLocked, true);
    eq(load({ isLocked:false }).isLocked, false);
    eq(load({}).isLocked, false, 'absent means unlocked, not undefined:');
  });

  console.log('\n== Older and malformed sessions ==');
  t('a pre-v153 session using the old cp zone key is mapped forward', () => {
    const st = load({ boms:{ ebom:{ data:[] }, cp:{ data:[[1]] } },
                      cpManualMap:{ pn:3 } });
    eq(!!st.boms.chp, true, 'the Change Pedigree zone must survive the rename:');
    eq(st.boms.cp, undefined, 'the old key is removed, not left as a duplicate:');
    eq(st.chpManualMap, { pn:3 }, 'and its manual column map carries forward:');
  });
  t('a new-key session is not overwritten by the back-compat path', () => {
    const st = load({ boms:{ chp:{ data:[['new']] }, cp:{ data:[['old']] } } });
    eq(st.boms.chp.data, [['new']], 'the current key wins:');
  });
  t('an empty payload restores usable defaults rather than throwing', () => {
    const st = load({});
    eq(st.mode, 'ebom_mbom', 'the current mode is kept:');
    eq(st.adjudications, [], 'claims default to empty, not undefined:');
    eq(st.abomColumnMapping, 1, 'column mapping falls back to 1:');
    eq(Object.keys(st.boms).length, 9, 'all nine zones are present as null:');
  });
  t('a null boms object does not leave the app without zones', () => {
    eq(Object.keys(load({ boms:null }).boms).sort(),
       ['abom','acn','chp','ci','ebom','mbom','ncr','rfv','wo5']);
  });
  t('an out-of-range column mapping falls back to 1, not to itself', () => {
    // Only 2 is a valid alternative. A hand-edited or corrupted session must
    // not select a mapping that does not exist.
    [99, 'two', null, 0, -1].forEach(v => {
      eq(load({ abomColumnMapping:v }).abomColumnMapping, 1, JSON.stringify(v) + ':');
    });
    eq(load({ abomColumnMapping:2 }).abomColumnMapping, 2, 'but 2 is honoured:');
  });
  t('proc code behaviour and its name both restore', () => {
    const st = load({ procOverrides:{ XR:'remove' }, procProfileName:'Falcon' });
    eq([st.procOverrides, st.procProfileName], [{ XR:'remove' }, 'Falcon']);
    const base = load({});
    eq([base.procOverrides, base.procProfileName], [null, null], 'absent means baseline:');
  });
  t('a session with claims but no results does not throw', () => {
    eq(load({ adjudications:[{ id:'a1' }] }).adjudications.length, 1);
  });
});

// ── TIER 18 ────────────────────────────────────────────────────────────────
// v160 — two program-level conventions: which indenture levels are structural
// collectors, and whether the source file writes indenture as alpha or numeric.
// Both change what reconciles, so both must travel with the session and be
// named on the certificate.
suite('Tier 18 — indenture scope and normalisation', (t, eq) => {
  const E = sandbox({ PROC_CODE_EXCEPTIONS: {} }, ['engine']).E;
  const eb = (pn, nh, q, ind) => { const r = new Array(6).fill('');
    r[0] = ind == null ? 'C' : ind; r[1] = pn; r[3] = nh; r[4] = String(q); return r; };
  const ab = (pn, uo, q, wo) => [pn, uo, String(q), wo, 'CLOSED', ''];
  function run(ebom, mbom, abom, levels) {
    return E.runReconciliationCore({
      mode: 'ebom_mbom_abom', required: ['ebom', 'mbom', 'abom'], serializeMaps: false,
      collectorLevels: levels === undefined ? ['A', 'B'] : levels,
      primaryQtyMap: E.buildQtyMap(ebom, 1, 3, 4, true),
      mbomMap: E.buildQtyMap(mbom, 1, 3, 4),
      abomMap: E.buildAbomMap(abom, 0, 1, 2, 3, 4, 5), openAbomMap: {},
      mbomUsedOnMap: E.buildMbomUsedOnMap(mbom, 1, 3, 4),
      abomUsedOnMap: E.buildAbomUsedOnMap(abom, 0, 1, 2, 3, 4, 5), openAbomUsedOnMap: {},
      abomWoToUsedOns: {}, ebomFlex: {}, ebomRef: {}, removalScope: {}, ptTypeMap: {},
      ebomLineNoMap: {}, ebomQtyTextMap: {},
      indentureInfo: E.buildEbomIndentureMap(ebom, 0, 1, 3),
      chpTrace: {}, chpPnTrace: {}, ncrByDiscPn: {}, ncrByOrigWo: {}, wo5Map: {} });
  }
  const of = (res, key) => (res.find(r => r.key === key) || {}).overall;

  console.log('\n== Numeric indenture is read as alpha ==');
  t('1 through 26 map to A through Z', () => {
    eq([1,2,3,26].map(n => E.normIndenture(n)), ['A','B','C','Z']);
    eq(E.normIndenture('2'), 'B', 'strings too:');
    eq(E.normIndenture(' 2 '), 'B', 'and padded values:');
  });
  t('alpha values pass through untouched', () => {
    eq(['A','b','C'].map(v => E.normIndenture(v)), ['A','B','C']);
  });
  t('values outside 1-26 are left alone rather than remapped', () => {
    // 0 and 27 have no alpha equivalent. Silently turning 0 into '@' would be
    // worse than leaving a value the program can still recognise.
    eq(['0','27','99'].map(v => E.normIndenture(v)), ['0','27','99']);
  });
  t('blank and junk values do not become a level', () => {
    eq([null, undefined, '', '  '].map(v => E.normIndenture(v)), ['','','','']);
    eq(E.normIndenture('AA'), 'AA', 'multi-letter levels are a program\'s own:');
  });
  t('a numeric EBOM reconciles identically to the same alpha EBOM', () => {
    // The whole point: one rule, either convention.
    const alpha = run([eb('TOP','',1,'A'), eb('P1','TOP',2,'C')],
                      [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')]);
    const numeric = run([eb('TOP','',1,'1'), eb('P1','TOP',2,'3')],
                        [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')]);
    eq(of(numeric, 'TOP||'), of(alpha, 'TOP||'), 'the apex row:');
    eq(of(numeric, 'P1||TOP'), of(alpha, 'P1||TOP'), 'the line item:');
    eq(of(numeric, 'TOP||'), 'collector', 'and level 1 IS a collector:');
  });

  console.log('\n== The collector rule is a setting, not a constant ==');
  t('the default still excludes A and B', () => {
    const r = run([eb('TOP','',1,'A'), eb('MID','TOP',1,'B'), eb('P1','MID',2,'C')],
                  [eb('P1','MID',2)], [ab('P1','MID',2,'W1')]);
    eq([of(r,'TOP||'), of(r,'MID||TOP')], ['collector', 'collector']);
    eq(of(r,'P1||MID'), 'ok', 'and C still reconciles:');
  });
  t('an empty list makes every level reconcile', () => {
    const r = run([eb('TOP','',1,'A'), eb('P1','TOP',2,'C')],
                  [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')], []);
    if (of(r,'TOP||') === 'collector')
      throw new Error('level A should reconcile when no level is a collector');
    // It reads as pn_as_usedon: once in scope, the apex IS found — as the
    // used-on parent of the row beneath it. That is the engine judging it on
    // its own evidence, which is exactly what removing the exclusion means.
    eq(of(r,'TOP||'), 'pn_as_usedon', 'the apex is now judged on its own evidence:');
  });
  t('a program can exclude A only, leaving B as real parts', () => {
    // The case a boolean could not express, and the reason this is a list.
    const r = run([eb('TOP','',1,'A'), eb('MID','TOP',1,'B'), eb('P1','MID',2,'C')],
                  [eb('MID','TOP',1), eb('P1','MID',2)],
                  [ab('MID','TOP',1,'W1'), ab('P1','MID',2,'W1')], ['A']);
    eq(of(r,'TOP||'), 'collector', 'A is still structural:');
    if (of(r,'MID||TOP') === 'collector')
      throw new Error('B must reconcile when only A is excluded');
    eq(of(r,'MID||TOP'), 'pn_as_usedon', 'B is now reconciled on its own evidence:');
  });
  t('a level can be excluded that the default never touched', () => {
    const r = run([eb('P1','TOP',2,'C')], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')], ['C']);
    eq(of(r,'P1||TOP'), 'collector');
  });
  t('the setting works on a numeric EBOM too', () => {
    const r = run([eb('TOP','',1,'1'), eb('P1','TOP',2,'3')],
                  [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')], ['C']);
    if (of(r,'TOP||') === 'collector')
      throw new Error('level 1 should reconcile when only C is excluded');
    eq(of(r,'P1||TOP'), 'collector', 'level 3 = C is excluded:');
  });

  console.log('\n== It travels with the session and the certificate ==');
  t('every engine call site passes the setting', () => {
    // Worker AND synchronous fallback. If only one carried it, a worker failure
    // would silently reconcile a different set of rows.
    const calls = [...SRC.matchAll(/runReconciliationCore\(\{/g)];
    eq(calls.length, 2, 'engine call sites:');
    calls.forEach(m => {
      const seg = SRC.slice(m.index, m.index + 900);
      if (seg.indexOf('collectorLevels') < 0)
        throw new Error('an engine call site does not pass collectorLevels');
    });
  });
  t('the worker is sent the setting, and reads it', () => {
    const post = SRC.slice(at('worker.postMessage({'), at('worker.postMessage({') + 900);
    if (post.indexOf('collectorLevels') < 0)
      throw new Error('postMessage does not carry collectorLevels');
    if (!/var collectorLevels = d\.collectorLevels/.test(SRC))
      throw new Error('the worker does not read it from the message');
  });
  t('the session writes it and reads it back', () => {
    const exp = SRC.slice(at('const head = {'), at('downloadFile', at('const head = {')));
    if (exp.indexOf('collectorLevels') < 0)
      throw new Error('the session export omits collectorLevels');
    const imp = grabFn('importSessionJson');
    if (!/state\.collectorLevels\s*=\s*Array\.isArray\(payload\.collectorLevels\)/.test(imp))
      throw new Error('the session import does not restore collectorLevels');
    if (imp.indexOf("['A', 'B']") < 0)
      throw new Error('a session without the field must fall back to A/B, not to an empty list');
  });
  t('the certificate names the scope', () => {
    if (!/indentureScope:\s*_collectorScopeLabel\(\)/.test(SRC))
      throw new Error('the certificate does not record the indenture scope');
    // v178 — this counted two copies of the row, and passed partly BECAUSE the
    // CI report printed it twice. There is now one certificate definition,
    // used by every export (Tier 20 checks that every sheet comes from it).
    if (!/\['EBOM Indenture Scope', c\.indentureScope/.test(grabFn('_auditCertRows')))
      throw new Error('the certificate sheet does not carry the scope');
  });
  t('the panel refuses to change a frozen report', () => {
    ['setCollectorLevel', 'resetCollectorLevels'].forEach(fn => {
      const body = SRC.slice(at('function ' + fn), SRC.indexOf('\n}', at('function ' + fn)));
      if (body.indexOf('state.isLocked') < 0)
        throw new Error(fn + ' can change the scope while the report is frozen');
    });
  });
  t('changing the scope marks existing results stale', () => {
    const body = SRC.slice(at('function setCollectorLevel'),
                           SRC.indexOf('\n}', at('function setCollectorLevel')));
    if (body.indexOf('_procDirtySinceRun') < 0)
      throw new Error('results computed under the old rule must be marked stale');
  });
});

// ── TIER 19 ────────────────────────────────────────────────────────────────
// v162 — importing Manufacturing Engineering's adjudications. Their COTS export
// is keyed on part number only: no next higher, no quantity, no leg. All three
// are inferred at import, so every inference needs a test — an adjudication
// landing on the wrong position changes the reconciliation numbers.
suite('Tier 19 — ME adjudication import', (t, eq) => {
  const IMP = sandbox({}, ['adjimport']).IMP;
  const C = IMP.COL.adj;
  const R = (pn, nh, ms, as, eq_) => ({ key: pn + '||' + nh, pn, nh, eq: eq_ || 4,
    ms, as, msUsedOn: 'n/a', asUsedOn: 'n/a',
    overall: (ms === 'missing' || as === 'missing') ? 'missing' : (ms !== 'ok' ? ms : as) });
  // a source row in the canonical layout
  const src = o => { const r = new Array(20).fill('');
    r[C.pn] = o.pn || ''; r[C.claimNo] = o.claimNo || ''; r[C.claimStatus] = o.status || '';
    r[C.createDate] = o.date || ''; r[C.lastName] = o.last || ''; r[C.firstName] = o.first || '';
    r[C.description] = o.desc || ''; r[C.narrative] = o.narr || ''; return r; };

  console.log('\n== Resolving a bare part number to a position ==');
  t('a part at one failing position resolves automatically', () => {
    eq(IMP.resolveImportedAdjRow('P1', [R('P1','TOP','missing','ok')]).verdict, 'auto');
  });
  t('a part at several positions where only ONE fails still resolves automatically', () => {
    // The reason the picker stays small: a position that already reconciles is
    // never a candidate for adjudication.
    const v = IMP.resolveImportedAdjRow('P2',
      [R('P2','TOP','ok','ok'), R('P2','OTHER','missing','ok')]);
    eq(v.verdict, 'auto');
    eq(v.rows[0].key, 'P2||OTHER');
  });
  t('a part at several FAILING positions needs a human', () => {
    const v = IMP.resolveImportedAdjRow('P3',
      [R('P3','A','missing','ok'), R('P3','B','qty_mismatch','ok')]);
    eq([v.verdict, v.rows.length], ['picker', 2]);
  });
  t('a part that already reconciles everywhere is reported, not dropped', () => {
    const v = IMP.resolveImportedAdjRow('P4', [R('P4','A','ok','ok'), R('P4','B','ok','ok')]);
    eq(v.verdict, 'none');
    if (!v.reason) throw new Error('a no-action row must carry a reason');
  });
  t('a part not in this EBOM is rejected with a reason', () => {
    const v = IMP.resolveImportedAdjRow('P9', [R('P1','TOP','missing','ok')]);
    eq(v.verdict, 'reject');
  });
  t('rows reconciled by pass 2 or pass 3 are not adjudication candidates', () => {
    ['pn_as_usedon', 'covered', 'covered_adjudicated', 'flex_ok'].forEach(st => {
      eq(IMP.resolveImportedAdjRow('P5', [R('P5','A', st, 'ok')]).verdict, 'none', st + ':');
    });
  });

  console.log('\n== Claims are built only for legs that actually fail ==');
  t('a healthy leg produces no claim, so ME is not credited with it', () => {
    const c = IMP.buildImportedClaims({ claimNo:'AC-1', lastName:'Rodriguez', firstName:'J' },
                                      R('P1','TOP','missing','ok'));
    eq(c.length, 1);
    eq(c[0].leg, 'mbom');
  });
  t('both legs failing produces two claims', () => {
    eq(IMP.buildImportedClaims({ claimNo:'AC-1' }, R('P1','TOP','missing','missing')).length, 2);
  });
  t('a row needing nothing produces nothing', () => {
    eq(IMP.buildImportedClaims({ claimNo:'AC-1' }, R('P1','TOP','ok','ok')).length, 0);
  });
  t('the quantity always makes the line whole', () => {
    const c = IMP.buildImportedClaims({ claimNo:'AC-1' }, R('P1','TOP','missing','ok', 7));
    eq(c[0].claimedQty, 7, 'claimed qty must be the EBOM qty:');
  });
  t('the reason is derived from the row status, not from their spreadsheet', () => {
    eq(IMP.buildImportedClaims({claimNo:'A'}, R('P1','TOP','missing','ok'))[0].reason, 'mbom_missing');
    eq(IMP.buildImportedClaims({claimNo:'A'}, R('P1','TOP','qty_mismatch','ok'))[0].reason,
       'qty_mismatch_mbom');
    eq(IMP.buildImportedClaims({claimNo:'A'}, R('P1','TOP','ok','missing'))[0].reason, 'abom_missing');
  });
  t('imported claims arrive PENDING and carry their provenance', () => {
    const c = IMP.buildImportedClaims({ claimNo:'AC-1', lastName:'Rodriguez', firstName:'J',
      narrative:'Built per MPP.', date:'2026-08-01' }, R('P1','TOP','missing','ok'))[0];
    eq(c.applied, false, 'must not self-apply:');
    eq(c.createdFrom, 'external_import');
    eq(c.sme, 'Rodriguez, J');
    eq(c.extClaimNo, 'AC-1', 'the external claim number is retained:');
  });
  t('a row with no SME name is marked unattributed rather than blank', () => {
    eq(IMP.buildImportedClaims({claimNo:'A'}, R('P1','TOP','missing','ok'))[0].sme,
       'ME (unattributed)');
  });

  console.log('\n== The narrative scanner finds known values in prose ==');
  const NARR = 'Reviewed the package on 14 AUG. Confirmed it hangs under next higher ' +
               '88421-7 on this tail, not 88421-9 as originally routed. Work on DWO 4471102.';
  t('an identifier buried mid-sentence is found', () => {
    const h = IMP.scanNarrative(NARR, ['88421-7']);
    eq(h.length, 1);
    if (h[0].sentence.indexOf('hangs under') < 0)
      throw new Error('the containing sentence must be captured for the reader');
  });
  t('a longer identifier containing the candidate does NOT match', () => {
    eq(IMP.scanNarrative('see reference 588421-70 instead', ['88421-7']).length, 0);
    eq(IMP.scanNarrative('88421-70 applies', ['88421-7']).length, 0);
    eq(IMP.scanNarrative('88421-7A applies', ['88421-7']).length, 0);
  });
  t('punctuation and brackets are boundaries, but hyphens are not', () => {
    ['ends here 88421-7.', '(88421-7)', 'is 88421-7, yes'].forEach(txt =>
      eq(IMP.scanNarrative(txt, ['88421-7']).length, 1, JSON.stringify(txt) + ':'));
  });
  t('a run-together identifier does not match', () => {
    eq(IMP.scanNarrative('DWO4471102 done', ['4471102']).length, 0);
    eq(IMP.scanNarrative('DWO 4471102 done', ['4471102']).length, 1);
  });
  t('very short candidates are never searched for', () => {
    // Searching prose for 'A' or 'B' would match constantly.
    eq(IMP.scanNarrative('the A position applies', ['A']).length, 0);
  });

  console.log('\n== Suggest only when the prose is unambiguous ==');
  t('one candidate mentioned is suggested', () => {
    const plan = IMP.planAdjImport(
      [src({ pn:'P3', claimNo:'AC-3', narr:'It hangs under 88421-7 on this tail.' })],
      [R('P3','88421-7','missing','ok'), R('P3','77310-2','missing','ok')]);
    eq(plan.picker.length, 1);
    eq(plan.picker[0].suggestedKey, 'P3||88421-7');
  });
  t('several candidates mentioned suggests NOTHING', () => {
    // The narrative here explicitly rules one out in words. A matcher cannot
    // read negation, so suggesting either would be a coin flip dressed as an
    // answer. The sentences are shown instead.
    const plan = IMP.planAdjImport(
      [src({ pn:'P3', claimNo:'AC-3', narr:NARR })],
      [R('P3','88421-7','missing','ok'), R('P3','88421-9','missing','ok')]);
    eq(plan.picker[0].suggestedKey, null, 'must not guess:');
    if (plan.picker[0].mentions.length < 2)
      throw new Error('both mentions must still be shown to the reader');
  });
  t('an unresolved picker entry contributes no claims', () => {
    const plan = IMP.planAdjImport(
      [src({ pn:'P3', claimNo:'AC-3', narr:'no identifiers here' })],
      [R('P3','A1234','missing','ok'), R('P3','B5678','missing','ok')]);
    eq(IMP.finalizeAdjImport(plan).length, 0, 'nothing may be applied unchosen:');
    plan.picker[0].chosenKey = 'P3||B5678';
    eq(IMP.finalizeAdjImport(plan).length, 1, 'and one claim once chosen:');
  });

  console.log('\n== The plan sorts every row into a visible bucket ==');
  t('auto, picker, no-action and rejected are all accounted for', () => {
    const results = [R('P1','TOP','missing','ok'),
                     R('P3','A1234','missing','ok'), R('P3','B5678','missing','ok'),
                     R('P4','A','ok','ok')];
    const plan = IMP.planAdjImport([
      src({ pn:'P1', claimNo:'AC-1' }), src({ pn:'P3', claimNo:'AC-3' }),
      src({ pn:'P4', claimNo:'AC-4' }), src({ pn:'P9', claimNo:'AC-9' })], results);
    eq(plan.sourceRows, 4);
    eq([plan.claims.length, plan.picker.length, plan.noAction.length, plan.rejected.length],
       [1, 1, 1, 1]);
  });
  t('blank lines are ignored without inflating the count', () => {
    eq(IMP.planAdjImport([new Array(20).fill(''), src({ pn:'P1', claimNo:'AC-1' })],
                         [R('P1','TOP','missing','ok')]).sourceRows, 1);
  });

  console.log('\n== CM\u2019s CI-to-NCR claims are out of scope for an ME batch ==');
  t('a CI-to-NCR trace is never treated as an imported claim', () => {
    // Belt and braces: an imported batch could only carry createdFrom
    // 'external_import', but deleting another team's work would be silent and
    // serious, so the claim TYPE is checked as well as its provenance.
    eq(IMP.isImportedClaim({ id:'a', type:'ncr_ci_trace', createdFrom:'ncr_ci_helper' }), false);
    eq(IMP.isImportedClaim({ id:'x', type:'ncr_ci_trace', createdFrom:'external_import' }), false,
       'type must veto provenance:');
    eq(IMP.isImportedClaim({ id:'x', type:'ebom_ncr_trace', createdFrom:'external_import' }), false);
    eq(IMP.isImportedClaim({ id:'y', type:'row', createdFrom:'external_import' }), true);
  });
  t('a re-import cannot withdraw a CM trace', () => {
    const cm = { id:'adj_ci_9', type:'ncr_ci_trace', createdFrom:'ncr_ci_helper',
                 rowKey:'P1||TOP', leg:'abom', claimedQty:4, applied:true,
                 mode:'embodiment', ciKey:'CI-77||P1||TOP', reason:'ncr_ci_manual_trace' };
    const me = { id:'imp_1', type:'row', createdFrom:'external_import', rowKey:'P1||TOP',
                 leg:'mbom', claimedQty:4, applied:true, reason:'mbom_missing' };
    const rows = [{ key:'P1||TOP', pn:'P1', nh:'TOP', eq:4, ms:'missing', as:'missing',
                    msUsedOn:'n/a', asUsedOn:'n/a', overall:'missing' }];
    const after = IMP.replaceImportedClaims([cm, me], []);
    eq(after.map(c => c.id), ['adj_ci_9'], 'only the ME claim is withdrawn:');
    const r = IMP.computeEffectiveResults(rows, after)[0];
    eq(r.ms, 'missing', 'the ME claim is gone:');
    eq(r.as, 'direct_adjudicated', 'the CM trace still resolves the ABOM leg:');
  });
  t('the two organisations\u2019 work is reported separately', () => {
    const p = IMP.partitionClaims([
      { id:'a', type:'ncr_ci_trace', createdFrom:'ncr_ci_helper' },
      { id:'b', type:'row', createdFrom:'external_import' },
      { id:'c', type:'row', createdFrom:'qty_modal' }]);
    eq([p.imported.length, p.native.length, p.ciNcr.length], [1, 2, 1]);
  });

  console.log('\n== Staging has to drive the workbench, not just the array ==');
  t('every path that adds claims refreshes the workbench', () => {
    // v164 — the workbench is what applies claims, and it only re-reads
    // state.adjudications when told. stageAdjImport pushed claims and told
    // nobody, so Process Adjudications stayed greyed out and the staged claims
    // could not be applied at all. Every NATIVE claim path calls
    // _adjRefreshWorkbench; the import path must too.
    const paths = ['_adjSubmitClaim', '_adjSubmitNcrCiClaim', '_adjSubmitEbomNcrClaim',
                   'stageAdjImport'];
    const missing = paths.filter(fn => {
      let body;
      try { body = grabFn(fn).replace(/\/\/[^\n]*/g, ''); } catch (e) { return true; }
      return !/_adjRefreshWorkbench\s*\(/.test(body);
    });
    if (missing.length)
      throw new Error('claims can be added without refreshing the workbench: ' + missing.join(', '));
  });
  t('staging reveals the workbench even when the run produced no candidates', () => {
    // The section is hidden unless the reconciliation surfaced helper
    // candidates of its own. An import can be the only source of claims, so
    // staging must reveal it or the button is not merely disabled — it is
    // nowhere on the page.
    // Strip comments first: the body explains WHY it calls _adjShowWorkbench,
    // and matching that prose made this test pass against a build where the
    // call itself had been removed.
    const body = grabFn('stageAdjImport').replace(/\/\/[^\n]*/g, '');
    if (!/_adjShowWorkbench\s*\(/.test(body))
      throw new Error('staging does not reveal the workbench section');
  });
  t('the Process button enables on any pending claim, whatever its origin', () => {
    // The gate is origin-agnostic by design: pending count, not claim type.
    const wb = grabFn('_adjRefreshWorkbench');
    if (!/btnProc\.disabled = pending === 0/.test(wb))
      throw new Error('the Process gate is no longer a simple pending count');
    if (/createdFrom|external_import/.test(wb))
      throw new Error('the Process gate must not discriminate by claim origin');
  });

  console.log('\n== The review panel is built around the exceptions ==');
  t('every bucket is surfaced in the panel', () => {
    const ui = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    ['auto-resolved', 'need a decision', 'no action needed', 'not in this EBOM'].forEach(b => {
      if (ui.indexOf(b) < 0) throw new Error('the panel does not report: ' + b);
    });
  });
  t('the panel states that CM claims are untouched', () => {
    const ui = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    if (ui.indexOf('NCR trace claim') < 0)
      throw new Error('the panel must say CI-to-NCR traces survive the import');
  });
  t('staging refuses while the report is frozen, and uses the scoped replace', () => {
    const body = SRC.slice(at('function stageAdjImport'), at('function discardAdjImport'));
    if (body.indexOf('state.isLocked') < 0) throw new Error('staging can alter a frozen report');
    if (body.indexOf('replaceImportedClaims') < 0)
      throw new Error('staging must go through the scoped replace');
  });
  t('an ME file loaded before a run is refused with a reason', () => {
    const h = SRC.slice(at('function handleFile'), at('function handleFile') + 12000);
    const i = h.indexOf("if (type === 'adj')");
    if (i < 0) throw new Error('the adj hook is gone from handleFile');
    const seg = h.slice(i, i + 800);
    if (seg.indexOf('state.results') < 0 || seg.indexOf('showError') < 0)
      throw new Error('loading before a run must be refused, not silently planned');
  });
  t('the picker shows the matched sentence, full narrative on request', () => {
    const q = SRC.slice(at('function _adjQueueHtml'), at('function setAdjFilter'));
    if (q.indexOf('m.sentence') < 0) throw new Error('the matched sentence is not shown');
    if (q.indexOf('full narrative') < 0)
      throw new Error('the full narrative must stay available behind a disclosure');
    if (q.indexOf('adj-sug-tag') < 0) throw new Error('the suggestion is not marked');
  });

  console.log('\n== It has to survive a real file ==');
  t('a 3,000-row import against an 80k-line EBOM stays responsive', () => {
    // A real ME export runs to ~3,000 rows. Resolving each by scanning the full
    // result set is O(rows x results) — measured at 3.2s on an 80k EBOM, which
    // freezes the tab. planAdjImport indexes by part number first.
    const results = [];
    for (let i = 0; i < 80000; i++) {
      const fail = i % 12 === 0;
      results.push({ key: 'PN' + i + '||NH' + (i % 900), pn: 'PN' + i, nh: 'NH' + (i % 900),
        eq: 2, ms: fail ? 'missing' : 'ok', as: 'ok', msUsedOn: 'n/a', asUsedOn: 'n/a',
        overall: fail ? 'missing' : 'ok' });
    }
    const rows = [];
    for (let i = 0; i < 3000; i++) {
      const r = new Array(20).fill('');
      r[C.pn] = 'PN' + ((i * 12) % 80000); r[C.claimNo] = 'AC-' + i;
      r[C.narrative] = 'Reviewed the planning package. Installed on DWO ' + (4400000 + i) + '.';
      rows.push(r);
    }
    const t0 = Date.now();
    const plan = IMP.planAdjImport(rows, results);
    const ms = Date.now() - t0;
    eq(plan.claims.length, 3000, 'every row resolved:');
    if (ms > 1500) throw new Error('planAdjImport took ' + ms + 'ms — the tab would freeze');
  });
  t('the planner indexes by part number rather than rescanning', () => {
    // Structural, so the guarantee survives even on a fast machine where the
    // timing test above would pass anyway.
    if (!/function indexResultsByPn/.test(SRC))
      throw new Error('the part-number index is gone');
    const body = SRC.slice(at('function planAdjImport'), at('function finalizeAdjImport'));
    if (body.indexOf('indexResultsByPn(results)') < 0)
      throw new Error('planAdjImport no longer builds the index');
    // Building the index is not enough — it must be PASSED to the resolver.
    // The first version of this test checked only that it was built, and passed
    // while the planner rescanned per row and took 3s.
    if (!/resolveImportedAdjRow\([^)]*pnIndex\)/.test(body))
      throw new Error('the index is built but not passed to resolveImportedAdjRow');
  });

  console.log('\n== Re-import replaces the batch, never the native work ==');
  t('a second import drops the previous batch only', () => {
    const native = { id:'adj_ci_9', createdFrom:'ncr_ci_helper', rowKey:'P2||TOP', leg:'abom' };
    const first  = [{ id:'imp_1', createdFrom:'external_import' },
                    { id:'imp_2', createdFrom:'external_import' }, native];
    const out = IMP.replaceImportedClaims(first, [{ id:'imp_3', createdFrom:'external_import' }]);
    eq(out.map(c => c.id), ['adj_ci_9', 'imp_3']);
  });
  t('a withdrawn claim reverts its row', () => {
    const rows = [R('P1','TOP','missing','ok')];
    const c = IMP.buildImportedClaims({ claimNo:'AC-1' }, rows[0])
      .map(x => Object.assign({}, x, { applied: true }));
    eq(IMP.computeEffectiveResults(rows, c)[0].overall, 'direct_adjudicated');
    eq(IMP.computeEffectiveResults(rows, IMP.replaceImportedClaims(c, []))[0].overall, 'missing',
       'dropping the claim must restore the raw status:');
  });
  t('every native provenance value survives a replace', () => {
    // v178 — derived from the build. The hand-written list named seven and the
    // build has eight: missing_abom was absent, and the test still passed.
    const vals = createdFromValues();
    vals.delete('external_import');
    if (vals.size < 8) throw new Error('only ' + vals.size + ' native provenance values found');
    const natives = [...vals].map((cf, i) => ({ id: 'n' + i, createdFrom: cf }));
    const out = IMP.replaceImportedClaims(
      natives.concat([{ id:'imp_1', createdFrom:'external_import' }]), []);
    eq(out.length, natives.length);
  });
});

suite('NCR dispositions without EBOM trace — one row per disposition', (t, eq) => {
  let SHEET = null;
  const ctx = sandbox({
    XLSX:{utils:{book_new:()=>({}),aoa_to_sheet:a=>{SHEET=a;return{};},book_append_sheet:()=>{}},writeFile:()=>{}},
    COL:{ncr:{ncrNum:60,ncrStatus:61,originatingWo:62,discrepantPart:63,discNum:64,discStatus:65,
      discSummary:66,defectQty:67,causeCode:68,causeCodeDesc:69,defectCode:74,defectCodeDesc:75,
      discrepancyText:70,dispNo:71,dispStatus:72,dispType:76,dispCode:77,dispText:82}},
    state:{results:[],boms:{ncr:null}} }, ['ncr']);
  const M = ctx.N, COL = ctx.COL, state = ctx.state;
  function nrow(o){const r=new Array(90).fill('');const N=COL.ncr;
   r[N.ncrNum]=o.ncr;r[N.dispNo]=o.disp;r[N.ncrStatus]=o.ncrStatus||'OPEN';
   r[N.dispStatus]=o.dispStatus||'WORKING';r[N.discrepantPart]=o.part||'';
   r[N.originatingWo]=o.wo||'';r[N.dispText]=o.text||'';return r;}
  function run(ncrRows,results){state.boms.ncr={data:ncrRows};
   state.results=(results&&results.length)?results:[{ncrEntriesPool1:[],ncrEntriesPool2:[]}];
   SHEET=null;M.exportUntracedNcrDispositions();
   const hi=SHEET.findIndex(r=>r[0]==='NCR Number');
   return {hdr:SHEET[hi],rows:SHEET.slice(hi+1),meta:Object.fromEntries(SHEET.filter(r=>r.length===2).map(r=>[r[0],r[1]]))};}

  console.log('\n== Grain: one row per disposition number ==');
  t('4 file rows for 1 disposition collapse to 1 export row', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'}),
                 nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'})]);
    eq(r.rows.length,1,'export rows:');
    eq(r.meta['Dispositions without EBOM trace'],1);
    eq(r.meta['Source NCR file rows'],4,'source count still reported:');
    eq(r.rows[0][18],4,'Source Rows Merged:');
  });
  t('distinct dispositions under one NCR stay separate', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N1',disp:'D2'}),nrow({ncr:'N1',disp:'D3'})]);
    eq(r.rows.length,3);
    eq(r.rows.map(x=>x[1]),['D1','D2','D3']);
  });
  t('same disposition number under different NCRs stays separate', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D1'})]);
    eq(r.rows.length,2,'must not collapse across NCRs:');
  });
  t('differing values are joined, not dropped', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P2'})]);
    eq(r.rows.length,1);
    eq(r.rows[0][8],'P1 | P2','discrepant parts merged:');
    eq(r.rows[0][18],2);
  });
  t('identical values do not duplicate in the join', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'})]);
    eq(r.rows[0][8],'P1');
  });
  t('Source Rows Merged is 1 when nothing collapsed', ()=>{
    eq(run([nrow({ncr:'N1',disp:'D1'})]).rows[0][18],1);
  });

  console.log('\n== Predicate matches the on-screen helper ==');
  t('a traced disposition is excluded', ()=>{
    const res=[{ncrEntriesPool1:[{ncrNum:'N1',dispNo:'D1'}],ncrEntriesPool2:[]}];
    eq(run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D9'})],res).rows.length,1);
  });
  t('Pool 2 traces also exclude', ()=>{
    const res=[{ncrEntriesPool1:[],ncrEntriesPool2:[{ncrNum:'N1',dispNo:'D1'}]}];
    eq(run([nrow({ncr:'N1',disp:'D1'})],res).rows.length,0);
  });
  t('CANCELLED NCRs are excluded', ()=>{
    eq(run([nrow({ncr:'N1',disp:'D1',ncrStatus:'CANCELLED'}),nrow({ncr:'N2',disp:'D2'})]).rows.length,1);
  });
  t('export count equals the helper count', ()=>{
    const rows=[nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D2'})];
    state.boms.ncr={data:rows};state.results=[{ncrEntriesPool1:[],ncrEntriesPool2:[]}];
    const helper=M.computeUntracedNcrs().length;
    const r=run(rows);
    eq(helper,3,'helper is per file row:');
    eq(r.rows.length,2,'export is per disposition:');
    eq(r.meta['Source NCR file rows'],helper,'and reconciles to the helper:');
  });
  t('sorted by NCR then disposition, numerically', ()=>{
    const r=run([nrow({ncr:'N10',disp:'D2'}),nrow({ncr:'N2',disp:'D10'}),nrow({ncr:'N2',disp:'D2'})]);
    eq(r.rows.map(x=>x[0]+'/'+x[1]),['N2/D2','N2/D10','N10/D2']);
  });
  t('empty result set produces headers and a zero count', ()=>{
    const res=[{ncrEntriesPool1:[{ncrNum:'N1',dispNo:'D1'}],ncrEntriesPool2:[]}];
    const r=run([nrow({ncr:'N1',disp:'D1'})],res);
    eq(r.rows.length,0); eq(r.meta['Dispositions without EBOM trace'],0);
  });
});

suite('ECN footprint completeness', (t, eq) => {
  const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3},chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
    state:{results:[],boms:{ebom:null,chp:null}} }, ['proc','engine','chp','chpalign','ecn']);
  const B = ctx.B, state = ctx.state, normPN = ctx.E.normPN;
  function R(pn,nh,o){o=o||{};return{key:normPN(pn)+'||'+normPN(nh),pn,nh,overall:'ok',as:'ok',
   woStatus:o.wo===undefined?'closed':o.wo,woValues:['W1'],
   trace:o.ecn?{dcn:new Map(),ecn:new Map(o.ecn),ecr:new Map()}:null,
   ncrEntriesPool1:o.ncr||[],ncrEntriesPool2:[]};}
  const chpRow=(pn,nh,ecn)=>{const r=new Array(25).fill('');r[3]=pn;r[5]=nh;r[18]=ecn;return r;};

  console.log('\n== The completeness hole is now closed ==');
  t('CHP lists 12, only 9 joined: ECN NO LONGER recommended', ()=>{
    const rows=[];for(let i=1;i<=9;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;state.boms.ebom=null;
    state.boms.chp={data:Array.from({length:12},(_,i)=>chpRow('P'+(i+1),'A','E1'))};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.allAccepted,true,'joined items all fine:');
    eq(e.complete,false,'but footprint incomplete:');
    eq(e.chpItemCount,12); eq(e.items.length,9);
    eq(e.unjoined,['P10','P11','P12'],'unmatched parts named:');
  });
  t('all 12 join: ECN qualifies', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    state.boms.chp={data:Array.from({length:12},(_,i)=>chpRow('P'+(i+1),'A','E1'))};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq([e.allAccepted,e.complete],[true,true]);
  });
  t('the two failure reasons stay distinguishable', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']],wo:'open'})];
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('P9','A','E1')]};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.allAccepted,false,'unembodied item:'); eq(e.complete,false,'AND missing item:');
  });
  t('PN-only matching: different NH still counts as joined', ()=>{
    state.results=[R('P1','ASSY-X',{ecn:[['E1','']]})];
    state.boms.chp={data:[chpRow('P1','ASSY-Y','E1')]};
    eq(B.buildEcnFootprints().ecnMap.get('E1').complete,true,'NH mismatch must not false-alarm:');
  });
  t('no CHP loaded: degrades without false alarms', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]})]; state.boms.chp=null;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq([e.complete,e.chpItemCount],[true,0]);
  });
  t('inherited COTS children count toward coverage', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]}),R('C1','P1',{})];
    state.boms.ebom={data:[[0,'P1',0,'A'],[0,'C1',0,'P1']].map(r=>{const x=new Array(30).fill('');x[1]=r[1];x[3]=r[3];return x;})};
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('C1','P1','E1')]};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.complete,true,'child joined via inheritance:'); eq(e.items.length,2);
  });
  t('incompleteEcns is counted for the report footer', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]})]; state.boms.ebom=null;
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('P2','A','E1')]};
    eq(B.buildEcnFootprints().incompleteEcns,1);
  });
});

suite('Many EBOM line items to one ECN', (t, eq) => {
  const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3},chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
    state:{results:[],boms:{ebom:null,chp:null}} }, ['proc','engine','chp','chpalign','ecn']);
  const B = ctx.B, state = ctx.state, normPN = ctx.E.normPN;
  function R(pn,nh,o){o=o||{};return{key:normPN(pn)+'||'+normPN(nh),pn,nh,overall:'ok',as:'ok',
   woStatus:o.wo===undefined?'closed':o.wo,woValues:['W1'],
   trace:o.ecn?{dcn:new Map(),ecn:new Map(o.ecn),ecr:new Map()}:null,
   ncrEntriesPool1:o.ncr||[],ncrEntriesPool2:[]};}

  console.log('\n== Many EBOM line items -> one ECN ==');
  t('12 items all embodied: ECN qualifies', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','OPEN']]}));
    state.results=rows;state.boms.ebom=null;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,12,'footprint size:');eq(e.allAccepted,true);
  });
  t('12 items, ONE open WO: ECN excluded', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','OPEN']],wo:i===7?'open':'closed'}));
    state.results=rows;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,12);eq(e.allAccepted,false,'one bad item must exclude:');
    eq(e.items.filter(x=>!x.accepted).length,1);
  });
  t('12 items, ONE open disposition: ECN excluded', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']],
      ncr:i===3?[{ncrNum:'N1',dispNo:'D1',dispStatus:'WORKING'}]:[]}));
    state.results=rows;
    eq(B.buildEcnFootprints().ecnMap.get('E1').allAccepted,false);
  });
  t('order independent: bad item first still excludes', ()=>{
    const rows=[R('P1','A',{ecn:[['E1','']],wo:'open'})];
    for(let i=2;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    eq(B.buildEcnFootprints().ecnMap.get('E1').allAccepted,false);
  });
  t('an item on TWO ECNs blocks both', ()=>{
    state.results=[R('P1','A',{ecn:[['E1',''],['E2','']],wo:'open'}),R('P2','A',{ecn:[['E1','']]})];
    const m=B.buildEcnFootprints().ecnMap;
    eq(m.get('E1').allAccepted,false);eq(m.get('E2').allAccepted,false);
  });

  console.log('\n== COMPLETENESS: can a CHP-listed item be missing from the footprint? ==');
  t('CHP lists 12 items for E1 but only 9 are EBOM result rows', ()=>{
    // Simulates: CHP file rows for P1..P12 under E1, but P10-P12 have no EBOM
    // result row (no key match). Those three never enter the footprint.
    const rows=[];for(let i=1;i<=9;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,9,'footprint sees only the joined rows:');
    eq(e.allAccepted,true,'and therefore RECOMMENDS closure:');
    console.log('        >> CHP says 12 items, footprint counted 9, ECN recommended anyway');
  });
});

suite('Stylesheet and chrome integrity', (t, eq) => {
  const css = STYLE_BLOCKS.map(b => b.css).join('\n');   // ALL blocks, not just the first

  console.log('\n== The slice is CSS, not the vendored spreadsheet library ==');
  t('the naive "<style" search still lands inside vendored JavaScript', () => {
    // Documents the trap this suite fell into for its whole existence. If
    // SheetJS is ever removed and this starts failing, the guarded regex in
    // STYLE_BLOCKS can be simplified — but not before.
    const naive = SRC.indexOf('<style');
    if (naive === STYLE_BLOCKS[0].at)
      throw new Error('naive search is now safe — re-check whether the guard is still needed');
    if (!/^<style:/.test(SRC.slice(naive, naive + 8)))
      throw new Error('naive search hit something unexpected: ' + JSON.stringify(SRC.substr(naive, 40)));
  });
  t('every extracted block is a stylesheet, not markup', () => {
    STYLE_BLOCKS.forEach((b, i) => {
      if (b.css.includes('<style') || b.css.includes('<script'))
        throw new Error('block ' + (i + 1) + ' contains markup — the slice is wrong');
      if (!b.css.includes('{'))
        throw new Error('block ' + (i + 1) + ' has no rules at all');
    });
  });
  t('both style blocks are found and neither is trivial', () => {
    eq(STYLE_BLOCKS.length, 2, 'block count:');
    STYLE_BLOCKS.forEach((b, i) => { if (b.css.length < 500)
      throw new Error('block ' + (i + 1) + ' is only ' + b.css.length + ' chars'); });
  });

  console.log('\n== Brace balance: an assertion, not a baseline ==');
  t('every style block is brace-balanced', () => {
    // Replaces the old "delta must equal -2". That -2 was never a real
    // imbalance; it was minified JS being counted as CSS. Both real blocks
    // balance exactly, so the correct expectation is zero.
    STYLE_BLOCKS.forEach((b, i) => {
      const r = scanCss(b.css);
      if (r.balanced) return;
      const fileLine = l => l + b.line - 1;
      const parts = [];
      if (r.unmatchedOpen.length)  parts.push('unclosed rule opened at file line(s) ' +
        r.unmatchedOpen.map(fileLine).join(', '));
      if (r.unmatchedClose.length) parts.push('stray closing brace at file line(s) ' +
        r.unmatchedClose.map(fileLine).join(', '));
      throw new Error('block ' + (i + 1) + ': ' + parts.join('; '));
    });
  });
  t('the scanner ignores braces inside quoted strings', () => {
    eq(scanCss('a{content:"{"}').balanced, true, 'quoted open:');
    eq(scanCss("a{content:'}'}").balanced, true, 'quoted close:');
  });
  t('the scanner ignores braces inside comments', () => {
    eq(scanCss('a{color:red} /* } stray in a comment { */').balanced, true);
  });
  t('a stray closing brace is caught and located', () => {
    const r = scanCss('a{color:red}\nb{color:blue}\n}\n');
    eq([r.balanced, r.unmatchedClose], [false, [3]], 'line of the stray }:');
  });
  t('an unclosed rule is caught and located', () => {
    const r = scanCss('a{color:red}\n\nb{color:blue;\n');
    eq([r.balanced, r.unmatchedOpen], [false, [3]], 'line of the unclosed {:');
  });
  t('one stray open and one stray close do not cancel out', () => {
    // A net-delta counter reports 0 here and passes. This is why the check
    // tracks positions rather than a total.
    const r = scanCss('}\na{color:red\n');
    eq(r.balanced, false, 'a delta-based check would have said 0:');
  });

  console.log('\n== Variables and keyframes, across every block ==');
  t('no orphaned keyframes remain', () => {
    const defs = [...new Set([...css.matchAll(/@keyframes\s+([\w-]+)/g)].map(m => m[1]))];
    const orphans = defs.filter(k => !new RegExp('animation:[^;]*\\b' + k + '\\b').test(SRC));
    if (orphans.length) throw new Error('orphans: ' + orphans.join(', '));
  });
  t('--text-dim is fully retired', () => {
    if (SRC.includes('var(--text-dim)')) throw new Error('references remain');
    if (/^\s*--text-dim:/m.test(SRC)) throw new Error('definition remains');
  });
  t('no CSS var is referenced without a definition', () => {
    const defined = new Set([...css.matchAll(/^\s*(--[\w-]+):/gm)].map(m => m[1]));
    const used = new Set([...SRC.matchAll(/var\((--[\w-]+)\)/g)].map(m => m[1]));
    const missing = [...used].filter(v => !defined.has(v));
    if (missing.length) throw new Error('undefined vars used: ' + missing.join(', '));
  });

  console.log('\n== The import zone lives where the workflow needs it ==');
  t('the ME ADJ zone sits inside the Adjudication Workbench, not the upload grid', () => {
    // v166 — an ME export is not reconciliation INPUT: it is a batch of claims
    // about a run that must already exist. In the upload grid it read as a
    // tenth BOM source and the ordering had to be enforced with an error.
    // Inside the workbench the ordering enforces itself.
    const secA = at('id="adjudication-workbench-section"');
    const secB = at('<!-- /adjudication-workbench-section -->');
    const zone = at('id="zone-adj"');
    if (zone < secA || zone > secB)
      throw new Error('the ME ADJ zone is outside the Adjudication Workbench section');
    const panel = at('id="adj-import-panel"');
    if (panel < secA || panel > secB)
      throw new Error('the import review panel is outside the workbench section');
  });
  t('it sits between the Candidates Helpers and the Claim Ledger', () => {
    const helpers = at('id="kpi-adjudication-zone"');
    const imp     = at('id="adj-import-zone-wrap"');
    const ledger  = at('id="adj-workbench"');
    if (!(helpers < imp && imp < ledger))
      throw new Error('the import block is not between discovery and execution');
  });
  t('the upload grid no longer carries a tenth zone', () => {
    const grid = SRC.slice(at('id="zone-ebom"'), at('id="adjudication-workbench-section"'));
    if (grid.indexOf('id="zone-adj"') >= 0)
      throw new Error('the ME ADJ zone is still in the pre-run upload grid');
  });
  t('the workbench section appears after ANY completed run', () => {
    // A run with no helper candidates is exactly when an SME may still want to
    // import ME's decisions. Gating on "something to adjudicate" would hide the
    // upload zone precisely then.
    const fn = SRC.slice(at('const unifiedSec = document.getElementById'),
                         at('const unifiedSec = document.getElementById') + 1400);
    if (!/hasRun/.test(fn))
      throw new Error('section visibility still ignores whether a run exists');
    if (!/state\.results && state\.results\.length/.test(fn))
      throw new Error('hasRun is not derived from the results');
  });

  console.log('\n== The three workbench blocks read as three blocks ==');
  t('Imported Claims is enclosed like the Claim Ledger', () => {
    // v167 — without a border it read as a continuation of the Candidates
    // Helpers above, which is a different activity: helpers find candidates in
    // THIS run; imports bring in decisions taken elsewhere.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const m = css.match(/#adj-import-zone-wrap\s*\{([^}]*)\}/);
    if (!m) throw new Error('the import block has no enclosure rule');
    ['border', 'padding', 'border-radius'].forEach(prop => {
      if (m[1].indexOf(prop) < 0) throw new Error('the enclosure is missing ' + prop);
    });
  });
  t('each block carries exactly ONE subhead', () => {
    // v169 — the Candidates Helpers zone already had a subhead INSIDE it, and
    // v167 added a second outside. Both rendered, giving the reader
    // "Candidates Helpers Candidates Helpers". Counting, not just presence.
    const sec = SRC.slice(at('id="adjudication-workbench-section"'),
                          at('<!-- /adjudication-workbench-section -->'));
    const found = [...sec.matchAll(/adj-section-subhead">([^<]+)</g)].map(m => m[1].trim());
    ['Candidates Helpers', 'Imported Claims'].forEach(h => {
      const n = found.filter(x => x === h).length;
      if (n === 0) throw new Error('no subhead for ' + h);
      if (n > 1) throw new Error(h + ' has ' + n + ' subheads — it will render twice');
    });
  });

  console.log('\n== Staging says what it did, and is repeatable ==');
  t('re-staging preserves claims that were already applied', () => {
    // Staging rebuilds the whole imported batch and replaceImportedClaims swaps
    // the old one out. Without carrying the applied flag forward by id, a
    // second stage would silently REVERT everything already applied.
    const body = grabFn('stageAdjImport').replace(/\/\/[^\n]*/g, '');
    if (body.indexOf('wasApplied') < 0)
      throw new Error('re-staging does not preserve applied state');
    if (!/c\.applied\s*=\s*true/.test(body))
      throw new Error('the applied flag is never carried forward');
    if (!/isImportedClaim\(c\)\s*&&\s*c\.applied/.test(body))
      throw new Error('applied state must be carried for IMPORTED claims only');
  });
  t('the import panel refreshes whenever claim state changes', () => {
    // v170 — the panel reports how many of ITS claims are applied vs pending,
    // so it goes stale the moment anything applies, reverts or removes a claim.
    // It said "none applied yet" for ever, because Process never told it.
    // Hung off _adjRefreshWorkbench, which EVERY state-changing path already
    // calls, so no path can forget it — patching each caller would have left
    // the next one to be written broken again.
    const wb = grabFn('_adjRefreshWorkbench').replace(/\/\/[^\n]*/g, '');
    if (!/renderAdjImportPanel\s*\(/.test(wb))
      throw new Error('the import panel is not refreshed from the shared refresh point');
    // and every state-changing path must go through that point
    ['_adjProcessClaims', '_adjRevertClaims', '_adjConfirmRemove', 'stageAdjImport'].forEach(fn => {
      const body = grabFn(fn).replace(/\/\/[^\n]*/g, '');
      if (!/_adjRefreshWorkbench\s*\(/.test(body))
        throw new Error(fn + ' changes claim state without refreshing');
    });
  });
  t('refreshing cannot recurse', () => {
    // renderAdjImportPanel must not call back into _adjRefreshWorkbench.
    const panel = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    if (/_adjRefreshWorkbench\s*\(/.test(panel))
      throw new Error('the panel calls the refresher that calls it');
  });
  t('the panel reports what is already in the ledger', () => {
    const ui = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    if (ui.indexOf('adj-staged-state') < 0)
      throw new Error('the panel gives no confirmation that staging happened');
    ['already applied', 'pending'].forEach(bit => {
      if (ui.indexOf(bit) < 0) throw new Error('the confirmation omits: ' + bit);
    });
  });
  t('the button changes once a batch is staged', () => {
    const ui = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    if (ui.indexOf('Re-stage') < 0)
      throw new Error('the action button never becomes a re-stage');
    if (!/newSinceStage/.test(ui))
      throw new Error('the button does not distinguish new decisions from none');
  });

  console.log('\n== The funnel legend matches the bars it describes ==');
  const FUNNEL = (() => {
    const a = at('<div id="funnel-info-overlay"');
    let d = 0, i = a;
    for (;;) {
      if (SRC.startsWith('<div', i)) d++;
      else if (SRC.startsWith('</div>', i)) { d--; if (!d) break; }
      i++;
      if (i > a + 40000) throw new Error('the funnel overlay never closes');
    }
    return SRC.slice(a, i + 6);
  })();
  const RESSEGS = (() => {
    const a = at('const resSegs = [');
    const seg = SRC.slice(a, at('].filter', a));
    const out = {};
    [...seg.matchAll(/color:\s*([^,]+),\s*w:[^,]+,\s*stage:[^,]+,\s*count:[^,]+,\s*lbl:\s*'([^']+)'/g)]
      .forEach(m => { out[m[2].trim()] = m[1].trim(); });
    return out;
  })();

  t('the legend draws no emoji swatches', () => {
    // v167 — #11. The legend used 🟥 🟧 🟪 🟨 ⬛ ▒, none of which were tied to the
    // colours the bars use. THREE of them stood for the same token (--warn),
    // teaching a distinction the chart does not draw.
    const emoji = FUNNEL.match(/[\u{1F7E0}-\u{1F7EB}\u2B1B\u2592]/gu);
    if (emoji) throw new Error('emoji swatches are back: ' + [...new Set(emoji)].join(' '));
    if (!/class="fn-sw"/.test(FUNNEL))
      throw new Error('the legend has no token-driven swatches');
  });
  t('every colour the residual bar uses appears in the legend', () => {
    const tokens = new Set(Object.values(RESSEGS)
      .map(v => v.replace(/^'|'$/g, ''))
      .map(v => v === 'C.missing' ? 'var(--danger)'
              : v === 'C.qty'     ? 'var(--warn)'
              : v === 'C.other'   ? 'var(--text-muted)' : v));
    const shown = new Set([...FUNNEL.matchAll(/class="fn-sw" style="background:([^"]+)"/g)].map(m => m[1]));
    const missing = [...tokens].filter(t2 => !shown.has(t2));
    if (missing.length)
      throw new Error('residual colours with no legend swatch: ' + missing.join(', '));
  });
  t('WO Not Closed is shown as the two colours it actually draws', () => {
    // The segment is SPLIT: teal for RFV-authorised open WOs, amber for bare.
    // One swatch cannot represent it.
    const m = FUNNEL.match(/(?:<span class="fn-sw"[^>]*><\/span>\s*){1,3}<strong>WO Not Closed<\/strong>/);
    if (!m) throw new Error('the WO Not Closed legend entry moved');
    const n = (m[0].match(/fn-sw/g) || []).length;
    if (n !== 2) throw new Error('WO Not Closed shows ' + n + ' swatch(es); the bar draws two colours');
    // v173 — the bare half moved from --warn to --wo-open. The token existed
    // and was named for exactly this, but the WO NOT CLOSED badge used --warn,
    // so open WO / proc removed / qty mismatch all drew one amber.
    ['var(--rfv)', 'var(--wo-open)'].forEach(t2 => {
      if (m[0].indexOf(t2) < 0) throw new Error('the split entry is missing ' + t2);
    });
  });
  t('reference bars are described as uncoloured, because they are', () => {
    // Every reference bar renders in one neutral fill: they are context, not
    // findings. Giving them category colours in the legend was the worst of the
    // errors — colour where the tool draws none.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const fill = css.match(/\.funnel-bar-fill-ref\s*\{[^}]*background:\s*([^;]+)/);
    if (!fill) throw new Error('the reference bar fill rule is gone');
    const neutral = fill[1].trim();
    ['Part Qty Mismatch', 'Part WO Not Closed'].forEach(lbl => {
      // Locate the legend paragraph by its label, then read the swatch that
      // immediately precedes it. A regex over the whole modal matched an
      // unrelated 'EBOM-MBOM Part Qty Mismatch' bullet instead.
      const at2 = FUNNEL.indexOf('<strong>' + lbl + '</strong>');
      if (at2 < 0) throw new Error('no legend entry for ' + lbl);
      const before = FUNNEL.slice(Math.max(0, at2 - 120), at2);
      const sw = before.match(/background:([^"]+)"><\/span>$/);
      if (!sw) throw new Error(lbl + ' has no swatch immediately before it');
      if (sw[1] !== neutral)
        throw new Error(lbl + ' is shown as ' + sw[1] + ' but reference bars render ' + neutral);
    });
    if (FUNNEL.indexOf('deliberately uncoloured') < 0)
      throw new Error('the legend does not say reference bars carry no category colour');
  });

  console.log('\n== The residual is measured, not just divided ==');
  (() => {
    const RES = SRC.slice(at('const resSegs = ['), at('funnel-residual-rows'));
    t('no residual row sets flex, which would override its width', () => {
      // THE defect. Each segment carried width:${s.w}% AND flex:${s.count}.
      // `flex:N` is shorthand for flex-grow:N flex-shrink:1 flex-basis:0%, and
      // that basis beats the width declaration outright. Every computed width
      // was dead code and the track always filled 100%, so a residual of 3 and
      // a residual of 3,000 drew an identical bar. Nothing in the suite noticed
      // because Tier 11 executes the CANVAS renderers; this one is HTML.
      if (/flex:\$\{/.test(RES))
        throw new Error('a residual row sets flex from a count — widths are dead again');
    });
    t('residual widths are on the same axis as the coverage ladder', () => {
      // Both must be a share of scopeN, or a residual row and a ladder bar of
      // equal length mean different things in the same panel.
      const decl = [...SRC.slice(at('const missPct'), at('const resSegs = ['))
        .matchAll(/const\s+\w+Pct\s*=\s*([^;]+);/g)].map(m => m[1].trim());
      if (!decl.length) throw new Error('the residual percentage block moved');
      const bad = decl.filter(d => !/^pct\(/.test(d));
      if (bad.length)
        throw new Error('residual widths not measured against scope: ' + bad.join(' | '));
    });
    t('every residual category is measured, including Other', () => {
      // `other` used to be a rounding remainder (pRes minus the rest), so its
      // label and its geometry could disagree. It is a real count; measure it.
      if (/othPct\s*=\s*Math\.max/.test(SRC))
        throw new Error('Other is back-filled from a remainder instead of counted');
    });
    t('each residual category renders its own labelled row', () => {
      ['funnel-res-row', 'funnel-res-label', 'funnel-res-track', 'funnel-res-fill']
        .forEach(c => { if (RES.indexOf(c) < 0)
          throw new Error('the residual row layout lost ' + c); });
      if (RES.indexOf('${s.lbl}') < 0)
        throw new Error('rows no longer carry their own label — back to a legend hunt');
    });
    t('the label column matches the ladder, so the tracks line up', () => {
      const css = STYLE_BLOCKS.map(b => b.css).join('\n');
      // v180 — compared as the declared value, so a shared token counts.
      const w = r => (css.match(new RegExp('\\.' + r + '\\s*\\{[^}]*?[^-]width:\\s*([^;]+);')) || [])[1];
      const ladder = w('funnel-stage-label'), res = w('funnel-res-label');
      if (!ladder || !res) throw new Error('a label-column width rule is missing');
      eq(res, ladder, 'residual label width vs ladder label width:');
    });
  })();

  console.log('\n== The residual is rendered, not just described ==');
  (() => {
    // Tier 11's lesson applied to HTML. Reading the percentage block would
    // never have revealed this defect: the widths were computed correctly and
    // then discarded by a CSS shorthand three lines away. Only running it and
    // measuring the output catches that class of bug, so run it.
    const fnSrc = grabFrom(SRC, 'renderFunnelPanel', 'funnel panel');
    const ctx = sandbox({ _funnelActiveStage: null, _funnelCurveOn: false });
    vm.runInContext(fnSrc, ctx);
    const BASE = { total: 1200, scopeN: 1000, d1: 300, d2: 340, d3: 360, residual: 640,
      missing: 400, woopen: 180, qty: 60, flexmiss: 20, other: 10,
      res_woopen: 150, res_proc: 30, res_qty: 30, res_woopen_rfv: 50, res_woopen_bare: 100,
      newDirect: new Set(), newUsedOn: new Set(), newParent: new Set(),
      adjDirect: 0, adjParent: 0 };
    const SMALL = Object.assign({}, BASE, { d1: 900, d2: 960, d3: 990, residual: 10,
      missing: 6, woopen: 2, qty: 1, res_woopen: 2, res_woopen_rfv: 1, res_woopen_bare: 1,
      res_proc: 1, res_qty: 1, flexmiss: 1, other: 0 });
    const render = d => { ctx.__d = d;
      return vm.runInContext('renderFunnelPanel(__d, "abom", "ABOM", "sub")', ctx); };
    const widths = h => [...h.matchAll(/funnel-res-fill" style="width:(\d+)%/g)].map(m => +m[1]);
    const sum = a => a.reduce((x, y) => x + y, 0);

    t('the residual block draws to the size of the residual', () => {
      // The old track was display:flex with flex-grow per segment, so it filled
      // 100% of its width for ANY residual. 3 items and 3,000 items drew the
      // same bar. This is the assertion that would have failed then.
      const big = sum(widths(render(BASE)));
      const small = sum(widths(render(SMALL)));
      eq([big, small], [64, 1], 'total residual width at 640/1000 and 10/1000 scope:');
      if (big <= small) throw new Error('a larger residual does not draw larger');
    });
    t('a residual row and a ladder bar of equal length mean equal counts', () => {
      // The two live in one panel; if they are on different axes the panel
      // lies. Each residual width must be its count as a share of scope.
      const html = render(BASE);
      const rows = [...html.matchAll(
        /funnel-res-fill" style="width:(\d+)%[^>]*><\/div>\s*<div class="funnel-res-count">([\d,]+)</g)];
      if (rows.length < 5) throw new Error('only ' + rows.length + ' residual rows rendered');
      rows.forEach(m => {
        const w = +m[1], n = +m[2].replace(/,/g, '');
        const want = Math.round(n / BASE.scopeN * 100);
        if (w !== want)
          throw new Error(n + ' items drew ' + w + '% where scope share is ' + want + '%');
      });
    });
    t('no residual row is drawn to zero width', () => {
      // At a small residual every row rounds to 0%. A row the reader can click
      // must still be visible, which is what the fill min-width is for.
      const css = STYLE_BLOCKS.map(b => b.css).join('\n');
      const rule = css.match(/\.funnel-res-fill\s*\{[^}]*\}/);
      if (!rule || !/min-width:\s*[1-9]/.test(rule[0]))
        throw new Error('.funnel-res-fill has no min-width; small categories vanish');
      if (!widths(render(SMALL)).length)
        throw new Error('a 10-item residual rendered no rows at all');
    });
  })();

  console.log('\n== One finding, one colour ==');
  t('WO NOT CLOSED wears the token named for it', () => {
    // --wo-open existed and was used for open-WO numbers in three table cells,
    // but the badge for the concept used --warn — the same token as PROC
    // REMOVED and QTY MISMATCH. Three unrelated findings, one amber, on the
    // badges and therefore in the funnel that inherits them.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const rule = css.match(/\.badge-woopen\s*\{[^}]*\}/);
    if (!rule) throw new Error('.badge-woopen is gone');
    if (rule[0].indexOf('var(--wo-open)') < 0)
      throw new Error('WO NOT CLOSED is not using --wo-open: ' + rule[0]);
    if (/var\(--warn\)/.test(rule[0]))
      throw new Error('WO NOT CLOSED still carries the shared amber');
  });
  t('the funnel and the badge agree on the bare open-WO colour', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const badge = (css.match(/\.badge-woopen\s*\{[^}]*color:\s*var\((--[\w-]+)\)/) || [])[1];
    const bar = (RESSEGS['WO Not Closed (bare)'] || '').replace(/^'|'$/g, '');
    if (!badge) throw new Error('cannot read the badge colour');
    eq(bar, 'var(' + badge + ')', 'residual bar vs badge:');
  });

  console.log('\n== Long notes stay inside the column-mapping modal ==');
  t('the mapping table is fixed-layout so notes wrap rather than widen', () => {
    // v167 — #10. With an auto layout a long note widened its own column and
    // pushed the table past the panel border. Two of the three columns have
    // fixed widths, so table-fixed gives Notes the remainder and wraps it.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const tbl = css.match(/\.col-map-panel table\s*\{([^}]*)\}/);
    if (!tbl) throw new Error('the mapping table rule is gone');
    if (tbl[1].indexOf('table-layout: fixed') < 0)
      throw new Error('the table can still be widened by its content');
    const notes = css.match(/\.col-map-panel td\.col-notes\s*\{([^}]*)\}/g) || [];
    const joined = notes.join(' ');
    if (!/overflow-wrap|word-break/.test(joined))
      throw new Error('a single unbroken token in a note has nowhere to wrap');
  });
  t('the two fixed columns still leave room for the notes', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const widths = ['col-field', 'col-letter'].map(c => {
      const m = css.match(new RegExp('\\\\.col-map-panel td\\\\.' + c + '\\\\s*\\\\{([^}]*)\\\\}'));
      const w = m && m[1].match(/width:\s*(\d+)px/);
      return w ? parseInt(w[1], 10) : 0;
    });
    const panel = css.match(/\.col-map-panel\s*\{[^}]*max-width:\s*(\d+)px/);
    if (!panel) throw new Error('the panel has no max-width');
    const remaining = parseInt(panel[1], 10) - widths[0] - widths[1];
    if (remaining < 300)
      throw new Error('only ' + remaining + 'px left for notes — they will be unreadable');
  });

  console.log('\n== Job Number search, on all three tables ==');
  t('the summary bar puts Job Number between Part Number and Work Order', () => {
    const bar = SRC.slice(at('class="summary-search-bar"'), at('class="summary-search-bar"') + 1400);
    const order = ['id="search-input"', 'id="job-search-input"', 'id="wo-search-input"']
      .map(k => bar.indexOf(k));
    if (order.some(i => i < 0)) throw new Error('a summary search input is missing');
    eq(order.slice().sort((a, b) => a - b), order, 'order must be PN, Job, WO:');
  });
  t('the MBOM and ABOM bars put Job Number between Used On and Work Order', () => {
    ['mbom', 'abom'].forEach(leg => {
      const order = ['-search-uo', '-search-job', '-search-wo'].map(k => SRC.indexOf('id="' + leg + k + '"'));
      if (order.some(i => i < 0)) throw new Error(leg + ' is missing a search input');
      eq(order.slice().sort((a, b) => a - b), order, leg + ' order:');
    });
  });
  t('the summary job search matches ANY job planned against the line', () => {
    // A line can be planned on several jobs, so the match is "any", read from
    // the cached _meta map rather than rescanning the MBOM per row.
    if (!/function _rowMbomJobs/.test(SRC))
      throw new Error('the job lookup helper is gone');
    const h = grabFn('_rowMbomJobs');
    if (h.indexOf('mbomJobsByKey') < 0)
      throw new Error('the helper no longer reads the cached job map');
    eq((SRC.match(/_rowMbomJobs\(r\)\.some/g) || []).length, 2,
       'both the context and plain match paths must honour it:');
  });
  t('BOM job search uses the DATA path, not a DOM filter', () => {
    // A matching row may sit on another page. Filtering only what is rendered
    // would report "no matches" for data that exists — the same reason WO#
    // search re-renders rather than hiding rows.
    const f = grabFn('filterBomTable');
    if (!/\(woQ \|\| jobQ\)/.test(f))
      throw new Error('job search does not trigger the data-level re-render');
    const cfg = SRC.slice(at('const _bomSearchConfig'), at('const _bomSearchConfig') + 400);
    ['mbom', 'abom'].forEach(leg => {
      if (!new RegExp(leg + ':[^}]*jobCol').test(cfg))
        throw new Error(leg + ' has no jobCol in the search config');
    });
  });
  t('clearing a search clears the job box too', () => {
    const bom = grabFn('clearBomSearch');
    if (!/\['pn','uo','job','wo'\]/.test(bom))
      throw new Error('clearBomSearch leaves the job box populated');
    const sum = grabFn('clearSummarySearch');
    if (sum.indexOf('job-search-input') < 0)
      throw new Error('clearSummarySearch leaves the job box populated');
  });
  t('an empty job box does not suppress collapsed rows', () => {
    // The collapse guard lists every active search; omitting one would keep
    // rows hidden after the box is cleared.
    const T = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    if (!/!search && !woSearch && !ncrDispSearch && !rfvSearch && !jobSearch && isHiddenByCollapse/.test(T))
      throw new Error('jobSearch is missing from the collapse guard');
  });

  console.log('\n== RFV: one glyph rule, one badge colour, and documented ==');
  t('the RFV Links column drops the glyph, as an approved exception', () => {
    // v167 — #8. The build carries a glyph CONTRACT: ◈ means RFV everywhere,
    // ◆ is reserved for structural part-type badges. Dropping it in a column
    // literally headed "RFV Links" is a considered exception, not drift: there
    // the glyph restates the header on every row. It stays everywhere else,
    // where context is ambiguous.
    const cell = SRC.match(/<span style="font-family:var\(--mono\);color:var\(--text\)">[^`]{0,40}esc\(lnk\.rfvNum/);
    if (!cell) throw new Error('the RFV link cell moved');
    if (cell[0].indexOf('\u25c8') >= 0)
      throw new Error('the diamond is back in the RFV Links column');
    // and the contract still holds elsewhere
    ['\u25c8 = RFV authorized', '\u25c8 RFV'].forEach(k => {
      if (SRC.indexOf(k) < 0) throw new Error('the glyph contract was broken elsewhere: ' + k);
    });
  });
  t('all three RFV pass badges are the same colour', () => {
    // The pass is carried by the LABEL. Colouring them differently was a second
    // encoding needing a legend — the argument that retired the green glyphs.
    const cols = [...SRC.matchAll(/passLabel:\s*'P\d[^']*',\s*passColor:\s*'([^']+)'/g)].map(m => m[1]);
    if (cols.length !== 3) throw new Error('expected 3 pass badges, found ' + cols.length);
    if (new Set(cols).size !== 1)
      throw new Error('pass badges use different colours: ' + JSON.stringify(cols));
    eq(cols[0], 'var(--text-muted)');
  });
  t('the RFV Information legend and its MATCH PASS badges are both flat', () => {
    // v169 — the first version of this test checked only the legend LINE at the
    // top of the view. The MATCH PASS column badges are built somewhere else
    // entirely, from addMatch(), and stayed blue/red while the legend went dim.
    // Checking one and not the other is how a half-done change passes.
    const seg = SRC.slice(at('function renderRFVTable'), at('function renderRFVTable') + 4000);
    const legend = [...seg.matchAll(/<span style="color:(var\(--[\w-]+\))">P\d/g)].map(m => m[1]);
    if (legend.length < 3) throw new Error('the pass legend moved');
    if (new Set(legend).size !== 1)
      throw new Error('the legend colours the passes differently: ' + JSON.stringify(legend));

    // The badges themselves, from the addMatch() calls.
    const calls = [...SRC.matchAll(/addMatch\(rfvRow,\s*(\d),\s*'([^']+)',\s*([^)]+)\)/g)]
      .map(m => ({ pass: +m[1], label: m[2], color: m[3].trim() }));
    if (calls.length < 4) throw new Error('the MATCH PASS badge builders moved');
    const physical = calls.filter(c => c.pass <= 3);
    if (new Set(physical.map(c => c.color)).size !== 1)
      throw new Error('P1-P3 badges use different colours: ' +
                      JSON.stringify(physical.map(c => c.pass + '=' + c.color)));
    // The SME-linked pass is a PROVENANCE distinction, not a pass ranking, and
    // keeps the manual-provenance purple used across the whole tool.
    const sme = calls.find(c => c.pass === 4);
    if (!sme) throw new Error('the SME-linked pass is gone');
    if (sme.color === physical[0].color)
      throw new Error('the SME-linked pass lost its provenance colour');
    if (sme.color.indexOf('a371f7') < 0 && sme.color.indexOf('--adj') < 0)
      throw new Error('the SME-linked pass is no longer the adjudication purple');
  });
  t('the RFV pass badges are documented', () => {
    // They are built INLINE rather than through the badge maps, which is why
    // the guide never carried them and Tier 10 never noticed.
    const help = SRC.slice(at('const BADGE_HELP = {'), at('function _badgeHelp'));
    ['P1\u00b7PN+NH', 'P2\u00b7NCR', 'P3\u00b7WO'].forEach(k => {
      if (help.indexOf("'" + k + "'") < 0)
        throw new Error('no explanation for the ' + k + ' badge');
    });
    // at() searches from the START of the file, and _setReportHtml appears
    // earlier than showBadgeGuide — so anchoring on it produced an INVERTED
    // slice and an empty string, which failed for the wrong reason. Search
    // forward from the guide.
    const gA = at('function showBadgeGuide()');
    const guide = SRC.slice(gA, at('_setReportHtml(html)', gA));
    if (guide.indexOf('RFV Links column') < 0)
      throw new Error('the badge guide has no RFV section');
  });
  t('RFV is explained in the Detailed View modal', () => {
    const m = SRC.slice(at("'detailed-view': {"), at("'adjudication-workbench': {"));
    if (m.indexOf('RFV Links') < 0)
      throw new Error('the Detailed View explanation still never mentions RFV');
    ['P1', 'P2', 'P3', 'not</em> ranked'].forEach(bit => {
      if (m.indexOf(bit) < 0) throw new Error('the RFV explanation omits: ' + bit);
    });
  });
  t('the Has RFV filter behaves like every other conditional filter', () => {
    // There was already an RFV SEARCH ("where is RFV-1234"); there was no way
    // to ask "which lines carry variance coverage at all".
    //
    // v168 — the first cut gated visibility on state.boms.rfv, i.e. on the FILE
    // being loaded. Every other conditional filter gates on count > 0 and shows
    // its count in the label. File-gating meant the button was invisible with no
    // RFV file (reads as "not implemented" rather than "not applicable") and
    // would have offered an always-empty filter for a file matching nothing.
    const btn = SRC.match(/<button[^>]*data-fk="has_rfv"[\s\S]{0,240}?<\/button>/);
    if (!btn) throw new Error('the Has RFV filter is missing');
    if (btn[0].indexOf('var(--rfv)') < 0)
      throw new Error('the filter does not wear the RFV colour');
    const uf = grabFn('updateFilterCounts');
    if (!/has_rfv:\s*\S/.test(uf))
      throw new Error('has_rfv has no entry in the counts object, so it renders with no count');
    if (!/filter-has-rfv'\)[\s\S]{0,160}counts\.has_rfv > 0/.test(SRC))
      throw new Error('the filter is not revealed by its count, like pt_removal is');
    if (/filter-has-rfv'\)[\s\S]{0,120}state\.boms\.rfv/.test(SRC))
      throw new Error('the old file-presence gate is still there — two rules, one button');
    eq((SRC.match(/activeFilter === 'has_rfv'/g) || []).length, 2,
       'both the render and count paths must honour it:');
  });
  t('every conditional filter is revealed the same way', () => {
    // pt_removal, abom_proc_removed and has_rfv all key on count > 0. A filter
    // revealed by a different rule is the one that surprises the reader.
    ['filter-pt-removal', 'filter-abom-proc-removed', 'filter-has-rfv'].forEach(id => {
      const re = new RegExp("getElementById\\('" + id + "'\\)[\\s\\S]{0,200}counts\\.\\w+ > 0");
      if (!re.test(SRC)) throw new Error(id + ' is not revealed by a count');
    });
  });

  console.log('\n== updateFilterCounts may only call what it can see ==');
  t('updateFilterCounts calls nothing that is local to another function', () => {
    // v172 — the counts object is built as ONE literal. A single unresolvable
    // call throws before any button is labelled, so every filter count vanishes
    // and every count-based reveal stops firing. v169 called getRowRfvLinks(),
    // which is local to renderSummaryTable and runs AFTER this — the reported
    // symptom was "no Has RFV button", the actual damage was every count.
    const uf = grabFn('updateFilterCounts').replace(/\/\/[^\n]*/g, '');
    const called = new Set([...uf.matchAll(/(^|[^.\w$])([a-zA-Z_$][\w$]*)\s*\(/g)].map(m => m[2]));
    const BUILTIN = new Set(['if','for','while','switch','return','function','catch','typeof',
      'Set','Map','Array','Object','String','Number','Boolean','parseInt','parseFloat','filter',
      'forEach','some','every','map','has','add','get','set','includes','indexOf','join','split',
      'slice','sort','push','trim','toUpperCase','toLowerCase','querySelectorAll','getElementById',
      'getAttribute','setAttribute','hasAttribute','normPN','esc','fmt']);
    const bad = [];
    called.forEach(fn => {
      if (BUILTIN.has(fn)) return;
      const at2 = SRC.indexOf('function ' + fn + '(');
      if (at2 < 0) return;                       // not a build function
      // is it declared at column 0 (top level) or indented (nested)?
      const lineStart = SRC.lastIndexOf('\n', at2) + 1;
      if (at2 !== lineStart) bad.push(fn);
    });
    if (bad.length)
      throw new Error('updateFilterCounts calls function(s) local to another scope: ' +
                      bad.join(', ') + ' — this throws and kills every filter count');
  });
  t('the RFV row count is computed at top level', () => {
    if (!/^function _rfvLinkedRowCount\(/m.test(SRC))
      throw new Error('_rfvLinkedRowCount is not a top-level function');
    const body = grabFn('_rfvLinkedRowCount');
    if (/getRowRfvLinks/.test(body))
      throw new Error('it delegates to the function that is out of scope');
  });

  console.log('\n== A filter wears the colour of what it finds ==');
  t('the Adjudicated filter matches its badges, not the interaction blue', () => {
    const btn = SRC.match(/<button[^>]*data-fk="adjudicated"[\s\S]{0,260}?<\/button>/);
    if (!btn) throw new Error('the Adjudicated filter is gone');
    if (/var\(--accent\)/.test(btn[0]))
      throw new Error('the filter is still interaction-blue while its badges are purple');
    if (!/var\(--adj\)/.test(btn[0]))
      throw new Error('the filter does not use the adjudication colour');
  });

  console.log('\n== The bar no longer shares its name with the section ==');
  t('the action bar is the Claim Ledger, distinct from the section', () => {
    const bar = SRC.match(/<span class="adj-title">([^<]*)<\/span>/);
    if (!bar) throw new Error('the action bar title is gone');
    if (/Adjudication Workbench/.test(bar[1]))
      throw new Error('the bar still carries the same name as the section it sits inside');
    eq(bar[1].replace(/[^A-Za-z ]/g, '').trim(), 'Claim Ledger');
  });
  t('the explanation modal covers all three blocks in order', () => {
    const m = SRC.slice(at("'adjudication-workbench': {"), at("'adjudication-workbench': {") + 20000);
    const order = ['The Candidates Helpers', 'Imported Claims', 'The Claim Ledger']
      .map(h => m.indexOf('<h3>' + h));
    order.forEach((i, k) => { if (i < 0)
      throw new Error('the explanation modal is missing a block: ' + k); });
    eq(order.slice().sort((a, b) => a - b), order, 'blocks must read in workflow order:');
  });
  t('the modal explains the CM boundary and the pending arrival', () => {
    const m = SRC.slice(at("'adjudication-workbench': {"), at("'adjudication-workbench': {") + 20000);
    ['never touches CI-to-NCR', 'arrive <em>pending</em>'].forEach(bit => {
      if (m.indexOf(bit) < 0) throw new Error('the modal no longer states: ' + bit);
    });
  });

  console.log('\n== The ten upload zones look like one another ==');
  t('every zone tag uses the shared uniform treatment', () => {
    // v163 — adding the tenth zone put a coloured .tag-adj rule INSIDE the
    // shared no-op selector, which turned nine tags purple and left ACN alone.
    // The zones are meant to be visually identical; .bom-tag owns the styling.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const coloured = [...css.matchAll(/\.tag-[\w-]+[^{}]*\{([^}]*)\}/g)]
      .filter(m => /background|color|border/.test(m[1]));
    if (coloured.length)
      throw new Error('a per-zone tag rule sets its own colour: ' +
                      coloured[0][0].replace(/\s+/g, ' ').slice(0, 90));
  });
  t('every zone offers the same column-mapping help control', () => {
    const icons = [...SRC.matchAll(/class="abom-cm-help"[^>]*>([^<]*)<\/a>/g)].map(m => m[1].trim());
    if (icons.length < 5) throw new Error('only found ' + icons.length + ' help controls');
    const distinct = [...new Set(icons)];
    if (distinct.length !== 1)
      throw new Error('zones use different help icons: ' + JSON.stringify(distinct));
  });
  t('the ME ADJ zone is wired like the other supplemental zones', () => {
    const zone = SRC.slice(at('id="zone-adj"'), at('id="zone-adj"') + 1400);
    ['handleFile(\'adj\'', 'setSuppMappingMode(\'adj\'', 'openSuppManualMap(\'adj\'',
     'id="fn-adj"', 'id="rows-adj"'].forEach(bit => {
      if (zone.indexOf(bit) < 0) throw new Error('the ME ADJ zone is missing ' + bit);
    });
  });

  console.log('\n== Export menu wiring ==');
  t('every menu item is wired, and every wire has a button', () => {
    // The count is derived from the build, not pinned to 13, so ADDING an
    // export is not a failure — leaving one unwired is.
    const items = [...SRC.matchAll(/class="export-menu-item"[^>]*>\s*([^<]{1,60})/g)].map(m => m[1].trim());
    const wired = [...SRC.matchAll(/id="(export-menu-[\w-]+)"[^>]*onclick="invokeExport\('([^']+)'\)/g)];
    if (!items.length) throw new Error('no export menu items found at all');
    eq(wired.length, items.length, 'menu items vs invokeExport wires:');
    const dead = wired.filter(w => !SRC.includes('id="' + w[2] + '"')).map(w => w[2]);
    if (dead.length) throw new Error('wired to missing button(s): ' + dead.join(', '));
  });
  t('menu ids are unique', () => {
    const ids = [...SRC.matchAll(/id="(export-menu-[\w-]+)"/g)].map(m => m[1]);
    const dupes = ids.filter((v, i) => ids.indexOf(v) !== i);
    if (dupes.length) throw new Error('duplicate menu ids: ' + [...new Set(dupes)].join(', '));
  });
  t('export menu uses one arrow convention', () => {
    const items = [...SRC.matchAll(/class="export-menu-item"[^>]*>\s*([^<]{1,60})/g)].map(m => m[1].trim());
    const arr = items.filter(i => i.startsWith('\u2b07'));
    if (arr.length !== 0 && arr.length !== items.length)
      throw new Error('mixed: ' + arr.length + '/' + items.length);
  });

  console.log('\n== v185 — summary search boxes look alike; reference bars scale to Active Scope ==');
  t('no Comparison Summary search box carries its own border colour', () => {
    // The NCR Disp # box had a red outline and the RFV # box a teal one. The
    // owner asked for one look across the bar.
    const a = at('class="summary-search-bar"');
    const bar = SRC.slice(a, SRC.indexOf('</div>', a));
    const inputs = [...bar.matchAll(/<input[^>]*>/g)].map(m => m[0]);
    if (inputs.length < 5) throw new Error('found ' + inputs.length + ' search inputs, expected 5');
    const odd = inputs.filter(s => /border(-color)?\s*:/.test(s)).map(s => (s.match(/id="([^"]+)"/) || [])[1]);
    if (odd.length) throw new Error('inline border on: ' + odd.join(', '));
  });
  t('per-leg reference bars are drawn as a share of Active Scope', () => {
    const f = grabFn('refBarScaled');
    const run = new Function('bom', 'fmt', f + '; return refBarScaled;')('ebom', n => String(n));
    const pct = h => parseFloat((h.match(/--pct:([\d.]+)%/) || [])[1]);
    eq(pct(run('Part Qty Mismatch', 25, 'ref_qty', 100)), 25, 'a quarter of scope:');
    eq(pct(run('Part Qty Mismatch', 250, 'ref_qty', 100)), 100, 'capped at the full track:');
    eq(pct(run('Part Qty Mismatch', 5, 'ref_qty', 0)), 0, 'no scope, no bar:');
    if (!/1 · &lt;1% of scope|1 · <1% of scope/.test(run('x', 1, 'ref_qty', 1000)))
      throw new Error('a tiny share must read "<1% of scope"');
    const body = grabFn('renderFunnelPanel');
    ['ref_qty', 'ref_woopen'].forEach(st => {
      if (!new RegExp("refBarScaled\\([^)]*'" + st + "', scopeN\\)").test(body))
        throw new Error(st + ' is not scaled against Active Scope');
    });
  });
});

// ── TIER 20 ────────────────────────────────────────────────────────────────
// v178 — provenance. Three copies of "which build, which rules, which claims"
// had drifted apart: the session file said v142 for 36 builds, the certificate
// hash stopped growing when claims gained fields at v85/v87/v162, and the two
// Audit Certificate sheets disagreed with each other. Every rule here is
// DERIVED from the build where it can be, because each of those drifts
// happened to a hand-maintained list.
function stripComments(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`\\])\/\/[^\n]*/g, '$1');
}
// Every createdFrom value the build can write: quoted directly, mapped through
// _ADJ_CREATED_FROM, or held in a variable named *CreatedFrom first. The first
// version of this looked only at the first two and missed the two
// "_paired" values, which are chosen by a ternary into a variable.
function createdFromValues() {
  const vals = new Set([...SRC.matchAll(/createdFrom:\s*'([a-z_]+)'/g)].map(m => m[1]));
  const cf = SRC.match(/const _ADJ_CREATED_FROM = \{([\s\S]*?)\};/);
  if (!cf) throw new Error('BUILD MARKER MOVED: _ADJ_CREATED_FROM');
  [...cf[1].matchAll(/:\s*'([a-z_]+)'/g)].forEach(m => vals.add(m[1]));
  for (const m of SRC.matchAll(/\b\w*CreatedFrom\s*=\s*([^;]+);/g))
    // the quoted RESULTS only — a string compared in the condition is not a value
    for (const q of m[1].replace(/[!=]==\s*'[a-z_]+'/g, '').matchAll(/'([a-z_]+)'/g)) vals.add(q[1]);
  return vals;
}
// Every key written by an object literal pushed onto state.adjudications, or
// built by the ME importer. This is the claim schema as the build actually
// writes it — no hand list.
function claimFieldsWritten() {
  const keys = new Set();
  const re = /state\.adjudications\.push\(\{|out\.push\(\{\s*\n\s*id:\s*'imp_/g;
  let m;
  while ((m = re.exec(SRC))) {
    let k = SRC.lastIndexOf('{', m.index + m[0].length), d = 0;
    const i = k;
    for (;; k++) { if (SRC[k] === '{') d++; else if (SRC[k] === '}' && !--d) break; }
    for (const x of SRC.slice(i + 1, k).matchAll(/^\s*([A-Za-z_]+)\s*:/gm)) keys.add(x[1]);
  }
  if (keys.size < 10) throw new Error('claim literals not found — marker moved?');
  return keys;
}
// The per-claim projection the certificate hash covers.
function hashedClaimFields() {
  const f = grabFn('freezeReport');
  const s = f.indexOf('const adjSerializable');
  if (s < 0) throw new Error('BUILD MARKER MOVED: adjSerializable in freezeReport');
  const blk = stripComments(f.slice(s, f.indexOf('}));', s)));
  // Keys only: a key follows '{', ',' or a line start. A bare word before ':'
  // elsewhere is a ternary branch (`? null : x`), not a field.
  return new Set([...blk.matchAll(/(?:^|[{,])\s*([A-Za-z]+)\s*:/gm)].map(m => m[1]));
}
// Fields a claim carries that the hash deliberately does NOT cover, and why.
const HASH_EXEMPT = {
  applied:      'hashed once for the whole batch as adjudicationsApplied',
  ncrSnapshot:  'a copy of NCR file content taken at claim time; the disposition numbers that identify it are hashed',
  ncrSnapshots: 'as ncrSnapshot, for multi-disposition claims',
};

suite('Tier 20 — provenance: version, certificate and claims', (t, eq) => {
  console.log('\n== The build says which build it is, everywhere ==');
  t('the session file is stamped from APP_VERSION, not a literal', () => {
    const b = stripComments(grabFn('exportSessionJson'));
    if (/toolVersion:\s*['"`]/.test(b))
      throw new Error('toolVersion is a literal: ' + b.match(/toolVersion:\s*['"`][^'"`]*['"`]/)[0]);
    if (!/toolVersion:\s*APP_VERSION\b/.test(b)) throw new Error('toolVersion is not read from APP_VERSION');
  });
  t('APP_VERSION is the only quoted version string in any code', () => {
    // The header-only check below missed toolVersion: 'v142' for 36 builds.
    const hits = [...stripComments(SRC).matchAll(/['"`]v\d{2,3}(?:\.\d+)?['"`]/g)].map(m => m[0]);
    if (hits.length !== 1) throw new Error(hits.length + ' quoted version strings: ' + hits.join(', '));
  });
  t('the certificate records which build computed it, outside the hash', () => {
    const f = stripComments(grabFn('freezeReport'));
    const c = f.slice(f.indexOf('state.auditCert = {'), f.indexOf('};', f.indexOf('state.auditCert = {')));
    if (!/toolVersion:\s*APP_VERSION/.test(c)) throw new Error('auditCert has no toolVersion');
    const h = f.slice(f.indexOf('const hashPayload'), f.indexOf('};', f.indexOf('const hashPayload')));
    if (/toolVersion|APP_VERSION/.test(h))
      throw new Error('the build version must stay OUT of the hash: it labels the certificate, it is not attested');
  });
  t('the certificate banner shows the build, including after a session import', () => {
    if (!/id="cert-build"/.test(SRC)) throw new Error('no cert-build element in the banner');
    if (!/cert-build'\)\.textContent\s*=\s*APP_VERSION/.test(stripComments(grabFn('freezeReport'))))
      throw new Error('freezeReport does not fill cert-build');
    if (!/setIf\('cert-build'/.test(grabFn('importSessionJson')))
      throw new Error('a re-imported frozen session would show a blank build');
  });

  console.log('\n== One Audit Certificate sheet, not two copies ==');
  t('one function defines the Audit Certificate sheet', () => {
    const rows = grabFn('_auditCertRows');
    ['exportXLSX', 'exportCIReport'].forEach(fn => {
      const b = grabFn(fn);
      if (b.includes('CERTIFICATE OF CONFIGURATION AUDIT'))
        throw new Error(fn + ' still builds its own certificate rows');
      if (!/_auditCertRows\(/.test(b)) throw new Error(fn + ' does not call _auditCertRows');
    });
    if (!rows.includes('CERTIFICATE OF CONFIGURATION AUDIT')) throw new Error('title row missing');
  });
  t('the certificate sheet carries every provenance row exactly once', () => {
    const labels = [...grabFn('_auditCertRows').matchAll(/\[\s*'([^']+)'\s*,/g)].map(m => m[1]);
    const dup = labels.filter((v, i) => labels.indexOf(v) !== i);
    if (dup.length) throw new Error('repeated rows: ' + dup.join(', '));
    ['Auditor', 'Frozen', 'Mode', 'Build', 'Proc Code Profile', 'EBOM Indenture Scope',
     'Removal Proc Codes', 'Swap Proc Codes', 'SHA-256 Integrity Hash'].forEach(l => {
      if (labels.indexOf(l) < 0) throw new Error('missing row: ' + l);
    });
  });
  t('every Audit Certificate sheet in the build comes from that function', () => {
    // Discovery, so a third copy written later fails here by line.
    const bad = [];
    for (const m of SRC.matchAll(/'Audit Certificate'\s*\)/g)) {
      const before = SRC.slice(Math.max(0, m.index - 400), m.index);
      if (!/_auditCertRows\(/.test(before)) bad.push('line ' + (SRC.slice(0, m.index).split('\n').length));
    }
    if (bad.length) throw new Error('certificate sheet not built from _auditCertRows at ' + bad.join(', '));
  });
  t('every certificate the build writes (Excel, CSV, HTML) comes from that function', () => {
    // v179 — v178 unified the two Excel copies and missed two more: the CSV and
    // HTML exports each wrote their own certificate, still without the build,
    // the proc code profile, the codes or the scope. Found by searching for the
    // title text, which every copy has to print.
    const code = stripComments(SRC);
    const at0 = code.indexOf('function _auditCertRows(');
    const own = grabFrom(code, '_auditCertRows', 'build');
    const hits = [];
    let i = -1;
    while ((i = code.indexOf('CERTIFICATE OF CONFIGURATION AUDIT', i + 1)) >= 0) hits.push(i);
    const outside = hits.filter(h => h < at0 || h > at0 + own.length);
    if (outside.length) throw new Error(outside.length + ' certificate title(s) written outside _auditCertRows');
    ['exportCSV', 'exportHTML'].forEach(fn => {
      if (!/_auditCertRows\(/.test(grabFn(fn))) throw new Error(fn + ' does not use _auditCertRows');
    });
  });
  t('a certificate frozen before v178 says so rather than borrowing today’s build', () => {
    if (!/c\.toolVersion\s*\|\|\s*'not recorded/.test(grabFn('_auditCertRows')))
      throw new Error('an old certificate would print no build, or the wrong one');
  });

  console.log('\n== The hash covers everything that changes what a claim does ==');
  t('every field a claim is written with is hashed, or exempt for a stated reason', () => {
    const hashed = hashedClaimFields();
    const miss = [...claimFieldsWritten()].filter(k => !hashed.has(k) && !(k in HASH_EXEMPT));
    if (miss.length) throw new Error('claims carry fields the certificate does not attest: ' + miss.join(', '));
  });
  t('the exemptions are still real fields, so the list cannot rot', () => {
    const written = claimFieldsWritten();
    const stale = Object.keys(HASH_EXEMPT).filter(k => !written.has(k));
    if (stale.length) throw new Error('exempt but no longer written: ' + stale.join(', '));
  });
  t('the hash covers the indenture scope', () => {
    const f = stripComments(grabFn('freezeReport'));
    const h = f.slice(f.indexOf('const hashPayload'), f.indexOf('};', f.indexOf('const hashPayload')));
    if (!/collectorLevels\s*:/.test(h)) throw new Error('the scope decides what reconciles but is not hashed');
  });

  console.log('\n== Claim origins are readable ==');
  t('every createdFrom value the build emits has a readable source label', () => {
    const vals = createdFromValues();
    if (!vals.has('nh_mismatch_helper_paired')) throw new Error('the variable-assigned values were not found');
    const lm = SRC.match(/^const CLAIM_SOURCE_LABEL = \{([\s\S]*?)\};/m);
    if (!lm) throw new Error('CLAIM_SOURCE_LABEL is not declared at top level');
    const keys = new Set([...lm[1].matchAll(/'([a-z_]+)'\s*:/g)].map(m => m[1]));
    const miss = [...vals].filter(v => !keys.has(v));
    if (miss.length) throw new Error('no label for: ' + miss.join(', '));
  });
  t('no local copy of the label map survives', () => {
    if (/_claimSourceLabel\b/.test(stripComments(SRC))) throw new Error('_claimSourceLabel still referenced');
  });

  console.log('\n== Session parity for every column map ==');
  t('every *ManualMap in state is exported, restored and reset', () => {
    const s0 = at('const state = {');
    const init = SRC.slice(s0, SRC.indexOf('\n};', s0));
    const maps = [...init.matchAll(/\b([a-z]+ManualMap):/g)].map(m => m[1]);
    if (maps.length < 7) throw new Error('found only ' + maps.length + ' manual maps in state');
    const ex = grabFn('exportSessionJson'), im = grabFn('importSessionJson'), rs = grabFn('resetAll');
    const bad = [];
    maps.forEach(k => {
      if (!ex.includes(k + ':'))                                  bad.push(k + ' not exported');
      if (!im.includes('payload.' + k))                           bad.push(k + ' not restored');
      if (!new RegExp('state\\.' + k + '\\s*=\\s*null').test(rs)) bad.push(k + ' not reset');
    });
    if (bad.length) throw new Error(bad.join('; '));
  });
  t('Reset leaves the indenture scope alone, by decision', () => {
    // D4 (v178 audit): the scope is a program convention, so Reset keeps it,
    // while proc codes return to baseline. Pinned so a change is a decision.
    if (/collectorLevels\s*=/.test(stripComments(grabFn('resetAll'))))
      throw new Error('resetAll now changes the indenture scope — update the guide (3.4) if intended');
  });

  console.log('\n== One glyph for Proc Removed ==');
  t('the Proc Removed window uses the badge’s glyph, not the Removal Item one', () => {
    const b = grabFn('showProcRemovedModal');
    if (b.includes('⊘')) throw new Error('⊘ is the Removal Item glyph');
    if (!b.includes('⬇')) throw new Error('the window title has lost its glyph');
  });
});

// ── TIER 4b ────────────────────────────────────────────────────────────────
// Delta v3.4 — the delta tool against the main build it reads. Each test
// derives its expectation from the main build where it can: every copy the
// delta tool keeps (the streaming reader, the claim-source labels, the KPI
// predicates, the palette) is compared, not trusted.
function deltaSlice(src, startMarker, endMarker) {
  const a = src.indexOf(startMarker);
  if (a < 0) throw new Error('marker not found: ' + startMarker);
  const b = src.indexOf(endMarker, a);
  if (b < 0) throw new Error('marker not found: ' + endMarker);
  return src.slice(a, src.lastIndexOf('\n}\n', b) + 3);
}
function streamReaderText(src) {
  return deltaSlice(src, 'async function _parseJsonStream(', 'async function _readSessionPayload(') +
         grabFrom(src, '_readSessionPayload', 'reader');
}
const norm = s => s.replace(/\s+/g, ' ').trim();
function deltaSandbox(names, consts) {
  const ctx = { console, JSON, Math, Array, Object, String, Number, Boolean, Set, Map };
  ctx.globalThis = ctx; vm.createContext(ctx);
  // A name prefixed '?' is optional: absent, it is declared empty, so a test
  // about something else does not fail for this reason.
  const code = (consts || []).map(c0 => {
    const opt = c0[0] === '?', c = opt ? c0.slice(1) : c0;
    const m = DSRC.match(new RegExp('(?:var|const|let)\\s+' + c + '\\s*=\\s*\\{'));
    if (!m && opt) return 'var ' + c + ' = {};';
    if (!m) throw new Error('delta tool has no ' + c);
    return DSRC.slice(m.index, DSRC.indexOf('};', m.index) + 2);
  }).join('\n') + '\n' + names.map(grabDelta).join('\n') +
    '\nglobalThis.X = {' + names.concat((consts || []).map(c => c.replace('?', ''))).map(n => n + ':' + n).join(',') + '};';
  vm.runInContext(code, ctx);
  return ctx.X;
}

suite('Tier 4b — delta tool follows the main build', (t, eq) => {
  console.log('\n== It can open every session the main build can write ==');
  t('the delta tool’s streaming reader is identical to the main build’s', () => {
    let d;
    try { d = streamReaderText(DSRC); }
    catch (e) { throw new Error('delta tool has no streaming reader (' + e.message + ')'); }
    if (norm(d) !== norm(streamReaderText(SRC))) throw new Error('the two copies differ');
  });
  t('readSession goes through the streaming reader, never a bare JSON.parse', () => {
    const b = stripComments(grabDelta('readSession'));
    if (!/_readSessionPayload\(/.test(b)) throw new Error('readSession does not use _readSessionPayload');
    if (/JSON\.parse\(/.test(b)) throw new Error('readSession still parses the whole file as one string');
  });

  console.log('\n== The Claims sheet compares what the certificate attests ==');
  const hashedForDelta = () => [...hashedClaimFields()].filter(f => f !== 'id' && f !== 'timestamp');
  t('every claim field the main build hashes is a field the delta compares', () => {
    // timestamp is excluded deliberately (HARNESS.md): it moves on every re-save.
    const sig = grabDelta('claimSig');
    const miss = hashedForDelta().filter(x => !new RegExp('c\\.' + x + '\\b').test(sig));
    if (miss.length) throw new Error('hashed but not compared: ' + miss.join(', '));
  });
  t('changing any one of those fields reports the claim as Modified', () => {
    const X = deltaSandbox(['claimSig', 'claimRow', 'claimsDelta'], ['?CLAIM_SOURCE_LABEL']);
    const base = { id: 'c1', type: 'row', reason: 'abom_missing', mode: 'embodiment', leg: 'abom',
      rowKey: 'P||N', rowKeys: ['P||N'], ciKey: 'CI1', dispNo: 'D1', ncrDispNo: 'D1',
      ncrDispNos: ['D1'], woNo: 'W1', woPn: 'P', woUsedOn: 'N', claimedQty: 1,
      nhPayload: { nh: 'N2' }, pairedClaimId: 'c2', createdFrom: 'missing_abom',
      extClaimNo: 'E1', extStatus: 'OPEN', sme: 'A', smeRole: 'R', rationale: 'x', applied: false };
    const alt = v => Array.isArray(v) ? v.concat('Z') : typeof v === 'number' ? v + 1 :
                     typeof v === 'boolean' ? !v : (v && typeof v === 'object') ? { nh: 'OTHER' } : v + 'Z';
    const missed = hashedForDelta().filter(f => {
      const b = Object.assign({}, base, { [f]: alt(base[f]) });
      const r = X.claimsDelta({ adjudications: [base] }, { adjudications: [b] });
      return !(r.length === 1 && r[0].Change === 'Modified');
    });
    if (missed.length) throw new Error('a change to these went unreported: ' + missed.join(', '));
  });
  t('the delta tool’s claim-source labels match the main build’s', () => {
    const main = SRC.match(/^const CLAIM_SOURCE_LABEL = (\{[\s\S]*?\});/m);
    const dm = DSRC.match(/var CLAIM_SOURCE_LABEL = (\{[\s\S]*?\});/);
    if (!main || !dm) throw new Error('label map missing in ' + (main ? 'delta tool' : 'main build'));
    const ev = s => vm.runInNewContext('(' + s + ')');
    eq(ev(dm[1]), ev(main[1]));
  });
  t('the Claims sheet says where each claim came from', () => {
    const X = deltaSandbox(['claimRow'], ['CLAIM_SOURCE_LABEL']);
    const imp = X.claimRow('Added in B', { id: 'imp_9_abom', type: 'row', createdFrom: 'external_import', extClaimNo: '9' });
    eq(imp.Origin, 'ME adjudication import');
    eq(imp['External Claim No'], '9');
    const nat = X.claimRow('Added in B', { id: 'adj_1', reason: 'abom_missing', createdFrom: 'missing_abom' });
    eq(nat.Reason, 'abom_missing', 'an issue-card claim has no type, so its reason must show:');
    const multi = X.claimRow('Modified', { id: 'x', ncrDispNos: ['D1', 'D2'], ncrDispNo: 'D1' });
    eq(multi['NCR Disp No'], 'D1; D2');
  });

  console.log('\n== Provenance of the sessions being compared ==');
  t('old version stamps are labelled as the range they cover, not as a build', () => {
    const X = deltaSandbox(['toolVersionLabel']);
    eq(X.toolVersionLabel({ toolVersion: 'v142' }), 'v142–v177 (exact build not recorded)');
    eq(X.toolVersionLabel({ toolVersion: 'v83' }), 'v83–v141 (exact build not recorded)');
    eq(X.toolVersionLabel({ toolVersion: 'v178' }), 'v178');
    eq(X.toolVersionLabel({}), 'not recorded');
  });
  t('the Summary names each session’s build through that label', () => {
    if (!/toolVersionLabel\(A\)/.test(grabDelta('buildSummaryRows')))
      throw new Error('Summary prints the raw stamp');
  });

  console.log('\n== One delta version, stated once ==');
  t('DELTA_VERSION is the only version literal in the delta tool’s code', () => {
    const script = DSRC.slice(DSRC.lastIndexOf('<script>'));
    const hits = [...stripComments(script).matchAll(/['"`]v\d+(?:\.\d+)+['"`]/g)].map(m => m[0]);
    if (hits.length !== 1 || !/var DELTA_VERSION = /.test(script))
      throw new Error('version literals: ' + hits.join(', '));
    if (/Delta <span class="fam">v\d/.test(DSRC)) throw new Error('the header still carries a literal version');
    if (!/id="delta-version"/.test(DSRC)) throw new Error('no element renders DELTA_VERSION');
  });
  t('the file name, the page title and DELTA_VERSION agree', () => {
    const v = DSRC.match(/var DELTA_VERSION = '(v[\d.]+)'/)[1];
    const fileV = 'v' + DELTA.match(/v([\d_]+)\.html$/)[1].replace(/_/g, '.');
    eq(v, fileV, 'DELTA_VERSION vs file name:');
    if (DSRC.match(/<title>([^<]*)<\/title>/)[1].indexOf(v) < 0) throw new Error('title disagrees');
  });
  t('the exported workbook names the delta version', () => {
    if (!/DELTA_VERSION/.test(grabDelta('exportXlsx'))) throw new Error('the workbook does not say which delta tool produced it');
    if (!/DELTA_VERSION/.test(grabDelta('buildSummaryRows'))) throw new Error('the Summary has no delta version row');
  });

  console.log('\n== The same number means the same thing in both tools ==');
  t('Part WO Status: Not Closed counts what the dashboard card counts', () => {
    // Lift the dashboard's predicates rather than restating them.
    const pick = name => {
      const m = SRC.match(new RegExp('const ' + name + '\\s*=\\s*\\w+\\.filter\\((x\\s*=>[^\\n]*?)\\)\\.length'));
      if (!m) throw new Error('BUILD MARKER MOVED: ' + name);
      return vm.runInNewContext('(' + m[1] + ')');
    };
    const cardOpen = pick('woopen_m'), cardUo = pick('abomUoWoOpen');
    const X = deltaSandbox(['fscope', 'modeHasMbom', 'modeHasAbom', 'computeKpis'],
                           ['DIRECT_OK', 'COVERED_OK', 'SCOPE_EXCLUDED']);
    const rows = [['wo_open', 'n/a'], ['ok', 'wo_open'], ['wo_open', 'wo_open'], ['ok', 'pn_as_usedon'], ['missing', 'n/a']]
      .map(([as, uo], i) => ({ key: 'k' + i, overall: 'ok', ms: 'ok', as, asUsedOn: uo }));
    const k = X.computeKpis({ mode: 'ebom_abom', results: rows });
    eq(k.abomOpen, rows.filter(cardOpen).length, 'Part WO Status: Not Closed:');
    eq(k.abomUoOpen, rows.filter(cardUo).length, 'Used-On WO Not Closed:');
  });
  t('the Summary uses the dashboard’s card names for those rows', () => {
    const b = grabDelta('buildSummaryRows');
    ['Part WO Status: Not Closed', 'Used-On WO Not Closed'].forEach(n => {
      if (!b.includes("'" + n + "'")) throw new Error('no Summary row named ' + n);
    });
    if (b.includes('ABOM Open-WO items')) throw new Error('the old label is still there');
  });
  t('the Summary says the dashboard rounds these percentages', () => {
    if (!/whole percent/.test(grabDelta('buildSummaryRows')))
      throw new Error('93.6% here vs 94% on the card needs explaining where it is read');
  });
  t('ME-imported claims are counted separately on the Summary', () => {
    if (!/external_import/.test(grabDelta('computeKpis'))) throw new Error('no imported-claim count');
  });

  console.log('\n== Purple still means a human decided ==');
  t('an unresolved cause is not drawn in the adjudication purple', () => {
    const b = stripComments(grabDelta('renderTable'));
    if (/c === 'Cause' && v !== 'Build data'\) cls = ' class="adj"'/.test(b))
      throw new Error('every non-build cause is purple, including Unresolved');
    if (!/Unresolved[\s\S]{0,80}class="warn"/.test(b)) throw new Error('Unresolved has no warning style');
    if (!/td\.warn\s*\{/.test(DSRC)) throw new Error('td.warn is not styled');
  });

  console.log('\n== One palette ==');
  t('every token the delta tool defines has the main build’s dark value', () => {
    const vars = src => {
      const m = src.replace(/\/\*[\s\S]*?\*\//g, '').match(/:root\s*\{([^}]*)\}/);
      return Object.fromEntries([...m[1].matchAll(/(--[\w-]+)\s*:\s*([^;]+);/g)].map(x => [x[1], x[2].trim()]));
    };
    const mainRoot = vars(SRC.slice(SRC.search(/<style(?:\s[^>]*)?>/)));
    const d = vars(DSRC.slice(DSRC.search(/<style(?:\s[^>]*)?>/)));
    const bad = Object.keys(d).filter(k => mainRoot[k] !== undefined && mainRoot[k] !== d[k])
      .map(k => k + ' ' + d[k] + ' vs ' + mainRoot[k]);
    const unknown = Object.keys(d).filter(k => mainRoot[k] === undefined);
    if (bad.length || unknown.length)
      throw new Error((bad.length ? 'differ: ' + bad.join('; ') : '') + (unknown.length ? ' unknown: ' + unknown.join(', ') : ''));
  });
  t('the delta stylesheet holds no raw colour outside :root', () => {
    const css = DSRC.slice(DSRC.search(/<style(?:\s[^>]*)?>/), DSRC.indexOf('</style>'))
      .replace(/@font-face\{[^}]*\}/g, '').replace(/:root\s*\{[^}]*\}/, '');
    const hits = css.match(/#[0-9a-fA-F]{3,8}\b/g) || [];
    if (hits.length) throw new Error('raw colours: ' + hits.join(', '));
  });

  console.log('\n== Pedigree values say what they are ==');
  t('each pedigree row says whether its value is a release date or a status', () => {
    const X = deltaSandbox(['chpBom', 'pedigreeDelta', 'chpAlignOf', '_colLetter', 'chpAlignLabel', 'chpAlignDiff', 'chpAlignContext']);
    const tr = (dcn, ecn) => ({ dcn: [[dcn[0], dcn[1]]], ecn: [[ecn[0], ecn[1]]], ecr: [] });
    const A = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr(['D1', '2024-01-01'], ['E1', 'OPEN']) }] };
    const B = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr(['D1', '2024-02-01'], ['E1', 'CLOSED']) }] };
    const rows = X.pedigreeDelta(A, B).rows;
    const by = Object.fromEntries(rows.map(r => [r['Record Type'], r['Value Meaning']]));
    eq(by, { DCN: 'release date', ECN: 'status' });
  });

  // v3.5 — Change Pedigree Alignment (main build v182).
  console.log('\n== Change Pedigree Alignment (v3.5) ==');
  const CAX = () => deltaSandbox(['chpBom', 'pedigreeDelta', 'chpAlignOf', '_colLetter', 'chpAlignLabel', 'chpAlignDiff', 'chpAlignContext']);
  const drawingSess = (o) => Object.assign({ rule: 'drawing', ebomDrawCol: 12, matchRev: false, ebomRevCol: null }, o || {});
  t('the delta tool names the rules in the main build\u2019s words', () => {
    const X = CAX();
    const main = sandbox({ state: { chpAlign: null } }, ['chpalign']).CA;
    [null, drawingSess(), drawingSess({ matchRev: true, ebomRevCol: 13 })].forEach(a => {
      const words = X.chpAlignLabel({ chpAlign: a }).replace(/ \(EBOM [^)]*\)$/, '');
      eq(words, main._chpAlignRuleLabel(a || { rule: 'pn_nh' }));
    });
    eq(X.chpAlignLabel({ chpAlign: drawingSess({ matchRev: true, ebomRevCol: 13 }) }),
       'Drawing number + revision (EBOM drawing column M, revision column N)', 'with columns:');
  });
  t('a session without the field, or with a rule it does not know, is the default', () => {
    const X = CAX();
    eq([X.chpAlignOf({}), X.chpAlignOf({ chpAlign: { rule: 'pn_nh' } }), X.chpAlignOf({ chpAlign: { rule: 'other' } })], [null, null, null]);
    eq(X.chpAlignDiff({}, { chpAlign: { rule: 'pn_nh' } }), { same: true, anyCustom: false });
  });
  t('two default sessions: no warning, no caveat, no Via Drawing column', () => {
    const X = CAX();
    const tr = e => ({ dcn: [], ecn: [], ecr: [[e, 'OPEN']] });
    const A = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr('R1') }] };
    const B = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr('R2') }] };
    eq(X.chpAlignContext(A, B).warning, '');
    const d = X.pedigreeDelta(A, B);
    eq(d.caveat, undefined);
    if (d.rows.some(r => 'Via Drawing' in r)) throw new Error('a default report gained a column');
  });
  t('different rules: warned at load, noted on the pedigree sheet, drawings named', () => {
    const X = CAX();
    const tr = e => ({ dcn: [], ecn: [], ecr: [[e, 'OPEN']] });
    const A = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr('R1') }] };
    const B = { boms: { chp: {} }, chpAlign: drawingSess(),
                results: [{ key: 'P||N', pn: 'P', nh: 'N', chpVia: ['D-1'], trace: tr('R2') }] };
    const w = X.chpAlignContext(A, B).warning;
    if (!/Part number \+ next higher/.test(w) || !/Drawing number \(EBOM drawing column M\)/.test(w)) throw new Error('warning: ' + w);
    const d = X.pedigreeDelta(A, B);
    eq(d.caveat, w, 'the sheet carries the same words:');
    eq(d.rows.map(r => r['Via Drawing']), ['D-1', 'D-1'], 'every row names the drawing:');
    eq(X.chpAlignDiff(B, Object.assign({}, B, { chpAlign: drawingSess({ ebomDrawCol: 13 }) })).same, false, 'same rule, different column:');
  });
  t('the summary row is gated on a non-default rule, and the load warning is wired', () => {
    const b = grabDelta('buildSummaryRows');
    if (!/if \(_caDiff\.anyCustom\)[\s\S]{0,200}line\('Change Pedigree alignment'/.test(b)) throw new Error('summary row not gated on a non-default rule');
    if (DSRC.indexOf('var _ca = chpAlignContext(state.A, state.B);') < 0) throw new Error('no load warning');
  });
  // v3.6 — one rule for "the same code" in both tools: two codes the main
  // build's Disposition Code card counts as one are not a change in the delta.
  console.log('\n== Disposition Code (v3.6) ==');
  t('the delta tool treats two codes as the same exactly when the dashboard card does', () => {
    const D = sandbox({}, ['delta']).D;
    const c = sandbox({}, []);
    vm.runInContext(grabFn('_ncrEntryCodeCounts') + '\n' + grabFn('_ncrDispCodeCounts') + '\nglobalThis.K = (a, b) => _ncrDispCodeCounts([{ ncrEntriesPool1: [{ dispCode: a }, { dispCode: b }] }]).rows.length === 1;', c);
    const N = D.NCR_COL;
    const mk = code => { const r = []; r[N.ncrNum] = 'N1'; r[N.dispNo] = 'D1'; r[N.dispStatus] = 'OPEN'; r[N.dispCode] = code; return r; };
    const ss = code => ({ results: [], boms: { ncr: { data: [mk(code)] } } });
    [['UAI', 'uai'], [' UAI', 'UAI '], ['UAI', 'U-AI'], ['', 'UAI'], ['', ' '], ['REWORK', 'RWK']].forEach(([a, b]) => {
      const card = c.K(a, b), delta = D.ncrDispositionDelta(ss(a), ss(b)).rows.length === 0;
      if (card !== delta) throw new Error(JSON.stringify([a, b]) + ': card says same=' + card + ', delta says same=' + delta);
    });
  });
});

// ── v177 visual grammar ────────────────────────────────────────────────────
// v177 shipped a visual refactor with no tests. These pin what its own
// comments say must not come back, and pin the one thing it left open.
suite('Visual grammar and type scale', (t, eq) => {
  const css = [...SRC.matchAll(/<style(?:\s[^>]*)?>([\s\S]*?)<\/style>/g)].map(m => m[1]).join('\n');
  t('the metric bar is gone and stays gone', () => {
    if (/metric-bar/.test(SRC)) throw new Error('a metric bar is back: a KPI card reports a finding, not progress');
  });
  t('the three component primitives exist', () => {
    ['.panel', '.toolbar', '.u-label'].forEach(c => {
      if (!new RegExp('\\' + c + '\\b[^{]*\\{').test(css)) throw new Error(c + ' is not defined');
    });
  });
  t('section jump links are text, underlined when active, like .tab', () => {
    const r = css.match(/\.section-nav a\s*\{([^}]*)\}/);
    if (!r) throw new Error('no .section-nav a rule');
    if (!/border:\s*0/.test(r[1]) || !/background:\s*none/.test(r[1])) throw new Error('jump links look like buttons again');
    if (!/\.section-nav a\.active\s*\{[^}]*border-bottom-color/.test(css)) throw new Error('active link is not underlined');
  });
  t('the type scale has four steps and an 11px floor', () => {
    // v180 — before this, seven declarations used a size token and ~630 wrote
    // 8-13px directly, so there was no floor to raise. The scale is the floor.
    const v = n => parseFloat((SRC.match(new RegExp(n + ':\\s*(\\d+(?:\\.\\d+)?)px')) || [])[1]);
    const steps = ['--fs-xs', '--fs-sm', '--fs-md', '--fs-lg'].map(v);
    if (steps.some(x => !x)) throw new Error('a scale step is missing: ' + steps.join(', '));
    if (steps[0] < 11) throw new Error('the floor is ' + steps[0] + 'px');
    steps.forEach((x, i) => { if (i && x <= steps[i - 1]) throw new Error('the scale does not ascend: ' + steps.join(', ')); });
  });
  t('every size below 14px comes from the scale, never a literal', () => {
    // Stylesheets, inline styles and script-built markup alike. The vendored
    // SheetJS is not ours and is skipped. One named exception: the render-error
    // banner, which must not depend on CSS variables (Tier 12).
    const app = SRC.slice(at('</script>'));
    const hits = [];
    for (const m of app.matchAll(/font-size:\s*(\d+(?:\.\d+)?)px/g)) {
      if (+m[1] >= 14) continue;
      const ctx = app.slice(Math.max(0, m.index - 300), m.index);
      if (/id="kpi-render-error-banner"[^>]*$/.test(ctx)) continue;
      hits.push(m[0] + ' @' + (SRC.slice(0, SRC.indexOf(app) + m.index).split('\n').length));
    }
    // v180 review — sizes set from script bypass the "font-size:" spelling:
    // el.style.fontSize = '9px', and canvas fonts anywhere, not only in the
    // chart functions. Canvas cannot read CSS variables, so a canvas size may be
    // literal, but not below the floor.
    const line = i => SRC.slice(0, SRC.indexOf(app) + i).split('\n').length;
    for (const m of app.matchAll(/\.fontSize\s*=\s*['"`](\d+(?:\.\d+)?)px/g))
      if (+m[1] < 14) hits.push(m[0] + ' @' + line(m.index));
    for (const m of app.matchAll(/\.font\s*=\s*['"`][^'"`\n]*?(\d+(?:\.\d+)?)px/g))
      if (+m[1] < 11) hits.push('canvas ' + m[1] + 'px @' + line(m.index));
    if (hits.length) throw new Error(hits.length + ' literal size(s): ' + hits.slice(0, 6).join(', '));
  });
  t('every size token resolves at or above the floor', () => {
    const css = STYLE_BLOCKS[0].css;
    const raw = n => (css.match(new RegExp(n + '\\s*:\\s*([^;]+);')) || [])[1];
    const px = (n, d) => { const v = (raw(n) || '').trim(); const a = v.match(/^var\((--[\w-]+)\)$/);
      return a && (d || 0) < 5 ? px(a[1], (d || 0) + 1) : parseFloat(v); };
    const floor = px('--fs-xs');
    const toks = [...new Set([...css.matchAll(/(--fs-[\w-]+)\s*:/g)].map(m => m[1]))];
    const low = toks.filter(t => !(px(t) >= floor)).map(t => t + '=' + px(t));
    if (low.length) throw new Error('below the floor: ' + low.join(', '));
  });
});

// ── USER GUIDE ─────────────────────────────────────────────────────────────
// v179. The guide drifted for twenty builds — a stale version stamp, a symbol
// the tool had stopped using, colour and theme names that changed at v173-175,
// section numbers that skipped — because nothing compared it with the tool.
// Its source now ships as Comparator_User_Guide.md (build_guide.py turns it
// into the .docx) and this suite reads it. Every expectation is derived from
// the build: the badge map, the theme menu, the certificate rows, the versions.
// Not shipped alongside: nothing to check, and the suite says so.
function guideSource() {
  const dirs = [__dirname, path.join(__dirname, '..')];
  for (const d of dirs) {
    const f = path.join(d, 'Comparator_User_Guide.md');
    try { if (fs.statSync(f).isFile()) return fs.readFileSync(f, 'utf8'); } catch (e) {}
  }
  return null;
}
suite('User guide agrees with the build', (t, eq) => {
  const G = guideSource();
  const need = fn => () => { if (G === null) return; fn(); };
  if (G === null) console.log('  (Comparator_User_Guide.md not shipped alongside — nothing to compare)');
  const badgeKeys = () => {
    const a = at('const BADGE_HELP = {');
    const body = SRC.slice(a, SRC.indexOf('\n};', a));
    return new Set([...body.matchAll(/^\s*'([^']+)'\s*:/gm)].map(m => m[1]));
  };
  const known = (label, keys) => keys.has(label) || [...keys].some(k => k.startsWith(label + ' '));

  t('the guide is written for the build under test', need(() => {
    const v = SRC.match(/const APP_VERSION = '(v\d+)'/)[1];
    const stamps = [...G.matchAll(/for build (v\d+)|against build (v\d+)/g)].map(m => m[1] || m[2]);
    if (!stamps.length) throw new Error('no "for build vNNN" stamp in the guide');
    const wrong = stamps.filter(s => s !== v);
    if (wrong.length) throw new Error('guide says ' + wrong.join(', ') + '; the build is ' + v);
  }));
  t('the guide names the delta tool version that ships beside it', need(() => {
    const dv = (DSRC.match(/var DELTA_VERSION = '(v[\d.]+)'/) || [])[1];
    const named = [...G.matchAll(/Delta tool (v[\d.]+\d)/g)].map(m => m[1]);
    if (!named.length) throw new Error('the guide does not say which delta tool it describes');
    const wrong = named.filter(x => x !== dv);
    if (wrong.length) throw new Error('guide says Delta tool ' + wrong.join(', ') + '; the file is ' + dv);
  }));
  t('every symbol-led badge the guide names is a badge the build renders', need(() => {
    // "⬇ PROC REMOVED" yes; "⊘ PROC REMOVED" was the guide's for twenty builds.
    const keys = badgeKeys();
    const found = new Set();
    for (const m of G.matchAll(/([⚠✗⊘⬇⚑▲▼✓?◆]) ((?:[A-Z0-9][A-Z0-9./&()-]*(?![a-z])(?: |$))*[A-Z0-9][A-Z0-9./&()-]*(?![a-z]))/gm)) {
      let lab = (m[1] + ' ' + m[2]).replace(/[).]+$/, '');
      if ((lab.match(/\(/g) || []).length > (lab.match(/\)/g) || []).length) lab += ')';
      found.add(lab.trim());
    }
    const bad = [...found].filter(l => !known(l, keys));
    if (bad.length) throw new Error('not a badge in this build: ' + bad.join(', '));
  }));
  t('every label in the status table is a badge the build renders', need(() => {
    const keys = badgeKeys();
    const a = G.indexOf('What the statuses mean');
    if (a < 0) throw new Error('the status table heading moved');
    const tbl = G.slice(a, G.indexOf('\n\n', G.indexOf('| --- |', a) + 10));
    const labels = [...tbl.matchAll(/^\| ([^|]+?) \|/gm)].map(m => m[1]).filter(l => !/^Status|^---/.test(l))
      .flatMap(c => c.split(' / ')).map(s => s.replace(/\*/g, '').trim());
    if (labels.length < 8) throw new Error('only ' + labels.length + ' labels found — table format changed?');
    const bad = labels.filter(l => !known(l, keys));
    if (bad.length) throw new Error('not a badge in this build: ' + bad.join(', '));
  }));
  t('the guide uses the theme names the menu shows', need(() => {
    const sel = SRC.slice(at('id="theme-select"'), SRC.indexOf('</select>', at('id="theme-select"')));
    const names = [...sel.matchAll(/<option[^>]*>([^<]+)<\/option>/g)].map(m => m[1].replace(/&amp;/g, '&'));
    if (names.length !== 3) throw new Error('theme menu has ' + names.length + ' options');
    const missing = names.filter(n => G.indexOf(n) < 0);
    if (missing.length) throw new Error('the guide never names: ' + missing.join(', '));
    // A retired name may survive only in the history appendix, where it is true.
    const body = G.slice(0, G.indexOf('What changed since'));
    if (/high contrast/i.test(body)) throw new Error('"High contrast" outside the history appendix; the menu says ' + names[2]);
  }));
  t('every section the guide refers to exists, and numbering has no gaps', need(() => {
    const heads = [...G.matchAll(/^#{1,3} (\d+)\.(\d+)?/gm)].map(m => m[2] ? m[1] + '.' + m[2] : m[1]);
    const set = new Set(heads);
    const refs = [...G.matchAll(/(?:\(|[Ss]ee |[Ii]n |§)(\d{1,2}\.\d{1,2})\b/g)].map(m => m[1]);
    const dangling = [...new Set(refs)].filter(r => !set.has(r));
    if (dangling.length) throw new Error('refers to missing section(s): ' + dangling.join(', '));
    // A section must sit inside its own chapter (v176 had 3.6 inside chapter 4).
    let cur = null;
    heads.forEach(h => {
      if (h.indexOf('.') < 0) { cur = h; return; }
      if (h.split('.')[0] !== cur) throw new Error('section ' + h + ' sits inside chapter ' + cur);
    });
    const chapters = heads.filter(h => h.indexOf('.') < 0).map(Number);
    chapters.forEach((c, i) => { if (c !== i + 1) throw new Error('chapter ' + c + ' follows ' + (chapters[i - 1] || 'the title')); });
    chapters.forEach(c => {
      const subs = heads.filter(h => h.startsWith(c + '.')).map(h => +h.split('.')[1]);
      subs.forEach((n, i) => { if (n !== i + 1) throw new Error('section ' + c + '.' + n + ' follows ' + (i ? c + '.' + subs[i - 1] : 'chapter ' + c)); });
    });
  }));
  t('the certificate description names every row the certificate prints', need(() => {
    // Phrase per certificate row. A row added to _auditCertRows with no phrase
    // here fails by name: the guide has to learn about it too.
    const PHRASE = { 'Auditor': 'auditor', 'Frozen': 'timestamp', 'Mode': 'comparison mode', 'Build': 'build',
      'Proc Code Profile': 'proc code profile', 'EBOM Indenture Scope': 'indenture scope',
      'Removal Proc Codes': 'removal', 'Swap Proc Codes': 'swap', 'SHA-256 Integrity Hash': 'hash',
      'Change Pedigree Alignment': 'change pedigree alignment' };   // v182
    const rows = [...grabFn('_auditCertRows').matchAll(/\[\s*'([^']+)'\s*,/g)].map(m => m[1]);
    const a = G.indexOf('Finalize & Freeze'); const sec = G.slice(a, G.indexOf('\n# ', a)).toLowerCase();
    const bad = rows.filter(r => !PHRASE[r] || sec.indexOf(PHRASE[r]) < 0);
    if (bad.length) throw new Error('10.2 does not describe: ' + bad.join(', '));
  }));
  t('the history appendix has a row for the build under test', need(() => {
    const v = SRC.match(/const APP_VERSION = '(v\d+)'/)[1];
    if (!new RegExp('^\\| ' + v + ' \\|', 'm').test(G)) throw new Error('no "What changed" row for ' + v);
  }));
});

suite('Version single-source', (t, eq) => {
  t('exactly one hardcoded version string in the file', ()=>{
    const m = SRC.match(/const APP_VERSION = '(v\d+)'/);
    if(!m) throw new Error('APP_VERSION not found');
    // no other vNNN literal in visible markup
    const body = SRC.slice(SRC.indexOf('<div class="header"'), SRC.indexOf('<script', SRC.indexOf('<div class="header"')));
    const stripped = body.replace(/<!--[\s\S]*?-->/g,'');
    // Dev/Logic tooltip blocks legitimately cite the release a behaviour landed
    // in ("v66 pre-filters the ABOM"). Those are provenance prose, not a claim
    // about which version is running. Exclude them; anything else is a drift risk.
    const noDev = stripped.replace(/<div class="metric-tooltip-dev"[\s\S]*?<\/div>\s*<\/div>/g,'');
    const vis = noDev.replace(/<[^>]+>/g,' ');
    const hits = vis.match(/\bv\d{2,3}\b/g) || [];
    if(hits.length) throw new Error('version literals still in chrome: '+hits.join(', '));
  });
  t('the pill has an id and no literal', ()=>{
    if(!SRC.includes('id="app-version-pill"')) throw new Error('no id');
    if(/<span class="pill">v\d+<\/span>/.test(SRC)) throw new Error('literal pill remains');
  });
  t('renderVersionPill is called at boot', ()=>{
    if(!/renderVersionPill\(\);/.test(SRC)) throw new Error('never called');
  });
  t('APP_VERSION matches the build', ()=>{
    const m=SRC.match(/const APP_VERSION = '(v\d+)'/);
    if(m[1]!=='v191') throw new Error('says '+m[1]);
  });
});


// ── TIER 22 ────────────────────────────────────────────────────────────────
// v182 — CHANGE PEDIGREE ALIGNMENT. Two promises, tested separately.
//
// 1. The default rule is v181, unchanged. Twelve places used to work out the
//    CHP-to-EBOM join for themselves, with four different rules between them.
//    They now call one module, and each call must reproduce ITS OWN v181 rule,
//    including the two disagreements kept on purpose (KI-1, KI-2). A guard
//    fails if code outside the module reads the CHP join columns again.
//    The strongest check is the browser equivalence run (--reference), which
//    compares every output with a v181 build; these tests pin the rules.
// 2. The drawing rule does what the owner agreed: an ECR attaches to every
//    EBOM line on its drawing, matched exactly after trim and upper-case, with
//    no part-number fallback, and it is visible everywhere results go.
const REAL_COL = (function () {
  const a = at('const COL = {');
  const ctx = {}; vm.createContext(ctx);
  vm.runInContext(SRC.slice(a, at('};', a) + 2).replace('const COL', 'globalThis.COL'), ctx);
  return ctx.COL;
})();

// The source with the alignment module cut out, for the guards below.
function srcOutsideChpAlign(src) {
  const a = src.indexOf('// ── v182 — CHANGE PEDIGREE ALIGNMENT: DRAWING RULE (worker-safe)');
  const b = src.indexOf('// ── v182 — CHANGE PEDIGREE ALIGNMENT: END');
  if (a < 0 || b < a) throw new Error('BUILD MARKER MOVED: the CHANGE PEDIGREE ALIGNMENT block');
  return src.slice(0, a) + src.slice(b);
}
// Every place outside the module that reads a CHP join column. The COL table
// itself is not a read.
function chpJoinReadsOutside(src) {
  const out = stripComments(srcOutsideChpAlign(src));
  const colA = out.indexOf('const COL = {'), colB = out.indexOf('};', colA);
  const body = out.slice(0, colA) + out.slice(colB);
  const hits = [];
  for (const m of body.matchAll(/COL\.chp\.(pn|nh|docNo|docRev)\b/g)) hits.push(m[0]);
  for (const m of body.matchAll(/\bcr\[10\]/g)) hits.push(m[0]);
  return hits;
}

suite('Tier 22 — Change Pedigree Alignment', (t, eq) => {
  const mk = (extraState) => sandbox({ COL: REAL_COL,
    state: Object.assign({ results: [], boms: {}, isLocked: false, chpManualMap: null, ebomManualMap: null, mode: 'ebom_mbom_abom' }, extraState || {}),
    esc: s => String(s) }, ['engine', 'chp', 'chpalign']);
  const chpRow = o => { const r = new Array(25).fill(''); const C = REAL_COL.chp;
    Object.keys(o).forEach(k => { r[C[k]] = o[k]; }); return r; };
  const trace = (d, e, r) => ({ dcn: new Map(d || []), ecn: new Map(e || []), ecr: new Map(r || []) });
  const R = (pn, nh, o) => Object.assign({ key: pn + '||' + nh, pn, nh, trace: trace() }, o || {});

  console.log('\n== One place reads the CHP join columns ==');
  t('no code outside the module reads the CHP part number, next higher or drawing columns', () => {
    const hits = chpJoinReadsOutside(SRC);
    if (hits.length) throw new Error(hits.length + ' direct read(s) outside CHANGE PEDIGREE ALIGNMENT: ' + [...new Set(hits)].join(', '));
  });
  t('the guard would catch a join written the old way', () => {
    const planted = SRC.replace('function exportCSV(', "function _planted(cr){ return normPN(cr[COL.chp.pn]) + String(cr[10]); }\nfunction exportCSV(");
    eq(chpJoinReadsOutside(planted).length, 2, 'planted reads found:');
  });
  t('every former join site calls the module', () => {
    const out = stripComments(srcOutsideChpAlign(SRC));
    const n = re => (out.match(re) || []).length;
    eq(n(/chpDrawingForLine\(/g), 5, 'Drawing column sites (Detailed View + four exports):');
    eq(n(/chpHistoryState\(/g) >= 6, true, 'History label sites:');
    eq(n(/_chpIngestKeyCol\(\)/g), 2, 'CHP upload and re-read filters:');
    ['chpEntriesForCiTrace(', 'chpEntriesForLineExact(', 'chpEntriesForPn(', 'chpResultForChpRow(',
     'chpEcnItemIndex()', 'chpEcnItemKeysOf(', 'chpDocLookup()'].forEach(f => {
      if (out.indexOf(f) < 0) throw new Error('no call to ' + f);
    });
    if (/'\|\|'/.test(grabFn('renderChpTable'))) throw new Error('renderChpTable builds its own join key again');
  });

  console.log('\n== The default rule is v181, site by site ==');
  t('a state without the field reads as the default rule', () => {
    const c = mk(); delete c.state.chpAlign;
    eq([c.CA.chpAlignRule(), c.CA.isChpAlignCustom(), c.CA.chpAlignRunBlocker(), c.CA.chpAlignEnginePlan()],
       ['pn_nh', false, '', null]);
    eq(c.CA._chpAlignForSession(), undefined, 'nothing is written to the session:');
  });
  t('the upload filter column is v181’s: part number, manual position when mapped', () => {
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    eq(c.CA._chpIngestKeyCol(), REAL_COL.chp.pn);
    c.state.chpManualMap = { pn: 7, docNo: 2 };
    eq(c.CA._chpIngestKeyCol(), 7);
    eq(c.CA._chpRequiredMapKeys(), ['pn', 'nh'], 'required manual-map fields:');
  });
  t('Drawing column: first non-blank drawing for the exact PN + NH, no fallback (KI-1)', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'p1', nh: 'a', docNo: '' }), chpRow({ pn: 'P1', nh: 'A', docNo: 'D-1' }),
                               chpRow({ pn: 'P1', nh: 'A', docNo: 'D-2' }), chpRow({ pn: 'P2', nh: 'X', docNo: 'D-9' })] };
    eq(c.CA.chpDrawingForLine(R('P1', 'A')), 'D-1', 'first non-blank, case-insensitive key:');
    eq(c.CA.chpDrawingForLine(R('P2', 'A')), '', 'no part-number fallback:');
    eq(c.CA.chpDrawingForLine(R('P9', '')), '');
  });
  t('CI Traceability detail: exact PN + NH, else every row for the part number', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'P1', nh: 'A', ecr: 'R1' }), chpRow({ pn: 'P1', nh: 'B', ecr: 'R2' })] };
    eq(c.CA.chpEntriesForCiTrace('P1', 'A', null).map(e => e.ecr), ['R1']);
    eq(c.CA.chpEntriesForCiTrace('P1', 'Z', null).map(e => e.ecr), ['R1', 'R2'], 'fallback:');
  });
  t('CI report sheets: exact next higher, and part number alone for the next-higher sheet', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'P1', nh: 'A', ecr: 'R1' }), chpRow({ pn: 'P1', nh: 'B', ecr: 'R2' })] };
    eq(c.CA.chpEntriesForLineExact('P1', 'B').map(e => e.ecr), ['R2']);
    eq(c.CA.chpEntriesForLineExact('P1', 'Z'), [], 'no fallback on this sheet:');
    eq(c.CA.chpEntriesForPn('P1').map(e => e.ecr), ['R1', 'R2']);
  });
  t('Change Pedigree tab: raw PN + NH, case-sensitive (KI-2)', () => {
    const c = mk();
    c.state.results = [R('P1', 'A')];
    eq(!!c.CA.chpResultForChpRow(chpRow({ pn: ' P1 ', nh: 'A' })), true, 'trimmed match:');
    eq(c.CA.chpResultForChpRow(chpRow({ pn: 'p1', nh: 'A' })), null, 'lower case does not match, as in v181:');
    eq(c.CA.chpResultForChpRow(chpRow({ pn: 'P1', nh: 'B' })), null, 'no fallback:');
  });
  t('ECN completeness: part numbers, matched on part number alone', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'p1', nh: 'A', ecn: 'E1' }), chpRow({ pn: 'P2', nh: 'B', ecn: 'E1' }), chpRow({ pn: 'P3', ecn: '' })] };
    const idx = c.CA.chpEcnItemIndex();
    eq([...idx.get('E1')], ['P1', 'P2']);
    eq(c.CA.chpEcnItemKeysOf(R('p9', 'X')), ['P9']);
  });
  t('ECN report document lookup: PN + NH, else PN with a blank next higher', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'P1', nh: '', docNo: 'D-0', docRev: 'Z' }), chpRow({ pn: 'P1', nh: 'A', docNo: 'D-1', docRev: 'A' })] };
    const look = c.CA.chpDocLookup();
    eq(look('P1', 'A'), { docNo: 'D-1', docRev: 'A' });
    eq(look('P1', 'Q'), { docNo: 'D-0', docRev: 'Z' });
    eq(look('P9', 'Q'), { docNo: '', docRev: '' });
  });
  t('the History badge and tooltip are chpReleaseState and chpTraceTooltip, unchanged', () => {
    const c = mk();
    [trace(), trace([], [['E1', 'OPEN']]), trace([['D1', '2024-03-15']]), trace([['D1', '']], [], [['R1', 'x']])].forEach(tr => {
      const r = R('P1', 'A', { trace: tr });
      eq(JSON.stringify(c.CA.chpHistoryState(r)), JSON.stringify(c.C.chpReleaseState(tr)));
      eq(c.CA.chpHistoryTooltip(r), c.chpTraceTooltip(tr));
    });
  });
  t('Change Pedigree tab search: the part number, plus the drawing number under the drawing rule', () => {
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    const row = chpRow({ pn: 'P1', docNo: 'D-7' });
    eq(c.CA.chpRowSearchText(row), 'P1', 'default, as v181:');
    c.state.chpAlign = { rule: 'drawing' };
    if (c.CA.chpRowSearchText(row).indexOf('D-7') < 0) throw new Error('drawing number not searchable');
  });
  t('Change Pedigree tab headings: the file\u2019s own, except over re-laid rows under either rule (KI-3, fixed v187)', () => {
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    const bom = { header: ['Drawing Number', 'Rev', 'ECR'] };
    eq([0, 1, 2, 10].map(i => c.CA.chpTabHeaderLabel(bom, i)), ['Drawing Number', 'Rev', 'ECR', 'K'], 'no manual map, as v181:');
    c.state.chpManualMap = { docNo: 0, ecr: 2 };
    eq([10, 19, 0].map(i => c.CA.chpTabHeaderLabel(bom, i)), ['Document/Drawing Number', 'ECR', '\u2014'], 'default rule, manual map:');
    c.state.chpAlign = { rule: 'drawing' };
    eq([10, 19, 0].map(i => c.CA.chpTabHeaderLabel(bom, i)), ['Document/Drawing Number', 'ECR', '\u2014'], 'drawing rule:');
  });
  t('a default run adds nothing to its results', () => {
    const c = mk();
    const rows = [R('P1', 'A')];
    c.CA.chpAttachVia(rows, null);
    eq(Object.keys(rows[0]).indexOf('chpVia'), -1, 'no chpVia field:');
    c.state.results = rows;
    eq(c.CA.chpEcnReportUnavailable(), '', 'ECN reports stay available:');
    eq(c.CA.chpAlignStats(), null, 'no match summary:');
  });

  console.log('\n== The drawing rule ==');
  const eb = (pn, nh, dwg, rev) => { const r = new Array(40).fill(''); r[1] = pn; r[3] = nh; r[12] = dwg == null ? '' : dwg; r[13] = rev == null ? '' : rev; return r; };
  const drawingState = (ebomRows, align) => {
    const c = mk({ chpAlign: Object.assign({ rule: 'drawing', ebomDrawCol: 12, matchRev: false, ebomRevCol: null }, align || {}) });
    c.state.boms.ebom = { raw: [new Array(40).fill('H')].concat(ebomRows), data: ebomRows.map(r => r.slice()) };
    return c;
  };
  t('an ECR attaches to every EBOM line on its drawing, and to nothing else', () => {
    const c = drawingState([eb('P1', 'A', 'D-1'), eb('P2', 'A', 'd-1 '), eb('P3', 'A', 'D-2'), eb('P4', 'A', '')]);
    const lines = c.CA.chpEbomDrawingIndex();
    eq(lines, { 'P1||A': ['D-1'], 'P2||A': ['D-1'], 'P3||A': ['D-2'], 'P4||A': [] });
    const m = c.CA.buildChpTraceMapByDrawing([chpRow({ docNo: 'D-1', ecr: 'R1' }), chpRow({ docNo: 'D-9', ecr: 'R9' })],
                                             REAL_COL.chp, { matchRev: false, ebomDrawings: lines });
    eq(Object.keys(m.map).sort(), ['P1||A', 'P2||A'], 'lines on D-1:');
    eq([...m.map['P2||A'].ecr.keys()], ['R1']);
    eq(m.pnMap, {}, 'no part-number fallback under this rule:');
  });
  t('the match is exact after trim and upper-case: no fuzzy matching', () => {
    const c = drawingState([eb('P1', 'A', 'D-100'), eb('P2', 'A', 'D100')]);
    const m = c.CA.buildChpTraceMapByDrawing([chpRow({ docNo: ' d-100 ', ecr: 'R1' })], REAL_COL.chp,
                                             { matchRev: false, ebomDrawings: c.CA.chpEbomDrawingIndex() });
    eq(Object.keys(m.map), ['P1||A'], 'D100 is not D-100:');
  });
  t('drawing + revision attaches only where the revision matches too', () => {
    const c = drawingState([eb('P1', 'A', 'D-1', 'A'), eb('P2', 'A', 'D-1', 'B')], { matchRev: true, ebomRevCol: 13 });
    const lines = c.CA.chpEbomDrawingIndex();
    eq(lines['P1||A'], ['D-1||A']);
    const m = c.CA.buildChpTraceMapByDrawing([chpRow({ docNo: 'D-1', docRev: 'a', ecr: 'R1' })], REAL_COL.chp,
                                             { matchRev: true, ebomDrawings: lines });
    eq(Object.keys(m.map), ['P1||A']);
  });
  t('merged duplicate lines collect every drawing, and the traces merge', () => {
    const c = drawingState([eb('P1', 'A', 'D-1'), eb('P1', 'A', 'D-2')]);
    const lines = c.CA.chpEbomDrawingIndex();
    eq(lines['P1||A'], ['D-1', 'D-2']);
    const m = c.CA.buildChpTraceMapByDrawing([chpRow({ docNo: 'D-1', ecr: 'R1' }), chpRow({ docNo: 'D-2', ecr: 'R2' })], REAL_COL.chp,
                                             { matchRev: false, ebomDrawings: lines });
    eq([...m.map['P1||A'].ecr.keys()], ['R1', 'R2']);
  });
  t('the EBOM drawing column is read from the file as uploaded, under Mapping 2 too', () => {
    // Mapping 2 keeps only canonical columns after ingest, so column M is gone
    // from data. It must come from raw, row for row.
    const raw = [eb('P1', 'A', 'D-1'), eb('P2', 'A', 'D-2')];
    const c = drawingState(raw);
    c.state.boms.ebom.data = raw.map(r => { const x = new Array(40).fill(''); x[1] = r[1]; x[3] = r[3]; return x; });
    eq(c.CA.chpEbomDrawingIndex(), { 'P1||A': ['D-1'], 'P2||A': ['D-2'] });
  });
  t('raw rows that do not line up with the parsed EBOM are refused, not guessed', () => {
    const c = drawingState([eb('P1', 'A', 'D-1'), eb('P2', 'A', 'D-2')]);
    c.state.boms.ebom.data = [c.state.boms.ebom.data[1], c.state.boms.ebom.data[0]];
    eq(c.CA._ebomSourceRows(), null);
    c.state.boms.chp = { data: [] };
    if (!/Re-upload the EBOM/.test(c.CA.chpAlignRunBlocker())) throw new Error('run not blocked: ' + c.CA.chpAlignRunBlocker());
  });
  t('a run is blocked, in words, until the picks are made', () => {
    const c = drawingState([eb('P1', 'A', 'D-1')], { ebomDrawCol: null });
    eq(c.CA.chpAlignRunBlocker(), '', 'no CHP file: nothing to align, nothing to block:');
    c.state.boms.chp = { data: [] };
    if (!/Choose the EBOM column/.test(c.CA.chpAlignRunBlocker())) throw new Error('no-column message missing');
    c.state.chpAlign.ebomDrawCol = 12; c.state.chpAlign.matchRev = true;
    if (!/revision column/.test(c.CA.chpAlignRunBlocker())) throw new Error('no-revision-column message missing');
    c.state.chpAlign.matchRev = false; c.state.chpManualMap = { docNo: null, ecr: 3 };
    if (!/Document\/Drawing Number and ECR/.test(c.CA.chpAlignRunBlocker())) throw new Error('manual-map message missing');
    c.state.chpManualMap = null; c.state.mode = 'mbom_abom';
    if (!/has no EBOM/.test(c.CA.chpAlignRunBlocker())) throw new Error('no-EBOM mode not blocked');
    c.state.mode = 'ebom_mbom_abom';
    eq(c.CA.chpAlignRunBlocker(), '', 'ready:');
    if (!c.CA.chpAlignEnginePlan().ebomDrawings['P1||A']) throw new Error('plan has no drawings');
  });
  t('History badge: NO DRAWING, ECR ONLY, and the DCN states unchanged', () => {
    const c = mk();
    const st = (via, tr) => c.CA.chpHistoryState(R('P1', 'A', { chpVia: via, trace: tr }));
    eq([st([], trace()).label, st([], trace()).state], ['NO DRAWING', 'no_drawing']);
    eq(st(['D-1'], trace([], [], [['R1', '']])).label, 'ECR ONLY');
    eq(st(['D-1'], trace([], [['E1', 'OPEN']], [['R1', '']])).label, 'NO DCN', 'an ECN present is not ECR only:');
    eq(st(['D-1'], trace([['D1', '2024-03-15']])).state, 'released');
    eq(st(['D-1'], trace()).label, 'NO HISTORY');
    eq(c.C.chpStateClass('no_drawing'), 'badge badge-neutral');
    if (!/Via drawing D-1/.test(c.CA.chpHistoryTooltip(R('P1', 'A', { chpVia: ['D-1'], trace: trace([], [], [['R1', '']]) }))))
      throw new Error('tooltip does not name the drawing');
  });
  t('every consumer follows the run’s rule', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ docNo: 'D-1', docRev: 'A', ecr: 'R1', ecn: '' }), chpRow({ docNo: 'D-9', ecr: 'R9' })] };
    c.state.results = [R('P1', 'A', { chpVia: ['D-1'] }), R('P2', 'A', { chpVia: [] })];
    eq(c.CA.chpDrawingForLine(c.state.results[0]), 'D-1', 'Drawing column is the EBOM’s own:');
    eq(c.CA.chpEntriesForCiTrace('P1', 'A', c.state.results[0]).map(e => e.ecr), ['R1']);
    eq(c.CA.chpEntriesForCiTrace('P2', 'A', c.state.results[1]), []);
    eq(c.CA.chpEntriesForLineExact('P1', 'A').map(e => e.ecr), ['R1']);
    eq(c.CA.chpEntriesForPn('P1').map(e => e.ecr), ['R1']);
    eq(c.CA.chpResultForChpRow(chpRow({ docNo: 'd-1' })).pn, 'P1', 'CHP tab matches by drawing:');
    eq(c.CA.chpResultForChpRow(chpRow({ docNo: 'D-9' })), null, 'a drawing not in the EBOM is NO MATCH:');
    eq(c.CA.chpDocLookup()('P1', 'A', c.state.results[0]), { docNo: 'D-1', docRev: 'A' });
    const st = c.CA.chpAlignStats();
    eq([st.rows, st.matchedRows, st.drawings, st.unmatched, st.lines], [2, 1, 2, 1, 1], 'match summary:');
  });
  t('ECN reports: not available when the extract has no ECNs, by drawing when it has', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ docNo: 'D-1', ecr: 'R1' })] };
    c.state.results = [R('P1', 'A', { chpVia: ['D-1'] })];
    if (!/Not available/.test(c.CA.chpEcnReportUnavailable())) throw new Error('no-ECN extract not refused');
    c.state.boms.chp.data.push(chpRow({ docNo: 'D-1', ecn: 'E1' }), chpRow({ docNo: 'D-7', ecn: 'E1' }));
    eq(c.CA.chpEcnReportUnavailable(), '');
    eq([...c.CA.chpEcnItemIndex().get('E1')], ['D-1', 'D-7'], 'listed by drawing:');
    eq(c.CA.chpEcnItemKeysOf(c.state.results[0]), ['D-1']);
  });
  t('the drawing rule keeps CHP rows by drawing number and requires drawing + ECR', () => {
    const c = mk({ chpAlign: { rule: 'drawing' } });
    eq(c.CA._chpIngestKeyCol(), REAL_COL.chp.docNo);
    c.state.chpManualMap = { pn: null, docNo: 0 };
    eq(c.CA._chpIngestKeyCol(), 0);
    eq(c.CA._chpRequiredMapKeys(), ['docNo', 'ecr']);
    const save = grabFn('_saveSuppManualMap');
    if (!/if \(bom === 'chp' && chpAlignRule\(\) === 'drawing'\) \{\s*map\[d\.key\] = null;/.test(save))
      throw new Error('under the drawing rule an unmapped CHP field would be read from a default column');
  });

  console.log('\n== It travels, and it is named ==');
  t('the engine is sent the plan on both paths, and results are stamped before the raw snapshot', () => {
    const post = SRC.slice(at('worker.postMessage({'), at('worker.postMessage({') + 1200);
    if (!/chpAlign:\s*chpPlan/.test(post)) throw new Error('postMessage does not carry the plan');
    if (!/d\.chpAlign \? buildChpTraceMapByDrawing\(d\.chpData, C\.chp, d\.chpAlign\)/.test(SRC)) throw new Error('the worker does not use the plan');
    const sync = grabFn('runSynchronous');
    if (!/const chpPlan = chpAlignEnginePlan\(\)/.test(sync) || !/chpPlan \? buildChpTraceMapByDrawing/.test(sync))
      throw new Error('the synchronous fallback does not use the same plan');
    [SRC.slice(at('worker.onmessage = function(e)'), at('worker.onerror')), sync].forEach((body, i) => {
      const a = body.indexOf('chpAttachVia(state.results, chpPlan)'), b = body.indexOf('state.resultsRaw');
      if (a < 0 || b < 0 || a > b) throw new Error((i ? 'sync' : 'worker') + ' path: results are not stamped before the raw snapshot');
    });
    const bundle = SRC.slice(at('const fns = ['), at('].map(fn => fn.toString())'));
    ['_chpDwgKey', 'buildChpTraceMapByDrawing'].forEach(f => { if (bundle.indexOf(f) < 0) throw new Error(f + ' is not in the worker bundle'); });
  });
  t('the session writes the rule only when it is not the default, and reads it back safely', () => {
    const exp = stripComments(grabFn('exportSessionJson'));
    if (!/chpAlign:\s*_chpAlignForSession\(\)/.test(exp)) throw new Error('the exporter does not write the rule');
    const imp = grabFn('importSessionJson');
    if (!/state\.chpAlign = _chpAlignSanitize\(payload\.chpAlign\)/.test(imp)) throw new Error('the importer does not restore it');
    const c = mk();
    eq(c.CA._chpAlignSanitize(undefined).rule, 'pn_nh', 'absent:');
    eq(c.CA._chpAlignSanitize({ rule: 'bogus', ebomDrawCol: 3 }).rule, 'pn_nh', 'unknown rule:');
    eq(c.CA._chpAlignSanitize({ rule: 'drawing', ebomDrawCol: -4, matchRev: 'yes', ebomRevCol: 2.5 }),
       { rule: 'drawing', ebomDrawCol: null, matchRev: false, ebomRevCol: null }, 'damaged fields:');
    c.state.chpAlign = { rule: 'drawing', ebomDrawCol: 12, matchRev: false, ebomRevCol: null };
    eq(c.CA._chpAlignForSession().label, 'Drawing number');
  });
  t('the hash and the certificate carry the rule only when it is not the default', () => {
    const f = stripComments(grabFn('freezeReport'));
    if (!/chpAlign:\s*_chpAlignForSession\(\)/.test(f)) throw new Error('the hash payload does not cover the rule');
    if (!/chpAlignment:\s*isChpAlignCustom\(\) \? _chpAlignLabel\(\) : undefined/.test(f)) throw new Error('the certificate does not name it');
    const ctx = sandbox({ _procProfileLabel: () => 'P', _collectorScopeLabel: () => 'S', _procCodesWithBehavior: () => [] });
    vm.runInContext(grabFn('_auditCertRows') + '\nglobalThis.rows = _auditCertRows;', ctx);
    const names = c => ctx.rows(c).map(r => r[0]);
    if (names({ hash: 'h' }).indexOf('Change Pedigree Alignment') >= 0) throw new Error('a default certificate prints an alignment row');
    const withRule = ctx.rows({ hash: 'h', chpAlignment: 'Drawing number · EBOM drawing column M' });
    eq(withRule.find(r => r[0] === 'Change Pedigree Alignment')[1], 'Drawing number · EBOM drawing column M');
    const c2 = drawingState([eb('P1', 'A', 'D-1')]);
    c2.state.boms.ebom.raw[0][12] = 'Drawing No.';
    eq(c2.CA._chpAlignLabel(), 'Drawing number · EBOM drawing column M (Drawing No.)', 'the label names the column:');
  });
  t('Reset returns to the default; a frozen report refuses changes; changes mark results stale', () => {
    if (!/state\.chpAlign = Object\.assign\(\{\}, CHP_ALIGN_DEFAULT\)/.test(grabFn('resetAll'))) throw new Error('Reset keeps the rule');
    const c = mk({ chpAlign: { rule: 'pn_nh' }, isLocked: true });
    c.CA.setChpAlignRule('drawing'); c.CA.setChpAlignCol('draw', '12'); c.CA.setChpAlignMatchRev(true);
    eq(c.state.chpAlign, { rule: 'pn_nh' }, 'frozen report unchanged:');
    ['setChpAlignRule', 'setChpAlignCol', 'setChpAlignMatchRev', 'resetChpAlign'].forEach(fn => {
      if (grabFn(fn).indexOf('_procDirtySinceRun') < 0 && fn !== 'resetChpAlign') throw new Error(fn + ' does not mark results stale');
    });
  });
  t('freezing is refused while the rule differs from the run, never for a default program', () => {
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    eq(c.CA.chpAlignFreezeBlocker(), '', 'before any run:');
    c.CA.chpAlignMarkRun();
    eq(c.CA.chpAlignFreezeBlocker(), '', 'default run, default rule:');
    c.state.chpAlign = { rule: 'drawing', ebomDrawCol: 12 };
    if (!/changed since the last run/.test(c.CA.chpAlignFreezeBlocker())) throw new Error('not refused');
    c.CA.chpAlignMarkRun();
    eq(c.CA.chpAlignFreezeBlocker(), '', 'after a run under the new rule:');
    if (grabFn('freezeReport').indexOf('chpAlignFreezeBlocker()') < 0) throw new Error('freezeReport does not ask');
    // A session exported after the rule was changed, but before re-running.
    const s2 = mk({ chpAlign: { rule: 'drawing', ebomDrawCol: 12 } });
    s2.state.boms.chp = { data: [] }; s2.state.results = [R('P1', 'A')];
    s2.CA.chpAlignMarkImported();
    if (!s2.CA.chpAlignFreezeBlocker()) throw new Error('a session whose results predate its rule can be frozen');
    s2.state.chpAlign = { rule: 'pn_nh' }; s2.CA.chpAlignMarkImported();
    eq(s2.CA.chpAlignFreezeBlocker(), '', 'a consistent default session:');
  });
  t('the panel is on the page, reads Default, and the two new badges are explained', () => {
    ['chpa-panel', 'chpa-summary', 'chpa-body', 'chpa-caret'].forEach(id => { if (SRC.indexOf('id="' + id + '"') < 0) throw new Error('no #' + id); });
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    c.CA.renderChpAlignPanel();
    eq(c.__els['chpa-summary'].textContent, 'Default');
    const help = SRC.slice(at('const BADGE_HELP = {'), at('};', at('const BADGE_HELP = {')));
    ['ECR ONLY', 'NO DRAWING'].forEach(l => { if (help.indexOf("'" + l + "'") < 0) throw new Error(l + ' has no BADGE_HELP entry'); });
    const guide = grabFn('showBadgeGuide');
    ["row('ECR ONLY'", "row('NO DRAWING'"].forEach(l => { if (guide.indexOf(l) < 0) throw new Error('badge guide lacks ' + l); });
  });
});

// ── TIER 23 ────────────────────────────────────────────────────────────────
// v183 — ACN Level and ACN Record Number in the Comparison Summary, to the right
// of CHP History (v184 — and ACN Record Revision), on screen and in the Excel exports of the table. The owner
// asked for exactly those surfaces; the CSV export and the HTML report are
// pinned unchanged so adding them later is a decision, not a drift.
suite('Tier 23 — ACN columns in the Comparison Summary', (t, eq) => {
  const code = span(at('// ── v183 — ACN COLUMNS IN THE COMPARISON SUMMARY'),
                    at('// computeNhMismatchCandidates(bom)'), 'acn columns');
  const mk = rows => {
    const c = sandbox({ COL: REAL_COL, state: { boms: { acn: rows ? { data: rows } : null } }, esc: s => String(s).replace(/</g, '&lt;') }, ['engine']);
    vm.runInContext(code + '\nglobalThis.AC = { acnEntriesForLine, acnExportCells, acnSummaryCellsHtml };', c);
    return c;
  };
  const acn = (pn, level, recNo, recRev) => { const r = new Array(6).fill(''); r[REAL_COL.acn.pn] = pn; r[REAL_COL.acn.level] = level; r[REAL_COL.acn.recNo] = recNo; r[REAL_COL.acn.recRev] = recRev == null ? '' : recRev; return r; };

  console.log('\n== The join is the ACN cards’ join: part number ==');
  t('a line picks up every ACN record for its part number, in file order, once each', () => {
    const c = mk([acn('p1', '6', 'A-1', 'A'), acn('P1', '7', 'A-2', 'A'), acn(' P1 ', '6', 'A-1', 'A'), acn('P1', '6', 'A-1', 'B'), acn('P2', '4', 'B-1')]);
    eq(c.AC.acnEntriesForLine({ pn: 'P1', nh: 'X' }), [{ level: '6', recNo: 'A-1', recRev: 'A' }, { level: '7', recNo: 'A-2', recRev: 'A' },
                                                       { level: '6', recNo: 'A-1', recRev: 'B' }], 'a new revision of a record is its own entry:');
    eq(c.AC.acnEntriesForLine({ pn: 'P1', nh: 'Y' }).length, 3, 'no next higher in an ACN file: every position of the part:');
    eq(c.AC.acnEntriesForLine({ pn: 'P9', nh: 'X' }), []);
  });
  t('no ACN file: nothing', () => {
    const c = mk(null);
    eq(c.AC.acnEntriesForLine({ pn: 'P1' }), []);
    eq(c.AC.acnExportCells({ pn: 'P1' }), ['', '', '']);
  });
  t('the three export cells stay aligned entry for entry, blanks included', () => {
    const c = mk([acn('P1', '6', '', 'A'), acn('P1', '', 'A-2', ''), acn('P3', '4', 'C-1', 'D')]);
    eq(c.AC.acnExportCells({ pn: 'P1' }), ['6; —', '—; A-2', 'A; —']);
    eq(c.AC.acnExportCells({ pn: 'P3' }), ['4', 'C-1', 'D']);
  });
  t('on screen: three cells, stacked one entry per line, escaped', () => {
    const c = mk([acn('P1', '6', '<A-1>', 'A'), acn('P1', '7', 'A-2', 'B')]);
    const h = c.AC.acnSummaryCellsHtml({ pn: 'P1' });
    eq((h.match(/<td/g) || []).length, 3, 'cells:');
    if (h.indexOf('&lt;A-1>') < 0) throw new Error('record number not escaped');
    eq((h.match(/<div/g) || []).length, 6, 'two stacked lines in each cell:');
    eq((mk(null).AC.acnSummaryCellsHtml({ pn: 'P1' }).match(/<td/g) || []).length, 3, 'empty line, still three cells:');
  });

  console.log('\n== Right of CHP History, on every surface asked for ==');
  const order = (body, a, b, c) => {
    const i = body.indexOf(a), j = body.indexOf(b, i), k = body.indexOf(c, j);
    return i >= 0 && j > i && k > j;
  };
  t('the Detailed View: header after CHP History, cells after the History badge, gated on the ACN file', () => {
    const f = grabFn('renderSummaryTable');
    if (!order(f, "'CHP History');", "if (state.boms.acn)  cols.push('ACN Level', 'ACN Record Number', 'ACN Record Revision');", "if (state.boms.wo5) cols.push("))
      throw new Error('header not between CHP History and WO Action');
    if (!order(f, '<td>${historyBadge}</td>', 'if (state.boms.acn) html += acnSummaryCellsHtml(r);', 'if (state.boms.wo5) html +='))
      throw new Error('cells not between the History badge and WO Action');
    if (f.indexOf("silo = 'th-acn'") < 0 || !/th\.th-acn\s*\{/.test(STYLE_BLOCKS.map(b => b.css).join('\n')))
      throw new Error('no ACN header style');
  });
  [['exportXLSX', "hdr.push('DCN','DCN Release Date','ECN','ECN Status','ECR','ECR Status','CHP History');", "hdr.push('ACN Level','ACN Record Number','ACN Record Revision');", "hdr.push('WO Action','WO Meta');",
    "chpHistoryState(r).label", 'row.push(...acnExportCells(r));', 'if (state.boms.wo5) {'],
   ['exportContextResults', "hdr.push('DCN', 'DCN Release Date', 'ECN', 'ECN Status', 'ECR', 'ECR Status', 'CHP History');", "hdr.push('ACN Level', 'ACN Record Number', 'ACN Record Revision');", "hdr.push('WO Action', 'WO Meta');",
    '_chpHistoryText(r)', 'row.push(...acnExportCells(r));', 'if (state.boms.wo5) {']].forEach(([fn, h1, h2, h3, r1, r2, r3]) => {
    t(fn + ': header and row builder move together', () => {
      const f = grabFn(fn);
      if (!order(f, h1, h2, h3)) throw new Error('header not between CHP History and WO Action');
      if (!order(f, r1, r2, r3)) throw new Error('row cells not between CHP History and WO Action');
      eq((f.match(/acnExportCells\(r\)/g) || []).length, 1, 'one row builder:');
    });
  });
  t('the three sheets of the Excel export share the one header and row builder', () => {
    const f = grabFn('exportXLSX');
    ['Comparison Summary', 'Issues Only', 'WO Status Not Closed'].forEach(n => {
      if (!new RegExp("aoa_to_sheet\\(\\[hdr, \\.\\.\\.buildRows\\([^\\n]*\\n\\s*XLSX\\.utils\\.book_append_sheet\\(wb, \\w+, '" + n + "'\\)").test(f))
        throw new Error(n + ' does not use the shared header and buildRows');
    });
  });
  t('the CSV export and the HTML report are unchanged (not asked for)', () => {
    ['exportCSV', 'exportHTML'].forEach(fn => {
      if (/ACN Level|acnExportCells|acnEntriesForLine/.test(grabFn(fn))) throw new Error(fn + ' gained the ACN columns');
    });
  });
});

// ── TIER 24 ────────────────────────────────────────────────────────────────
// v186 — manual column mapping on the Configuration Items and RFV zones. The
// owner asked for the same behaviour and look as the existing manual maps, so
// both zones reuse the supplemental-source mapper NCR and ACN already use:
// a Default / Manual… toggle, the same window, remap-at-ingest into the COL
// positions, a re-read without re-upload, saved with the session, cleared by
// Reset. Every downstream reader of COL.ci / COL.rfv is then unaffected, which
// the reference suite (--reference=) proves for the default layout.
suite('Tier 24 — CI and RFV column mapping', (t, eq) => {
  const MAPFNS = ['_suppManualFieldDefs', '_suppManualFieldDefsBase', 'refreshSuppMappingUI', 'setSuppMappingMode',
                  'openSuppManualMap', '_cancelSuppManualMap', '_saveSuppManualMap', '_applySuppManualMap',
                  '_suppRefreshRowCount', '_reparseBomFromRaw', 'colLetterToIndex', 'colIndexToLetter'];
  const labelDecl = SRC.slice(at('const _SUPP_MAP_LABEL = {'), at('};', at('const _SUPP_MAP_LABEL = {')) + 2);
  const mk = (st, extra) => {
    const c = sandbox(Object.assign({ COL: JSON.parse(JSON.stringify(REAL_COL)),
      state: Object.assign({ boms: {}, isLocked: false }, st || {}),
      esc: x => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;'),
      chpAlignRule: () => 'pn_nh', _chpRequiredMapKeys: () => ['pn', 'nh'], _chpIngestKeyCol: () => REAL_COL.chp.pn,
      _closeMapper: () => {}, _openMapperOverlay: () => {}, renderProcCodePanel: () => {}, renderIndenturePanel: () => {},
      TOASTS: [] }, extra || {}), []);
    vm.runInContext(labelDecl.replace('const _SUPP_MAP_LABEL', 'globalThis._SUPP_MAP_LABEL') + '\n' +
      MAPFNS.map(grabFn).join('\n') +
      '\nglobalThis.toast = m => TOASTS.push(m); globalThis._setMapperHtml = h => { globalThis.MAPPER = h; };', c);
    return c;
  };
  const defs = (c, bom) => vm.runInContext('_suppManualFieldDefs(' + JSON.stringify(bom) + ')', c);

  console.log('\n== The zones carry the same control as NCR and ACN ==');
  t('the CI and RFV zones have Default / Manual…, the help icon and a re-upload hint, and toggling opens no file picker', () => {
    ['ci', 'rfv'].forEach(b => {
      const z = SRC.slice(at('id="zone-' + b + '"'), at('</div>\n    </div>', at('id="zone-' + b + '"')));
      const need = ['onclick="if(!event.target.closest(\'.abom-cm-toggle\')){document.getElementById(\'file-' + b + '\').click()}"',
        '<div class="abom-cm-toggle" onclick="event.stopPropagation()">',
        'id="' + b + '-cm-btn-default"', 'onclick="setSuppMappingMode(\'' + b + '\',\'default\', event)">Default</button>',
        'id="' + b + '-cm-btn-manual"', 'onclick="openSuppManualMap(\'' + b + '\', event)">Manual…</button>',
        'class="abom-cm-help"', 'id="' + b + '-cm-reparse-hint"'];
      const miss = need.filter(n => z.indexOf(n) < 0);
      if (miss.length) throw new Error(b + ' zone lacks: ' + miss.join(' | '));
      if (!/class="abom-cm-btn active" id="[a-z]+-cm-btn-default"/.test(z)) throw new Error(b + ': Default is not the starting state');
    });
  });

  console.log('\n== The fields are the COL layout ==');
  t('CI: CI Identifier, Part Number and Next Higher, in COL.ci order, all required', () => {
    const d = defs(mk(), 'ci');
    eq(d.map(x => x.key), Object.keys(REAL_COL.ci), 'keys vs COL.ci:');
    eq(d.filter(x => !x.required).length, 0, 'optional fields:');
  });
  t('RFV: every COL.rfv field in order; only the RFV Number is required', () => {
    const d = defs(mk(), 'rfv');
    eq(d.map(x => x.key), Object.keys(REAL_COL.rfv), 'keys vs COL.rfv:');
    eq(d.filter(x => x.required).map(x => x.key), ['rfvNum']);
  });

  console.log('\n== Applying a map ==');
  const setVals = (c, bom, vals) => Object.keys(vals).forEach(k => { c.__els[bom + '-map-' + k] = { value: vals[k] }; });
  t('Apply stores column indexes; a blank optional field keeps its default position; Manual ✓ shows', () => {
    const c = mk();
    setVals(c, 'rfv', { rfvNum: 'D', pn: 'a', nh: 'B', woNo: 'C' });
    vm.runInContext("_saveSuppManualMap('rfv')", c);
    const m = c.state.rfvManualMap;
    eq([m.rfvNum, m.pn, m.nh, m.woNo, m.ncrDispNo, m.signatory], [3, 0, 1, 2, REAL_COL.rfv.ncrDispNo, REAL_COL.rfv.signatory]);
    eq(c.__els['rfv-cm-btn-manual'].textContent, 'Manual ✓');
    if (!/^RFV manual column mapping applied\./.test(c.TOASTS[0])) throw new Error(c.TOASTS[0]);
  });
  t('a missing required CI field or a column used twice is refused, and nothing is stored', () => {
    const c = mk();
    setVals(c, 'ci', { ciId: 'C', pn: 'A', nh: '' });
    vm.runInContext("_saveSuppManualMap('ci')", c);
    eq(c.__els['ci-map-error'].textContent, 'Next Higher Part Number is required.');
    setVals(c, 'ci', { ciId: 'C', pn: 'A', nh: 'a' });
    vm.runInContext("_saveSuppManualMap('ci')", c);
    eq(c.__els['ci-map-error'].textContent, 'Column A is mapped to both Part Number and Next Higher Part Number.');
    eq(c.state.ciManualMap, undefined, 'stored map:');
  });
  t('a loaded CI file is re-read at once into the default positions; rows without a part number drop out', () => {
    const raw = [['H0', 'H1', 'H2'], ['P1', 'ASM1', 'CI-1'], ['', 'ASM1', 'CI-2'], ['P3', '', 'CI-3']];
    const c = mk({ boms: { ci: { raw, data: [] } } });
    setVals(c, 'ci', { ciId: 'C', pn: 'A', nh: 'B' });
    vm.runInContext("_saveSuppManualMap('ci')", c);
    const d = c.state.boms.ci.data;
    eq(d.length, 2, 'rows kept:');
    eq([d[0][REAL_COL.ci.ciId], d[0][REAL_COL.ci.pn], d[0][REAL_COL.ci.nh]], ['CI-1', 'P1', 'ASM1']);
    eq([d[1][REAL_COL.ci.ciId], d[1][REAL_COL.ci.pn], d[1][REAL_COL.ci.nh]], ['CI-3', 'P3', '']);
    eq(c.__els['rows-ci'].textContent, '2 rows loaded', 'the zone count follows the re-read:');
    if (!/Applied to the loaded file\./.test(c.TOASTS[0])) throw new Error(c.TOASTS[0]);
  });
  t('RFV rows are kept on the mapped RFV Number, and Default re-reads the file as uploaded', () => {
    const raw = [['h'], ['x', 'P1', 'ASM1', 'RFV-1'], ['RFV-9', 'P2', 'ASM1', '']];
    const c = mk({ boms: { rfv: { raw, data: [] } } });
    setVals(c, 'rfv', { rfvNum: 'D', pn: 'B', nh: 'C' });
    vm.runInContext("_saveSuppManualMap('rfv')", c);
    eq(c.state.boms.rfv.data.map(r => r[REAL_COL.rfv.rfvNum]), ['RFV-1'], 'under the map:');
    vm.runInContext("setSuppMappingMode('rfv', 'default')", c);
    eq(c.state.rfvManualMap, null);
    eq(c.state.boms.rfv.data.map(r => r[REAL_COL.rfv.rfvNum]), ['x', 'RFV-9'], 'default layout, file as uploaded:');
    eq(c.__els['rfv-cm-btn-default'].classList.c.has('active'), true, 'Default highlighted:');
  });
  t('upload filters and remaps CI and RFV exactly as the re-read does', () => {
    // handleFile is not runnable here (FileReader + SheetJS); its CI / RFV lines
    // must be the re-read's lines, which the tests above execute.
    const up = SRC.slice(at('function handleFile('), at('state.boms[type] = { header, data, raw, filename: file.name };'));
    const re = grabFn('_reparseBomFromRaw');
    [/const ciPnCol\s*=\s*state\.ciManualMap\s*\?\s*state\.ciManualMap\.pn\s*:\s*COL\.ci\.pn;/,
     /const rfvNumCol\s*=\s*state\.rfvManualMap\s*\?\s*state\.rfvManualMap\.rfvNum\s*:\s*COL\.rfv\.rfvNum;/,
     /type === 'ci'\s*\?\s*ciPnCol\s*:/, /type === 'rfv'\s*\?\s*rfvNumCol\s*:/,
     /if \(type === 'ci'\s*&& state\.ciManualMap\)\s*data = _applySuppManualMap\('ci',\s*data, 40\);/,
     /if \(type === 'rfv' && state\.rfvManualMap\) data = _applySuppManualMap\('rfv', data, 40\);/].forEach(rx => {
      if (!rx.test(up)) throw new Error('upload lacks ' + rx);
      if (!rx.test(re)) throw new Error('re-read lacks ' + rx);
    });
  });

  console.log('\n== The window, the lock, the session, Reset ==');
  t('the window names the required fields in words that fit each source; NCR keeps its own words', () => {
    const c = mk();
    vm.runInContext("openSuppManualMap('ci')", c);
    if (!/Configuration Items — Manual Column Mapping/.test(c.MAPPER)) throw new Error('title');
    if (c.MAPPER.indexOf('<strong>CI Identifier, Part Number, Next Higher Part Number</strong>') < 0) throw new Error('ci required list');
    vm.runInContext("openSuppManualMap('rfv')", c);
    if (c.MAPPER.indexOf('<strong>RFV Number</strong>') < 0 || !/\(P1\)[\s\S]*\(P2\)[\s\S]*\(P3\)/.test(c.MAPPER)) throw new Error('rfv words');
    if ((c.MAPPER.match(/<input type="text" id="rfv-map-/g) || []).length !== Object.keys(REAL_COL.rfv).length) throw new Error('rfv inputs');
    vm.runInContext("openSuppManualMap('ncr')", c);
    if (!/The required fields are the trace keys the\s+reconciliation engine uses to link NCR records/.test(c.MAPPER)) throw new Error('the NCR sentence changed');
  });
  t('a frozen report refuses a CI or RFV mapping change', () => {
    const c = mk({ isLocked: true, ciManualMap: { ciId: 2, pn: 0, nh: 1 } });
    vm.runInContext("setSuppMappingMode('ci', 'default'); openSuppManualMap('rfv')", c);
    eq(c.state.ciManualMap, { ciId: 2, pn: 0, nh: 1 }, 'map kept:');
    eq(c.MAPPER, undefined, 'window opened:');
    eq(c.TOASTS.filter(m => /frozen/.test(m)).length, 2);
  });
  t('a session carries a CI or RFV map only when one is set; import and Reset restore the buttons', () => {
    const ex = grabFn('exportSessionJson'), im = grabFn('importSessionJson'), rs = grabFn('resetAll');
    ['ci', 'rfv'].forEach(b => {
      const k = b + 'ManualMap';
      if (!new RegExp(k + ':\\s*state\\.' + k + '\\s*\\|\\|\\s*undefined,').test(ex)) throw new Error(k + ' is not written only when set');
      if (!new RegExp('state\\.' + k + '\\s*=\\s*payload\\.' + k + '\\s*\\|\\|\\s*null;').test(im)) throw new Error(k + ' not restored as null when absent');
      if (im.indexOf("refreshSuppMappingUI('" + b + "')") < 0) throw new Error('import does not refresh the ' + b + ' buttons');
      if (rs.indexOf("refreshSuppMappingUI('" + b + "')") < 0) throw new Error('Reset does not refresh the ' + b + ' buttons');
    });
    if (!/\['chp','ncr','acn','ci','rfv'\]\.forEach\(b => \{ const h = document\.getElementById\(b \+ '-cm-reparse-hint'\)/.test(rs)) throw new Error('Reset leaves a CI / RFV re-upload hint showing');
    // JSON.stringify drops undefined: a default session is v185's file.
    eq(JSON.stringify({ a: 1, ciManualMap: null || undefined }), '{"a":1}');
  });
  t('the column mapping reference names the Manual option and the required fields for CI and RFV', () => {
    const ref = SRC.slice(at('const COL_MAP_DATA = {'), at('function openColMapModal'));
    const c = mk();
    ['ci', 'rfv'].forEach(b => {
      const blk = ref.slice(ref.indexOf('\n  ' + b + ': {'), ref.indexOf('cols:', ref.indexOf('\n  ' + b + ': {')));
      if (blk.indexOf('a Manual column-mapping option is available on the upload zone') < 0) throw new Error(b + ': no Manual note');
      defs(c, b).filter(d => d.required).forEach(d => { if (blk.indexOf(d.label) < 0) throw new Error(b + ' note misses ' + d.label); });
    });
  });
});

// ── TIER 25 ────────────────────────────────────────────────────────────────
// v187 — headings over re-laid rows (KI-3, KI-4) and a readable mapping box.
// A manual map, or Mapping 2, copies each source row into the default COL
// positions at upload. The file's own header row describes the file, not those
// positions, so every surface that printed it over the rows put headings over
// the wrong data. Each surface now asks sourceHeaderLabel / sourceHeaderRow,
// which return the file's header untouched when the rows are as uploaded.
suite('Tier 25 — headings over re-laid rows', (t, eq) => {
  const FNS = ['sourceHeaderLabel', 'sourceHeaderRow', '_sourceIsReLaid', '_sourceFieldDefs', '_ebomFieldDefs',
               '_bomManualFieldDefs', '_suppManualFieldDefsBase', 'safeColCount'];
  const mk = st => {
    const c = sandbox({ COL: REAL_COL, state: Object.assign({ boms: {} }, st || {}) }, []);
    vm.runInContext(FNS.map(grabFn).join('\n'), c);
    return c;
  };
  const s0 = at('const state = {');
  const MAPS = [...SRC.slice(s0, SRC.indexOf('\n};', s0)).matchAll(/\b([a-z]+)ManualMap:/g)].map(m => m[1]);

  console.log('\n== Rows as uploaded: nothing changes ==');
  t('with no map and Mapping 1, every source keeps its own header row, the same array', () => {
    const c = mk({ ebomColumnMapping: 1, abomColumnMapping: 1 });
    MAPS.concat(['wo5']).forEach(b => {
      const bom = { header: ['h0', 'h1', ''], data: [['a', 'b', 'c', 'd']] };
      c.B = bom; c.T = b;
      if (!vm.runInContext('sourceHeaderRow(T, B) === B.header', c)) throw new Error(b + ': not the file header row');
      eq(vm.runInContext('[0, 2, 3].map(i => sourceHeaderLabel(T, B, i))', c), ['h0', '', undefined], b + ':');
    });
  });

  console.log('\n== Re-laid rows: headings name the field ==');
  t('every source with a manual map is re-laid, and so are EBOM and ABOM under Mapping 2; WO5 never', () => {
    if (MAPS.length < 9) throw new Error('only ' + MAPS.length + ' manual maps found in state');
    MAPS.forEach(b => {
      if (!vm.runInContext('_sourceIsReLaid(' + JSON.stringify(b) + ')', mk({ [b + 'ManualMap']: { pn: 0 } }))) throw new Error(b + ' manual map not seen');
      if (vm.runInContext('_sourceIsReLaid(' + JSON.stringify(b) + ')', mk())) throw new Error(b + ' re-laid with no map');
    });
    ['ebom', 'abom'].forEach(b => {
      if (!vm.runInContext('_sourceIsReLaid(' + JSON.stringify(b) + ')', mk({ [b + 'ColumnMapping']: 2 }))) throw new Error(b + ' Mapping 2 not seen');
    });
    if (vm.runInContext("_sourceIsReLaid('mbom')", mk({ abomColumnMapping: 2, ebomColumnMapping: 2 }))) throw new Error('MBOM has no Mapping 2');
    if (vm.runInContext("_sourceIsReLaid('wo5')", mk({ wo5ManualMap: { a: 1 } }))) throw new Error('WO5 has no column mapping');
  });
  t('every COL position of every mappable source is headed by its mapping-window label', () => {
    MAPS.forEach(b => {
      const c = mk({ [b + 'ManualMap']: { pn: 0 } });
      const defs = vm.runInContext('_sourceFieldDefs(' + JSON.stringify(b) + ')', c);
      Object.keys(REAL_COL[b]).forEach(k => {
        const d = defs.find(x => x.key === k);
        if (!d) throw new Error(b + '.' + k + ' has no field label');
        c.B = { header: ['FILE HEADING'], data: [] }; c.I = REAL_COL[b][k];
        eq(vm.runInContext('sourceHeaderLabel(' + JSON.stringify(b) + ', B, I)', c), d.label, b + '.' + k + ':');
      });
    });
  });
  t('an export heading row is as wide as the re-laid rows, with \u2014 where no field sits (never a column letter)', () => {
    const c = mk({ ciManualMap: { ciId: 2, pn: 0, nh: 1 } });
    c.B = { header: ['PN', 'NH', 'junk', 'CI', 'more', 'and more'], data: [['CI-1', 'P1', 'A', '', ''], ['CI-2', 'P2', 'A']] };
    eq(vm.runInContext("sourceHeaderRow('ci', B)", c), ['CI Identifier', 'Part Number', 'Next Higher Part Number', '—', '—']);
  });

  console.log('\n== Every surface asks the one helper ==');
  t('the EBOM / MBOM / ABOM, Change Pedigree and NCR tabs head their columns through sourceHeaderLabel', () => {
    [['renderFullBom', 'type'], ['renderChpTable', "'chp'"], ['renderNcrTable', "'ncr'"]].forEach(([fn, ty]) => {
      const b = grabFn(fn);
      if (!b.includes('safeColCount(_sourceIsReLaid(' + ty + ') ? null : bom.header, bom.data)')) throw new Error(fn + ': column count still reads the file header over re-laid rows');
      if (/bom\.header\[i\]/.test(b)) throw new Error(fn + ' reads bom.header[i] directly');
    });
    if (!/sourceHeaderLabel\(type, bom, i\)/.test(grabFn('renderFullBom'))) throw new Error('renderFullBom');
    if (!/sourceHeaderLabel\('ncr', bom, i\)/.test(grabFn('renderNcrTable'))) throw new Error('renderNcrTable');
    if (!/chpTabHeaderLabel\(/.test(grabFn('renderChpTable'))) throw new Error('renderChpTable');
    // WO5 has no mapping, so its tab may keep reading the file header.
    const rest = stripComments(SRC.replace(grabFn('sourceHeaderLabel'), '').replace(grabFn('renderWo5Table'), ''));
    const hits = (rest.match(/bom\.header\[i\]/g) || []).length;
    eq(hits, 0, 'bom.header[i] read outside the helper and the WO5 tab:');
  });
  t('the Excel export’s raw sheets take their heading row from sourceHeaderRow (KI-4)', () => {
    const b = grabFn('exportXLSX');
    const raw = b.slice(b.indexOf('if (includeRaw)'), b.indexOf('XLSX.writeFile'));
    if (!/const srcHdr = sourceHeaderRow\(type, bom\);/.test(raw)) throw new Error('no sourceHeaderRow in the raw-sheet loop');
    if (/bom\.header/.test(raw)) throw new Error('the raw-sheet loop still reads bom.header');
    if (!/const hdrRow = \[\.\.\.srcHdr\];/.test(raw) || !/sheetData = \[srcHdr, \.\.\.bom\.data\];/.test(raw)) throw new Error('NCR and other sheets');
  });

  console.log('\n== The mapping box shows its default ==');
  t('all three mapping windows use one input class, wide enough for "DEFAULT: AAA"', () => {
    ['openEbomManualMap', '_openBomManualMap', 'openSuppManualMap'].forEach(fn => {
      const b = grabFn(fn);
      if (!/placeholder="default: \$\{defLetter\}"[\s\S]{0,120}class="map-col-input"/.test(b)) throw new Error(fn + ' does not use .map-col-input');
      if (/width:\s*90px/.test(b)) throw new Error(fn + ' still writes a 90px box');
    });
    const css = STYLE_BLOCKS.map(x => x.css).join('\n');
    const m = css.match(/\.map-col-input\s*\{[^}]*width:\s*calc\((\d+)ch \+ (\d+)px\)/);
    if (!m) throw new Error('no width for .map-col-input');
    if (+m[1] < 'DEFAULT: AAA'.length) throw new Error(m[1] + 'ch is narrower than the longest placeholder');
    const pad = css.match(/\.map-col-input\s*\{[^}]*padding:\s*\d+px (\d+)px/);
    if (!pad || +m[2] < 2 * +pad[1] + 2) throw new Error('the px allowance does not cover padding and border');
    if (!/\.map-col-input\s*\{[^}]*font-family:\s*var\(--mono\)/.test(css)) throw new Error('ch only measures a glyph in a mono face');
  });
});

// ── TIER 26 ────────────────────────────────────────────────────────────────
// Delta v3.7 — EBOM to EBOM. Two EBOM Excel files compared directly, with no
// Comparator run. "Line item" must mean exactly what it means in Comparator,
// so the rules are not restated here: each is checked against the main build's
// own code. The four map builders, normIndenture and the column-letter helpers
// are verbatim copies; the upload (filter + re-lay) and the Manual map's rules
// are run side by side with the main build's functions on the same input.
suite('Tier 26 — delta tool EBOM to EBOM', (t, eq) => {
  const dsrc = (() => {
    const a = DSRC.indexOf('// v3.7 — EBOM TO EBOM\n// Two EBOM Excel files');
    const b = DSRC.indexOf("if (typeof document !== 'undefined') {", a);
    if (a < 0 || b < 0) throw new Error('BUILD MARKER MOVED in delta tool: v3.7 EBOM TO EBOM block');
    return DSRC.slice(DSRC.lastIndexOf('// ═══', a), b);
  })();
  const dv = (DSRC.match(/var DELTA_VERSION = '[^']+';/) || [''])[0];
  const E = (() => {
    const c = sandbox({}, []);
    vm.runInContext(dv + '\n' + grabDelta('normPN') + '\n' + dsrc +
      '\nglobalThis.E = { EBOM_COL, EBOM_FIELDS, EBOM_DIFF_FIELDS, ebomRowsFromRaw, ebomManualFromLetters, ebomMappingLabel, ebomLineItems, ebomFileDelta, ebomDeltaSummary, ebomSimilarityText, ebomPanelsHtml, DELTA_VERSION };', c, { filename: 'delta-ebom.js' });
    return c.E;
  })();
  // The main build's EBOM upload and Manual-map save, run in a sandbox.
  const main = st => {
    const c = sandbox({ COL: REAL_COL, state: Object.assign({ boms: {}, ebomColumnMapping: 1, ebomManualMap: null }, st || {}),
      _chpIngestKeyCol: () => REAL_COL.chp.pn, renderProcCodePanel: () => {}, renderIndenturePanel: () => {},
      refreshEbomMappingUI: () => {}, _closeMapper: () => {} }, []);
    vm.runInContext(['_reparseBomFromRaw', '_applySuppManualMap', '_saveEbomManualMap', '_ebomFieldDefs', 'colLetterToIndex',
                     'normPN', 'normIndenture', 'buildQtyMap', 'buildEbomQtyTextMap', 'buildEbomCageMap', 'buildEbomLineNoMap', 'buildEbomIndentureMap'].map(grabFn).join('\n'), c);
    return c;
  };
  const W = 30;
  const raw2 = rows => [new Array(W).fill('').map((_, i) => 'H' + i)].concat(rows.map(o => { const r = new Array(W).fill(''); Object.keys(o).forEach(k => { r[k] = o[k]; }); return r; }));

  console.log('\n== The same rules as Comparator ==');
  t('the copied builders are the main build’s, character for character', () => {
    ['normIndenture', 'buildQtyMap', 'buildEbomQtyTextMap', 'buildEbomCageMap', 'buildEbomLineNoMap', 'colLetterToIndex', 'colIndexToLetter'].forEach(f => {   // v189 — + buildEbomCageMap
      if (grabDelta(f) !== grabFn(f)) throw new Error(f + ' in the delta tool differs from the main build');
    });
    if (grabDelta('normPN').replace(/\s+/g, '') === '') throw new Error('no normPN');
    ['p1 ', ' P1', 'p-1', null, undefined, 12].forEach(v => {
      const c = main(); c.V = v;
      const d = sandbox({}, []); vm.runInContext(grabDelta('normPN'), d); d.V = v;
      eq(vm.runInContext('normPN(V)', d), vm.runInContext('normPN(V)', c), 'normPN(' + JSON.stringify(v) + '):');
    });
  });
  t('the default layout and the mapping-window fields are the main build’s', () => {
    eq(JSON.parse(JSON.stringify(E.EBOM_COL)), REAL_COL.ebom, 'EBOM_COL vs COL.ebom:');
    eq(JSON.parse(JSON.stringify(E.EBOM_FIELDS)), vm.runInContext('_ebomFieldDefs()', main()), 'EBOM_FIELDS vs _ebomFieldDefs():');
  });
  t('rows are read as the main build reads an EBOM: Mapping 1, Mapping 2 and a Manual map', () => {
    // v189 — CAGE in G (Mapping 2), Q (Mapping 1) and W (the Manual map below).
    const rows = [{ 0: 'A', 1: 'TOP', 2: 'top', 3: 'x', 7: 1, 29: '' }, { 0: 'B', 1: 'P1', 2: 'd1', 5: 'A', 6: 'GGGGG', 7: 'PART', 10: '2', 11: 2, 16: 'QQQQQ', 22: 'WWWWW', 29: 'TOP' },
                  { 1: '', 2: 'no part', 29: 'TOP' }, { 0: '3', 1: 'p2 ', 3: 'TOP', 7: 4, 8: 'AR', 10: 'B', 11: 5, 29: 'P1' }];
    const raw = raw2(rows);
    const manual = { indenture: 0, pn: 1, desc: 2, nh: 29, qty: 11, qtyText: 10, drawingRev: 5, partType: 7, cage: 22 };
    const cageSeen = [];
    [[1, null, {}], [2, null, { ebomColumnMapping: 2 }], ['manual', manual, { ebomManualMap: manual }]].forEach(([m, mm, st]) => {
      const c = main(st); c.state.boms.ebom = { raw, data: [] };
      vm.runInContext("_reparseBomFromRaw('ebom')", c);
      eq(E.ebomRowsFromRaw(raw, m, mm), c.state.boms.ebom.data, 'mapping ' + m + ':');
      cageSeen.push(E.ebomRowsFromRaw(raw, m, mm)[1][REAL_COL.ebom.cage]);
    });
    eq(cageSeen, ['QQQQQ', 'GGGGG', 'WWWWW'], 'CAGE read from Q, G and the Manual pick:');
  });
  t('a Manual map from typed letters follows the main build’s window: defaults, refusals and their words', () => {
    const cases = [{ pn: 'D', nh: 'f', qty: 'H' }, { pn: '' }, { pn: 'B', nh: 'b' }, { pn: 'B', qty: '1x' }];
    cases.forEach(L => {
      const c = main();
      vm.createContext(c);
      E.EBOM_FIELDS.forEach(d => { c.__els['ebom-map-' + d.key] = { value: L[d.key] || '' }; });
      vm.runInContext('_saveEbomManualMap()', c);
      const r = E.ebomManualFromLetters(L);
      const mainErr = (c.__els['ebom-map-error'] || {}).textContent || '';
      if (mainErr) eq(r.error, mainErr, JSON.stringify(L) + ' refusal:');
      else eq(r.map, JSON.parse(JSON.stringify(c.state.ebomManualMap)), JSON.stringify(L) + ' map:');
    });
  });
  t('a line item is Comparator’s: duplicates merged, quantities summed, last quantity text, first indenture and drawing PL rev, every line number', () => {
    const C = REAL_COL.ebom;
    const row = o => { const r = new Array(26).fill(''); Object.keys(o).forEach(k => { r[C[k]] = o[k]; }); return r; };
    const data = [row({ indenture: 'A', pn: 'TOP', qty: 1 }), row({ indenture: '3', pn: 'p1', nh: 'top', qty: 2, qtyText: '2', drawingRev: '' }),
                  row({ indenture: 'D', pn: 'P1 ', nh: 'TOP', qty: 1.1, qtyText: 'AR', drawingRev: 'B' }), row({ indenture: 'C', pn: 'P1', nh: 'TOP', qty: 'x', qtyText: '', drawingRev: 'C', desc: 'later' })];
    const it = E.ebomLineItems(data);
    eq(it.order, ['TOP||', 'P1||TOP']);
    const p = it.items['P1||TOP'];
    const c = main(); c.D = data;
    const m = vm.runInContext('({ q: buildQtyMap(D, 1, 3, 7, true), t: buildEbomQtyTextMap(D, 1, 3, 8), l: buildEbomLineNoMap(D, 1, 3), i: buildEbomIndentureMap(D, 0, 1, 3) })', c);
    eq(p.qty, Number(m.q['P1||TOP'].toFixed(6)), 'qty, the engine’s sum:');
    eq(p.qty, 3.1);
    eq([p.qtyText, p.lineNos], [m.t['P1||TOP'], m.l['P1||TOP']], 'qty text and line numbers:');
    eq(p.indenture, m.i.keyInfo['P1||TOP'].indenture, 'indenture, as the main build’s indenture map keeps it:');
    eq([p.indenture, p.drawingRev, p.desc, it.rows], ['C', 'B', 'later', 4]);
  });

  console.log('\n== What counts as a change ==');
  const C = REAL_COL.ebom;
  const R = o => { const r = new Array(26).fill(''); Object.keys(o).forEach(k => { r[C[k]] = o[k]; }); return r; };
  const items = list => E.ebomLineItems(list.map(R));
  const base = [{ indenture: 'A', pn: 'TOP' }, { indenture: 'B', pn: 'ASM1', nh: 'TOP', qty: 1 },
                { indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 2, qtyText: '2', drawingRev: 'A', desc: 'bracket' }];
  t('two identical EBOMs: no rows, every line item unchanged', () => {
    const d = E.ebomFileDelta(items(base), items(base));
    eq([d.rows.length, d.unchanged, d.linesA, d.linesB], [0, 3, 3, 3]);
  });
  t('quantity, quantity text, indenture and drawing PL rev are each reported, together on one line', () => {
    const b = base.slice(0, 2).concat([{ indenture: 'D', pn: 'P1', nh: 'ASM1', qty: 3, qtyText: 'AR', drawingRev: 'B', desc: 'bracket' }]);
    const r = E.ebomFileDelta(items(base), items(b)).rows;
    eq(r.length, 1);
    eq([r[0]['Change Type'], r[0]['Fields Changed'], r[0]['Old Qty'], r[0]['New Qty'], r[0]['Old Qty Text'], r[0]['New Qty Text'],
        r[0]['Old Indenture'], r[0]['New Indenture'], r[0]['Old Drawing PL Rev'], r[0]['New Drawing PL Rev']],
       ['Changed', 'Qty; Qty Text; Indenture; Drawing PL Rev', 2, 3, '2', 'AR', 'C', 'D', 'A', 'B']);
  });
  t('spelling that Comparator reads as the same is not a change: case, spaces, 3 for C, "ar" for AR; description is not compared', () => {
    const a = base.slice(0, 2).concat([{ indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 2, qtyText: 'ar', drawingRev: 'a', desc: 'bracket' }]);
    const b = base.slice(0, 2).concat([{ indenture: '3', pn: ' p1', nh: 'asm1 ', qty: '2', qtyText: 'AR ', drawingRev: 'A', desc: 'BRACKET, LH' }]);
    eq(E.ebomFileDelta(items(a), items(b)).rows, []);
  });
  t('a part moved to a new next higher is one Re-parented line, matched one to one', () => {
    const a = base.concat([{ indenture: 'C', pn: 'P9', nh: 'ASM1', qty: 1 }, { indenture: 'C', pn: 'P9', nh: 'TOP', qty: 1 }]);
    const b = base.concat([{ indenture: 'C', pn: 'P9', nh: 'ASM2', qty: 4 }]);
    const r = E.ebomFileDelta(items(a), items(b)).rows;
    eq(r.map(x => [x['Change Type'], x['Old Next Higher'], x['New Next Higher'], x['Fields Changed']]),
       [['Re-parented', 'ASM1', 'ASM2', 'Qty'], ['Removed', 'TOP', '', '']], 'BOM order: the removed position follows the line it followed in A:');
  });
  t('added and removed lines, in BOM order, with both files’ line numbers', () => {
    const a = base.concat([{ indenture: 'C', pn: 'P2', nh: 'ASM1', qty: 1 }]);
    const b = base.slice(0, 2).concat([{ indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 5, qtyText: '2', drawingRev: 'A' }, { indenture: 'C', pn: 'P3', nh: 'ASM1', qty: 1 }]);
    const d = E.ebomFileDelta(items(a), items(b));
    eq(d.rows.map(x => x['Change Type'] + ':' + x['Part Number']), ['Changed:P1', 'Removed:P2', 'Added:P3']);
    eq([d.rows[1]['Line No(s) A'], d.rows[1]['Line No(s) B'], d.rows[2]['Line No(s) B']], ['4', '', '4']);
    eq(d.counts, { Removed: 1, 'Re-parented': 0, Changed: 1, Added: 1 });
    eq(d.fieldCounts, { Qty: 1, 'Qty Text': 0, Indenture: 0, 'Drawing PL Rev': 0, 'CAGE Code': 0 });   // v3.9
  });
  t('v3.9: a CAGE code change is a changed field, with the old and new codes; a line item’s code is Comparator’s', () => {
    const a = base.slice(0, 2).concat([{ indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 2, qtyText: '2', drawingRev: 'A', cage: '81205' }]);
    const b = base.slice(0, 2).concat([{ indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 2, qtyText: '2', drawingRev: 'A', cage: '1ABC2' }]);
    const d = E.ebomFileDelta(items(a), items(b));
    eq(d.rows.map(r => [r['Change Type'], r['Fields Changed'], r['Old CAGE Code'], r['New CAGE Code']]), [['Changed', 'CAGE Code', '81205', '1ABC2']]);
    eq(d.fieldCounts['CAGE Code'], 1);
    const keys = Object.keys(d.rows[0]);
    eq(keys.slice(keys.indexOf('New Drawing PL Rev') + 1, keys.indexOf('Line No(s) A')), ['Old CAGE Code', 'New CAGE Code'], 'report columns:');
    // A code appearing or disappearing is a change too.
    eq(E.ebomFileDelta(items(base), items(b)).rows.map(r => [r['Fields Changed'], r['Old CAGE Code'], r['New CAGE Code']]), [['CAGE Code', '', '1ABC2']]);
    // Merged lines: the item carries what the main build's own map gives.
    const merged = [{ indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 1, cage: '81205' }, { indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 1, cage: '0XY34' }, { indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 1, cage: '0xy34' }];
    const c = main(); c.D = merged.map(R);
    eq(items(merged).items['P1||ASM1'].cage, vm.runInContext('buildEbomCageMap(D, 1, 3, 16)', c)['P1||ASM1'], 'against the main build:');
    eq(items(merged).items['P1||ASM1'].cage, '81205; 0XY34');
  });
  t('v3.9: the same set of codes is not a change, whatever the line order or letter case; a code added to the set is', () => {
    const L = cage => ({ indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 1, cage });
    const a = base.slice(0, 2).concat([L('81205'), L('0XY34')]);
    const b = base.slice(0, 2).concat([L('0xy34 '), L('81205')]);
    eq(E.ebomFileDelta(items(a), items(b)).rows, []);
    const c2 = base.slice(0, 2).concat([L('81205'), L('0XY34'), L('K1234')]);
    eq(E.ebomFileDelta(items(a), items(c2)).rows.map(r => [r['Fields Changed'], r['Old CAGE Code'], r['New CAGE Code']]), [['Qty; CAGE Code', '81205; 0XY34', '81205; 0XY34; K1234']]);
  });
  t('the Summary names both files and mappings, counts every change type and field, and the tool version', () => {
    const d = E.ebomFileDelta(items(base), items(base.concat([{ indenture: 'C', pn: 'P3', nh: 'ASM1' }])));
    const s = E.ebomDeltaSummary(d, { fileA: 'a.xlsx', fileB: 'b.xlsx', mapA: 'Mapping 1', mapB: E.ebomMappingLabel(2) });
    const by = Object.fromEntries(s.map(r => [r.Metric, r]));
    eq([by.File['EBOM A'], by.File['EBOM B'], by['Column mapping']['EBOM B']], ['a.xlsx', 'b.xlsx', 'Mapping 2']);
    eq([by['Line items (part number + next higher)'].Change, by['Line items added'].Change, by['Line items unchanged'].Change], ['+1', '1', '3']);
    E.EBOM_DIFF_FIELDS.forEach(f => { if (!by[f.label + ' changed (changed and re-parented lines)']) throw new Error('no row for ' + f.label); });
    eq(by['Delta tool version']['EBOM A'], E.DELTA_VERSION);
    if (!/^Manual \(Indenture Code A, Part Number D,/.test(E.ebomMappingLabel('manual', Object.assign({}, E.EBOM_COL, { pn: 3, nh: 1 })))) throw new Error('manual label');
  });

  // v3.8 — BOM order, change apex, similarity, panels (owner's poll 2026-10-21).
  console.log('\n== v3.8: BOM order, change apex, similarity ==');
  const L = (ind, pn, nh, qty, o) => Object.assign({ indenture: ind, pn, nh, qty: qty == null ? 1 : qty }, o || {});
  t('BOM order: B’s line order, each removed line after the line it followed in A, in A order, first when nothing precedes it', () => {
    const a = [L('A', 'X0', 'TOP'), L('A', 'TOP', ''), L('B', 'ASM1', 'TOP'), L('C', 'R1', 'ASM1'), L('C', 'R2', 'ASM1'), L('C', 'K1', 'ASM1'), L('C', 'R3', 'ASM1')];
    const b = [L('A', 'TOP', ''), L('B', 'N0', 'TOP'), L('B', 'ASM1', 'TOP', 2), L('C', 'K1', 'ASM1')];
    const r = E.ebomFileDelta(items(a), items(b)).rows.map(x => x['Change Type'][0] + ':' + x['Part Number']);
    eq(r, ['R:X0', 'A:N0', 'C:ASM1', 'R:R1', 'R:R2', 'R:R3']);
  });
  t('the change apex climbs while the parent differs, of any change type, and stops at an unchanged parent', () => {
    const a = [L('A', 'TOP', ''), L('B', 'ASM1', 'TOP'), L('C', 'SUB1', 'ASM1'), L('D', 'P1', 'SUB1'), L('B', 'ASM2', 'TOP'), L('C', 'P2', 'ASM2')];
    const b = [L('A', 'TOP', ''), L('B', 'ASM1', 'TOP', 3), L('C', 'SUB1', 'ASM1', 1, { drawingRev: 'B' }), L('D', 'P1', 'SUB1', 5), L('D', 'P9', 'SUB1'),
               L('B', 'ASM2', 'TOP'), L('C', 'P2', 'ASM2', 4)];
    const d = E.ebomFileDelta(items(a), items(b));
    const by = Object.fromEntries(d.rows.map(x => [x['Part Number'], [x['Change Apex'], x['Is Apex']]]));
    eq(by, { ASM1: ['ASM1', 'Y'], SUB1: ['ASM1', ''], P1: ['ASM1', ''], P9: ['ASM1', ''], P2: ['P2', 'Y'] });
    eq(d.apexes.map(x => [x['Change Apex'], x['Lines Changed in Subtree'], x.Changed, x.Added]), [['ASM1', 4, 3, 1], ['P2', 1, 1, 0]]);
  });
  t('a removed line climbs file A’s tree; a re-parented line climbs B’s from its new position', () => {
    const a = [L('A', 'TOP', ''), L('B', 'ASM1', 'TOP'), L('C', 'P1', 'ASM1'), L('C', 'P2', 'ASM1'), L('B', 'ASM2', 'TOP')];
    const b = [L('A', 'TOP', ''), L('B', 'ASM2', 'TOP', 2), L('C', 'P2', 'ASM2')];
    const by = Object.fromEntries(E.ebomFileDelta(items(a), items(b)).rows.map(x => [x['Change Type'] + ':' + x['Part Number'], x['Change Apex']]));
    eq(by, { 'Removed:ASM1': 'ASM1', 'Removed:P1': 'ASM1', 'Changed:ASM2': 'ASM2', 'Re-parented:P2': 'ASM2' }, 'apex per row, in BOM order:');
  });
  t('a parent at two positions differs when either line does; a looping tree still ends', () => {
    const a = [L('A', 'TOP', ''), L('B', 'ASM1', 'TOP'), L('B', 'ASM1', 'ALT'), L('C', 'P1', 'ASM1')];
    const b = [L('A', 'TOP', ''), L('B', 'ASM1', 'TOP'), L('B', 'ASM1', 'ALT', 7), L('C', 'P1', 'ASM1', 2)];
    const by = Object.fromEntries(E.ebomFileDelta(items(a), items(b)).rows.map(x => [x['Part Number'] + '/' + x['New Next Higher'], x['Change Apex']]));
    eq(by['P1/ASM1'], 'ASM1', 'ASM1 differs at ALT, so P1 climbs to it:');
    const loop = [L('C', 'X', 'Y'), L('C', 'Y', 'X')];
    const d = E.ebomFileDelta(items(loop), items(loop.map(x => Object.assign({}, x, { qty: 2 }))));
    eq(d.rows.length, 2, 'a two-part loop:');
    d.rows.forEach(x => { if (!x['Change Apex']) throw new Error('no apex on a looping row'); });
  });
  t('similarity is identical line items of all distinct line items, never shown as 100% while anything differs', () => {
    const same = E.ebomFileDelta(items(base), items(base));
    eq([E.ebomSimilarityText(same), same.totalLines], ['100.0%', 3]);
    const b = base.slice(0, 2).concat([{ indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 3, qtyText: '2', drawingRev: 'A' }, { indenture: 'C', pn: 'P7', nh: 'ASM1' }]);
    const d = E.ebomFileDelta(items(base), items(b));
    eq([d.unchanged, d.differing, d.totalLines, E.ebomSimilarityText(d)], [2, 2, 4, '50.0%']);
    const big = Array.from({ length: 3000 }, (_, i) => ({ indenture: 'C', pn: 'Q' + i, nh: 'TOP' }));
    const one = E.ebomFileDelta(items(big), items(big.slice(0, 2999).concat([{ indenture: 'C', pn: 'Q2999', nh: 'TOP', qty: 9 }])));
    eq(E.ebomSimilarityText(one), '99.9%', '2999 of 3000 rounds to 100.0, and must not:');
    const sum = Object.fromEntries(E.ebomDeltaSummary(d, {}).map(r => [r.Metric, r.Change]));
    eq(sum['Similarity (identical line items, of all distinct line items)'], '50.0% (2 of 4)');
    eq(sum['Change apexes (tops of changed subtrees)'], String(d.apexes.length));
  });
  t('the panels show the similarity, each count and the apexes, with a strip whose shares are the counts and no purple', () => {
    const b = base.slice(0, 2).concat([{ indenture: 'C', pn: 'P1', nh: 'ASM1', qty: 3, qtyText: '2', drawingRev: 'A' }, { indenture: 'C', pn: 'P7', nh: 'ASM1' }]);
    const d = E.ebomFileDelta(items(base), items(b));
    const h = E.ebomPanelsHtml(d);
    const nums = [...h.matchAll(/class="e-panel ([\w-]+)( zero)?"[^>]*><div class="e-num">([^<]*)</g)].map(m => [m[1], m[3]]);
    eq([...h.matchAll(/class="e-panel ([\w-]+) zero"/g)].map(m => m[1]), ['p-removed', 'p-moved'], 'zeros are neutral:');
    eq(nums, [['p-sim', '50.0%'], ['p-diff', '2'], ['p-removed', '0'], ['p-moved', '0'], ['p-changed', '1'], ['p-added', '1'], ['p-apex', String(d.apexes.length)]]);
    eq([...h.matchAll(/<span class="(seg-[a-z]+)" style="flex-grow:(\d+)"/g)].map(m => m[1] + ':' + m[2]), ['seg-same:2', 'seg-changed:1', 'seg-added:1'], 'strip (empty shares left out):');
    const css = DSRC.slice(DSRC.indexOf('/* v3.8 — EBOM delta panels'), DSRC.indexOf('.map-manual .map-note {'));
    if (!css.length || /--adj/.test(css)) throw new Error('panel styles missing, or purple used (it means a human decision)');
    const page = DSRC.slice(DSRC.indexOf('// ── v3.7 — EBOM TO EBOM (the page)'), DSRC.indexOf("document.addEventListener('DOMContentLoaded'"));
    if (!/ebomPanelsHtml\(d\)/.test(page) || !/'Change Apexes'\);/.test(page)) throw new Error('panels or apex sheet not wired');
  });

  console.log('\n== The page ==');
  t('two modes; the sessions report keeps every control it had; the EBOM pane has its own cards, mapping and buttons', () => {
    const body = DSRC.slice(DSRC.indexOf('<main>'), DSRC.indexOf('</main>'));
    ['id="mode-sessions"', 'id="mode-ebom"', 'id="pane-sessions"', 'id="pane-ebom" hidden',
     'id="A-file"', 'id="B-file"', 'id="run-btn"', 'id="export-btn"', 'id="swap-btn"', 'id="results"',
     'id="eA-file" accept=".xlsx,.xls"', 'id="eB-file" accept=".xlsx,.xls"', 'id="eA-map"', 'id="eB-map"', 'id="eA-manual"', 'id="eB-manual"',
     'id="e-run-btn"', 'id="e-export-btn"', 'id="e-swap-btn"', 'id="e-results"'].forEach(x => {
      if (body.indexOf(x) < 0) throw new Error('missing ' + x);
    });
    const ps = body.slice(body.indexOf('id="pane-sessions"'), body.indexOf('id="pane-ebom"'));
    if (ps.indexOf('id="run-btn"') < 0 || ps.indexOf('id="e-run-btn"') >= 0) throw new Error('the panes are mixed');
    ['<option value="1">Mapping 1</option>', '<option value="2">Mapping 2</option>', '<option value="manual">Manual…</option>'].forEach(o => {
      if ((body.split(o).length - 1) !== 2) throw new Error('each card offers ' + o);
    });
    if (!/\[hidden\]\s*\{\s*display:\s*none !important;/.test(DSRC)) throw new Error('a hidden pane could still show (display rules beat [hidden])');
  });
  t('a file read with the main build’s options, refused in words when nothing has a part number, and two sheets exported', () => {
    const page = DSRC.slice(DSRC.indexOf('// ── v3.7 — EBOM TO EBOM (the page)'), DSRC.indexOf("document.addEventListener('DOMContentLoaded'"));
    if (!/XLSX\.read\(new Uint8Array\(ev\.target\.result\), \{ type: 'array', cellDates: true \}\)/.test(page)) throw new Error('not read as the main build reads an upload');
    if (!/sheet_to_json\(ws, \{ header: 1, defval: '' \}\)/.test(page)) throw new Error('rows not read with header: 1, defval: \'\'');
    if (!/no row has a part number in column/.test(page)) throw new Error('no refusal in words');
    if (!/book_append_sheet\(wb, [^;]*'Summary'\);/.test(page) || !/book_append_sheet\(wb, [^;]*'EBOM Changes'\);/.test(page)) throw new Error('export sheets');
    if (!/_eReread\(slot\);/.test(grabFrom(page, '_eOnMapChange', 'delta page'))) throw new Error('a mapping change does not re-read the loaded file');
  });
});

// ── TIER 27 ────────────────────────────────────────────────────────────────
// v189 — CAGE code. The EBOM carries a CAGE code per line (column Q in Mapping
// 1, G in Mapping 2, or a Manual pick). The owner asked for it in the
// Comparison Summary and its exports, the CI Traceability Report, the EBOM Full
// view and both gap reports. It is display data: the engine never reads it, so
// no result, KPI, session result row or certificate hash can depend on it.
// What can go wrong is the usual: one of the two copies of the upload re-lay
// forgets the field; a header list gains the column and its row builder does
// not; a report that sorts by a counted column position sorts on the wrong
// column. The browser suite runs every surface; these tests pin the rules.
suite('Tier 27 — CAGE code', (t, eq) => {
  const C = REAL_COL.ebom;
  const mk = st => {
    const c = sandbox({ COL: REAL_COL, state: Object.assign({ boms: {}, ebomColumnMapping: 1, ebomManualMap: null }, st || {}),
      _chpIngestKeyCol: () => REAL_COL.chp.pn, renderProcCodePanel: () => {}, renderIndenturePanel: () => {},
      refreshEbomMappingUI: () => {}, _closeMapper: () => {} }, []);
    vm.runInContext(['_reparseBomFromRaw', '_applySuppManualMap', '_saveEbomManualMap', '_ebomFieldDefs', 'colLetterToIndex', 'colIndexToLetter',
                     'normPN', 'buildEbomCageMap', 'ebomCageForKey', 'ebomCageForLine'].map(grabFn).join('\n') +
                    '\nlet _ebomCageCache = { data: null, map: {} };', c);
    return c;
  };
  const W = 32;
  const raw = rows => [new Array(W).fill('').map((_, i) => 'H' + i)].concat(rows.map(o => { const r = new Array(W).fill(''); Object.keys(o).forEach(k => { r[k] = o[k]; }); return r; }));
  const load = (st, rows) => { const c = mk(st); c.state.boms.ebom = { raw: raw(rows), data: [] }; vm.runInContext("_reparseBomFromRaw('ebom')", c); return c; };
  const fnBody = n => stripComments(grabFn(n));

  console.log('\n== Where the code is read from ==');
  t('the default layout holds CAGE in column Q, a position no other EBOM field uses', () => {
    eq(C.cage, 16);
    eq(vm.runInContext('colIndexToLetter(COL.ebom.cage)', mk()), 'Q');
    const clash = Object.keys(C).filter(k => k !== 'cage' && C[k] === C.cage);
    if (clash.length) throw new Error('column Q is also ' + clash.join(', '));
  });
  t('Mapping 1 reads column Q; Mapping 2 reads column G; neither reads the other’s column', () => {
    const rows = [{ 1: 'P1', 3: 'TOP', 6: 'GGGGG', 16: 'QQQQQ', 29: 'TOP' }];
    eq(vm.runInContext("ebomCageForKey('P1', 'TOP')", load({}, rows)), 'QQQQQ', 'Mapping 1:');
    eq(vm.runInContext("ebomCageForKey('P1', 'TOP')", load({ ebomColumnMapping: 2 }, rows)), 'GGGGG', 'Mapping 2:');
  });
  t('the Manual window lists CAGE Code, optional, and a typed letter is where it is read from', () => {
    const defs = vm.runInContext('_ebomFieldDefs()', mk());
    const d = defs.find(x => x.key === 'cage');
    if (!d) throw new Error('no cage field in the mapping window');
    eq([d.label, d.required], ['CAGE Code', false]);
    defs.forEach(x => { if (C[x.key] === undefined) throw new Error(x.key + ' has no default column'); });
    const c = mk();
    defs.forEach(x => { c.__els['ebom-map-' + x.key] = { value: { pn: 'B', nh: 'D', cage: 'AB' }[x.key] || '' }; });
    vm.runInContext('_saveEbomManualMap()', c);
    eq(c.state.ebomManualMap.cage, 27, 'AB is index 27:');
    const got = load({ ebomManualMap: JSON.parse(JSON.stringify(c.state.ebomManualMap)) }, [{ 1: 'P1', 3: 'TOP', 16: 'QQQQQ', 27: '5ZZZ9' }]);
    eq(vm.runInContext("ebomCageForKey('P1', 'TOP')", got), '5ZZZ9');
  });
  t('a Manual map with CAGE left blank reads the default column Q, as every optional field does', () => {
    const c = mk();
    vm.runInContext('_ebomFieldDefs()', c).forEach(x => { c.__els['ebom-map-' + x.key] = { value: x.key === 'pn' ? 'B' : '' }; });
    vm.runInContext('_saveEbomManualMap()', c);
    eq(c.state.ebomManualMap.cage, 16);
  });
  t('a Manual map saved before v189 has no CAGE pick: the column is empty, nothing is guessed, nothing throws', () => {
    const old = { indenture: 0, pn: 1, desc: 2, nh: 3, qty: 7, qtyText: 8, drawingRev: 10, partType: 25 };
    const c = load({ ebomManualMap: old }, [{ 1: 'P1', 3: 'TOP', 16: 'QQQQQ' }]);
    eq(c.state.boms.ebom.data[0][16], '');
    eq(vm.runInContext("ebomCageForKey('P1', 'TOP')", c), '');
  });
  t('the upload and the re-parse re-lay CAGE the same way (the re-lay exists twice)', () => {
    [fnBody('handleFile'), fnBody('_reparseBomFromRaw')].forEach((b, i) => {
      const who = i ? '_reparseBomFromRaw' : 'handleFile';
      if (!/put\(COL\.ebom\.cage,\s*mm\.cage\);/.test(b)) throw new Error(who + ' does not re-lay a Manual CAGE pick');
      if (!/r\[COL\.ebom\.cage\]\s*=\s*srcRow\[6\]\s*\|\|\s*'';/.test(b)) throw new Error(who + ' does not read column G under Mapping 2');
    });
  });
  t('the column-mapping reference names CAGE under both mappings, with the letters the code reads', () => {
    const a = at('— EBOM COLUMN MAPPING 1 (default) —'), b = at('— EBOM COLUMN MAPPING 2 (alternate layout) —', a);
    const m1 = SRC.slice(a, b), m2 = SRC.slice(b, at(']\n', b));
    if (!/\['Q',\s*'CAGE Code'/.test(m1)) throw new Error('Mapping 1 reference does not list CAGE Code in Q');
    if (!/\['G',\s*'CAGE Code'/.test(m2)) throw new Error('Mapping 2 reference does not list CAGE Code in G');
  });

  console.log('\n== What a line item’s code is ==');
  const map = rows => { const c = mk(); c.D = rows.map(o => { const r = new Array(W).fill(''); Object.keys(o).forEach(k => { r[k] = o[k]; }); return r; });
                        return JSON.parse(JSON.stringify(vm.runInContext('buildEbomCageMap(D, 1, 3, 16)', c))); };
  t('one code per part number + next higher; the same part under another parent keeps its own', () => {
    eq(map([{ 1: 'P1', 3: 'A', 16: '81205' }, { 1: 'p1 ', 3: 'B', 16: '1ABC2' }, { 1: 'TOP', 16: 'K1234' }]),
       { 'P1||A': '81205', 'P1||B': '1ABC2', 'TOP||': 'K1234' });
  });
  t('lines merged into one row list every distinct code, in file order; a repeat in another letter case is one code', () => {
    eq(map([{ 1: 'P1', 3: 'A', 16: '81205' }, { 1: 'P1', 3: 'A', 16: ' 0XY34 ' }, { 1: 'P1', 3: 'A', 16: '0xy34' }, { 1: 'P1', 3: 'A', 16: '81205' }, { 1: 'P1', 3: 'A', 16: '' }]),
       { 'P1||A': '81205; 0XY34' });
  });
  t('a code is shown as the file holds it: a number stays that number, no padding; a blank is no code', () => {
    eq(map([{ 1: 'P1', 3: 'A', 16: 7482 }, { 1: 'P2', 3: 'A', 16: '' }, { 1: 'P3', 3: 'A', 16: 0 }, { 1: '', 3: 'A', 16: 'XXXXX' }]),
       { 'P1||A': '7482', 'P3||A': '0' });
  });
  t('the lookup follows the rows: a new upload or a re-parse is never answered from the previous rows', () => {
    const c = load({}, [{ 1: 'P1', 3: 'TOP', 16: 'AAAAA' }]);
    eq(vm.runInContext("ebomCageForKey('P1', 'TOP')", c), 'AAAAA');
    c.state.boms.ebom.raw = raw([{ 1: 'P1', 3: 'TOP', 16: 'BBBBB' }]);
    vm.runInContext("_reparseBomFromRaw('ebom')", c);
    eq(vm.runInContext("[ebomCageForKey('P1', 'TOP'), ebomCageForLine({ pn: 'P1', nh: 'TOP' }), ebomCageForLine({ pn: 'P9', nh: '' }), ebomCageForLine(null)]", c), ['BBBBB', 'BBBBB', '', '']);
    c.state.boms.ebom = null;
    eq(vm.runInContext("ebomCageForKey('P1', 'TOP')", c), '', 'no EBOM loaded:');
  });

  console.log('\n== Display only ==');
  t('the engine, the worker, the saved result row and the certificate hash never read CAGE', () => {
    ['runReconciliationCore', 'runComparison', '_serializeResultRowForJson', 'freezeReport'].forEach(f => {
      if (/cage/i.test(fnBody(f))) throw new Error(f + ' mentions CAGE');
    });
  });
  t('every reader goes through the one lookup: only the re-lay, the lookup, the EBOM Full heading and the per-line Parts Mapping read the column', () => {
    const allowed = ['handleFile', '_reparseBomFromRaw', 'ebomCageForKey', 'renderFullBom', 'exportCIReport'];
    let rest = stripComments(SRC);
    allowed.forEach(f => { rest = rest.split(fnBody(f)).join(''); });
    const n = (rest.match(/COL\.ebom\.cage|C\.ebom\.cage/g) || []).length;
    if (n) throw new Error(n + ' other place(s) read COL.ebom.cage directly');
    if (/\b(er|row|r)\[16\]/.test(rest)) throw new Error('a raw [16] read of an EBOM row');
  });

  console.log('\n== Header and row together, on every surface ==');
  t('the four export header lists and the on-screen list put CAGE Code (EBOM) right after Part Qty Text (EBOM)', () => {
    eq((SRC.match(/'EBOM Qty', 'Part Qty Text \(EBOM\)', 'CAGE Code \(EBOM\)'/g) || []).length, 5, 'screen + context + CSV + XLSX + HTML:');
    eq((SRC.match(/'Part Qty Text \(EBOM\)'(?!\s*,\s*'CAGE Code \(EBOM\)')/g) || []).length, 0, 'a Part Qty Text (EBOM) heading with no CAGE after it:');
    const cols = fnBody('renderSummaryTable').match(/const cols = \[([^\]]*)\]/)[1];
    if (!/'Part Qty Text \(EBOM\)', 'CAGE Code \(EBOM\)', deltaColName$/.test(cols.trim())) throw new Error('on screen, CAGE is not between Part Qty Text and the delta column: ' + cols);
    if (!/const ebomCols\s*=\s*\[[^\]]*'CAGE Code \(EBOM\)'\]/.test(fnBody('renderSummaryTable'))) throw new Error('the heading is not in the EBOM colour block');
  });
  t('each of those surfaces builds the cell in the same place, from the one lookup', () => {
    if (!/\$\{esc\(r\.eqText\|\|''\)\}<\/td><td[^>]*>\$\{esc\(ebomCageForLine\(r\)\)/.test(fnBody('renderSummaryTable'))) throw new Error('screen: no CAGE cell after the Part Qty Text cell');
    if (!/row\.push\(r\.eq \?\? '', r\.eqText \|\| '', ebomCageForLine\(r\)\);/.test(fnBody('exportContextResults'))) throw new Error('context export row');
    if (!/row\.push\(r\.eq, r\.eqText \|\| '', ebomCageForLine\(r\)\);/.test(fnBody('exportCSV'))) throw new Error('CSV row');
    if (!/row\.push\(r\.eq, r\.eqText \|\| '', ebomCageForLine\(r\)\);/.test(fnBody('exportXLSX'))) throw new Error('XLSX row');
    if (!/\$\{esc\(row\.eqText\|\|''\)\}<\/td><td[^>]*>\$\{esc\(ebomCageForLine\(row\)\)\}<\/td>/.test(fnBody('exportHTML'))) throw new Error('HTML report row');
    eq((fnBody('exportXLSX').match(/aoa_to_sheet\(\[hdr, \.\.\.buildRows\(/g) || []).length, 3, 'the three sheets share one header and one row builder:');
  });
  t('the CI report: Parts Mapping, Detail and CSA Pedigree each gain one heading and one cell; the CI tab too', () => {
    const b = fnBody('exportCIReport');
    if (!/'Part Qty Text', 'CAGE Code', 'Next Higher Part Number'/.test(b)) throw new Error('Parts Mapping heading order');
    if (!/entry\.qtyText \|\| '—', entry\.cage \|\| '—',\s*entry\.nh \|\| '—'/.test(b)) throw new Error('Parts Mapping row order');
    const ph = b.match(/ebomPartRows\.push\(\[t\.ciId \|\| '—'([^\]]*)\]\)/);
    const hdrN = b.match(/const ebomPartHdr = \[([\s\S]*?)\];/)[1].split(',').filter(x => x.trim()).length;
    if (!ph || ph[1].split(',').length !== hdrN) throw new Error('the Parts Mapping placeholder row is not as wide as its header (' + hdrN + ')');
    if (!/'EBOM Qty', 'EBOM Part Qty Text', 'EBOM CAGE Code',/.test(b) || !/t\.ebomQty, t\.ebomQtyText \|\| '—', t\.ebomCage \|\| '—',/.test(b)) throw new Error('Detail heading or row');
    if (!/'EBOM Present',\s*'EBOM CAGE Code\(s\)',/.test(b) || !/ciId, pns, nhs, ebomPresent, ebomCages,/.test(b)) throw new Error('CSA Pedigree heading or row');
    const g = fnBody('generateCITrace');
    if (!/ebomCage\s*=\s*ebomCageForKey\(pn, nh\)/.test(g) || !/ebomQtyText,\s*ebomCage,/.test(g)) throw new Error('the CI trace does not carry the code');
    const tab = fnBody('renderCITraceTable');
    if (!/'EBOM Part Qty Text', 'EBOM CAGE Code', 'CHP Part Qty Text'/.test(tab)) throw new Error('CI tab heading order');
    const cells = tab.indexOf('t.ebomQtyText'), cage = tab.indexOf('t.ebomCage'), chp = tab.indexOf('esc(t.partQtyText');
    if (!(cells < cage && cage < chp)) throw new Error('CI tab cell order');
  });
  t('both gap reports carry the column and sort on Gap Type by name, not by a counted position', () => {
    [['exportUnplannedNotInstalled', /'EBOM Qty Text', 'EBOM CAGE Code', 'MBOM Qty'/, /r\.eqText \|\| '',\s*ebomCageForLine\(r\),\s*\(mqN !== null\)/],
     ['exportPlannedNotInstalled', /'EBOM Qty', 'EBOM CAGE Code', 'MBOM Qty', 'ABOM Qty'/, /\(r\.eqText \|\| ''\),\s*ebomCageForLine\(r\),\s*\(mqN !== null\)/]].forEach(([f, h, r]) => {
      const b = fnBody(f);
      if (!h.test(b)) throw new Error(f + ': heading order');
      if (!r.test(b)) throw new Error(f + ': row order');
      if (!/const GAP = hdr\.indexOf\('Gap Type'\);/.test(b) || !/a\[GAP\] !== b\[GAP\]/.test(b)) throw new Error(f + ': does not sort by the Gap Type heading');
      if (/\b[ab]\[\d+\] !== [ab]\[\d+\]/.test(b)) throw new Error(f + ': still sorts on a counted column');
      const n = b.match(/const hdr = \[([\s\S]*?)\];/)[1].split(',').filter(x => x.trim()).length;
      const row = b.match(/rows\.push\(\[([\s\S]*?)\n    \]\);/)[1].split('\n').filter(l => l.trim()).length;
      eq(row, n, f + ': cells per row vs headings:');
      if (!/EBOM CAGE Code = /.test(b)) throw new Error(f + ': the column is not explained in the title block');
    });
  });
  t('the EBOM Full view tags the column, and the explanation says what a merged row shows', () => {
    if (!/i === COL\.ebom\.cage\)\s*\?[\s\S]{0,120}\[CAGE\]/.test(fnBody('renderFullBom'))) throw new Error('no [CAGE] tag on the EBOM Full heading');
    if (!/<strong>CAGE Code \(EBOM\)<\/strong>[^<]*exactly as the file holds it[\s\S]{0,200}every distinct/.test(SRC)) throw new Error('the Detailed View explanation does not describe the column');
  });
});

// ── TIER 28 ────────────────────────────────────────────────────────────────
// v190 — the CI section without an ABOM, and CI · MBOM (as-planned). Before
// v190 renderKpiBlocks returned early unless both a CI file and an ABOM were
// loaded. In EBOM↔MBOM mode that hid the whole CI section, including CI Scope
// and CIs Missing from EBOM, which need no ABOM. The same early return skipped
// everything after the CI cards: NCRs Without EBOM Trace, the NH-mismatch and
// no-EBOM-trace helpers, and the nav-chip sync (so the CI Status chip pointed
// at a hidden section). The owner chose (poll, 2026-11-18): show the section
// with any CI file; add CI · MBOM cards; show both legs in Full mode; hide the
// ABOM-dependent CI cards when there is no ABOM.
suite('Tier 28 — CI section without an ABOM; CI · MBOM', (t, eq) => {
  const fnBody = n => stripComments(grabFn(n));
  const constSrc = name => { const a = at('const ' + name + ' = '); return SRC.slice(a, at('];', a) + 2).replace(/^const /, 'var ').replace('];', '];').replace(/\};$/, '};'); };
  const constObj = name => { const a = at('const ' + name + ' = {'); let d = 0, i = SRC.indexOf('{', a);
    for (let k = i; k < SRC.length; k++) { if (SRC[k] === '{') d++; else if (SRC[k] === '}') { d--; if (!d) return 'var ' + name + ' = ' + SRC.slice(i, k + 1) + ';'; } } };
  const dom = () => { const els = {}; return { els, document: { getElementById: id => (els[id] = els[id] || { id, textContent: '', style: { display: '' } }) } }; };
  const ciRows = list => list.map(([id, pn, nh]) => { const r = []; r[REAL_COL.ci.ciId] = id; r[REAL_COL.ci.pn] = pn; r[REAL_COL.ci.nh] = nh; return r; });
  const mk = (results, ci, ebom) => {
    const d = dom();
    const c = sandbox(Object.assign({ COL: REAL_COL, document: d.document,
      _STATUS_DIRECT_OK: new Set(['ok', 'flex_ok', 'direct_adjudicated', 'qty_mismatch_accepted']),
      _STATUS_COVERED: new Set(['covered', 'covered_adjudicated']),
      _kpiData: {}, state: { results, boms: { ci: { data: ciRows(ci) }, ebom: ebom ? { data: ebom } : null } } }), []);
    vm.runInContext(['normPN', '_ciScopeCount', '_ciMissingFromEbom', '_renderCiEbomOnlyCards', '_setCiSectionLayout', '_ciMbomLegCIs', '_renderCiMbomBlock']
      .map(grabFn).join('\n') + '\n' + constSrc('_CI_ABOM_KPI_KEYS'), c);
    c.__d = d; return c;
  };
  const R = (pn, nh, o) => Object.assign({ key: pn + '||' + nh, pn, nh, ms: 'n/a', msUsedOn: 'n/a', as: 'n/a' }, o);

  console.log('\n== Which parts of the section show ==');
  const layout = (hasCi, hasM, hasA) => {
    const c = mk([], []); const sec = c.document.getElementById('kpi-ci-status-section');
    c.H = [sec, hasCi, hasM, hasA]; vm.runInContext('_setCiSectionLayout(H[0], H[1], H[2], H[3])', c);
    const v = id => c.__d.els[id] ? c.__d.els[id].style.display !== 'none' : null;
    return { sec: v('kpi-ci-status-section'), mbom: v('kpi-ci-mbom-block'), abomLabel: v('kpi-ci-abom-label'),
             abomRows: ['kpi-ci-row-2', 'kpi-ci-row-3', 'kpi-ci-row-4', 'kpi-ci-open-wo', 'kpi-ci-row-5'].map(v),
             rfv: c.__d.els['kpi-rfv-row'] ? v('kpi-rfv-row') : 'untouched', cols: c.__d.els['kpi-ci-row-1'].style.gridTemplateColumns };
  };
  t('EBOM↔MBOM with a CI file: the section shows, with the MBOM block and no ABOM row, NCR row or RFV row', () => {
    eq(layout(true, true, false), { sec: true, mbom: true, abomLabel: false, abomRows: [false, false, false, false, false], rfv: false, cols: '1fr 1fr' });
  });
  t('Full mode: both legs, with the ABOM leg labelled; the RFV row is left to the RFV code', () => {
    eq(layout(true, true, true), { sec: true, mbom: true, abomLabel: true, abomRows: [true, true, true, true, true], rfv: 'untouched', cols: '1fr 1fr 1fr' });
  });
  t('EBOM↔ABOM: as before v190 — no MBOM block, no leg label, three cards in the CI-only row', () => {
    eq(layout(true, false, true), { sec: true, mbom: false, abomLabel: false, abomRows: [true, true, true, true, true], rfv: 'untouched', cols: '1fr 1fr 1fr' });
  });
  t('no CI file: the section is hidden, whatever else is loaded', () => {
    eq(layout(false, true, true).sec, false);
    eq(layout(false, true, true).mbom, false);
  });

  console.log('\n== CI · MBOM: the same predicates as the EBOM·MBOM section ==');
  const results = [
    R('P1', 'A', { ms: 'ok' }), R('P2', 'A', { ms: 'flex_ok' }), R('P3', 'A', { ms: 'direct_adjudicated' }),
    R('P4', 'A', { msUsedOn: 'pn_as_usedon' }), R('P5', 'A', { ms: 'ok', msUsedOn: 'pn_as_usedon' }),
    R('P6', 'A', { ms: 'covered', coveredAncestorPn: 'A' }), R('P7', 'A', { ms: 'covered_adjudicated', coveredAncestorPn: 'TOP' }),
    R('P8', 'A', { ms: 'missing' }), R('P9', 'A', { ms: 'qty_mismatch' }), R('P10', 'A', { ms: 'flex_missing' }),
    R('P11', 'A', { ms: 'missing', as: 'ok' }), R('P12', 'A', { ms: 'qty_mismatch_accepted' }),
  ];
  const ci = [['C1', 'P1', 'A'], ['C2', 'P2', 'A'], ['C3', 'P3', 'A'], ['C4', 'P4', 'A'], ['C5', 'P5', 'A'], ['C6', 'P6', 'A'], ['C7', 'P7', 'A'],
              ['C8', 'P8', 'A'], ['C9', 'P9', 'A'], ['C10', 'P10', 'A'], ['C11', 'P11', 'A'], ['C12', 'P12', 'A'], ['C13', 'P99', 'NOPE'], ['C1b', 'P1', 'A']];
  const legs = () => { const c = mk(results, ci); const m = vm.runInContext('_ciMbomLegCIs()', c);
    const ids = a => a.map(x => x.ciId); return { c, m: { direct: ids(m.direct), usedOn: ids(m.usedOn), parent: m.parent.map(x => x.ciId + '<' + x.ancestorPn), missing: ids(m.missing), qty: ids(m.qty), any: m.anyKeys.size } }; };
  t('Pass 1 counts ok, flex_ok and the adjudicated equivalents; one entry per CI row, as on the ABOM leg', () => {
    eq(legs().m.direct, ['C1', 'C2', 'C3', 'C5', 'C12', 'C1b']);
  });
  t('Pass 2 is the used-on leg on its own: a CI both direct and used-on counts in both cards', () => {
    eq(legs().m.usedOn, ['C4', 'C5']);
  });
  t('Pass 3 counts covered and covered_adjudicated, and names the ancestor', () => {
    eq(legs().m.parent, ['C6<A', 'C7<TOP']);
  });
  t('missing and qty mismatch read the MBOM leg only: an ABOM success does not hide an MBOM miss; flex_missing is neither', () => {
    eq([legs().m.missing, legs().m.qty], [['C8', 'C11'], ['C9']]);
  });
  t('any path is the union by CI ID + PN + NH; a CI with no EBOM line is in no MBOM card', () => {
    eq(legs().m.any, 9);   // C1 C2 C3 C4 C5 C6 C7 C12 C1b — C5 once, though it is in two cards
  });
  t('the cards and their percentages are written from those lists, over CI scope', () => {
    const c = mk(results, ci); c.__d.els; vm.runInContext('_renderCiMbomBlock(true, _ciScopeCount())', c);
    const n = id => c.__d.els[id + '-num'].textContent;
    eq([n('kpi-ci-mbom-pct-direct'), n('kpi-ci-mbom-pct-any'), n('kpi-ci-mbom-direct'), n('kpi-ci-mbom-used-on'), n('kpi-ci-mbom-parent'), n('kpi-ci-mbom-missing'), n('kpi-ci-mbom-qty')],
       ['43%', '64%', 6, 2, 2, 2, 1]);
    eq(vm.runInContext('_ciScopeCount()', c), 14);
    if (!c._kpiData.ciMbom || c._kpiData.ciMbom.direct.length !== 6) throw new Error('the drill-down lists were not stored');
    vm.runInContext('_renderCiMbomBlock(false, 14)', c);
    eq(c._kpiData.ciMbom, null, 'with no MBOM leg the lists are cleared:');
  });

  console.log('\n== One computation, two paths ==');
  t('CI Scope and CIs Missing from EBOM have one implementation each, used by both paths', () => {
    const k = fnBody('renderKpiBlocks');
    eq((k.match(/_ciScopeCount\(\)/g) || []).length, 2, 'calls to _ciScopeCount:');
    eq((k.match(/_ciMissingFromEbom\(\)/g) || []).length, 2, 'calls to _ciMissingFromEbom:');
    eq((k.match(/_renderCiEbomOnlyCards\(/g) || []).length, 2, 'calls to _renderCiEbomOnlyCards:');
    eq((k.match(/_renderCiMbomBlock\(/g) || []).length, 2, 'calls to _renderCiMbomBlock:');
    if (/ciScopeKeys|ebomExactKeys/.test(k)) throw new Error('an inline copy of the scope or missing-from-EBOM logic is still in renderKpiBlocks');
    if (/kpi-ci-scope-num|kpi-ci-missing-ebom-num/.test(k)) throw new Error('renderKpiBlocks still writes those cards itself');
  });
  t('CIs Missing from EBOM: PN + Next Higher on no EBOM line; REF lines do not count; a part elsewhere is "PN exists"', () => {
    const E = (pn, nh, txt) => { const r = []; r[REAL_COL.ebom.pn] = pn; r[REAL_COL.ebom.nh] = nh; r[REAL_COL.ebom.qtyText] = txt || '1'; return r; };
    const c = mk([], [['C1', 'P1', 'A'], ['C2', 'P2', 'A'], ['C3', 'P3', 'A'], ['C4', 'P4', 'A']], [E('P1', 'A'), E('P2', 'B'), E('P3', 'A', 'REF')]);
    eq(JSON.parse(JSON.stringify(vm.runInContext('_ciMissingFromEbom()', c))).map(x => x.ciId + ':' + x.pnInEbom), ['C2:true', 'C3:false', 'C4:false']);
  });
  t('the early-return path runs the same tail as the full path, and clears every ABOM-leg CI list', () => {
    const k = fnBody('renderKpiBlocks');
    eq((k.match(/_renderKpiBlocksTail\(hasNcr\)/g) || []).length, 2, 'tail calls:');
    const early = k.slice(k.indexOf('if (!hasCi || !hasAbom) {'), k.indexOf('return;', k.indexOf('if (!hasCi || !hasAbom) {')));
    ['_CI_ABOM_KPI_KEYS.forEach', '_renderKpiBlocksTail(hasNcr)', "kpi-ncr-adjudication"].forEach(x => { if (early.indexOf(x) < 0) throw new Error('early path lacks ' + x); });
    if (/renderAcnKpis\(\)/.test(early)) throw new Error('the early path calls renderAcnKpis itself; the tail does that');
    const tail = fnBody('_renderKpiBlocksTail');
    ['computeUntracedNcrs()', 'renderAcnKpis()', "computeNhMismatchCandidates('mbom')", "computeBomNoEbomTrace('mbom')", 'renderNhMismatchHelperCards()', '_syncSectionNav()']
      .forEach(x => { if (tail.indexOf(x) < 0) throw new Error('tail lacks ' + x); });
    if (/\b(req0|hasAbom|hasCi|resultByKey|ciScopeCount)\b/.test(tail)) throw new Error('the tail reads a variable of renderKpiBlocks');
  });
  t('the list of ABOM-leg CI keys names every CI list the full path stores', () => {
    const c = sandbox({}, []); vm.runInContext(constSrc('_CI_ABOM_KPI_KEYS'), c);
    const keys = new Set(c._CI_ABOM_KPI_KEYS);
    const lit = fnBody('renderKpiBlocks').match(/_kpiData = \{([\s\S]*?)\};/)[1];
    const names = (lit.match(/\b[a-zA-Z]+(?=\s*[:,}])/g) || []).filter(n => /CIs$|Ncrs$/.test(n) && n !== 'missingEbomCIs');
    const miss = names.filter(n => !keys.has(n));
    if (miss.length) throw new Error('not cleared without an ABOM: ' + miss.join(', '));
  });

  console.log('\n== Cards, drill-downs and words ==');
  t('every CI · MBOM card opens a drill-down that exists, and every drill-down reads a list the block stores', () => {
    const c = sandbox({}, []); vm.runInContext(constObj('_CI_MBOM_REPORTS'), c);
    const ids = [...SRC.matchAll(/onclick="showKpiReport\('(ci_mbom_[a-z_]+)'\)"/g)].map(m => m[1]);
    eq(ids.sort(), Object.keys(c._CI_MBOM_REPORTS).sort());
    const lists = ['direct', 'usedOn', 'parent', 'missing', 'qty'];
    Object.values(c._CI_MBOM_REPORTS).forEach(r => { if (lists.indexOf(r.list) < 0) throw new Error('unknown list ' + r.list); });
    if (!/if \(_CI_MBOM_REPORTS\[type\]\)/.test(fnBody('showKpiReport'))) throw new Error('showKpiReport does not route the CI · MBOM cards');
  });
  t('every number and subtitle the block writes has its element in the page', () => {
    const b = fnBody('_renderCiMbomBlock');
    [...b.matchAll(/set\('([a-z-]+)'/g)].map(m => m[1]).forEach(id => { if (SRC.indexOf('id="' + id + '"') < 0) throw new Error('no element ' + id); });
  });
  t('the Explanation says which cards need an ABOM, and describes the MBOM block', () => {
    const a = at("'ci-status': {"), x = SRC.slice(a, at('\n  },', a));
    ['Which cards show (v190)', 'CI · MBOM — Planned', 'CI · ABOM — Embodied', 'CIs Missing in MBOM'].forEach(w => { if (x.indexOf(w) < 0) throw new Error('missing: ' + w); });
  });
});

// ── TIER 29 ────────────────────────────────────────────────────────────────
// v191 — the CI zone reads the CI Index tool's Excel export. The export puts an
// About sheet first, so the CI rows are not on the sheet every other zone reads;
// its columns come from the tool's build configuration, so they are found by
// heading; and one CI can sit at several positions. The owner chose (2026-11-20):
// every position and every variant PIN; Active CIs only, blank counting as
// Active; Collectors left out; N/A as a blank next higher; a CI Index button
// beside Default and Manual, with Default and Manual refusing an export; the
// three keys only. The reader is pure and runs here on fixtures. The four
// helpers copied from the CI Index tool, and the headings it reads, are checked
// against the tool itself when the tool sits beside the build.
const CIINDEX = (function () {
  const dirs = [path.dirname(BUILD), __dirname, path.join(__dirname, '..')];
  const list = d => { try { return fs.readdirSync(d).filter(f => /CI_Index.*\.html$/i.test(f)).sort().reverse().map(f => path.join(d, f)); } catch (e) { return []; } };
  const p = [process.env.COMPARATOR_CI_INDEX].filter(Boolean).concat(...dirs.map(list))
    .find(x => { try { return fs.statSync(x).isFile(); } catch (e) { return false; } });
  if (!p) return null;
  const src = fs.readFileSync(p, 'utf8');
  const a = src.indexOf('/*CFG>*/'), b = src.indexOf('/*<CFG*/', a);
  if (a < 0 || b < a) throw new Error('CI Index tool found at ' + p + ' but its CONFIG block is not where it was');
  return { path: p, src, cfg: JSON.parse(src.slice(a + 8, b)) };
})();
if (CIINDEX) console.log('CI Index tool beside the build: ' + CIINDEX.path + '\n');

suite('Tier 29 — CI Index export as CI input', (t, eq) => {
  const OTH = 'Other Installed Positions (parent CI ID in NH PIN, Qty X)';
  const HDR = ['Level', 'CI ID', 'Parent CI ID', 'CI Name / Nomenclature', 'CI Type', 'CAGE', 'PIN', 'NH PIN', 'Qty per NH', OTH, 'Status', 'Notes'];
  const VHDR = ['CI ID', 'Variant PIN / Version Identifier', 'Variant Description', 'NH PIN', 'Qty per NH', OTH];
  const row = (h, o) => h.map(k => o[k] !== undefined ? o[k] : '');
  const CI = (id, type, status, pin, nh, oth) => row(HDR, { 'CI ID': id, 'CI Type': type, Status: status, PIN: pin, 'NH PIN': nh, [OTH]: oth || '' });
  const V = (id, pin, nh, oth) => row(VHDR, { 'CI ID': id, 'Variant PIN / Version Identifier': pin, 'NH PIN': nh || '', [OTH]: oth || '' });
  const CIROWS = [HDR,
    CI('CI-1', 'HWCI', 'Active', 'TOP', 'N/A'),
    CI('CI-2', 'HWCI', 'Active', 'P100', 'ASM1', 'CI-1 in ASM2, Qty 2; CI-1 in ASM3, Qty 1'),
    CI('CI-3', 'HWCI', '', 'P200', 'ASM1'),
    CI('CI-4', 'HWCI', 'Proposed', 'P400', 'ASM1'),
    CI('CI-5', 'HWCI', 'De-designated', 'P500', 'ASM1'),
    CI('CI-6', 'Collector', 'Active', '', ''),
    CI('CI-7', 'HWCI', 'Active', '', ''),
    CI('CI-8', 'HWCI', 'ACTIVE ', 'P800', 'NA'),
    CI('CI-9', 'HWCI', 'Active', 'P100', 'ASM1')];
  const VARROWS = [VHDR,
    V('CI-2', 'P100B'), V('CI-2', 'P100C', 'ASM6', 'CI-1 in ASM5, Qty 1'),
    V('CI-3', 'P200B', 'ASM4'), V('CI-3', 'P200'), V('CI-3', ''),
    V('CI-4', 'P400B'), V('CI-6', 'P600B'), V('CI-7', 'P700B', 'ASM7'), V('CI-99', 'P999')];
  const EXPECT = ['CI-1|TOP|', 'CI-2|P100|ASM1', 'CI-2|P100|ASM2', 'CI-2|P100|ASM3',
    'CI-2|P100B|ASM1', 'CI-2|P100B|ASM2', 'CI-2|P100B|ASM3', 'CI-2|P100C|ASM6', 'CI-2|P100C|ASM5',
    'CI-3|P200|ASM1', 'CI-3|P200B|ASM4', 'CI-7|P700B|ASM7', 'CI-8|P800|', 'CI-9|P100|ASM1'];
  const C = REAL_COL.ci;
  const keys = d => d.map(r => [r[C.ciId], r[C.pn], r[C.nh]].join('|'));
  const px = () => sandbox({ COL: REAL_COL }, ['ciindex']);
  const build = (ci, v) => { const c = px(); c.A = ci; c.B = v; return vm.runInContext('CX.buildCiRowsFromCiIndex(A, B)', c); };
  const plain = x => JSON.parse(JSON.stringify(x));

  console.log('\n== The zone ==');
  t('the CI zone has a CI Index button beside Default and Manual…, inside the toggle, so it opens no file picker', () => {
    const z = SRC.slice(at('id="zone-ci"'), at('</div>\n    </div>', at('id="zone-ci"')));
    const tg = z.slice(z.indexOf('<div class="abom-cm-toggle" onclick="event.stopPropagation()">'));
    if (tg.length === z.length) throw new Error('no toggle in the CI zone');
    const i = tg.indexOf('id="ci-cm-btn-ciindex"');
    if (i < 0 || i < tg.indexOf('id="ci-cm-btn-manual"')) throw new Error('the CI Index button is not after Manual… in the toggle');
    if (!/id="ci-cm-btn-ciindex"[\s\S]{0,140}onclick="setCiIndexMode\(event\)">CI Index<\/button>/.test(tg)) throw new Error('the button does not call setCiIndexMode');
    if (/class="abom-cm-btn active" id="ci-cm-btn-ciindex"/.test(tg)) throw new Error('CI Index is lit at start; Default must be');
    if (z.indexOf('id="ci-index-note"') < 0) throw new Error('no note line for what loaded');
  });

  console.log('\n== Reading the export ==');
  t('every position loads: first, each Other Installed Position, each variant in its own or its CI’s positions; in sheet order', () => {
    const r = build(CIROWS, VARROWS);
    eq(keys(r.data), EXPECT);
    eq([r.summary.cis, r.summary.firstPositions, r.summary.otherPositions, r.summary.variantPositions], [6, 5, 2, 7], 'cis / first / other / variant:');
  });
  t('columns are found by heading: any column order, a header row lower down, an alias heading', () => {
    const order = HDR.map((_, i) => i).reverse();
    const re = rows => rows.map(r => order.map(i => r[i]));
    const moved = [['CI Index of a program'], []].concat(re(CIROWS));
    eq(keys(build(moved, VARROWS).data), EXPECT, 'reversed columns, header on row 3:');
    const alias = CIROWS.map((r, i) => i ? r : r.map(h => h === OTH ? 'Also Installed In' : h));
    eq(keys(build(alias, VARROWS).data), EXPECT, 'alias heading:');
  });
  t('only Active CIs load: a blank Status counts as Active, case and spaces are ignored, others are counted by their label', () => {
    const r = build(CIROWS, VARROWS);
    eq(plain(r.summary.leftOut), { Proposed: 1, 'De-designated': 1 });
    if (keys(r.data).indexOf('CI-3|P200|ASM1') < 0) throw new Error('blank Status did not load');
    if (keys(r.data).indexOf('CI-8|P800|') < 0) throw new Error('"ACTIVE " did not load');
  });
  t('a Collector CI and its variants are left out; a CI with no PIN loads only its variants', () => {
    const r = build(CIROWS, VARROWS), k = keys(r.data);
    eq([r.summary.collectors, r.summary.noPin], [1, 1]);
    if (k.some(x => /^CI-6\|/.test(x))) throw new Error('a Collector or its variant loaded');
    eq(k.filter(x => /^CI-7\|/.test(x)), ['CI-7|P700B|ASM7']);
  });
  t('an NH PIN the tool reads as N/A loads blank, in every spelling and in Other Installed Positions; NAV-100 is a real PIN', () => {
    const rows = [HDR, CI('A', 'HWCI', 'Active', 'X1', 'N/A'), CI('B', 'HWCI', 'Active', 'X2', 'n/a'), CI('C', 'HWCI', 'Active', 'X3', 'NA'),
      CI('D', 'HWCI', 'Active', 'X4', 'N/A (system-level baseline)'), CI('E', 'HWCI', 'Active', 'X5', 'NAV-100', 'A in N/A, Qty 1')];
    eq(keys(build(rows, null).data), ['A|X1|', 'B|X2|', 'C|X3|', 'D|X4|', 'E|X5|NAV-100', 'E|X5|']);
  });
  t('a repeated CI ID + PIN + NH loads once and is counted; two CI IDs at one PIN + NH are two CIs, and CI Scope counts every position', () => {
    const r = build(CIROWS, VARROWS);
    eq(r.summary.repeats, 1);
    const k = keys(r.data);
    if (k.indexOf('CI-2|P100|ASM1') < 0 || k.indexOf('CI-9|P100|ASM1') < 0) throw new Error('two CI IDs at one position must both load');
    const c = sandbox({ COL: REAL_COL, state: { boms: { ci: { data: r.data } } } }, []);
    vm.runInContext(grabFn('normPN') + '\n' + grabFn('_ciScopeCount'), c);
    eq(vm.runInContext('_ciScopeCount()', c), EXPECT.length, 'the real CI Scope count:');
  });
  t('PN Variants rows of a CI left out, with no PIN, or naming no CI are counted and do not load', () => {
    const s = build(CIROWS, VARROWS).summary;
    eq([s.variantRows, s.variantsOfLeftOut, s.variantsNoPin, s.variantsNoCi, s.variantSheet], [9, 2, 1, 1, true]);
  });
  t('a sheet without CI ID, PIN or NH PIN is refused in words; without a PN Variants sheet the CI rows still load', () => {
    const drop = h => CIROWS.map((r, i) => i ? r : r.map(x => x === h ? 'Something else' : x));
    eq(build(drop('NH PIN'), null).error, 'The CI Index sheet has no NH PIN column.');
    eq(build(drop('PIN'), null).error, 'The CI Index sheet has no PIN column.');
    if (!/no header row with a CI ID column/.test(build(drop('CI ID'), null).error)) throw new Error('CI ID');
    const r = build(CIROWS, null);
    eq(keys(r.data).filter(k => !/P100B|P100C|P200B|P700B/.test(k)), keys(r.data), 'variants loaded with no sheet:');
    eq(r.summary.variantSheet, false);
  });
  t('the account adds up and names every row left out; the zone line counts CIs and rows left out', () => {
    const c = px(); c.A = CIROWS; c.B = VARROWS;
    const txt = vm.runInContext('(r => CX.ciIndexSummaryText(r.summary, r.data.length))(CX.buildCiRowsFromCiIndex(A, B))', c);
    eq(txt, '14 CI rows loaded from the CI Index export: 5 first positions, 2 other installed positions, 7 PN variant positions. ' +
      'Left out: 1 CI with Status Proposed, 1 CI with Status De-designated, 1 Collector CI, 1 CI with no PIN. ' +
      '2 PN Variants rows belong to a CI left out, so they are left out too. 1 PN Variants row has no PIN and did not load. ' +
      '1 PN Variants row names a CI ID that is not on the CI Index sheet and did not load. ' +
      '1 position repeats a CI ID, PIN and NH PIN already loaded and counts once.');
    eq(vm.runInContext('CX.ciIndexSummaryLine(CX.buildCiRowsFromCiIndex(A, B).summary)', c), '6 CIs · 4 left out ⓘ');
  });
  t('only the three keys come across: each row is CI ID, Part Number and Next Higher in COL.ci, and only six headings are read', () => {
    const r = build(CIROWS, VARROWS);
    const w = Math.max(C.ciId, C.pn, C.nh) + 1;
    if (r.data.some(x => x.length !== w)) throw new Error('a row is not ' + w + ' cells wide');
    const c = px();
    eq(vm.runInContext('Object.keys(CX.CI_INDEX_HEADINGS.ci)', c), ['id', 'pin', 'nhpin', 'status', 'type', 'alsoIn']);
    eq(vm.runInContext('Object.keys(CX.CI_INDEX_HEADINGS.variants)', c), ['ciId', 'pin', 'nhpin', 'alsoIn']);
  });

  console.log('\n== The same reading as the CI Index tool ==');
  t('tr, isNA, normH and aiParse are the CI Index tool’s, character for character', () => {
    if (!CIINDEX) { console.log('        (the CI Index tool is not beside the build: nothing to compare)'); return; }
    const blk = SRC.slice(at('// ── COPIED: CI INDEX ──'), at('// ── COPIED: CI INDEX END ──'));
    ['tr', 'isNA', 'normH', 'aiParse'].forEach(n => {
      const theirs = grabFrom(CIINDEX.src, n, 'CI Index tool'), ours = grabFrom(blk, n, 'the COPIED block');
      if (theirs !== ours) throw new Error(n + ' differs from the CI Index tool');
    });
  });
  t('the headings, aliases, sheet names, Active and Collector are the CI Index tool’s own', () => {
    if (!CIINDEX) { console.log('        (the CI Index tool is not beside the build: nothing to compare)'); return; }
    const cfg = CIINDEX.cfg, c = px();
    const H = vm.runInContext('CX.CI_INDEX_HEADINGS', c);
    const want = (cols, k) => { const x = cols.find(y => y.k === k); if (!x) throw new Error('the tool has no column ' + k); return [x.h].concat(x.alias || []); };
    Object.keys(H.ci).forEach(k => eq(plain(H.ci[k]), want(cfg.cols, k), 'CI Index ' + k + ':'));
    Object.keys(H.variants).forEach(k => eq(plain(H.variants[k]), want(cfg.vcols, k), 'PN Variants ' + k + ':'));
    eq(vm.runInContext('CX.CI_INDEX_ACTIVE', c), cfg.lists.status.items.find(i => i.m === 'active').v);
    eq(vm.runInContext('CX.CI_INDEX_COLLECTOR', c), cfg.lists.type.items.find(i => i.col).v);
    ["name:'CI Index'", "name:'PN Variants'", "find('ci index')", "find('pn variants')"].forEach(w => {
      if (CIINDEX.src.indexOf(w) < 0) throw new Error('the tool no longer has ' + w);
    });
  });
  t('the tool’s own example index, in the tool’s column order, loads 17 rows from 14 Active CIs', () => {
    if (!CIINDEX) { console.log('        (the CI Index tool is not beside the build: nothing to compare)'); return; }
    const cfg = CIINDEX.cfg;
    const ci = [cfg.cols.map(x => x.h)].concat(cfg.examples.cis.map(r => cfg.cols.map(x => r[x.k] == null ? '' : (Array.isArray(r[x.k]) ? r[x.k].join('; ') : r[x.k]))));
    const vv = [cfg.vcols.map(x => x.h)].concat((cfg.examples.vars || []).map(r => cfg.vcols.map(x => r[x.k] == null ? '' : r[x.k])));
    const r = build(ci, vv), k = keys(r.data);
    eq([r.data.length, r.summary.cis, plain(r.summary.leftOut)], [17, 14, { Proposed: 1 }]);
    ['CI-0001|AV-1000-001|', 'CI-0022|VLV-2235-001|ACT-2230-002', 'CI-0022|VLV-2235-001|FCS-2200-001',
     'CI-0022|VLV-2235-001|MLG-3210-001', 'CI-0021|ACT-2230-004|FCS-2200-001', 'CI-0051|ANT-2390-001|AV-1000-001',
     'CI-0053|ANT-2390-001|AV-1000-001'].forEach(x => { if (k.indexOf(x) < 0) throw new Error('missing ' + x); });
  });

  console.log('\n== The button, the refusals, the switches ==');
  const UIFNS = ['_ciIndexRenderNote', '_ciUnloadForLayout', 'setCiIndexMode', '_ciIndexRefuse', '_ciIndexClearRefusal',
    '_ciIndexHandleWorkbook', '_ciIndexReparse', 'refreshSuppMappingUI', 'setSuppMappingMode', 'openSuppManualMap',
    '_saveSuppManualMap', '_suppManualFieldDefs', '_suppManualFieldDefsBase', '_reparseBomFromRaw', '_applySuppManualMap',
    '_suppRefreshRowCount', 'colLetterToIndex', 'colIndexToLetter', 'sourceHeaderLabel', 'sourceHeaderRow',
    '_sourceIsReLaid', '_sourceFieldDefs', '_ebomFieldDefs', '_bomManualFieldDefs', 'safeColCount', 'hideError'];
  const ui = st => {
    const c = sandbox({ COL: JSON.parse(JSON.stringify(REAL_COL)), state: Object.assign({ boms: {}, isLocked: false }, st || {}),
      esc: x => String(x), chpAlignRule: () => 'pn_nh', _chpIngestKeyCol: () => REAL_COL.chp.pn,
      _closeMapper: () => {}, _openMapperOverlay: () => {}, _setMapperHtml: () => {}, renderProcCodePanel: () => {}, renderIndenturePanel: () => {},
      checkReady: () => {}, TOASTS: [], XLSX: { utils: { sheet_to_json: ws => ws.rows } } }, ['ciindex']);
    const lab = SRC.slice(at('const _SUPP_MAP_LABEL = {'), at('};', at('const _SUPP_MAP_LABEL = {')) + 2);
    vm.runInContext(lab.replace('const _SUPP_MAP_LABEL', 'globalThis._SUPP_MAP_LABEL') + '\nvar _ciIndexRefusal = "";\n' +
      UIFNS.map(grabFn).join('\n') + '\nglobalThis.toast = m => TOASTS.push(m);' +
      "\nglobalThis.showError = m => { const e = document.getElementById('error-box'); e.textContent = '⚠ ' + m; e.style = { display: 'block' }; };", c);
    return c;
  };
  const WB = { SheetNames: ['About', 'CI Index', 'PN Variants', 'Lists'],
               Sheets: { About: { rows: [['CI Index'], ['Program', 'X']] }, 'CI Index': { rows: CIROWS }, 'PN Variants': { rows: VARROWS }, Lists: { rows: [] } } };
  const LIST = { SheetNames: ['S'], Sheets: { S: { rows: [['CI', 'PN', 'NH'], ['CI-1', 'P1', 'A1']] } } };
  const err = c => c.__els['error-box'] ? c.__els['error-box'].textContent : '';
  const lit = c => ['default', 'manual', 'ciindex'].filter(k => c.__els['ci-cm-btn-' + k].classList.c.has('active'));
  t('Default and Manual refuse a CI Index export and name the button; a CI list falls through untouched', () => {
    [{}, { ciManualMap: { ciId: 0, pn: 1, nh: 2 } }].forEach(st => {
      const c = ui(st); c.W = WB;
      eq(vm.runInContext("_ciIndexHandleWorkbook(W, 'idx.xlsx')", c), true);
      eq(c.state.boms.ci, undefined, 'loaded anyway:');
      if (!/idx\.xlsx is a CI Index export\..*Press CI Index on the Configuration Items zone/.test(err(c))) throw new Error(err(c));
      c.W = LIST; eq(vm.runInContext("_ciIndexHandleWorkbook(W, 'list.xlsx')", c), false, 'a CI list:');
      // A CI list whose sheet happens to be named CI Index, without the export's headings, is still a CI list.
      c.W = { SheetNames: ['CI Index'], Sheets: { 'CI Index': LIST.Sheets.S } };
      eq(vm.runInContext("_ciIndexHandleWorkbook(W, 'list.xlsx')", c), false, 'a CI list on a sheet named CI Index:');
    });
  });
  t('the CI Index layout refuses a workbook with no CI Index sheet, and loads an export: rows, count, note, button', () => {
    const c = ui({ ciIndexMode: true });
    c.W = LIST;
    eq(vm.runInContext("_ciIndexHandleWorkbook(W, 'list.xlsx')", c), true);
    if (!/list\.xlsx has no sheet named CI Index/.test(err(c))) throw new Error(err(c));
    eq(c.state.boms.ci, undefined, 'loaded anyway:');
    c.W = WB;
    vm.runInContext("_ciIndexHandleWorkbook(W, 'idx.xlsx'); refreshSuppMappingUI('ci')", c);
    eq(keys(c.state.boms.ci.data), EXPECT);
    eq([c.__els['rows-ci'].textContent, c.__els['zone-ci'].className, c.__els['ci-index-note'].textContent],
       ['14 rows loaded', 'upload-zone loaded-ci', '6 CIs · 4 left out ⓘ']);
    if (!/^14 CI rows loaded from the CI Index export/.test(c.__els['ci-index-note'].title)) throw new Error('no account on hover');
    eq(lit(c), ['ciindex']);
  });
  t('a good load clears the CI Index refusal it follows, and never someone else’s error', () => {
    const c = ui(); c.W = WB;
    vm.runInContext("_ciIndexHandleWorkbook(W, 'idx.xlsx')", c);
    c.state.ciIndexMode = true;
    vm.runInContext("_ciIndexHandleWorkbook(W, 'idx.xlsx')", c);
    eq(c.__els['error-box'].style.display, 'none', 'the refusal still shows:');
    const d = ui({ ciIndexMode: true }); d.W = WB;
    vm.runInContext("showError('EBOM could not be read.'); _ciIndexHandleWorkbook(W, 'idx.xlsx')", d);
    eq(err(d), '⚠ EBOM could not be read.', 'another file’s error was hidden:');
  });
  t('changing the layout removes a loaded file the new layout would refuse, shows the re-upload hint, lights one button', () => {
    const loaded = () => ({ ci: { data: [['CI-1', 'P', 'N']], raw: CIROWS, filename: 'f.xlsx' } });
    let c = ui({ ciIndexMode: true, boms: loaded() });
    vm.runInContext("setSuppMappingMode('ci', 'default')", c);
    eq([c.state.ciIndexMode, c.state.boms.ci, c.__els['ci-cm-reparse-hint'].classList.c.has('visible'), lit(c)], [false, null, true, ['default']], 'CI Index to Default:');
    c = ui({ ciIndexMode: true, boms: loaded() });
    ['ciId', 'pn', 'nh'].forEach((k, i) => { c.__els['ci-map-' + k] = { value: 'ABC'[i] }; });
    vm.runInContext("_saveSuppManualMap('ci')", c);
    eq([c.state.ciIndexMode, plain(c.state.ciManualMap), c.state.boms.ci, lit(c)], [false, { ciId: 0, pn: 1, nh: 2 }, null, ['manual']], 'CI Index to Manual:');
    c = ui({ ciManualMap: { ciId: 0, pn: 1, nh: 2 }, boms: loaded() });
    vm.runInContext('setCiIndexMode()', c);
    eq([c.state.ciIndexMode, c.state.ciManualMap, c.state.boms.ci, lit(c)], [true, null, null, ['ciindex']], 'Manual to CI Index:');
    if (!/not a CI Index export, so it was removed/.test(c.TOASTS[0])) throw new Error(c.TOASTS[0]);
    c = ui();
    vm.runInContext('setCiIndexMode()', c);
    eq([c.state.ciIndexMode, c.__els['ci-cm-reparse-hint'].classList.c.has('visible')], [true, false], 'nothing loaded:');
  });
  t('a frozen report refuses the CI Index layout and every switch out of it', () => {
    const c = ui({ isLocked: true });
    vm.runInContext('setCiIndexMode()', c);
    eq(!!c.state.ciIndexMode, false, 'the layout changed under a frozen report:');
    const d = ui({ isLocked: true, ciIndexMode: true, boms: { ci: { data: [1] } } });
    vm.runInContext("setSuppMappingMode('ci', 'default'); openSuppManualMap('ci')", d);
    eq([d.state.ciIndexMode, !!d.state.boms.ci], [true, true]);
    eq(c.TOASTS.concat(d.TOASTS).filter(m => /frozen/.test(m)).length, 3);
  });
  t('the re-read rebuilds the same rows from the stored sheets; the CI tab and raw sheet head them by field name', () => {
    const c = ui({ ciIndexMode: true }); c.W = WB;
    vm.runInContext("_ciIndexHandleWorkbook(W, 'idx.xlsx')", c);
    c.state.boms.ci.data = [];
    eq(vm.runInContext("_reparseBomFromRaw('ci')", c), true);
    eq(keys(c.state.boms.ci.data), EXPECT);
    eq(vm.runInContext("sourceHeaderRow('ci', state.boms.ci)", c), ['CI Identifier', 'Part Number', 'Next Higher Part Number']);
  });
  t('upload goes through the CI Index layout before the first sheet is read; session and Reset carry the layout', () => {
    const up = grabFn('handleFile');
    const i = up.indexOf("if (type === 'ci' && _ciIndexHandleWorkbook(wb, file.name)) return;");
    if (i < 0 || i > up.indexOf('const ws = wb.Sheets[wb.SheetNames[0]];')) throw new Error('handleFile does not offer a CI workbook to the CI Index layout first');
    const ex = grabFn('exportSessionJson'), im = grabFn('importSessionJson'), rs = grabFn('resetAll');
    if (!/ciIndexMode:\s*state\.ciIndexMode\s*\|\|\s*undefined,/.test(ex)) throw new Error('the session writes the layout when it is not set');
    if (!/state\.ciIndexMode\s*=\s*payload\.ciIndexMode === true;/.test(im)) throw new Error('import does not read the layout strictly');
    if (!/state\.ciIndexMode\s*=\s*false;/.test(rs)) throw new Error('Reset keeps the layout');
    [im, rs].forEach((b, k) => { if (b.indexOf('_ciIndexRenderNote()') < 0) throw new Error((k ? 'Reset' : 'import') + ' leaves the note as it was'); });
    eq(JSON.stringify({ a: 1, ciIndexMode: false || undefined }), '{"a":1}', 'a default session gains no field:');
    const ref = SRC.slice(at('const COL_MAP_DATA = {'), at('function openColMapModal'));
    if (!/The CI Index option reads the Excel export of the CI Index tool/.test(ref)) throw new Error('the column mapping reference does not name the CI Index option');
  });
});

// ── TIER 21 ────────────────────────────────────────────────────────────────
// v178 — the streaming session reader. _parseJsonStream is a hand-written JSON
// parser (v143) that every large session goes through, in the main build and,
// from delta v3.4, in the delta tool. Its own comment says it was verified by a
// separate session_stream_test.js; that file is not in the project, so the
// verification lives here now.
//
// The parser is async and t() is synchronous — a rejected promise inside t()
// would count as a PASS. So the cases run first, here, and their settled
// results are reported through t() afterwards. Nothing is awaited inside t().
async function streamCases() {
  const ctx = { console, JSON, Math, Array, Object, String, Number, Boolean, Error, Promise };
  ctx.globalThis = ctx; vm.createContext(ctx);
  vm.runInContext(deltaSlice(SRC, 'async function _parseJsonStream(', 'async function _readSessionPayload(') +
                  '\nglobalThis.P = _parseJsonStream;', ctx);
  const feed = (s, size) => { let i = 0;
    return async () => { if (i >= s.length) return null; const c = s.slice(i, i + size); i += size; return c; }; };
  const SIZES = [1, 2, 3, 7, 64, 1e9];
  const same = async (name, value) => {
    const s = JSON.stringify(value);
    for (const size of SIZES) {
      const got = await ctx.P(feed(s, size));
      if (JSON.stringify(got) !== s) return { name, error: new Error('differs from JSON.parse at chunk size ' + size) };
    }
    return { name };
  };
  const rejects = async (name, text) => {
    for (const size of SIZES) {
      let ok = false;
      try { await ctx.P(feed(text, size)); } catch (e) { ok = true; }
      if (!ok) return { name, error: new Error('accepted malformed input at chunk size ' + size) };
    }
    return { name };
  };
  // A payload shaped like exportSessionJson's streamed output: head, boms with
  // row arrays, both result arrays with Map-serialised traces, then the tail.
  const session = {
    schema: 'bom-comparator-session', schemaVersion: '2.0', toolVersion: 'v178',
    exportedAt: '2026-09-23T10:00:00.000Z', mode: 'ebom_mbom_abom',
    boms: { ebom: { header: ['A', 'B'], filename: 'e.xlsx', data: [['A', 'P1'], ['B', 'P2 "quoted"']] }, rfv: null },
    resultsRaw: [{ key: 'P1||T', pn: 'P1', ms: 'ok', aq: 2.5, trace: { dcn: [['D1', '2024-03-15']], ecn: [], ecr: [] } }],
    results: [{ key: 'P1||T', pn: 'P1', ms: 'direct_adjudicated', aq: null }],
    adjudications: [{ id: 'imp_1_abom', rationale: 'line1\nline2\té 😀', applied: false }],
    isLocked: false, collectorLevels: ['A', 'B'], procOverrides: null,
  };
  return Promise.all([
    same('strings: quotes, backslashes, control escapes and the line separator', ['a"b', 'c\\d', '\n\r\t\b\f', '  ', '']),
    same('non-ASCII and a surrogate pair survive being split between chunks', ['été', '😀', '中文']),
    same('numbers: negative, fractional, exponent and zero', [0, -1, 3.25, -1.5e-3, 6.02e23, 1e-7]),
    same('literals: true, false and null', [true, false, null, { a: null }]),
    same('empty and deeply nested containers', [{}, [], [[[]]], { a: { b: { c: [{}] } } }]),
    same('an object whose keys need escaping', { 'k\n': 1, 'k"q': 2, '': 3 }),
    same('a session shaped exactly like the exporter writes it', session),
    same('a top-level string on its own', 'plain'),
    rejects('a file cut off mid-string is rejected, not half-loaded', '{"a":"unterminated'),
    rejects('a file cut off mid-array is rejected, not half-loaded', '{"results":[{"k":1},'),
  ]);
}

// ── HARNESS.md must describe this run ──────────────────────────────────────
// The headline count was already checked (Tier 2). The coverage TABLE was not,
// and drifted to 363 while the run was 473. Every suite that ran must appear
// in the table by its exact name with the count it actually ran.
function harnessDocSuite() {
  suite('HARNESS.md describes this run', (t, eq) => {
    const f = [path.join(__dirname, 'HARNESS.md'), path.join(__dirname, '..', 'HARNESS.md')]
      .find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
    if (!f) { console.log('  (HARNESS.md not shipped alongside — skipped)'); return; }
    const md = fs.readFileSync(f, 'utf8');
    const rows = [...md.matchAll(/^\|\s*([^|]+?)\s*\|\s*(\d+)\s*\|[^\n]*\|\s*$/gm)]
      .map(m => [m[1].replace(/\*/g, '').trim(), +m[2]]).filter(([n]) => SUITE_COUNTS[n] !== undefined || /^(Tier|v1|HARNESS|Engine|Proc|NCR|ECN|Many|Stylesheet|Version)/.test(n));
    const table = Object.fromEntries(rows);
    t('every suite that ran is in the coverage table with its real count', () => {
      const bad = Object.keys(SUITE_COUNTS).filter(n => n !== 'HARNESS.md describes this run' && table[n] !== SUITE_COUNTS[n])
        .map(n => n + ': table ' + (table[n] === undefined ? 'missing' : table[n]) + ', ran ' + SUITE_COUNTS[n]);
      if (bad.length) throw new Error(bad.join('; '));
    });
    t('the table names no suite that did not run', () => {
      // The browser suite is opt-in: listed in the table, absent from a plain run.
      const extra = Object.keys(table).filter(n => SUITE_COUNTS[n] === undefined &&
        n !== 'HARNESS.md describes this run' && !(n === BROWSER_SUITE && !BROWSER_RUN) &&
        !(n === REFERENCE_SUITE && !REFERENCE));
      if (extra.length) throw new Error('not a suite: ' + extra.join(', '));
    });
  });
}

// ── BROWSER — the product actually runs ────────────────────────────────────
// v179. Every other suite reads or sandboxes the source. None of them opens the
// page, runs a comparison through the real worker, or opens a file the build
// wrote — which is how v160 to v163 shipped unable to run a comparison at all
// while 397 tests passed. This suite drives the shipped HTML in a real browser.
//
// Opt-in, because it needs Playwright, which this file otherwise does not:
//   npm install playwright            (once, beside this file or globally)
//   node comparator-tests.js --browser
// To use a browser already on the machine instead of Playwright's download:
//   COMPARATOR_BROWSER="C:\Program Files\Google\Chrome\Application\chrome.exe" node comparator-tests.js --browser
//
// Asked for and unavailable is a FAILURE, not a skip: a run that was supposed
// to exercise the product must not report green without having done so.
//
// Fixtures are built inside the page with the build's own SheetJS, so the
// suite needs no files beyond the two HTML tools. Every download is read back
// from disk: the test inspects what a user would open, not an object in memory.
const BROWSER_EXPECTED = 62;   // v191 — +6 for the CI Index export as CI input; v190 — +7 for the CI section without an ABOM; v189 — +7 for the CAGE code column; v182 — +10 for Change Pedigree Alignment; v183 — +2 for the ACN columns; v186 — +3 for CI / RFV maps and the Disposition Code card
const BROWSER_SUITE = 'Browser \u2014 the product actually runs';

async function browserCases() {
  let pw;
  try { pw = require('playwright'); }
  catch (e) {
    try { pw = require('playwright-core'); }
    catch (e2) {
      return [{ name: 'Playwright is installed (npm install playwright)', error: new Error('require("playwright") failed: ' + e.message) }];
    }
  }
  const launchOpts = process.env.COMPARATOR_BROWSER ? { executablePath: process.env.COMPARATOR_BROWSER } : {};
  let browser;
  try { browser = await pw.chromium.launch(launchOpts); }
  catch (e) { return [{ name: 'a browser can be launched', error: e }]; }

  const errors = [];
  const results = [];
  const check = async (name, fn) => {
    try { await fn(); results.push({ name }); }
    catch (e) { results.push({ name, error: e }); }
  };
  const assert = (c, msg) => { if (!c) throw new Error(msg); };
  const url = p => 'file://' + path.resolve(p).replace(/\\/g, '/');
  const watch = (page, label) => {
    page.on('pageerror', e => errors.push(label + ': ' + e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push(label + ' console: ' + m.text()); });
  };
  const download = async (page, trigger) => {
    const [d] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), page.evaluate(trigger)]);
    return fs.readFileSync(await d.path());
  };
  // Parse a downloaded workbook with the page's own SheetJS.
  const readXlsx = (page, buf) => page.evaluate(b64 => {
    const wb = XLSX.read(b64, { type: 'base64' });
    const o = {};
    wb.SheetNames.forEach(n => { o[n] = XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: '' }); });
    return o;
  }, buf.toString('base64'));

  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'comparator-browser-'));
  try {
    const ctx = await browser.newContext({ acceptDownloads: true });
    const page = await ctx.newPage();
    watch(page, 'build');
    await page.goto(url(BUILD));
    await page.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");

    await check('the build opens and names its own version', async () => {
      const pill = await page.evaluate("document.getElementById('app-version-pill').textContent");
      const v = await page.evaluate('APP_VERSION');
      assert(pill === v, 'pill says ' + pill + ', APP_VERSION is ' + v);
    });

    // A small program: two structural levels, three parts, one child.
    // P100 fully built · P200 built under an OPEN work order · P300 never built.
    await page.evaluate(async () => {
      const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
      const book = (w, rows) => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
        return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
      };
      const E = [['A', 'TOP', '', 1], ['B', 'ASM1', 'TOP', 1], ['C', 'P100', 'ASM1', 2], ['C', 'P200', 'ASM1', 1], ['C', 'P300', 'ASM1', 3], ['D', 'P101', 'P100', 4]];
      const files = {
        ebom: book(40, E.map(([i, pn, nh, q]) => ({ 0: i, 1: pn, 2: 'desc ' + pn, 3: nh, 7: q, 8: String(q) }))),
        mbom: book(40, [['P100', 'ASM1', 2, 'WO1'], ['P200', 'ASM1', 1, 'WO2'], ['P300', 'ASM1', 3, 'WO3'], ['P101', 'P100', 4, 'WO1']]
          .map(([pn, nh, q, wo]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: 'CLOSED' }))),
        abom: book(40, [['P100', 'ASM1', 2, 'WO1', 'CLOSED'], ['P200', 'ASM1', 1, 'WO2', 'OPEN'], ['P101', 'P100', 4, 'WO1', 'CLOSED']]
          .map(([pn, nh, q, wo, st]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: st }))),
        ci: book(3, [{ 0: 'CI-1', 1: 'P100', 2: 'ASM1' }, { 0: 'CI-2', 1: 'P300', 2: 'ASM1' }]),
      };
      for (const k of ['ebom', 'mbom', 'abom', 'ci']) {
        handleFile(k, files[k]);
        const t0 = Date.now();
        while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) {
          if (Date.now() - t0 > 20000) throw new Error(k + ' did not load');
          await new Promise(r => setTimeout(r, 50));
        }
      }
    });
    await check('four Excel files load into their zones', async () => {
      const n = await page.evaluate("['ebom','mbom','abom','ci'].map(k => state.boms[k].data.length).join(',')");
      assert(n === '6,4,3,2', 'rows loaded: ' + n);
    });

    await page.click('#run-btn');
    await page.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
    const status = await page.evaluate("Object.fromEntries(state.results.map(r => [r.pn, [r.overall, r.ms, r.as].join('/')]))");
    await check('a comparison runs to completion in the browser', async () => {
      assert(Object.keys(status).length === 6, 'rows: ' + JSON.stringify(status));
    });
    await check('the engine reaches the right verdict for each kind of line', async () => {
      // P100 is also P101's next higher, so pass 2 finds it as a used-on parent.
      const want = { TOP: 'collector', ASM1: 'collector', P100: 'pn_as_usedon/ok/ok', P200: 'wo_open/ok/wo_open', P300: 'missing/ok/missing', P101: 'ok/ok/ok' };
      const bad = Object.keys(want).filter(k => !String(status[k]).startsWith(want[k]));
      assert(!bad.length, 'unexpected: ' + bad.map(k => k + '=' + status[k]).join(', '));
    });
    await check('the dashboard renders the counts it computed', async () => {
      const t = await page.evaluate("document.getElementById('m-total').textContent.trim()");
      assert(t === '6', 'EBOM line items card shows ' + JSON.stringify(t));
    });
    await check('after a real run the funnel bars and counts are placed with no help', async () => {
      // v181 review — the first placement runs while the results are still
      // hidden (tracks 0px wide); only the ResizeObserver puts the counts right.
      // So: nothing forced, nothing called. Bars must be their --pct length and
      // every count must be where it fits — first as rendered, then after a
      // window resize.
      const probe = () => page.evaluate(() => {
        const out = [];
        document.querySelectorAll('.funnel-bar-track.cov').forEach(tr => {
          const fl = tr.querySelector('.funnel-bar-fill-cov'), sp = tr.querySelector('.funnel-bar-inline-count');
          const id = (tr.closest('[id]') || {}).id;
          const pct = parseFloat(getComputedStyle(tr).getPropertyValue('--pct'));
          const want = tr.clientWidth * pct / 100, got = fl.getBoundingClientRect().width;
          if (!(pct > 0) || Math.abs(got - want) > 1.5) out.push(id + ' bar ' + got.toFixed(0) + 'px, want ' + want.toFixed(0));
          if (!sp) return;
          const fr = fl.getBoundingClientRect(), sr = sp.getBoundingClientRect(), t = tr.getBoundingClientRect();
          const fits = sr.width + 16 <= fr.width;
          const room = fits || sr.width + 10 <= t.width - fr.width;
          if (room && getComputedStyle(sp).visibility === 'hidden') { out.push(id + ' hidden though it has room'); return; }
          const inside = sr.left >= fr.left - 0.5 && sr.right <= fr.right + 0.5;
          if (fits && !inside) out.push(id + ' fits its bar but is not on it');
          if (!fits && sr.left < fr.right - 0.5) out.push(id + ' does not fit its bar but is on it');
          if (getComputedStyle(sp).visibility !== 'hidden' && (sr.right > t.right + 0.5 || sr.left < t.left - 0.5)) out.push(id + ' clipped');
        });
        if (!document.querySelector('.funnel-bar-track.cov')) out.push('no ladder bars');
        return out;
      });
      const settle = () => page.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
      await settle();
      const first = await probe();
      await page.setViewportSize({ width: 1024, height: 720 }); await settle();
      const resized = await probe();
      await page.setViewportSize({ width: 1280, height: 720 }); await settle();
      const bad = first.map(x => 'as rendered: ' + x).concat(resized.map(x => 'after resize: ' + x));
      assert(!bad.length, bad.slice(0, 6).join('; '));
    });
    await check('every funnel bar count is readable where it lands, in every theme and width', async () => {
      // v181 — the owner's photo: counts on 19% and 30% bars were grey on green.
      // A fixed percentage cannot say whether a count fits its bar (a 19% bar
      // holds it at 1920px, not at 1440px), so this measures what is drawn. For
      // each bar at several widths: the count sits wholly on the fill or wholly
      // on the track, is not clipped, and clears 4.5:1 against what is behind it.
      const theme0 = await page.evaluate("document.documentElement.getAttribute('data-theme') || 'dark'");
      const bad = [];
      for (const w of [760, 1024, 1440, 1920]) {
        await page.setViewportSize({ width: w, height: 900 });
        for (const th of ['dark', 'light', 'mono']) {
          await page.evaluate(t => { setTheme(t); renderFunnel(); }, th);
          const r = await page.evaluate(() => {
            const rgb = c => (c.match(/[\d.]+/g) || []).map(Number);
            const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
            const L = c => 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
            const cr = (a, b) => { const x = L(a), y = L(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
            const out = [];
            const fills = [...document.querySelectorAll('.funnel-bar-fill-cov')];
            if (!fills.length) return ['no ladder bars rendered'];
            for (const pct of [19, 30, 57, 100]) {
              fills.forEach(fl => {
                fl.style.transition = 'none'; fl.style.width = pct + '%';
                const tk = fl.closest('.funnel-bar-track'); if (tk) tk.style.setProperty('--pct', pct + '%');
              });
              if (typeof placeFunnelCounts === 'function') placeFunnelCounts();
              fills.forEach(fl => {
                const track = fl.closest('.funnel-bar-track');
                const sp = track && track.querySelector('.funnel-bar-inline-count');
                if (!sp) return;
                sp.textContent = pct + '% \u00b7 15,754';   // a realistic width
                if (typeof placeFunnelCounts === 'function') placeFunnelCounts();
                const fr = fl.getBoundingClientRect(), sr = sp.getBoundingClientRect(), tr = track.getBoundingClientRect();
                const id = (fl.closest('[id]') || {}).id + ' @' + pct + '%';
                // Below 1024px a count that fits neither on nor beside its bar is
                // hidden (the tooltip carries it); at 1024px and up none may be.
                if (getComputedStyle(sp).visibility === 'hidden') {
                  if (innerWidth >= 1024) out.push(id + ' hidden at ' + innerWidth + 'px');
                  return;
                }
                if (sr.left < tr.left - 0.5 || sr.right > tr.right + 0.5) { out.push(id + ' clipped by the track'); return; }
                const inside = sr.left >= fr.left - 0.5 && sr.right <= fr.right + 0.5;
                const beside = sr.left >= fr.right - 0.5;
                if (!inside && !beside) { out.push(id + ' straddles the end of the bar'); return; }
                const bg = rgb(getComputedStyle(inside ? fl : track).backgroundColor);
                const c = cr(rgb(getComputedStyle(sp).color), bg);
                if (!(c >= 4.5)) out.push(id + (inside ? ' on the fill ' : ' on the track ') + c.toFixed(2) + ':1');
              });
            }
            return out;
          });
          r.forEach(x => bad.push(w + 'px ' + th + ': ' + x));
        }
      }
      await page.setViewportSize({ width: 1280, height: 720 });
      await page.evaluate(t => { setTheme(t); renderFunnel(); }, theme0);
      assert(!bad.length, bad.length + ' unreadable: ' + bad.slice(0, 6).join('; '));
    });

    await page.evaluate(() => {
      state.adjudications.push({ id: 'adj_b1', rowKey: 'P300||ASM1', reason: 'abom_missing', leg: 'abom', createdFrom: 'missing_abom',
        sme: 'Browser Test', smeRole: 'CM', timestamp: '2026-09-23T10:00:00Z', rationale: 'fixture', woNo: 'WO9',
        woPn: 'P300', woUsedOn: 'ASM1', claimedQty: 3, applied: false });
      // On P300, not P200: P200 must stay under an open work order, or the
      // open-WO comparison below compares 0 with 0 and cannot fail.
      state.adjudications.push({ id: 'imp_77_abom', type: 'row', rowKey: 'P300||ASM1', leg: 'abom', reason: 'abom_missing', claimedQty: 3,
        sme: 'ME, Person', smeRole: 'Mfg Engineer', rationale: 'imported', timestamp: '2026-09-01', createdFrom: 'external_import',
        applied: false, extClaimNo: '77', extStatus: 'APPROVED' });
      state.adjManualMap = { pn: 0, claimNo: 1 };
      _adjProcessClaims();
    });
    await check('processing a claim changes the verdict it targets', async () => {
      const as = await page.evaluate("state.results.find(r => r.pn === 'P300').as");
      assert(as === 'direct_adjudicated', 'P300 ABOM leg is ' + as);
    });

    const sessA = JSON.parse((await download(page, 'exportSessionJson()')).toString('utf8'));
    await check('the session file is stamped with the running build', async () => {
      assert(sessA.toolVersion === await page.evaluate('APP_VERSION'), 'toolVersion ' + sessA.toolVersion);
    });
    await check('the session file carries every column map, including ME ADJ', async () => {
      assert(JSON.stringify(sessA.adjManualMap) === '{"pn":0,"claimNo":1}', 'adjManualMap ' + JSON.stringify(sessA.adjManualMap));
    });

    await page.evaluate("window.prompt = () => 'Browser Auditor'");
    await page.evaluate('freezeReport()');
    await page.waitForFunction('state.isLocked && state.auditCert && state.auditCert.hash', null, { timeout: 30000 });
    const certRows = await page.evaluate('_auditCertRows(state.auditCert)');
    await check('freezing shows the build on the certificate banner', async () => {
      const b = await page.evaluate("document.getElementById('cert-build').textContent");
      assert(b === await page.evaluate('APP_VERSION'), 'banner build ' + b);
    });

    const mainX = await readXlsx(page, await download(page, 'exportXLSX()'));
    const ciX = await readXlsx(page, await download(page, 'exportCIReport()'));
    // Trailing empty cells are the reader's padding (defval), not content.
    const norm = rows => JSON.stringify((rows || []).map(r => { const a = r.map(String); while (a.length && a[a.length - 1] === '') a.pop(); return a; })
      .filter(r => r.length));
    const certStr = norm(certRows);
    await check('the Excel export carries the full certificate', async () => {
      assert(norm(mainX['Audit Certificate']) === certStr, 'main export certificate differs from _auditCertRows: ' + norm(mainX['Audit Certificate']).slice(0, 400));
    });
    await check('the CI Traceability Report carries the identical certificate', async () => {
      assert(norm(ciX['Audit Certificate']) === certStr, 'CI report certificate differs');
    });
    await check('the CSV export opens with the full certificate', async () => {
      const csv = (await download(page, 'exportCSV()')).toString('utf8');
      const lines = csv.split('\n').slice(0, certRows.length);
      const want = certRows.map(r => r.map(v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"').join(','));
      assert(JSON.stringify(lines) === JSON.stringify(want), 'CSV certificate: ' + lines.slice(0, 5).join(' | '));
    });
    await check('the HTML report carries the full certificate', async () => {
      const html = (await download(page, 'exportHTML()')).toString('utf8');
      // The report prints the mode in display form (EBOM MBOM ABOM); every other value verbatim.
      const shown = r => r[0] === 'Mode' ? String(r[1]).replace(/_/g, ' ').toUpperCase() : String(r[1]);
      const missing = certRows.slice(1).map(shown).filter(v => v && html.indexOf(v.replace(/&/g, '&amp;')) < 0);
      assert(!missing.length, 'not in the HTML report: ' + missing.join(', '));
    });

    const frozenPath = path.join(tmp, 'frozen.json');
    fs.writeFileSync(frozenPath, await download(page, 'exportSessionJson()'));
    const page2 = await ctx.newPage();
    watch(page2, 'reimport');
    await page2.goto(url(BUILD));
    await page2.waitForFunction("typeof state !== 'undefined'");
    await page2.setInputFiles('#adj-import-input', frozenPath);
    await page2.waitForFunction('state.isLocked === true && state.results.length > 0', null, { timeout: 60000 });
    await check('a frozen session re-opens frozen, with the same results and certificate', async () => {
      const r = await page2.evaluate("({ n: state.results.length, hash: state.auditCert.hash, build: document.getElementById('cert-build').textContent, map: JSON.stringify(state.adjManualMap) })");
      assert(r.n === 6, 'results ' + r.n);
      assert(r.hash === await page.evaluate('state.auditCert.hash'), 'hash changed on re-import');
      assert(r.build === await page.evaluate('APP_VERSION'), 'banner build ' + r.build);
      assert(r.map === '{"pn":0,"claimNo":1}', 'ME ADJ map ' + r.map);
    });

    // ── The delta tool, reading what the build wrote ──
    const A = Object.assign({}, sessA, { toolVersion: 'v142', exportedAt: '2026-09-01T00:00:00.000Z' });
    const B = JSON.parse(fs.readFileSync(frozenPath, 'utf8'));
    B.adjudications.forEach(c => { if (c.id === 'adj_b1') c.woPn = 'P301'; if (c.id === 'imp_77_abom') c.extStatus = 'WITHDRAWN'; });
    const aPath = path.join(tmp, 'A.json'), bPath = path.join(tmp, 'B.json');
    fs.writeFileSync(aPath, JSON.stringify(A)); fs.writeFileSync(bPath, JSON.stringify(B));

    const dhtml = fs.readFileSync(DELTA, 'utf8');
    let deltaDefaultSummary = null;   // v182 — read by the alignment checks below
    const THRESH = 'const NATIVE_SAFE_BYTES = 400 * 1000 * 1000;';
    for (const mode of ['normal', 'streaming']) {
      const dp = await ctx.newPage();
      watch(dp, 'delta ' + mode);
      if (mode === 'normal') await dp.goto(url(DELTA));
      else {
        // Same page with the large-file threshold at 1 KB, so these small
        // sessions take the streaming route a 500 MB session would.
        if (dhtml.indexOf(THRESH) < 0) throw new Error('BUILD MARKER MOVED in delta tool: ' + THRESH);
        await dp.setContent(dhtml.replace(THRESH, 'const NATIVE_SAFE_BYTES = 1000;'), { waitUntil: 'load' });
      }
      await dp.setInputFiles('#A-file', aPath);
      await dp.waitForFunction("document.getElementById('card-A').classList.contains('loaded')", null, { timeout: 30000 });
      await dp.setInputFiles('#B-file', bPath);
      await dp.waitForFunction("document.getElementById('card-B').classList.contains('loaded')", null, { timeout: 30000 });
      await dp.click('#run-btn');
      await dp.waitForSelector('#results section');
      const [d] = await Promise.all([dp.waitForEvent('download'), dp.click('#export-btn')]);
      const wb = await readXlsx(page, fs.readFileSync(await d.path()));
      const summ = Object.fromEntries(wb['Summary'].filter(r => r[0]).map(r => [r[0], r]));
      const claims = wb['Claims Delta']; const hdr = claims[0];
      const byId = Object.fromEntries(claims.slice(1).map(r => [r[hdr.indexOf('Claim ID')], Object.fromEntries(hdr.map((h, i) => [h, r[i]]))]));
      if (mode === 'normal') {
        deltaDefaultSummary = summ;
        await check('the delta tool names the builds behind both sessions', async () => {
          const r = summ['Comparator build'] || [];
          assert(r[1] === 'v142\u2013v177 (exact build not recorded)' && r[2] === B.toolVersion && r[3] === 'different', JSON.stringify(r));
        });
        await check('the delta tool reports a claim whose work-order target moved', async () => {
          assert(byId.adj_b1 && byId.adj_b1.Change === 'Modified', JSON.stringify(byId.adj_b1));
        });
        await check('the delta tool shows where an imported claim came from', async () => {
          assert(byId.imp_77_abom && byId.imp_77_abom.Origin === 'ME adjudication import' && byId.imp_77_abom['External Status'] === 'WITHDRAWN', JSON.stringify(byId.imp_77_abom));
        });
        await check('the delta Summary counts open work orders as the dashboard card does', async () => {
          const card = await page.evaluate("state.results.filter(x => !['pt_collector','pt_reference','pt_bulk','pt_removal','collector'].includes(x.overall) && (x.as === 'wo_open' || x.asUsedOn === 'wo_open')).length");
          const r = summ['Part WO Status: Not Closed'] || [];
          assert(card > 0, 'the fixture has no open work order left to count');
          assert(r[2] === card, 'delta ' + r[2] + ' vs dashboard ' + card);
        });
      } else {
        await check('the delta tool opens sessions through the streaming route', async () => {
          assert(summ['Comparator build'] && byId.adj_b1 && byId.adj_b1.Change === 'Modified', 'streamed run produced a different report');
        });
      }
      await dp.close();
    }

    // ── v182 — a drawing + ECR program, under Change Pedigree Alignment ──
    // Its own page and its own files. The CHP extract carries only a drawing
    // number, revision, ECR and ECR status: no part number at all. Files the
    // page writes are read at the Blob it hands the browser (headless Chromium
    // drops roughly one download in ten; the bytes are the same either way).
    await check('a default run prints no alignment row and writes no alignment field', async () => {
      assert(!certRows.some(r => r[0] === 'Change Pedigree Alignment'), 'default certificate has an alignment row');
      assert(!('chpAlign' in sessA), 'default session carries chpAlign');
      assert(deltaDefaultSummary && !deltaDefaultSummary['Change Pedigree alignment'], 'default delta Summary names an alignment rule');
    });
    const dwp = await ctx.newPage();
    watch(dwp, 'drawing');
    await dwp.goto(url(BUILD));
    await dwp.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
    await dwp.evaluate(() => {
      const orig = URL.createObjectURL.bind(URL);
      URL.createObjectURL = b => { if (b instanceof Blob) (window.__blobs = window.__blobs || []).push(b); return orig(b); };
    });
    const written = async trigger => {
      const b64 = await dwp.evaluate(async t => {
        window.__blobs = [];
        await eval(t);
        for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(r => setTimeout(r, 50));
        const b = window.__blobs[window.__blobs.length - 1];
        if (!b) return null;
        const u = new Uint8Array(await b.arrayBuffer()); let s = '';
        for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
        return btoa(s);
      }, trigger);
      return b64 === null ? null : Buffer.from(b64, 'base64');
    };
    await dwp.evaluate(async () => {
      const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
      const book = (w, rows, hdr) => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([hdr || row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
        return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
      };
      // P100 and P101 share drawing D-100; P200's drawing is written in lower
      // case; P400 is a COTS part with no drawing; P500's drawing has no ECR.
      const E = [['A','TOP','',1,'',''],['B','ASM1','TOP',1,'D-ASM','A'],['C','P100','ASM1',2,'D-100','A'],
                 ['C','P200','ASM1',1,'d-200','B'],['C','P300','ASM1',3,'D-300','A'],['D','P101','P100',4,'D-100','A'],
                 ['C','P400','ASM1',1,'',''],['C','P500','ASM1',1,'D-500','C']];
      const eh = new Array(40).fill('').map((_, i) => 'H' + i); eh[10] = 'Drawing PL Rev'; eh[12] = 'Drawing No.';
      window.__files = {
        ebom: book(40, E.map(([i, pn, nh, q, dw, rv]) => ({ 0: i, 1: pn, 2: 'desc ' + pn, 3: nh, 7: q, 8: String(q), 10: rv, 12: dw })), eh),
        mbom: book(40, [['P100','ASM1',2,'WO1'],['P200','ASM1',1,'WO2'],['P300','ASM1',3,'WO3'],['P101','P100',4,'WO1'],['P400','ASM1',1,'WO4'],['P500','ASM1',1,'WO5']]
          .map(([pn, nh, q, wo]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: 'CLOSED' }))),
        abom: book(40, [['P100','ASM1',2,'WO1','CLOSED'],['P200','ASM1',1,'WO2','CLOSED'],['P101','P100',4,'WO1','CLOSED'],['P400','ASM1',1,'WO4','CLOSED'],['P500','ASM1',1,'WO5','CLOSED']]
          .map(([pn, nh, q, wo, st]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: st }))),
        chp: book(4, [{0:'D-100',1:'A',2:'R1',3:'APPROVED'},{0:'D-100',1:'A',2:'R2',3:'OPEN'},{0:'D-200',1:'B',2:'R4',3:'OPEN'},
                      {0:'D-300',1:'B',2:'R3',3:'OPEN'},{0:'D-999',1:'A',2:'R7',3:'OPEN'},{0:'',1:'',2:'R0',3:''}],
                  ['Drawing Number', 'Rev', 'ECR', 'ECR Status']),
      };
    });
    const loadZone = k => dwp.evaluate(async k => {
      const before = state.boms[k];
      handleFile(k, window.__files[k]);
      const t0 = Date.now();
      while (!(state.boms[k] && state.boms[k] !== before)) { if (Date.now() - t0 > 20000) throw new Error(k + ' did not load'); await new Promise(r => setTimeout(r, 50)); }
      return state.boms[k].data.length;
    }, k);
    for (const k of ['ebom', 'mbom', 'abom']) await loadZone(k);
    await dwp.evaluate("toggleChpAlignPanel(); setChpAlignRule('drawing');" +
      "openSuppManualMap('chp'); ['docNo:A','docRev:B','ecr:C','ecrStatus:D'].forEach(p => { const [k, v] = p.split(':'); document.getElementById('chp-map-' + k).value = v; });" +
      "_saveSuppManualMap('chp');");
    const chpRows = await loadZone('chp');
    await check('a drawing + ECR extract loads by drawing number, and switching the rule re-reads it', async () => {
      assert(chpRows === 5, 'rows kept under the drawing rule: ' + chpRows);
      const n = await dwp.evaluate("setChpAlignRule('pn_nh'); const a = state.boms.chp.data.length; setChpAlignRule('drawing'); [a, state.boms.chp.data.length, document.getElementById('rows-chp').textContent].join('|')");
      assert(n === '0|5|5 rows loaded', 'rows by rule (default|drawing|label): ' + n);
    });
    await check('the run is blocked, in words, until the EBOM drawing column is chosen', async () => {
      const r = await dwp.evaluate("hideError(); runComparison(); [document.getElementById('error-box').style.display, document.getElementById('error-box').textContent, (state.results || []).length].join('|')");
      assert(/^block\|.*Choose the EBOM column that holds the drawing number.*\|0$/.test(r), r);
      const panel = await dwp.evaluate("document.getElementById('chpa-body').textContent");
      assert(panel.indexOf('Run is blocked') >= 0 && panel.indexOf('M · Drawing No.') >= 0, 'panel: ' + panel.slice(0, 300));
    });
    await dwp.evaluate("setChpAlignCol('draw', '12'); hideError(); runComparison()");
    await dwp.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
    const dres = await dwp.evaluate("Object.fromEntries(state.results.map(r => [r.pn, [JSON.stringify(r.chpVia), [...r.trace.ecr.keys()].join(','), chpHistoryState(r).label].join(' ')]))");
    await check('an ECR reaches every EBOM line on its drawing, and nothing else', async () => {
      const want = { P100: '["D-100"] R1,R2 ECR ONLY', P101: '["D-100"] R1,R2 ECR ONLY', P200: '["D-200"] R4 ECR ONLY',
                     P300: '["D-300"] R3 ECR ONLY', P400: '[]  NO DRAWING', P500: '["D-500"]  NO HISTORY' };
      const bad = Object.keys(want).filter(k => dres[k] !== want[k]);
      assert(!bad.length, bad.map(k => k + ': ' + dres[k]).join('; '));
    });
    await check('the panel reports the match, and the Change Pedigree tab names the unmatched drawing', async () => {
      const p = await dwp.evaluate("document.getElementById('chpa-body').textContent");
      assert(/4 of 5 Change Pedigree rows matched an EBOM drawing\. 1 drawing not in the EBOM\./.test(p), 'panel: ' + p.slice(-300));
      const tab = await dwp.evaluate("renderChpTable(0); [...document.querySelectorAll('#chp-table-wrap tbody tr')].map(tr => tr.lastElementChild.textContent).join(',')");
      assert(tab === 'ECR ONLY,ECR ONLY,ECR ONLY,ECR ONLY,NO MATCH', 'tab badges: ' + tab);
    });
    await check('the Excel export shows the EBOM drawing and the new badges', async () => {
      const x = await readXlsx(dwp, await written('exportXLSX()'));
      const s = x['Comparison Summary'], h = s[0];
      const by = Object.fromEntries(s.slice(1).map(r => [r[h.indexOf('Part Number')], r[h.indexOf('Drawing')] + '|' + r[h.indexOf('CHP History')]]));
      assert(by.P101 === 'D-100|ECR ONLY' && by.P400 === '|NO DRAWING' && by.P200 === 'D-200|ECR ONLY', JSON.stringify(by));
    });
    await check('the ECN reports say they are not available instead of exporting an empty report', async () => {
      const f = await written('hideError(); exportChangeCommitmentClosures()');
      const msg = await dwp.evaluate("document.getElementById('error-box').textContent");
      assert(f === null && /Not available: this program.s Change Pedigree carries no ECNs/.test(msg), 'file written: ' + !!f + ', message: ' + msg);
    });
    await check('revision matching attaches only where the revision agrees, and counts the misses', async () => {
      const r = await dwp.evaluate(async () => {
        setChpAlignMatchRev(true); setChpAlignCol('rev', '10'); hideError(); runComparison();
        const t0 = Date.now();
        while (!(state.results.length && state.results[0].chpVia && state.results.some(x => (x.chpVia || []).some(k => k.indexOf('||') > 0)))) {
          if (Date.now() - t0 > 30000) throw new Error('re-run did not finish'); await new Promise(z => setTimeout(z, 50));
        }
        await new Promise(z => setTimeout(z, 200));
        const p3 = state.results.find(x => x.pn === 'P300');
        const out = [p3.trace.ecr.size, chpHistoryState(p3).label, chpAlignStats().revMiss].join('|');
        setChpAlignMatchRev(false); hideError(); runComparison();
        return out;
      });
      assert(r === '0|NO HISTORY|1', 'P300 (EBOM rev A, CHP rev B): ' + r);
      await dwp.waitForFunction("state.results.length && state.results.every(x => (x.chpVia || []).every(k => k.indexOf('||') < 0)) && state.results.find(x => x.pn === 'P300').trace.ecr.size === 1", null, { timeout: 30000 });
    });
    const dSess = JSON.parse((await written('exportSessionJson()')).toString('utf8'));
    await dwp.evaluate("window.prompt = () => 'Drawing Auditor'");
    await dwp.evaluate('freezeReport()');
    await dwp.waitForFunction('state.isLocked && state.auditCert && state.auditCert.hash', null, { timeout: 30000 });
    const dCert = await dwp.evaluate('_auditCertRows(state.auditCert)');
    const dFrozen = path.join(tmp, 'drawing_frozen.json');
    fs.writeFileSync(dFrozen, await written('exportSessionJson()'));
    await check('the rule travels in the session, prints on the certificate, and reopens', async () => {
      assert(JSON.stringify(dSess.chpAlign) === '{"rule":"drawing","ebomDrawCol":12,"matchRev":false,"ebomRevCol":10,"label":"Drawing number"}',
             'session: ' + JSON.stringify(dSess.chpAlign));
      const row = dCert.find(r => r[0] === 'Change Pedigree Alignment');
      assert(row && row[1] === 'Drawing number · EBOM drawing column M (Drawing No.)', 'certificate: ' + JSON.stringify(row));
      const p3 = await ctx.newPage(); watch(p3, 'drawing reimport');
      await p3.goto(url(BUILD)); await p3.waitForFunction("typeof state !== 'undefined'");
      await p3.setInputFiles('#adj-import-input', dFrozen);
      await p3.waitForFunction('state.isLocked === true && state.results.length > 0', null, { timeout: 60000 });
      const r = await p3.evaluate("[state.chpAlign.rule, document.getElementById('chpa-summary').textContent, state.results.find(x => x.pn === 'P101').chpVia.join(','), _auditCertRows(state.auditCert).find(x => x[0] === 'Change Pedigree Alignment')[1]].join('|')");
      assert(r === 'drawing|Drawing number|D-100|Drawing number · EBOM drawing column M (Drawing No.)', r);
      await p3.evaluate('resetAll()');
      const after = await p3.evaluate("state.chpAlign.rule + '|' + document.getElementById('chpa-summary').textContent");
      assert(after === 'pn_nh|Default', 'after Reset: ' + after);
      await p3.close();
    });
    await check('the delta tool names both rules and warns when they differ', async () => {
      const aP = path.join(tmp, 'align_A.json'), bP = path.join(tmp, 'align_B.json');
      fs.writeFileSync(aP, JSON.stringify(Object.assign({}, sessA, { exportedAt: '2026-09-01T00:00:00.000Z' })));
      fs.writeFileSync(bP, fs.readFileSync(dFrozen));
      const dp = await ctx.newPage(); watch(dp, 'delta alignment');
      await dp.goto(url(DELTA));
      await dp.setInputFiles('#A-file', aP);
      await dp.waitForFunction("document.getElementById('card-A').classList.contains('loaded')", null, { timeout: 30000 });
      await dp.setInputFiles('#B-file', bP);
      await dp.waitForFunction("document.getElementById('card-B').classList.contains('loaded')", null, { timeout: 30000 });
      const warn = await dp.evaluate("document.body.textContent");
      assert(/different Change Pedigree Alignment rules/.test(warn), 'no load warning');
      await dp.click('#run-btn');
      await dp.waitForSelector('#results section');
      const [d] = await Promise.all([dp.waitForEvent('download'), dp.click('#export-btn')]);
      const wb = await readXlsx(page, fs.readFileSync(await d.path()));
      const row = wb['Summary'].find(r => r[0] === 'Change Pedigree alignment') || [];
      assert(row[1] === 'Part number + next higher' && row[2] === 'Drawing number (EBOM drawing column M)' && row[3] === 'DIFFERENT', JSON.stringify(row));
      await dp.close();
    });
    await dwp.close();

    // ── v183 — ACN Level and ACN Record Number in the Comparison Summary ──
    const ap = await ctx.newPage();
    watch(ap, 'acn columns');
    await ap.goto(url(BUILD));
    await ap.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
    await ap.evaluate(async () => {
      const orig = URL.createObjectURL.bind(URL);
      URL.createObjectURL = b => { if (b instanceof Blob) (window.__blobs = window.__blobs || []).push(b); return orig(b); };
      const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
      const book = (w, rows) => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
        return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
      };
      const files = {
        ebom: book(40, [['A','TOP','',1],['C','P100','TOP',1],['C','P200','TOP',1],['C','P300','TOP',1]].map(([i, pn, nh, q]) => ({ 0: i, 1: pn, 2: 'd', 3: nh, 7: q, 8: String(q) }))),
        abom: book(40, [['P100','TOP'],['P200','TOP']].map(([pn, nh]) => ({ 5: 'J1', 8: nh, 9: pn, 10: 'd', 13: 1, 35: 'WO1', 36: 'OPEN' }))),
        chp: book(25, [{ 3: 'P100', 5: 'TOP', 19: 'R1' }]),
        acn: book(4, [{ 0: 'ACN-7', 1: 'A', 2: 'P100', 3: '6' }, { 0: 'ACN-8', 1: 'B', 2: 'p100', 3: '7' }, { 0: 'ACN-9', 1: 'A', 2: 'P200', 3: '4' }]),
      };
      document.querySelector(".mode-btn[onclick*=\"'ebom_abom'\"]").click();
      for (const k of ['ebom', 'abom', 'chp', 'acn']) {
        handleFile(k, files[k]);
        const t0 = Date.now();
        while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) { if (Date.now() - t0 > 20000) throw new Error(k); await new Promise(r => setTimeout(r, 50)); }
      }
      runComparison();
    });
    await ap.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
    await check('the Comparison Summary shows ACN Level, Record Number and Record Revision right of CHP History', async () => {
      const r = await ap.evaluate(() => {
        renderSummaryTable();
        const ths = [...document.querySelectorAll('#summary-table-wrap thead th')].map(th => th.textContent.trim());
        const i = ths.indexOf('CHP History');
        const rowFor = pn => [...document.querySelectorAll('#summary-table-wrap tbody tr')].find(tr => [...tr.cells].some(td => td.textContent.trim() === pn));
        const cellsOf = pn => { const tr = rowFor(pn); return tr ? [1, 2, 3].map(k => tr.cells[i + k].innerText.replace(/\n+/g, '|')).join(' / ') : 'no row'; };
        return { next: ths.slice(i + 1, i + 4).join(','), p100: cellsOf('P100'), p200: cellsOf('P200'), p300: cellsOf('P300'), cells: ths.length };
      });
      assert(r.next === 'ACN Level,ACN Record Number,ACN Record Revision', 'after CHP History: ' + r.next);
      assert(r.p100 === '6|7 / ACN-7|ACN-8 / A|B' && r.p200 === '4 / ACN-9 / A' && r.p300 === '— / — / —', JSON.stringify(r));
    });
    await check('the Excel exports of the table carry the three columns, filled per line', async () => {
      const grab = t2 => ap.evaluate(async t3 => {
        window.__blobs = []; await eval(t3);
        for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(r => setTimeout(r, 50));
        const b = window.__blobs[window.__blobs.length - 1]; const u = new Uint8Array(await b.arrayBuffer()); let s = '';
        for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s);
      }, t2);
      const x = await readXlsx(ap, Buffer.from(await grab('exportXLSX()'), 'base64'));
      const bad = [];
      ['Comparison Summary', 'Issues Only', 'WO Status Not Closed'].forEach(sh => {
        const s = x[sh], h = s[0], i = h.indexOf('CHP History');
        if (h[i + 1] !== 'ACN Level' || h[i + 2] !== 'ACN Record Number' || h[i + 3] !== 'ACN Record Revision') bad.push(sh + ' header: ' + h.slice(i, i + 4).join(','));
        s.slice(1).forEach(r => { if (r.length !== h.length && r.length > h.length) bad.push(sh + ' row wider than header'); });
        const p100 = s.find(r => r[h.indexOf('Part Number')] === 'P100');
        if (p100 && (p100[i + 1] !== '6; 7' || p100[i + 2] !== 'ACN-7; ACN-8' || p100[i + 3] !== 'A; B')) bad.push(sh + ' P100: ' + p100.slice(i + 1, i + 4).join(' / '));
        if (!p100) bad.push(sh + ' has no P100 row');
      });
      await ap.evaluate("document.getElementById('search-input').value = 'P100'; setSearchMode('context'); renderSummaryTable();");
      const cx = await readXlsx(ap, Buffer.from(await grab('exportContextResults()'), 'base64'));
      const cs0 = cx['Context Results'];
      const hr = cs0.findIndex(r => r.indexOf('CHP History') >= 0);   // the sheet opens with a title block
      const cs = cs0.slice(Math.max(hr, 0)), ch = cs[0], ci = ch.indexOf('CHP History');
      const cp = cs.find(r => r[ch.indexOf('Part Number')] === 'P100');
      if (ch[ci + 1] !== 'ACN Level' || ch[ci + 3] !== 'ACN Record Revision' || !cp || cp[ci + 2] !== 'ACN-7; ACN-8' || cp[ci + 3] !== 'A; B') bad.push('context export: ' + JSON.stringify(cp ? cp.slice(ci, ci + 4) : ch));
      assert(!bad.length, bad.join('; '));
    });
    await ap.close();

    // ── v189 — CAGE code: mapped from the EBOM, shown in every table and report the owner listed ──
    // One program in the default layout (Mapping 1, CAGE in column Q). P100 sits on
    // three EBOM lines under ASM1 with two different codes and one repeat in lower
    // case; P200's code is a number in the file; P300 has none.
    const gp = await ctx.newPage();
    watch(gp, 'cage code');
    await gp.goto(url(BUILD));
    await gp.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
    await gp.evaluate(async () => {
      const orig = URL.createObjectURL.bind(URL);
      URL.createObjectURL = b => { if (b instanceof Blob) (window.__blobs = window.__blobs || []).push(b); return orig(b); };
      const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
      const book = (w, rows) => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
        return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
      };
      const E = [['A', 'TOP', '', 1, ''], ['B', 'ASM1', 'TOP', 1, '1ABC2'], ['C', 'P100', 'ASM1', 2, '81205'], ['C', 'P100', 'ASM1', 1, '0XY34'], ['C', 'P100', 'ASM1', 1, '0xy34 '],
                 ['C', 'P200', 'ASM1', 1, 7482], ['C', 'P300', 'ASM1', 3, ''], ['C', 'P400', 'ASM1', 1, 'K1234'], ['C', 'P500', 'ASM1', 1, 'U9999'], ['C', 'P600', 'ASM1', 5, 'S5555']];
      const files = {
        ebom: book(40, E.map(([i, pn, nh, q, cage]) => ({ 0: i, 1: pn, 2: 'desc ' + pn, 3: nh, 7: q, 8: String(q), 16: cage }))),
        mbom: book(40, [['P100', 'ASM1', 4], ['P200', 'ASM1', 1], ['P300', 'ASM1', 3], ['P400', 'ASM1', 1], ['P600', 'ASM1', 2]]
          .map(([pn, nh, q]) => ({ 5: 'J1', 8: nh, 9: pn, 10: 'd', 13: q, 35: 'WO1', 36: 'CLOSED' }))),
        abom: book(40, [['P100', 'ASM1', 4], ['P200', 'ASM1', 1], ['P300', 'ASM1', 3], ['P600', 'ASM1', 2]]
          .map(([pn, nh, q]) => ({ 5: 'J1', 8: nh, 9: pn, 10: 'd', 13: q, 35: 'WO1', 36: 'CLOSED' }))),
        ci: book(3, [{ 0: 'CI-1', 1: 'P100', 2: 'ASM1' }, { 0: 'CI-1', 1: 'P200', 2: 'ASM1' }, { 0: 'CI-2', 1: 'P300', 2: 'ASM1' }, { 0: 'CI-9', 1: 'P999', 2: 'NOPE' }]),
      };
      for (const k of ['ebom', 'mbom', 'abom', 'ci']) {
        handleFile(k, files[k]);
        const t0 = Date.now();
        while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) { if (Date.now() - t0 > 20000) throw new Error(k); await new Promise(r => setTimeout(r, 50)); }
      }
      runComparison();
    });
    await gp.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
    const gGrab = t2 => gp.evaluate(async t3 => {
      window.__blobs = []; await eval(t3);
      for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(r => setTimeout(r, 50));
      const b = window.__blobs[window.__blobs.length - 1]; const u = new Uint8Array(await b.arrayBuffer()); let s = '';
      for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s);
    }, t2);
    const gXlsx = async t2 => readXlsx(gp, Buffer.from(await gGrab(t2), 'base64'));
    const gText = async t2 => Buffer.from(await gGrab(t2), 'base64').toString('utf8');
    // A sheet with a title block: the table starts at the row that holds `mark`.
    const tableOf = (sheet, mark) => { const i = sheet.findIndex(r => r.indexOf(mark) >= 0); return i < 0 ? [[]] : sheet.slice(i); };
    const WANT = { P100: '81205; 0XY34', P200: '7482', P300: '', P400: 'K1234', ASM1: '1ABC2' };
    await check('CAGE is display data: no result row carries it, and the engine’s verdicts are what they were without it', async () => {
      const r = await gp.evaluate(() => ({
        keys: state.results.some(x => Object.keys(x).some(k => /cage/i.test(k))),
        st: Object.fromEntries(state.results.map(x => [x.pn, x.overall])), eq: state.results.find(x => x.pn === 'P100').eq }));
      assert(!r.keys, 'a result row has a CAGE field');
      assert(r.eq === 4 && r.st.P100 === 'ok' && r.st.P500 === 'missing' && r.st.P400 === 'missing' && r.st.P600 === 'qty_mismatch', JSON.stringify(r));
    });
    await check('the Comparison Summary shows CAGE Code between Part Qty Text and the delta column, every distinct code on a merged row', async () => {
      const r = await gp.evaluate(() => {
        renderSummaryTable();
        const ths = [...document.querySelectorAll('#summary-table-wrap thead th')];
        const names = ths.map(th => th.textContent.trim());
        const i = names.indexOf('CAGE Code (EBOM)');
        const cell = pn => { const tr = [...document.querySelectorAll('#summary-table-wrap tbody tr')].find(t => t.querySelector('.pn-col') && t.querySelector('.pn-col').textContent.trim().split(/\s/)[0] === pn); return tr ? tr.cells[i].textContent.trim() : 'no row'; };
        const widths = [...document.querySelectorAll('#summary-table-wrap tbody tr')].map(t => t.cells.length);
        return { before: names[i - 1], after: names[i + 1], cls: ths[i] ? ths[i].className : '', p100: cell('P100'), p200: cell('P200'), p300: cell('P300'), asm: cell('ASM1'),
                 ragged: widths.some(w => w !== names.length) };
      });
      assert(r.before === 'Part Qty Text (EBOM)' && /^Δ EBOM/.test(r.after), 'neighbours: ' + r.before + ' | ' + r.after);
      assert(/th-ebom/.test(r.cls), 'the heading is not in the EBOM block: ' + r.cls);
      assert(r.p100 === WANT.P100 && r.p200 === '7482' && r.p300 === '—' && r.asm === '1ABC2', JSON.stringify(r));
      assert(!r.ragged, 'a row has a different number of cells than the header');
    });
    await check('the base Excel export carries CAGE on all three sheets; the CSV, HTML and context exports carry it too', async () => {
      const bad = [];
      const colCheck = (name, tbl, pnHead) => {
        const h = tbl[0], i = h.indexOf('CAGE Code (EBOM)');
        if (i < 0 || h[i - 1] !== 'Part Qty Text (EBOM)') { bad.push(name + ' header: ' + h.slice(0, 14).join(',')); return; }
        tbl.slice(1).forEach(r => { if (r.length > h.length) bad.push(name + ' row wider than header'); });
        Object.keys(WANT).forEach(pn => {
          const rows = tbl.slice(1).filter(r => r[h.indexOf(pnHead || 'Part Number')] === pn);
          rows.forEach(r => { if (String(r[i]) !== WANT[pn]) bad.push(name + ' ' + pn + ': ' + JSON.stringify(r[i])); });
        });
        if (!tbl.slice(1).some(r => r[h.indexOf(pnHead || 'Part Number')] === 'P100')) bad.push(name + ' has no P100 row');
        if (h[h.length - 1].indexOf('Overall') !== 0) bad.push(name + ' last heading: ' + h[h.length - 1]);
        const last = tbl.slice(1).find(r => r[h.indexOf(pnHead || 'Part Number')] === 'P100');
        if (last && !/^(ok|missing|qty_mismatch|collector|wo_open)/.test(String(last[h.length - 1]))) bad.push(name + ' P100 overall cell: ' + last[h.length - 1]);
      };
      const x = await gXlsx('exportXLSX()');
      colCheck('Comparison Summary', x['Comparison Summary']);
      ['Issues Only', 'WO Status Not Closed'].forEach(sh => {
        const h = x[sh][0], i = h.indexOf('CAGE Code (EBOM)');
        if (i < 0 || h[i - 1] !== 'Part Qty Text (EBOM)') bad.push(sh + ' header');
        x[sh].slice(1).forEach(r => { if (r.length > h.length) bad.push(sh + ' row wider than header'); });
      });
      const p400 = x['Issues Only'].find(r => r[x['Issues Only'][0].indexOf('Part Number')] === 'P400');
      if (!p400 || p400[x['Issues Only'][0].indexOf('CAGE Code (EBOM)')] !== 'K1234') bad.push('Issues Only P400: ' + JSON.stringify(p400 && p400.slice(0, 12)));
      // CSV: parse the quoted rows.
      const csv = (await gText('exportCSV()')).split('\n').map(l => l.slice(1, -1).split('","'));
      colCheck('CSV', csv);
      // HTML report: the table's headings and the P100 row.
      const html = await gText('exportHTML()');
      const hr = await gp.evaluate(h => {
        const d = new DOMParser().parseFromString(h, 'text/html');
        const tb = [...d.querySelectorAll('table')].find(t => [...t.querySelectorAll('th')].some(th => th.textContent.trim() === 'CAGE Code (EBOM)'));
        if (!tb) return null;
        const ths = [...tb.querySelectorAll('th')].map(th => th.textContent.trim());
        const i = ths.indexOf('CAGE Code (EBOM)');
        const trs = [...tb.querySelectorAll('tbody tr')];
        const tr = trs.find(t => t.cells[1] && t.cells[1].textContent.trim() === 'P100');
        return { before: ths[i - 1], p100: tr ? tr.cells[i].textContent.trim() : 'no row', ragged: trs.some(t => t.cells.length !== ths.length), n: ths.length };
      }, html);
      if (!hr || hr.before !== 'Part Qty Text (EBOM)' || hr.p100 !== WANT.P100 || hr.ragged) bad.push('HTML report: ' + JSON.stringify(hr));
      await gp.evaluate("document.getElementById('search-input').value = 'P100'; setSearchMode('context'); renderSummaryTable();");
      const cx = await gXlsx('exportContextResults()');
      colCheck('context export', tableOf(cx['Context Results'], 'CAGE Code (EBOM)'));
      const ui = await gp.evaluate(() => {
        const names = [...document.querySelectorAll('#summary-table-wrap thead th')].map(th => th.textContent.trim());
        const i = names.indexOf('CAGE Code (EBOM)');
        const trs = [...document.querySelectorAll('#summary-table-wrap tbody tr')];
        return { first: names[0], before: names[i - 1], ragged: trs.some(t => t.cells.length !== names.length), any: trs.some(t => t.cells[i].textContent.trim() === '81205; 0XY34') };
      });
      if (ui.first !== 'Relationship' || ui.before !== 'Part Qty Text (EBOM)' || ui.ragged || !ui.any) bad.push('context view on screen: ' + JSON.stringify(ui));
      await gp.evaluate("document.getElementById('search-input').value = ''; setSearchMode('isolated'); renderSummaryTable();");
      assert(!bad.length, bad.join('; '));
    });
    await check('the CI Traceability Report carries CAGE on the Parts Mapping, Detail and CSA Pedigree sheets, and the CI tab shows it', async () => {
      const x = await gXlsx('exportCIReport()');
      const bad = [];
      const pm = tableOf(x['CI - EBOM Parts Mapping'], 'EBOM Part Indenture'), ph = pm[0], pi = ph.indexOf('CAGE Code');
      if (ph[pi - 1] !== 'Part Qty Text' || ph[pi + 1] !== 'Next Higher Part Number') bad.push('Parts Mapping header: ' + ph.join(','));
      const pmRows = pm.slice(1).filter(r => r[ph.indexOf('Part Number')] === 'P100').map(r => r[pi]).join('|');
      if (pmRows !== '81205|0XY34|0xy34') bad.push('Parts Mapping P100 rows (one per EBOM line, its own code): ' + pmRows);
      const nf = pm.slice(1).find(r => r[ph.indexOf('Part Number')] === 'P999');
      if (!nf || nf[pi] !== '—' || nf.length !== ph.length || !/^NOT FOUND/.test(nf[ph.length - 1])) bad.push('Parts Mapping placeholder row: ' + JSON.stringify(nf));
      pm.slice(1).forEach(r => { if (r.length !== ph.length) bad.push('Parts Mapping row width ' + r.length + ' vs ' + ph.length); });
      const dt = x['CI Traceability Detail'], dh = dt[0], di = dh.indexOf('EBOM CAGE Code');
      if (dh[di - 1] !== 'EBOM Part Qty Text' || dh[di + 1] !== 'CHP Part Qty Text') bad.push('Detail header: ' + dh.slice(0, 10).join(','));
      const dv = pn => (dt.slice(1).find(r => r[1] === pn) || [])[di];
      if (dv('P100') !== WANT.P100 || dv('P200') !== '7482' || dv('P300') !== '—' || dv('P999') !== '—') bad.push('Detail values: ' + [dv('P100'), dv('P200'), dv('P300'), dv('P999')].join(' / '));
      dt.slice(1).forEach(r => { if (r.length !== dh.length) bad.push('Detail row width ' + r.length + ' vs ' + dh.length); });
      if (dh[dh.length - 1] !== 'Pedigree Trace') bad.push('Detail last heading: ' + dh[dh.length - 1]);
      const cs = tableOf(x['CSA Pedigree Summary'], 'EBOM Present'), ch = cs[0], ci = ch.indexOf('EBOM CAGE Code(s)');
      if (ch[ci - 1] !== 'EBOM Present' || ch[ci + 1] !== 'All DCNs') bad.push('CSA header: ' + ch.slice(0, 7).join(','));
      const cv = id => (cs.slice(1).find(r => r[0] === id) || [])[ci];
      if (cv('CI-1') !== '81205; 0XY34; 7482' || cv('CI-2') !== '—' || cv('CI-9') !== '—') bad.push('CSA values: ' + [cv('CI-1'), cv('CI-2'), cv('CI-9')].join(' / '));
      cs.slice(1).forEach(r => { if (r.length !== ch.length) bad.push('CSA row width ' + r.length + ' vs ' + ch.length); });
      if (ch[ch.length - 1] !== 'Report Generated') bad.push('CSA last heading: ' + ch[ch.length - 1]);
      const tab = await gp.evaluate(() => {
        renderCITraceTable();
        const names = [...document.querySelectorAll('#ci-table-wrap thead th')].map(th => th.textContent.trim());
        const i = names.indexOf('EBOM CAGE Code');
        const trs = [...document.querySelectorAll('#ci-table-wrap tbody tr')];
        const tr = trs.find(t => t.cells[1].textContent.trim() === 'P100');
        return { before: names[i - 1], after: names[i + 1], p100: tr ? tr.cells[i].textContent.trim() : 'no row', ragged: trs.some(t => t.cells.length !== names.length) };
      });
      if (tab.before !== 'EBOM Part Qty Text' || tab.after !== 'CHP Part Qty Text' || tab.p100 !== WANT.P100 || tab.ragged) bad.push('CI tab: ' + JSON.stringify(tab));
      assert(!bad.length, bad.join('; '));
    });
    await check('both gap reports carry CAGE, and still list whole-line gaps before quantity shortfalls', async () => {
      const bad = [];
      const u = tableOf((await gXlsx('exportUnplannedNotInstalled()'))['Unplanned Not Installed'], 'Gap Type'), uh = u[0], ui = uh.indexOf('EBOM CAGE Code');
      if (uh[ui - 1] !== 'EBOM Qty Text' || uh[ui + 1] !== 'MBOM Qty') bad.push('Unplanned header: ' + uh.join(','));
      const ur = u.slice(1).map(r => [r[1], r[ui], r[uh.indexOf('Qty Missing')], r[uh.length - 1]].join('/')).join(' | ');
      if (ur !== 'P500/U9999/1/Missing from MBOM | P600/S5555/3/Qty Shortfall') bad.push('Unplanned rows: ' + ur);
      u.slice(1).forEach(r => { if (r.length !== uh.length) bad.push('Unplanned row width'); });
      const p = tableOf((await gXlsx('exportPlannedNotInstalled()'))['Planned Not Installed'], 'Gap Type'), ph = p[0], pi = ph.indexOf('EBOM CAGE Code');
      if (ph[pi - 1] !== 'EBOM Qty' || ph[pi + 1] !== 'MBOM Qty') bad.push('Planned header: ' + ph.join(','));
      const pr = p.slice(1).map(r => [r[1], r[pi], r[ph.indexOf('Qty Missing')], r[ph.length - 1]].join('/')).join(' | ');
      if (pr !== 'P400/K1234/1/Missing from ABOM') bad.push('Planned rows: ' + pr);
      p.slice(1).forEach(r => { if (r.length !== ph.length) bad.push('Planned row width'); });
      assert(!bad.length, bad.join('; '));
    });
    await check('the EBOM Full view marks the CAGE column, and Mapping 2 reads CAGE from column G of the same file', async () => {
      const r = await gp.evaluate(() => {
        switchTab('ebom', document.getElementById('tab-btn-ebom'));
        const th = [...document.querySelectorAll('#ebom-table-wrap thead th')][16];
        const tr = [...document.querySelectorAll('#ebom-table-wrap tbody tr')].find(t => t.cells[1].textContent.trim() === 'P400');
        const m1 = { head: th.textContent.trim(), cell: tr.cells[16].textContent.trim() };
        // Mapping 2 on the same raw rows, with a value planted in column G (index 6).
        state.boms.ebom.raw.forEach((row, i) => { if (i) row[6] = 'G' + i; });
        setEbomColumnMapping(2);
        const m2 = { relaid: state.boms.ebom.data[7][16], acc: ebomCageForKey('P400', '') };   // Mapping 2 reads next higher from AD, empty here
        renderFullBom('ebom', 0);
        const th2 = [...document.querySelectorAll('#ebom-table-wrap thead th')][16];
        return { m1, m2, head2: th2.textContent.trim() };
      });
      assert(r.m1.head === 'H16 [CAGE]' && r.m1.cell === 'K1234', 'Mapping 1 view: ' + JSON.stringify(r.m1));
      assert(r.m2.relaid === 'G8' && r.m2.acc === 'G8', 'Mapping 2 did not read column G, or the lookup served the old rows: ' + JSON.stringify(r.m2));
      assert(r.head2 === 'CAGE Code [CAGE]', 'Mapping 2 view heading: ' + r.head2);
    });
    await gp.close();

    // The Manual window, used as a user uses it: CAGE Code is a field, its default is Q,
    // and a typed letter is where the code is read from.
    const gm = await ctx.newPage();
    watch(gm, 'cage manual map');
    await gm.goto(url(BUILD));
    await gm.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
    await check('EBOM Manual mapping offers CAGE Code, defaults it to Q, reads the typed column, and saves the pick in the session', async () => {
      await gm.click('#ebom-cm-btn-manual');
      const win = await gm.evaluate(() => { const el = document.getElementById('ebom-map-cage'); return el ? { ph: el.placeholder, label: el.closest('tr').cells[0].textContent.trim() } : null; });
      assert(win && win.ph === 'default: Q' && win.label === 'CAGE Code', 'the window: ' + JSON.stringify(win));
      const letters = { indenture: 'A', pn: 'C', desc: 'D', nh: 'B', qty: 'E', qtyText: 'F', cage: 'AB' };
      for (const k of Object.keys(letters)) await gm.fill('#ebom-map-' + k, letters[k]);
      await gm.click('#mapper-panel button.btn-primary');
      const r = await gm.evaluate(async () => {
        const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
        const book = (w, rows) => {
          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
          return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
        };
        const files = {
          // Indenture | NH | PN | Desc | Qty | Qty Text … CAGE in AB; column Q holds something else.
          ebom: book(40, [['A', '', 'TOP', 1, ''], ['C', 'TOP', 'P100', 1, '5ZZZ9'], ['C', 'TOP', 'P200', 1, '']].map(([i, nh, pn, q, cage]) => ({ 0: i, 1: nh, 2: pn, 3: 'd', 4: q, 5: String(q), 16: 'NOT-CAGE', 27: cage }))),
          abom: book(40, [['P100', 'TOP'], ['P200', 'TOP']].map(([pn, nh]) => ({ 5: 'J1', 8: nh, 9: pn, 10: 'd', 13: 1, 35: 'WO1', 36: 'CLOSED' }))),
        };
        document.querySelector(".mode-btn[onclick*=\"'ebom_abom'\"]").click();
        for (const k of ['ebom', 'abom']) {
          handleFile(k, files[k]);
          const t0 = Date.now();
          while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) { if (Date.now() - t0 > 20000) throw new Error(k); await new Promise(r => setTimeout(r, 50)); }
        }
        runComparison();
        const t0 = Date.now();
        while (!(state.results && state.results.length)) { if (Date.now() - t0 > 30000) throw new Error('run'); await new Promise(r => setTimeout(r, 50)); }
        renderSummaryTable();
        const names = [...document.querySelectorAll('#summary-table-wrap thead th')].map(th => th.textContent.trim());
        const i = names.indexOf('CAGE Code (EBOM)');
        const cell = pn => { const tr = [...document.querySelectorAll('#summary-table-wrap tbody tr')].find(t => t.querySelector('.pn-col').textContent.trim().split(/\s/)[0] === pn); return tr ? tr.cells[i].textContent.trim() : 'no row'; };
        return { map: state.ebomManualMap.cage, p100: cell('P100'), p200: cell('P200'), st: state.results.find(x => x.pn === 'P100').overall };
      });
      assert(r.map === 27 && r.p100 === '5ZZZ9' && r.p200 === '—' && r.st === 'ok', JSON.stringify(r));
    });
    await gm.close();

    // ── v190 — the CI section without an ABOM; CI · MBOM ──
    // One program: TOP > ASM1 > P100..P500, ASM2 > P700. MBOM: P100 direct, P200 under
    // the wrong parent (covered by ASM1), P400 planned short, P500 only as a Used On,
    // ASM1/ASM2 direct. ABOM: P100, P300, ASM1, ASM2. CI file: seven CIs, one not in the EBOM.
    const cp = await ctx.newPage();
    watch(cp, 'ci without abom');
    await cp.goto(url(BUILD));
    await cp.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
    await cp.evaluate(() => {
      const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
      const book = (w, rows) => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
        return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
      };
      const E = [['A', 'TOP', '', 1], ['B', 'ASM1', 'TOP', 1], ['C', 'P100', 'ASM1', 2], ['C', 'P200', 'ASM1', 1], ['C', 'P300', 'ASM1', 1], ['C', 'P400', 'ASM1', 4], ['C', 'P500', 'ASM1', 1], ['B', 'ASM2', 'TOP', 1], ['C', 'P700', 'ASM2', 1]];
      const line = ([pn, nh, q]) => ({ 5: 'J1', 8: nh, 9: pn, 10: 'd', 13: q, 35: 'WO1', 36: 'CLOSED' });
      window.__ciFiles = {
        ebom: book(40, E.map(([i, pn, nh, q]) => ({ 0: i, 1: pn, 2: 'desc ' + pn, 3: nh, 7: q, 8: String(q) }))),
        mbom: book(40, [['ASM1', 'TOP', 1], ['P100', 'ASM1', 2], ['P200', 'ASM9', 1], ['P400', 'ASM1', 1], ['X1', 'P500', 1], ['ASM2', 'TOP', 1]].map(line)),
        abom: book(40, [['ASM1', 'TOP', 1], ['P100', 'ASM1', 2], ['P300', 'ASM1', 1], ['ASM2', 'TOP', 1]].map(line)),
        ncr:  book(60, [{ 0: 'N1', 1: 'OPEN', 3: 'WO9', 5: 'XPART', 8: '1', 9: 'OPEN' }]),
        ci:   book(3, [['CI-1', 'P100', 'ASM1'], ['CI-2', 'P200', 'ASM1'], ['CI-3', 'P400', 'ASM1'], ['CI-4', 'P500', 'ASM1'], ['CI-5', 'P700', 'ASM2'], ['CI-6', 'P300', 'ASM1'], ['CI-9', 'P999', 'NOPE']]
                .map(([a, b, c]) => ({ 0: a, 1: b, 2: c }))),
      };
      window.__ciRun = async (mode, loads) => {
        document.querySelector(".mode-btn[onclick*=\"'" + mode + "'\"]").click();
        for (const k of ['ebom', 'mbom', 'abom', 'ncr', 'ci']) {
          if (loads.indexOf(k) < 0) { if (state.boms[k]) state.boms[k] = null; continue; }
          if (state.boms[k] && state.boms[k].data && state.boms[k].data.length) continue;
          handleFile(k, window.__ciFiles[k]);
          const t0 = Date.now();
          while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) { if (Date.now() - t0 > 20000) throw new Error(k); await new Promise(r => setTimeout(r, 50)); }
        }
        state.results = null;
        runComparison();
        const t0 = Date.now();
        while (!(state.results && state.results.length)) { if (Date.now() - t0 > 30000) throw new Error('run'); await new Promise(r => setTimeout(r, 50)); }
        await new Promise(r => setTimeout(r, 300));
      };
      window.__ciView = () => {
        const shown = id => { const e = document.getElementById(id); return !!e && e.style.display !== 'none' && getComputedStyle(e).display !== 'none'; };
        const num = id => document.getElementById(id + '-num').textContent;
        const C = COL.ci, byKey = new Map(state.results.map(r => [r.key, r]));
        // An independent count, straight from the result rows and the main dashboard's predicates.
        const legs = { md: 0, mu: 0, mp: 0, mm: 0, mq: 0, ad: 0 };
        ((state.boms.ci && state.boms.ci.data) || []).forEach(row => { const r = byKey.get(normPN(row[C.pn]) + '||' + normPN(row[C.nh])); if (!r) return;
          if (_STATUS_DIRECT_OK.has(r.ms)) legs.md++; if (r.msUsedOn === 'pn_as_usedon') legs.mu++; if (_STATUS_COVERED.has(r.ms)) legs.mp++;
          if (r.ms === 'missing') legs.mm++; if (r.ms === 'qty_mismatch') legs.mq++; if (_STATUS_DIRECT_OK.has(r.as)) legs.ad++; });
        return { sec: shown('kpi-ci-status-section'), chip: shown('navchip-ci'), mbom: shown('kpi-ci-mbom-block'), abomLabel: shown('kpi-ci-abom-label'),
                 abom: ['kpi-ci-row-2', 'kpi-ci-row-3', 'kpi-ci-row-4', 'kpi-ci-open-wo', 'kpi-ci-row-5'].map(shown),
                 row1: document.getElementById('kpi-ci-row-1').style.gridTemplateColumns,
                 m: ['kpi-ci-mbom-pct-direct', 'kpi-ci-mbom-pct-any', 'kpi-ci-mbom-direct', 'kpi-ci-mbom-used-on', 'kpi-ci-mbom-parent', 'kpi-ci-mbom-missing', 'kpi-ci-mbom-qty'].map(num),
                 scope: num('kpi-ci-scope'), missEbom: num('kpi-ci-missing-ebom'), aDirect: num('kpi-ci-direct'),
                 legs, untraced: shown('kpi-ncr-ebom-untraced') ? num('kpi-ncr-ebom-untraced') : 'hidden',
                 staleAbom: (_kpiData.directReconciledCIs || []).length + (_kpiData.ciMissingAbomCIs || []).length };
      };
    });
    const ciView = async (mode, loads) => { await cp.evaluate(([m, l]) => window.__ciRun(m, l), [mode, loads]); return cp.evaluate('window.__ciView()'); };
    await check('EBOM↔MBOM with EBOM, MBOM and CI: the CI section shows, with CI Scope, CIs Missing from EBOM and the MBOM cards', async () => {
      const v = await ciView('ebom_mbom', ['ebom', 'mbom', 'ncr', 'ci']);
      assert(v.sec && v.chip && v.mbom && !v.abomLabel, JSON.stringify(v));
      assert(v.abom.every(x => !x) && v.row1 === '1fr 1fr', 'an ABOM-only row shows: ' + JSON.stringify(v.abom) + ' ' + v.row1);
      assert(v.scope === '7' && v.missEbom === '1', 'scope / missing from EBOM: ' + v.scope + ' / ' + v.missEbom);
      assert(JSON.stringify(v.m) === JSON.stringify(['14%', '71%', '1', '1', '3', '0', '1']), 'MBOM cards: ' + JSON.stringify(v.m));
      assert(+v.m[2] === v.legs.md && +v.m[3] === v.legs.mu && +v.m[4] === v.legs.mp && +v.m[5] === v.legs.mm && +v.m[6] === v.legs.mq,
             'a card disagrees with the result rows: ' + JSON.stringify(v.legs));
    });
    await check('without an ABOM, NCRs Without EBOM Trace is computed and shown (it needed CI and ABOM before v190)', async () => {
      const v = await cp.evaluate('window.__ciView()');
      assert(v.untraced === '1', 'NCRs Without EBOM Trace: ' + v.untraced);
    });
    await check('each CI · MBOM card opens its drill-down with the right CIs', async () => {
      const r = await cp.evaluate(() => {
        const rows = id => { document.getElementById(id).click();
          const o = document.getElementById('report-overlay');
          const out = [...o.querySelectorAll('tbody tr')].map(t => [...t.cells].map(c => c.textContent.trim()).join('/')).join(' | ');
          closeKpiReport(); return out; };
        return { qty: rows('kpi-ci-mbom-qty'), parent: rows('kpi-ci-mbom-parent'), used: rows('kpi-ci-mbom-used-on'), missing: rows('kpi-ci-mbom-missing') };
      });
      assert(r.qty === 'CI-3/P400/desc P400/ASM1/4/1/-3', 'qty: ' + r.qty);
      assert(r.parent === 'CI-2/P200/desc P200/ASM1/ASM1/1/—/— | CI-5/P700/desc P700/ASM2/ASM2/1/—/— | CI-6/P300/desc P300/ASM1/ASM1/1/—/—', 'parent: ' + r.parent);
      assert(/^CI-4\/P500\//.test(r.used), 'used on: ' + r.used);
      assert(/planned in the MBOM/.test(r.missing), 'missing: ' + r.missing);
    });
    await check('Full mode shows both legs, MBOM first, the ABOM leg labelled; both agree with the result rows', async () => {
      const v = await ciView('ebom_mbom_abom', ['ebom', 'mbom', 'abom', 'ncr', 'ci']);
      assert(v.sec && v.mbom && v.abomLabel && v.abom.every(x => x) && v.row1 === '1fr 1fr 1fr', JSON.stringify(v));
      assert(+v.m[2] === v.legs.md && +v.m[4] === v.legs.mp && +v.m[5] === v.legs.mm && +v.aDirect === v.legs.ad, JSON.stringify(v));
      const order = await cp.evaluate(() => document.getElementById('kpi-ci-mbom-block').compareDocumentPosition(document.getElementById('kpi-ci-row-2')) & Node.DOCUMENT_POSITION_FOLLOWING);
      assert(order, 'the MBOM block is not above the ABOM cards');
    });
    await check('a run without an ABOM after one with: the ABOM cards hide and their drill-down lists are empty, not the last run’s', async () => {
      const v = await ciView('ebom_mbom', ['ebom', 'mbom', 'ci']);
      assert(v.abom.every(x => !x) && v.staleAbom === 0, JSON.stringify(v));
    });
    await check('EBOM↔ABOM looks as it did before v190: no MBOM block, no leg label, three cards in the CI-only row', async () => {
      const v = await ciView('ebom_abom', ['ebom', 'abom', 'ci']);
      assert(v.sec && !v.mbom && !v.abomLabel && v.abom.every(x => x) && v.row1 === '1fr 1fr 1fr', JSON.stringify(v));
    });
    await check('no CI file: the section and its nav chip are hidden; the helpers after it still run', async () => {
      const v = await ciView('ebom_mbom_abom', ['ebom', 'mbom', 'abom', 'ncr']);
      assert(!v.sec && !v.chip, 'section ' + v.sec + ', chip ' + v.chip);
      assert(v.untraced === '1', 'NCRs Without EBOM Trace: ' + v.untraced);
    });
    await cp.close();

    // ── v191 — the CI Index tool's export as CI input ──
    // The CI Index tool writes the file: the fixture goes into the tool through
    // its own loadData and comes out through its own Excel export. Without the
    // tool beside the build, the same rows are written in the export's layout
    // by the build's SheetJS, and the run says so.
    const CIX = {
      cis: [
        { id: 'CI-1', parent: '',     name: 'Air vehicle',  type: 'HWCI',      status: 'Active',        pin: 'TOP',  nhpin: 'N/A',  qty: 'N/A' },
        { id: 'CI-2', parent: 'CI-1', name: 'Valve',        type: 'HWCI',      status: 'Active',        pin: 'P100', nhpin: 'ASM1', qty: '1', alsoIn: 'CI-1 in ASM2, Qty 2; CI-1 in ASM3, Qty 1' },
        { id: 'CI-3', parent: 'CI-1', name: 'Pump',         type: 'HWCI',      status: '',              pin: 'P200', nhpin: 'ASM1', qty: '1' },
        { id: 'CI-4', parent: 'CI-1', name: 'Proposed box', type: 'HWCI',      status: 'Proposed',      pin: 'P400', nhpin: 'ASM1', qty: '1' },
        { id: 'CI-5', parent: 'CI-1', name: 'Old box',      type: 'HWCI',      status: 'De-designated', pin: 'P500', nhpin: 'ASM1', qty: '1' },
        { id: 'CI-6', parent: 'CI-1', name: 'Avionics',     type: 'Collector', status: 'Active',        pin: '',     nhpin: '',     qty: '' },
        { id: 'CI-7', parent: 'CI-6', name: 'Radio',        type: 'HWCI',      status: 'Active',        pin: 'P700', nhpin: 'ASM9', qty: '1' },
        { id: 'CI-8', parent: 'CI-6', name: 'Software',     type: 'CSCI',      status: 'Active',        pin: 'SW-1', nhpin: 'P700', qty: '1' } ],
      vars: [ { ciId: 'CI-2', pin: 'P100B', nhpin: '', alsoIn: '' }, { ciId: 'CI-3', pin: 'P200B', nhpin: 'ASM4', alsoIn: '' },
              { ciId: 'CI-4', pin: 'P400B', nhpin: '', alsoIn: '' } ],
    };
    const CIX_EXPECT = ['CI-1|TOP|', 'CI-2|P100|ASM1', 'CI-2|P100|ASM2', 'CI-2|P100|ASM3', 'CI-2|P100B|ASM1', 'CI-2|P100B|ASM2',
                        'CI-2|P100B|ASM3', 'CI-3|P200|ASM1', 'CI-3|P200B|ASM4', 'CI-7|P700|ASM9', 'CI-8|SW-1|P700'];
    const cixPath = path.join(tmp, 'ci_index_export.xlsx');
    if (CIINDEX) {
      const tp = await ctx.newPage();
      watch(tp, 'ci index tool');
      await tp.goto(url(CIINDEX.path));
      await tp.waitForFunction("typeof doExport === 'function' && typeof loadData === 'function'");
      await tp.evaluate(f => { loadData({ meta: { prog: 'Harness' }, cis: f.cis, vars: f.vars }, null); render(); }, CIX);
      fs.writeFileSync(cixPath, await download(tp, 'doExport()'));
      await tp.close();
    } else {
      console.log('  (the CI Index tool is not beside the build: the v191 checks read a workbook written in its layout)');
      fs.writeFileSync(cixPath, Buffer.from(await page.evaluate(f => {
        const OTH = 'Other Installed Positions (parent CI ID in NH PIN, Qty X)';
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['CI Index'], ['Program', 'Harness']]), 'About');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Level', 'CI ID', 'Parent CI ID', 'CI Name / Nomenclature', 'CI Type', 'PIN', 'NH PIN', 'Qty per NH', OTH, 'Status']]
          .concat(f.cis.map(r => ['', r.id, r.parent, r.name, r.type, r.pin, r.nhpin, r.qty, r.alsoIn || '', r.status]))), 'CI Index');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['CI ID', 'Variant PIN / Version Identifier', 'NH PIN', OTH]]
          .concat(f.vars.map(v => [v.ciId, v.pin, v.nhpin, v.alsoIn]))), 'PN Variants');
        return Array.from(XLSX.write(wb, { type: 'array', bookType: 'xlsx' }));
      }, CIX)));
    }
    const xp = await ctx.newPage();
    watch(xp, 'ci index layout');
    let xPickers = 0;
    xp.on('filechooser', () => { xPickers++; });
    await xp.setViewportSize({ width: 1440, height: 900 });
    await xp.goto(url(BUILD));
    await xp.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
    await xp.evaluate(() => {
      const orig = URL.createObjectURL.bind(URL);
      URL.createObjectURL = b => { if (b instanceof Blob) (window.__blobs = window.__blobs || []).push(b); return orig(b); };
      window.__ciKeys = () => (state.boms.ci ? state.boms.ci.data : []).map(r => [r[COL.ci.ciId], r[COL.ci.pn], r[COL.ci.nh]].join('|'));
      window.__lit = () => ['default', 'manual', 'ciindex'].filter(k => document.getElementById('ci-cm-btn-' + k).classList.contains('active'));
    });
    await check('in Default, the CI Index export is refused in words and nothing loads', async () => {
      await xp.setInputFiles('#file-ci', cixPath);
      await xp.waitForFunction("document.getElementById('error-box').style.display === 'block'", null, { timeout: 20000 });
      const r = await xp.evaluate("({ msg: document.getElementById('error-box').textContent, ci: state.boms.ci, fn: document.getElementById('fn-ci').textContent })");
      assert(/is a CI Index export\. .*Press CI Index on the Configuration Items zone/.test(r.msg), r.msg);
      assert(r.ci === null && r.fn === 'Drop .xlsx or click', 'loaded anyway: ' + JSON.stringify(r));
    });
    await check('the CI Index button reads the tool’s own export: every position of every Active CI, nothing else, no file picker', async () => {
      await xp.click('#ci-cm-btn-ciindex');
      assert(xPickers === 0, 'the button opened the file picker');
      await xp.setInputFiles('#file-ci', cixPath);
      await xp.waitForFunction('state.boms.ci && state.boms.ci.data.length', null, { timeout: 20000 });
      const r = await xp.evaluate("({ keys: window.__ciKeys(), lit: window.__lit(), rows: document.getElementById('rows-ci').textContent, note: document.getElementById('ci-index-note').textContent, title: document.getElementById('ci-index-note').title, err: document.getElementById('error-box').style.display })");
      assert(JSON.stringify(r.keys) === JSON.stringify(CIX_EXPECT), 'rows: ' + JSON.stringify(r.keys));
      assert(JSON.stringify(r.lit) === '["ciindex"]' && r.rows === '11 rows loaded' && r.note === '5 CIs · 3 left out ⓘ', JSON.stringify(r));
      assert(/Left out: 1 CI with Status Proposed, 1 CI with Status De-designated, 1 Collector CI\./.test(r.title), r.title);
      assert(r.err === 'none', 'the Default refusal still shows');
    });
    await check('a run counts CI Scope by position, matches the top-level CI to the EBOM apex, and finds the positions missing from the EBOM', async () => {
      const r = await xp.evaluate(async () => {
        const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
        const book = (w, rows) => { const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
          return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx'); };
        const E = [['A', 'TOP', '', 1], ['B', 'ASM1', 'TOP', 1], ['B', 'ASM2', 'TOP', 1], ['C', 'P100', 'ASM1', 1], ['C', 'P100', 'ASM2', 2], ['C', 'P200', 'ASM1', 1], ['C', 'P100B', 'ASM1', 1]];
        const files = { ebom: book(40, E.map(([i, pn, nh, q]) => ({ 0: i, 1: pn, 2: 'd', 3: nh, 7: q, 8: String(q) }))),
                        mbom: book(40, [['ASM1', 'TOP', 1], ['P100', 'ASM1', 1]].map(([pn, nh, q]) => ({ 5: 'J1', 8: nh, 9: pn, 10: 'd', 13: q, 35: 'WO1', 36: 'CLOSED' }))) };
        document.querySelector(".mode-btn[onclick*=\"'ebom_mbom'\"]").click();
        for (const k of ['ebom', 'mbom']) { handleFile(k, files[k]);
          const t0 = Date.now(); while (!(state.boms[k] && state.boms[k].data.length)) { if (Date.now() - t0 > 20000) throw new Error(k); await new Promise(res => setTimeout(res, 50)); } }
        runComparison();
        const t0 = Date.now(); while (!(state.results && state.results.length)) { if (Date.now() - t0 > 30000) throw new Error('run'); await new Promise(res => setTimeout(res, 50)); }
        await new Promise(res => setTimeout(res, 300));
        return { scope: document.getElementById('kpi-ci-scope-num').textContent, miss: document.getElementById('kpi-ci-missing-ebom-num').textContent,
                 missing: _ciMissingFromEbom().map(m => [m.ciId, m.pn, m.nh].join('|')) };
      });
      assert(r.scope === '11', 'CI Scope ' + r.scope);
      assert(r.miss === '6' && JSON.stringify(r.missing) === JSON.stringify(['CI-2|P100|ASM3', 'CI-2|P100B|ASM2', 'CI-2|P100B|ASM3', 'CI-3|P200B|ASM4', 'CI-7|P700|ASM9', 'CI-8|SW-1|P700']),
             'missing from EBOM: ' + r.miss + ' ' + JSON.stringify(r.missing));
    });
    await check('the session carries the layout and the rows; Reset returns to Default; import brings back CI Index and its note', async () => {
      const r = await xp.evaluate(async () => {
        window.__blobs = []; exportSessionJson();
        for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(res => setTimeout(res, 50));
        const text = await window.__blobs[window.__blobs.length - 1].text();
        const sess = JSON.parse(text);
        resetAll();
        const afterReset = { mode: state.ciIndexMode, lit: window.__lit(), note: document.getElementById('ci-index-note').textContent };
        importSessionJson(new File([text], 's.json', { type: 'application/json' }));
        for (let i = 0; i < 200 && !(state.results && state.results.length); i++) await new Promise(res => setTimeout(res, 50));
        return { field: sess.ciIndexMode, rows: sess.boms.ci.data.length, afterReset,
                 back: { mode: state.ciIndexMode, lit: window.__lit(), keys: window.__ciKeys(), note: document.getElementById('ci-index-note').textContent } };
      });
      assert(r.field === true && r.rows === 11, 'session: ' + r.field + ' / ' + r.rows);
      assert(r.afterReset.mode === false && JSON.stringify(r.afterReset.lit) === '["default"]' && r.afterReset.note === '', 'after Reset: ' + JSON.stringify(r.afterReset));
      assert(r.back.mode === true && JSON.stringify(r.back.lit) === '["ciindex"]' && JSON.stringify(r.back.keys) === JSON.stringify(CIX_EXPECT) &&
             r.back.note === '5 CIs · 3 left out ⓘ', 'after import: ' + JSON.stringify(r.back));
    });
    await check('Cancel in the Manual window leaves CI Index lit; Default removes the export and asks for a CI file', async () => {
      await xp.click('#ci-cm-btn-manual');
      await xp.click("#mapper-panel button.btn:not(.btn-primary)");
      const mid = await xp.evaluate("({ lit: window.__lit(), n: state.boms.ci ? state.boms.ci.data.length : 0 })");
      assert(JSON.stringify(mid.lit) === '["ciindex"]' && mid.n === 11, 'after Cancel: ' + JSON.stringify(mid));
      await xp.click('#ci-cm-btn-default');
      const r = await xp.evaluate("({ lit: window.__lit(), ci: state.boms.ci, hint: document.getElementById('ci-cm-reparse-hint').classList.contains('visible'), note: document.getElementById('ci-index-note').textContent })");
      assert(JSON.stringify(r.lit) === '["default"]' && r.ci === null && r.hint && r.note === '', 'after Default: ' + JSON.stringify(r));
      assert(xPickers === 0, 'a button opened the file picker');
    });
    await check('the CI zone fits its three buttons and its note at 1920, 1440 and 1024px', async () => {
      await xp.click('#ci-cm-btn-ciindex');
      await xp.setInputFiles('#file-ci', cixPath);
      await xp.waitForFunction('state.boms.ci && state.boms.ci.data.length', null, { timeout: 20000 });
      for (const w of [1920, 1440, 1024]) {
        await xp.setViewportSize({ width: w, height: 900 });
        await xp.waitForTimeout(200);
        const r = await xp.evaluate(() => { const z = document.getElementById('zone-ci'), n = document.getElementById('ci-index-note'), b = document.getElementById('ci-cm-btn-ciindex').getBoundingClientRect(), zr = z.getBoundingClientRect();
          return { over: z.scrollWidth > z.clientWidth + 1, noteOver: n.scrollWidth > n.clientWidth + 1, inside: b.left >= zr.left && b.right <= zr.right }; });
        assert(!r.over && !r.noteOver && r.inside, w + 'px: ' + JSON.stringify(r));
      }
      await xp.setViewportSize({ width: 1440, height: 900 });
    });
    await xp.close();

    // ── v186 — CI and RFV manual column maps; the Disposition Code card ──
    // The maps are set through the real window (click Manual…, type letters,
    // Apply) before upload, on files laid out unlike the default.
    const mp = await ctx.newPage();
    watch(mp, 'ci/rfv maps');
    let pickers = 0;
    mp.on('filechooser', () => { pickers++; });
    await mp.setViewportSize({ width: 1440, height: 900 });
    await mp.goto(url(BUILD));
    await mp.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
    const applyMap = async (bom, letters) => {
      await mp.click('#' + bom + '-cm-btn-manual');
      for (const k of Object.keys(letters)) await mp.fill('#' + bom + '-map-' + k, letters[k]);
      await mp.click("#mapper-panel button.btn-primary");
    };
    await applyMap('ci', { ciId: 'D', pn: 'A', nh: 'B' });
    await applyMap('rfv', { rfvNum: 'B', pn: 'C', nh: 'D' });
    await mp.evaluate(async () => {
      const orig = URL.createObjectURL.bind(URL);
      URL.createObjectURL = b => { if (b instanceof Blob) (window.__blobs = window.__blobs || []).push(b); return orig(b); };
      const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
      const book = (w, rows) => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
        return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
      };
      const N = (code, st) => ({ 0: 'N1', 1: st || 'OPEN', 25: 'WO1', 43: 'P100', 47: 'C1', 48: 'Damaged', 71: 'D-' + Math.random().toString(36).slice(2, 7), 72: 'WORKING', 77: code });
      const files = {
        ebom: book(40, [['A','TOP','',1],['C','P100','TOP',1],['C','P200','TOP',1]].map(([i, pn, nh, q]) => ({ 0: i, 1: pn, 2: 'd', 3: nh, 7: q, 8: String(q) }))),
        abom: book(40, [['P100','TOP'],['P200','TOP']].map(([pn, nh]) => ({ 5: 'J1', 8: nh, 9: pn, 10: 'd', 13: 1, 35: 'WO1', 36: 'CLOSED' }))),
        ncr: book(90, [N('UAI'), N('uai '), N('REWORK'), N(''), N('SCRAP', 'CANCELLED')]),
        // CI laid out as PN | NH | (other) | CI ID; one row with no PN is dropped.
        ci: book(4, [{ 0: 'P100', 1: 'TOP', 2: 'x', 3: 'CI-1' }, { 0: 'P200', 1: 'TOP', 2: 'x', 3: 'CI-2' }, { 0: '', 1: 'TOP', 2: 'x', 3: 'CI-3' }]),
        // RFV laid out as (other) | RFV Number | PN | NH.
        rfv: book(4, [{ 0: 'note', 1: 'RFV-1', 2: 'P100', 3: 'TOP' }]),
      };
      document.querySelector(".mode-btn[onclick*=\"'ebom_abom'\"]").click();
      for (const k of ['ebom', 'abom', 'ncr', 'ci', 'rfv']) {
        handleFile(k, files[k]);
        const t0 = Date.now();
        while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) { if (Date.now() - t0 > 20000) throw new Error(k); await new Promise(r => setTimeout(r, 50)); }
      }
      runComparison();
    });
    await mp.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
    await mp.waitForTimeout(500);
    await check('CI and RFV files in their own layouts load through Manual mapping and feed the CI cards', async () => {
      const r = await mp.evaluate(() => ({
        btn: ['ci', 'rfv'].map(b => document.getElementById(b + '-cm-btn-manual').textContent).join(','),
        ci: state.boms.ci.data.map(x => [x[COL.ci.ciId], x[COL.ci.pn], x[COL.ci.nh]].join('/')).join(' '),
        rows: document.getElementById('rows-ci').textContent,
        scope: document.getElementById('kpi-ci-scope-num').textContent.trim(),
        p1: document.getElementById('kpi-rfv-p1-num').textContent.trim() }));
      assert(r.btn === 'Manual ✓,Manual ✓', 'buttons: ' + r.btn);
      assert(r.ci === 'CI-1/P100/TOP CI-2/P200/TOP' && r.rows === '2 rows loaded', 'CI rows: ' + r.ci + ' · ' + r.rows);
      assert(r.scope === '2' && r.p1 === '1', 'CI Scope ' + r.scope + ', RFV P1 ' + r.p1);
      assert(pickers === 0, 'clicking the mapping control opened the file picker ' + pickers + ' time(s)');
    });
    await check('the cause code and Disposition Code lists count every code, three across, stacking on narrow windows', async () => {
      const probe = () => mp.evaluate(() => {
        const row = document.getElementById('secondary-charts-row');
        const cards = [...row.children].map(c => c.getBoundingClientRect());
        const list = [...document.querySelectorAll('#ncr-disp-code-list .ncr-code-row')].map(r =>
          r.querySelector('.ncr-code-name').innerText.trim() + ' ' + r.querySelector('.ncr-code-n').innerText.trim());
        const cause = [...document.querySelectorAll('#ncr-cause-code-list .ncr-code-row')].map(r =>
          r.querySelector('.ncr-code-name').innerText.trim() + ' ' + r.querySelector('.ncr-code-n').innerText.trim());
        const over = [...row.querySelectorAll('.chart-card')].filter(c => c.scrollWidth > c.clientWidth + 1).length;
        // The expected list, worked out here from the run's own NCR entries by
        // the rule the owner chose: every non-cancelled entry, both pools.
        const want = {};
        state.results.forEach(x => (x.ncrEntriesPool1 || []).concat(x.ncrEntriesPool2 || []).forEach(e => {
          if (String(e.ncrStatus).toUpperCase() === 'CANCELLED') return;
          const k = String(e.dispCode).trim().toUpperCase() || 'UNSPECIFIED'; want[k] = (want[k] || 0) + 1; }));
        const wantCause = {};
        state.results.forEach(x => (x.ncrEntriesPool1 || []).concat(x.ncrEntriesPool2 || []).forEach(e => {
          if (String(e.ncrStatus).toUpperCase() === 'CANCELLED') return;
          const k = String(e.causeCode).trim().toUpperCase() + ': ' + e.causeCodeDesc; wantCause[k] = (wantCause[k] || 0) + 1; }));
        return { list, want, cause, wantCause, canvases: document.querySelectorAll('canvas').length, over, rw: row.getBoundingClientRect().width, cards: cards.map(b => [Math.round(b.left), Math.round(b.top), Math.round(b.width)]),
                 title: row.children[1].querySelector('.chart-title').textContent };
      });
      const wide = await probe();
      const w = wide.want;
      assert(w.UAI === 2 * w.REWORK && w.REWORK === w.UNSPECIFIED && w.REWORK > 0 && !w.SCRAP, 'fixture: ' + JSON.stringify(w));
      assert(JSON.stringify(wide.list) === JSON.stringify(['UAI ' + w.UAI, 'REWORK ' + w.REWORK, 'UNSPECIFIED ' + w.UNSPECIFIED]), 'list: ' + JSON.stringify(wide.list) + ' want ' + JSON.stringify(w));
      assert(wide.title === 'NCR by disposition code', 'second card: ' + wide.title);
      assert(JSON.stringify(wide.cause) === JSON.stringify(Object.keys(wide.wantCause).map(k => k + ' ' + wide.wantCause[k])) && wide.cause.length === 1,
        'cause list: ' + JSON.stringify(wide.cause) + ' want ' + JSON.stringify(wide.wantCause));
      assert(wide.canvases === 0, wide.canvases + ' canvas element(s) on the page');
      const [a, b, c] = wide.cards;
      assert(a[1] === b[1] && b[1] === c[1] && a[0] < b[0] && b[0] < c[0], '1440px, not three across: ' + JSON.stringify(wide.cards));
      assert(a[2] > b[2] && b[2] >= 200, '1440px widths: ' + JSON.stringify(wide.cards));
      await mp.setViewportSize({ width: 1200, height: 900 });
      await mp.waitForTimeout(300);
      const mid = await probe();
      assert(mid.cards[0][1] === mid.cards[1][1] && mid.cards[1][1] === mid.cards[2][1] && mid.cards[0][2] > mid.cards[1][2], '1200px, not three across: ' + JSON.stringify(mid.cards));
      await mp.setViewportSize({ width: 800, height: 900 });
      await mp.waitForTimeout(300);
      const narrow = await probe();
      assert(narrow.cards[0][1] < narrow.cards[1][1] && narrow.cards[1][1] < narrow.cards[2][1], '800px, not stacked: ' + JSON.stringify(narrow.cards));
      assert(!wide.over && !mid.over && !narrow.over, 'a card scrolls sideways');
      await mp.setViewportSize({ width: 1440, height: 900 });
    });
    await check('the CI and RFV maps travel in the session, clear on Reset and come back on import', async () => {
      const r = await mp.evaluate(async () => {
        window.__blobs = []; exportSessionJson();
        for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(res => setTimeout(res, 50));
        const text = await window.__blobs[window.__blobs.length - 1].text();
        const sess = JSON.parse(text);
        resetAll();
        const afterReset = [state.ciManualMap, state.rfvManualMap, document.getElementById('ci-cm-btn-manual').textContent,
                            document.getElementById('rfv-cm-btn-default').classList.contains('active')];
        importSessionJson(new File([text], 's.json', { type: 'application/json' }));
        for (let i = 0; i < 200 && !(state.results && state.results.length); i++) await new Promise(res => setTimeout(res, 50));
        return { ci: sess.ciManualMap, rfv: sess.rfvManualMap, afterReset,
                 back: [JSON.stringify(state.ciManualMap), document.getElementById('ci-cm-btn-manual').textContent, document.getElementById('rfv-cm-btn-manual').textContent] };
      });
      assert(JSON.stringify(r.ci) === '{"ciId":3,"pn":0,"nh":1}', 'session ciManualMap ' + JSON.stringify(r.ci));
      assert(r.rfv && r.rfv.rfvNum === 1 && r.rfv.pn === 2 && r.rfv.nh === 3, 'session rfvManualMap ' + JSON.stringify(r.rfv));
      assert(JSON.stringify(r.afterReset) === '[null,null,"Manual…",true]', 'after Reset: ' + JSON.stringify(r.afterReset));
      assert(r.back[0] === '{"ciId":3,"pn":0,"nh":1}' && r.back[1] === 'Manual ✓' && r.back[2] === 'Manual ✓', 'after import: ' + JSON.stringify(r.back));
    });
    // v187 — headings over re-laid rows, on screen and in the raw sheets,
    // and the mapping box wide enough to show its default letter.
    await check('re-laid files are headed by field name on their tabs and raw sheets; the mapping box shows its default', async () => {
      const r = await mp.evaluate(async () => {
        // An NCR manual map that swaps the Discrepant Part and Cause Code columns.
        state.ncrManualMap = Object.assign({}, COL.ncr, { discrepantPart: COL.ncr.causeCode, causeCode: COL.ncr.discrepantPart });
        _reparseBomFromRaw('ncr');
        renderNcrTable(0);
        const ths = [...document.querySelectorAll('#ncr-table-wrap thead th')].map(th => th.textContent.trim());
        document.getElementById('export-raw-chk').checked = true;
        window.__blobs = []; await exportXLSX();
        for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(res => setTimeout(res, 50));
        const wb = XLSX.read(new Uint8Array(await window.__blobs[window.__blobs.length - 1].arrayBuffer()), { type: 'array' });
        const head = n => (XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: '' })[0] || []);
        const ncrH = head('NCR'), ciH = head('CI'), ebomH = head('EBOM');
        document.getElementById('export-raw-chk').checked = false;
        // The box: the placeholder's drawn width against the box's content width.
        await new Promise(res => { document.getElementById('ncr-cm-btn-manual').click(); setTimeout(res, 100); });
        const inp = document.getElementById('ncr-map-dispCode');
        const cs = getComputedStyle(inp), cx = document.createElement('canvas').getContext('2d');
        cx.font = cs.fontSize + ' ' + cs.fontFamily;
        const need = cx.measureText(inp.placeholder.toUpperCase()).width;
        const room = inp.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
        _cancelSuppManualMap('ncr');
        return { thPart: ths[COL.ncr.discrepantPart], thCause: ths[COL.ncr.causeCode + 1],   // +1: the tab inserts DISCREPANT PART QTY after the part
                 thQty: ths[COL.ncr.discrepantPart + 1],
                 xPart: ncrH[COL.ncr.discrepantPart], xQty: ncrH[COL.ncr.discrepantPart + 1], xCause: ncrH[COL.ncr.causeCode + 1],
                 ci: ciH.slice(0, 3).join(','), ebom: ebomH[COL.ebom.pn], ebomFile: ebomH[COL.ebom.pn] === 'H' + COL.ebom.pn,
                 need, room, placeholder: inp.placeholder };
      });
      assert(r.thPart === 'Discrepant Part Number' && r.thQty === 'DISCREPANT PART QTY \u2605' && r.thCause === 'Cause Code', 'NCR tab headings: ' + JSON.stringify([r.thPart, r.thQty, r.thCause]));
      assert(r.xPart === 'Discrepant Part Number' && r.xQty === 'DISCREPANT PART QTY \u2605' && r.xCause === 'Cause Code', 'NCR raw sheet: ' + JSON.stringify([r.xPart, r.xQty, r.xCause]));
      assert(r.ci === 'CI Identifier,Part Number,Next Higher Part Number', 'CI raw sheet: ' + r.ci);
      assert(r.ebomFile, 'an EBOM in its own layout must keep its file headings: ' + r.ebom);
      assert(r.need <= r.room, 'placeholder "' + r.placeholder + '" needs ' + r.need.toFixed(1) + 'px, the box has ' + r.room.toFixed(1) + 'px');
    });
    await mp.close();

    // ── Delta v3.7 — EBOM to EBOM ──
    // Two EBOM files, built in the page with SheetJS and written to disk: A in
    // the Mapping 2 layout, B in a layout of its own read through a Manual map
    // typed into the delta tool's form. Each kind of change appears once.
    {
      const mkBook = (rows) => page.evaluate(rs => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rs), 'S');
        return XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });
      }, rows);
      const m2 = (ind, pn, nh, qty, txt, rev, desc) => { const r = new Array(30).fill(''); r[0] = ind; r[1] = pn; r[2] = desc || ('d ' + pn); r[5] = rev || ''; r[10] = txt == null ? String(qty) : txt; r[11] = qty; r[29] = nh; return r; };
      const hdr2 = new Array(30).fill('').map((_, i) => 'M2_' + i);
      const A = [hdr2, m2('A', 'TOP', '', 1), m2('B', 'ASM1', 'TOP', 1), m2('C', 'P100', 'ASM1', 2, '2', 'A'), m2('C', 'p100 ', 'ASM1', 1, '1', ''),
                 m2('C', 'P200', 'ASM1', 1, '1', 'A'), m2('C', 'P300', 'ASM1', 3), m2('C', 'P400', 'ASM1', 1), m2('C', 'P500', 'ASM1', 1, 'ar', '', 'bracket')];
      // B: PN | NH | Desc | Qty | Qty text | Indenture | PL rev | Part type
      const B = [['PN', 'NH', 'Desc', 'Qty', 'QtyTxt', 'Ind', 'Rev', 'Type'],
                 ['TOP', '', 'd TOP', 1, '1', '1', '', ''], ['ASM1', 'TOP', 'd ASM1', 1, '1', '2', '', ''], ['P100', 'ASM1', 'd P100', 3, '1', '3', 'A', ''],
                 ['P200', 'ASM1', 'd P200', 2, '1', 'C', 'B', ''], ['P300', 'ASM2', 'd P300', 3, '3', 'C', '', ''], ['P500', 'ASM1', 'BRACKET, LH', 1, 'AR', 'C', '', ''],
                 ['P600', 'ASM1', 'd P600', 1, '1', 'C', '', '']];
      const ePathA = path.join(tmp, 'ebom_A.xlsx'), ePathB = path.join(tmp, 'ebom_B.xlsx');
      fs.writeFileSync(ePathA, Buffer.from(await mkBook(A), 'base64'));
      fs.writeFileSync(ePathB, Buffer.from(await mkBook(B), 'base64'));
      const ep = await ctx.newPage(); watch(ep, 'delta ebom');
      await ep.goto(url(DELTA));
      await ep.click('#mode-ebom');
      await ep.selectOption('#eA-map', '2');
      await ep.setInputFiles('#eA-file', ePathA);
      await ep.waitForFunction("document.getElementById('card-eA').classList.contains('loaded')", null, { timeout: 30000 });
      await ep.selectOption('#eB-map', 'manual');
      const letters = { pn: 'A', nh: 'B', desc: 'C', qty: 'D', qtyText: 'E', indenture: 'F', drawingRev: 'G', partType: 'H' };
      for (const k of Object.keys(letters)) await ep.fill('#eB-map-' + k, letters[k]);
      await ep.click('#eB-map-apply');
      await ep.setInputFiles('#eB-file', ePathB);
      await ep.waitForFunction("document.getElementById('card-eB').classList.contains('loaded')", null, { timeout: 30000 });
      await check('the delta tool reads two EBOM files, one in Mapping 2 and one through a Manual map, merging lines as Comparator does', async () => {
        const st = await ep.evaluate(() => [document.getElementById('eA-status').innerText, document.getElementById('eB-status').innerText,
                                            document.getElementById('pane-sessions').hidden, document.getElementById('e-run-btn').disabled]);
        assert(/8 rows read · 7 line items · Mapping 2/.test(st[0]), 'A: ' + st[0]);
        assert(/7 rows read · 7 line items · Manual \(/.test(st[1]), 'B: ' + st[1]);
        assert(st[2] === true && st[3] === false, 'panes / run button: ' + JSON.stringify(st.slice(2)));
      });
      await ep.click('#e-run-btn');
      await ep.waitForSelector('#e-results section');
      const [dl] = await Promise.all([ep.waitForEvent('download'), ep.click('#e-export-btn')]);
      const ewb = await readXlsx(page, fs.readFileSync(await dl.path()));
      await check('the EBOM delta reports each kind of change once, on screen and in its Summary and EBOM Changes sheets', async () => {
        const ch = ewb['EBOM Changes'], h = ch[0], col = n => h.indexOf(n);
        const got = ch.slice(1).map(r => [r[col('Change Type')], r[col('Part Number')], r[col('Fields Changed')], r[col('Old Next Higher')], r[col('New Next Higher')]].join('|'));
        // v3.8 — BOM order: B's order, the removed P400 after P300, where it sat in A.
        assert(JSON.stringify(got) === JSON.stringify(['Changed|P200|Qty; Drawing PL Rev|ASM1|ASM1', 'Re-parented|P300||ASM1|ASM2', 'Removed|P400||ASM1|', 'Added|P600|||ASM1']),
               'changes: ' + JSON.stringify(got));
        const p100 = ch.find(r => r[col('Part Number')] === 'P100');
        assert(!p100, 'P100 (two A rows, 2 + 1 = 3) should match B’s single row of 3');
        const by = Object.fromEntries(ewb['Summary'].filter(r => r[0]).map(r => [r[0], r]));
        assert(by['Line items unchanged'][3] === '4' && by['File'][1] === 'ebom_A.xlsx' && by['Column mapping'][1] === 'Mapping 2', 'summary: ' + JSON.stringify([by['Line items unchanged'], by['File'], by['Column mapping']]));
        const screen = await ep.evaluate(() => document.getElementById('e-results').innerText);
        assert(/4 line items, in BOM order · 1 removed · 1 re-parented · 1 changed · 1 added/.test(screen), 'on screen: ' + screen.slice(0, 300));
      });
      await check('the EBOM delta shows its panels and similarity, and exports a Change Apexes sheet', async () => {
        const p = await ep.evaluate(() => [...document.querySelectorAll('#e-results .e-panel')].map(x => x.querySelector('.e-num').textContent + ' ' + x.querySelector('.e-label').textContent));
        assert(JSON.stringify(p) === JSON.stringify(['50.0% Similarity', '4 Line items that differ', '1 Removed', '1 Re-parented', '1 Changed', '1 Added', '4 Change apexes']), 'panels: ' + JSON.stringify(p));
        const segs = await ep.evaluate(() => [...document.querySelectorAll('#e-results .e-strip span')].map(x => x.className + ':' + x.style.flexGrow));
        assert(JSON.stringify(segs) === JSON.stringify(['seg-same:4', 'seg-changed:1', 'seg-moved:1', 'seg-removed:1', 'seg-added:1']), 'strip: ' + JSON.stringify(segs));
        const ap = ewb['Change Apexes'], ah = ap[0];
        assert(ap.length === 5 && ap.slice(1).every(r => r[ah.indexOf('Lines Changed in Subtree')] === 1), 'apex sheet: ' + JSON.stringify(ap));
        const ch = ewb['EBOM Changes'], h = ch[0];
        assert(ch.slice(1).every(r => r[h.indexOf('Is Apex')] === 'Y' && r[h.indexOf('Change Apex')] === r[h.indexOf('Part Number')]), 'every row its own apex here');
        const by = Object.fromEntries(ewb['Summary'].filter(r => r[0]).map(r => [r[0], r]));
        assert(by['Similarity (identical line items, of all distinct line items)'][3] === '50.0% (4 of 8)', 'summary similarity: ' + JSON.stringify(by['Similarity (identical line items, of all distinct line items)']));
      });
      await check('the EBOM delta and Comparator agree on what a line item is', async () => {
        // The same file A through Comparator itself, Mapping 2, in a fresh page
        // (the first page is frozen by now, and a frozen report takes no upload).
        const cp = await ctx.newPage(); watch(cp, 'ebom cross-check');
        await cp.goto(url(BUILD));
        await cp.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
        const r = await cp.evaluate(async b64 => {
          setEbomColumnMapping(2);
          const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
          handleFile('ebom', new File([u], 'ebom_A.xlsx'));
          for (let i = 0; i < 200 && !(state.boms.ebom && state.boms.ebom.filename === 'ebom_A.xlsx'); i++) await new Promise(res => setTimeout(res, 50));
          const q = buildQtyMap(state.boms.ebom.data, COL.ebom.pn, COL.ebom.nh, COL.ebom.qty, true);
          const out = { keys: Object.keys(q).length, p100: q['P100||ASM1'], rows: state.boms.ebom.data.length };
          return out;
        }, fs.readFileSync(ePathA).toString('base64'));
        await cp.close();
        const by = Object.fromEntries(ewb['Summary'].filter(x => x[0]).map(x => [x[0], x]));
        assert(r.keys === by['Line items (part number + next higher)'][1] && r.rows === by['EBOM rows read (rows with a part number)'][1] && r.p100 === 3,
               'Comparator ' + JSON.stringify(r) + ' vs delta ' + JSON.stringify([by['Line items (part number + next higher)'], by['EBOM rows read (rows with a part number)']]));
      });
      await ep.close();
    }

    await check('no page error or console error anywhere in the run', async () => {
      assert(!errors.length, errors.slice(0, 5).join(' | '));
    });
    await ctx.close();
  } catch (e) {
    results.push({ name: 'the browser run completed', error: e });
  } finally {
    await browser.close();
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {}
  }
  return results;
}

// ── REFERENCE — default output matches a reference build ───────────────────
// v182. Opt-in: node comparator-tests.js --reference=path/to/previous_build.html
// Runs one program through the reference build and the build under test, with
// every setting at its default, and compares every output a user can take away:
// the results, the rendered Comparison Summary and Change Pedigree tab, the
// Excel, CSV and HTML exports, the CI Traceability Report and As-Built Records
// Guide, both ECN reports, the context export, the session file, the certificate
// hash payload and every certificate-bearing export after freezing. Time stamps,
// the build number and the hash itself are masked; nothing else is.
//
// This is how v182 showed that Change Pedigree Alignment changes nothing for a
// program on the default rule. The fixture exercises every CHP join the build
// makes, including the two v181 disagreements kept on purpose (KI-1, KI-2).
// Keep a copy of the previous build under another file name to use it.
const REFERENCE = (ARGS.find(a => a.startsWith('--reference=')) || '').slice('--reference='.length) || null;
const REFERENCE_EXPECTED = 60;   // 58 outputs compared, the known-additions check and the page-error check (v186: +CI tab, RFV tab, four RFV report sheets; v189: +both gap reports, +the known-additions check)
const REFERENCE_SUITE = 'Reference — default output matches a reference build';

// v189 — known additions. The reference suite fails on any difference, which
// is right for a build that promises "no change". v189 does change the default
// output, on purpose and in one way: a CAGE code column in the tables and
// reports the owner listed. So when the reference build is older than v189,
// that column (and the one line that explains it in each gap report's title
// block) is taken out of THIS build's outputs before comparing, and what is
// left must be the reference build's output exactly. That proves the column
// was added and nothing else moved. The removal is by heading name, so a
// column in the wrong place, a shifted cell or a second new column still
// fails. Against a v189 or later reference nothing is removed.
const CAGE_SINCE = 189;
const CAGE_HEADS = ['CAGE Code (EBOM)', 'EBOM CAGE Code', 'EBOM CAGE Code(s)', 'CAGE Code'];
// The outputs that must carry the column, by label ("output · sheet").
const CAGE_OUTPUTS = ['Comparison Summary, as rendered', 'CI tab, as rendered', 'CSV export', 'HTML report',
  'Excel export · Comparison Summary', 'Excel export · Issues Only', 'Excel export · WO Status Not Closed',
  'CI Traceability Report · CI Traceability Detail', 'CI Traceability Report · CSA Pedigree Summary', 'CI Traceability Report · CI - EBOM Parts Mapping',
  'context export · Context Results', 'Unplanned Not Installed report · Unplanned Not Installed', 'Planned Not Installed report · Planned Not Installed',
  'CSV export, frozen', 'HTML report, frozen',
  'Excel export, frozen · Comparison Summary', 'Excel export, frozen · Issues Only', 'Excel export, frozen · WO Status Not Closed',
  'CI Traceability Report, frozen · CI Traceability Detail', 'CI Traceability Report, frozen · CSA Pedigree Summary', 'CI Traceability Report, frozen · CI - EBOM Parts Mapping'];
function withoutCage(value) {
  if (Array.isArray(value)) {                                  // a sheet: rows of cells
    const h = value.findIndex(r => r.some(c => CAGE_HEADS.includes(c)));
    if (h < 0) return { value, hit: false };
    const i = value[h].findIndex(c => CAGE_HEADS.includes(c));
    const rows = [];
    value.forEach((r, n) => {
      if (/^EBOM CAGE Code = /.test(String(r[0]))) return;     // the title-block line that explains the column
      if (n < h && r[i] !== '' && r[i] !== undefined) throw new Error('a title row has a value under the CAGE heading: ' + JSON.stringify(r));
      const c = r.slice(); c.splice(i, 1); rows.push(c);
    });
    return { value: rows, hit: true };
  }
  const s = String(value);
  if (/<t[hd][ >]/.test(s)) {                                  // markup: one heading, one marked cell per row
    const out = s.replace(/<th[^>]*>(CAGE Code \(EBOM\)|EBOM CAGE Code)<\/th>/g, '').replace(/<td class="td-cage"[^>]*>[^<]*<\/td>(\n +(?=<td))?/g, '');
    return { value: out, hit: out !== s };
  }
  const lines = s.split('\n');                                 // CSV
  const h = lines.findIndex(l => l.indexOf('"CAGE Code (EBOM)"') >= 0);
  if (h < 0) return { value, hit: false };
  const i = lines[h].split('","').findIndex(c => c.replace(/"/g, '') === 'CAGE Code (EBOM)');
  return { value: lines.map((l, n) => { if (n < h) return l; const c = l.split('","'); c.splice(i, 1); return c.join('","'); }).join('\n'), hit: true };
}

async function referenceCollect(browser, buildFile) {
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(buildFile).replace(/\\/g, '/'));
  await page.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
  await page.evaluate(() => {
    const orig = URL.createObjectURL.bind(URL);
    URL.createObjectURL = b => { if (b instanceof Blob) (window.__blobs = window.__blobs || []).push(b); return orig(b); };
  });
  await page.evaluate(async () => {
    const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
    const book = (w, rows) => {
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
      return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
    };
    // v189 — a seventh cell: the CAGE code in column Q. A build before v189
    // ignores the column. The two P400 lines merge and carry different codes;
    // P200's is a number; P300 and TOP have none. P600 (planned nowhere) and
    // P700 (planned and built short) give both gap reports rows to compare.
    const E = [['A','TOP','',1,'','',''],['B','ASM1','TOP',1,'D-ASM','A','1ABC2'],['C','P100','ASM1',2,'D-100','A','81205'],
               ['C','P200','ASM1',1,'D-200','B',7482],['C','P300','ASM1',3,'D-300','A',''],['D','P101','P100',4,'D-100','A','81205'],
               ['C','P400','ASM1',1,'','','K1234'],['C','P400','ASM1',1,'','','0XY34'],['C','P500','ASM1',1,'D-500','C','5ZZZ9'],
               ['C','P600','ASM1',2,'','','U9999'],['C','P700','ASM1',5,'','','S5555']];
    const C = (pn, nh, o) => Object.assign({ 1: 'X', 3: pn, 4: 'name ' + pn, 5: nh, 7: '1' }, o);
    // Row by row: a blank drawing before a filled one (first non-blank wins);
    // P200 under the wrong next higher (KI-1: engine falls back, tab and
    // Drawing do not); p300 in lower case (KI-2); P999 not in the EBOM (an
    // incomplete ECN); a blank part number (dropped at upload); ASM1 for the
    // next-higher sheet; P500 with a blank next higher (document fallback).
    const CHP = [
      C('P100','ASM1',{10:'',11:'',15:'DCN1',16:'2024-03-15',17:'E1',18:'OPEN',19:'R1',20:'APPROVED'}),
      C('P100','ASM1',{10:'D-100',11:'A',12:'1',13:'A',15:'DCN1',16:'2024-03-15',17:'E1',18:'OPEN',19:'R1',20:'APPROVED'}),
      C('P101','P100',{10:'D-100',11:'A',17:'E1',18:'OPEN',19:'R2',20:'OPEN'}),
      C('P200','ASMX',{10:'D-200',11:'B',15:'DCN2',16:'',19:'R4'}),
      C('p300','asm1',{10:'D-300',11:'A',17:'E2',18:'CLOSED',19:'R3'}),
      C('P999','ASM1',{10:'D-999',11:'A',17:'E2',18:'CLOSED'}),
      C('','ASM1',{10:'D-777',19:'R9'}),
      C('ASM1','TOP',{10:'D-ASM',11:'A',17:'E3',18:'OPEN',19:'R8'}),
      C('P500','',{10:'D-500',11:'C',19:'R5',20:'OPEN'}),
    ];
    const files = {
      ebom: book(40, E.map(([i, pn, nh, q, dw, rv, cage]) => ({ 0: i, 1: pn, 2: 'desc ' + pn, 3: nh, 7: q, 8: String(q), 10: rv, 12: dw, 16: cage }))),
      mbom: book(40, [['P100','ASM1',2,'WO1'],['P200','ASM1',1,'WO2'],['P300','ASM1',3,'WO3'],['P101','P100',4,'WO1'],['P400','ASM1',2,'WO4'],['P500','ASM1',1,'WO5'],['P700','ASM1',2,'WO7']]
        .map(([pn, nh, q, wo]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: 'CLOSED' }))),
      abom: book(40, [['P100','ASM1',2,'WO1','CLOSED'],['P200','ASM1',1,'WO2','OPEN'],['P101','P100',4,'WO1','CLOSED'],['P400','ASM1',2,'WO4','CLOSED'],['P500','ASM1',1,'WO5','CLOSED'],['P700','ASM1',2,'WO7','CLOSED']]
        .map(([pn, nh, q, wo, st]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: st }))),
      chp: book(25, CHP),
      ci: book(3, [{0:'CI-1',1:'P100',2:'ASM1'},{0:'CI-2',1:'P300',2:'ASM1'},{0:'CI-3',1:'P500',2:''},{0:'CI-4',1:'P200',2:'ASM1'}]),
      // v186 — NCR and RFV, so the default CI / RFV / NCR ingestion is compared
      // too: v186 added manual maps to the CI and RFV zones and must read the
      // default layout exactly as v185 did. One NCR is CANCELLED, one has a
      // lower-case disposition code, one has none; RFVs reach lines by each of
      // P1 (PN + NH), P2 (disposition number) and P3 (work order), plus one
      // that matches nothing and one with a blank RFV number (dropped).
      ncr: book(90, [
        { 0:'N1', 1:'OPEN',      25:'WO1', 43:'P100', 47:'C1', 48:'Damaged',    71:'D1', 72:'CLOSED',  76:'MRB', 77:'UAI' },
        { 0:'N1', 1:'OPEN',      25:'WO1', 43:'P100', 47:'C1', 48:'Damaged',    71:'D2', 72:'WORKING', 76:'MRB', 77:'rework' },
        { 0:'N2', 1:'OPEN',      25:'WO2', 43:'P200', 47:'C2', 48:'Wrong part', 71:'D3', 72:'WORKING', 76:'MRB', 77:'' },
        { 0:'N3', 1:'CANCELLED', 25:'WO1', 43:'P101', 47:'C1', 48:'Damaged',    71:'D4', 72:'CLOSED',  76:'MRB', 77:'SCRAP' },
      ]),
      rfv: book(11, [
        { 0:'RFV-1', 1:'P100', 2:'ASM1', 3:'2', 4:'',    5:'',   6:'DEV', 7:'MINOR', 8:'by part' },
        { 0:'RFV-2', 1:'',     2:'',     3:'',  4:'',    5:'D2', 6:'WVR', 7:'MAJOR', 8:'by disposition' },
        { 0:'RFV-3', 1:'',     2:'',     3:'',  4:'WO2', 5:'',   6:'DEV', 7:'MINOR', 8:'by work order' },
        { 0:'RFV-4', 1:'P888', 2:'ASM9', 3:'1', 4:'',    5:'',   6:'DEV', 7:'MINOR', 8:'matches nothing' },
        { 0:'',      1:'P100', 2:'ASM1', 3:'1', 4:'',    5:'',   6:'DEV', 7:'MINOR', 8:'no number' },
      ]),
    };
    for (const k of ['ebom','mbom','abom','chp','ci','ncr','rfv']) {
      handleFile(k, files[k]);
      const t0 = Date.now();
      while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) {
        if (Date.now() - t0 > 20000) throw new Error(k + ' did not load');
        await new Promise(r => setTimeout(r, 50));
      }
    }
  });
  await page.click('#run-btn');
  await page.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
  await page.waitForTimeout(800);
  const written = async trigger => {
    const b64 = await page.evaluate(async t => {
      window.__blobs = [];
      await eval(t);
      for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(r => setTimeout(r, 50));
      const b = window.__blobs[window.__blobs.length - 1];
      if (!b) throw new Error('no file written by ' + t);
      const u = new Uint8Array(await b.arrayBuffer()); let s = '';
      for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
      return btoa(s);
    }, trigger);
    return Buffer.from(b64, 'base64');
  };
  const book = async trigger => page.evaluate(b64 => {
    const wb = XLSX.read(b64, { type: 'base64' }); const o = {};
    wb.SheetNames.forEach(n => { o[n] = XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: '' }); });
    return o;
  }, (await written(trigger)).toString('base64'));
  const text = async trigger => (await written(trigger)).toString('utf8');
  const out = {};
  out['results (raw)'] = await page.evaluate('JSON.stringify(state.resultsRaw.map(_serializeResultRowForJson))');
  out['results (effective)'] = await page.evaluate('JSON.stringify(state.results.map(_serializeResultRowForJson))');
  out['Comparison Summary, as rendered'] = await page.evaluate("renderSummaryTable(); document.getElementById('summary-table-wrap').innerHTML");
  out['Change Pedigree tab, as rendered'] = await page.evaluate("renderChpTable(0); document.getElementById('chp-table-wrap').innerHTML");
  out['CI tab, as rendered'] = await page.evaluate("renderCITraceTable(); document.getElementById('ci-table-wrap').innerHTML");    // v186
  out['RFV tab, as rendered'] = await page.evaluate("renderRFVTable(0); document.getElementById('rfv-table-wrap').innerHTML");   // v186
  out['Excel export'] = await book('exportXLSX()');
  out['CSV export'] = await text('exportCSV()');
  out['HTML report'] = await text('exportHTML()');
  out['CI Traceability Report'] = await book('exportCIReport()');
  out['CI As-Built Records Guide'] = await book('exportCIAsBuiltGuide()');
  out['Change Commitment List'] = await book('exportChangeCommitmentClosures()');
  out['Premature ECN Closures'] = await book('exportPrematureEcnClosures()');
  out['RFV Traceability Report'] = await book('exportRFVReport()');   // v186
  out['Unplanned Not Installed report'] = await book('exportUnplannedNotInstalled()');   // v189
  out['Planned Not Installed report'] = await book('exportPlannedNotInstalled()');       // v189
  await page.evaluate("document.getElementById('search-input').value = 'ASM1'; setSearchMode('context'); onSearchInput();");
  await page.waitForTimeout(400);
  out['context export'] = await book('exportContextResults()');
  const strip = s => { const o = JSON.parse(s); delete o.exportedAt; delete o.toolVersion; return JSON.stringify(o); };
  out['session file'] = strip(await text('exportSessionJson()'));
  await page.evaluate(() => {
    const orig = crypto.subtle.digest.bind(crypto.subtle);
    crypto.subtle.digest = (a, b) => { window.__hashMsg = new TextDecoder().decode(b); return orig(a, b); };
    window.prompt = () => 'Reference Auditor';
  });
  await page.evaluate('freezeReport()');
  await page.waitForFunction('state.isLocked && state.auditCert && state.auditCert.hash', null, { timeout: 30000 });
  const hm = JSON.parse(await page.evaluate('window.__hashMsg')); delete hm.freezeInitiated;
  out['certificate hash payload'] = JSON.stringify(hm);
  out['certificate rows'] = await page.evaluate('JSON.stringify(_auditCertRows(state.auditCert))');
  out['Excel export, frozen'] = await book('exportXLSX()');
  out['CSV export, frozen'] = await text('exportCSV()');
  out['HTML report, frozen'] = await text('exportHTML()');
  out['CI Traceability Report, frozen'] = await book('exportCIReport()');
  out['session file, frozen'] = strip(await text('exportSessionJson()'));
  out.__errors = errors;
  await ctx.close();
  return out;
}

async function referenceCases() {
  if (!fs.existsSync(REFERENCE)) return [{ name: 'the reference build exists', error: new Error('not found: ' + REFERENCE) }];
  let pw;
  try { pw = require('playwright'); } catch (e) {
    try { pw = require('playwright-core'); } catch (e2) { return [{ name: 'Playwright is installed (npm install playwright)', error: e }]; }
  }
  const launchOpts = process.env.COMPARATOR_BROWSER ? { executablePath: process.env.COMPARATOR_BROWSER } : {};
  const browser = await pw.chromium.launch(launchOpts);
  try {
    const a = await referenceCollect(browser, REFERENCE), b = await referenceCollect(browser, BUILD);
    // v189 — see "known additions" above.
    const verOf = f => +((fs.readFileSync(f, 'utf8').match(/const APP_VERSION = 'v(\d+)'/) || [])[1] || 0);
    const strip = verOf(REFERENCE) < CAGE_SINCE && verOf(BUILD) >= CAGE_SINCE;
    const removed = [];
    let stripError = null;
    if (strip) {
      try {
        Object.keys(b).filter(k => k !== '__errors').forEach(k => {
          if (b[k] && typeof b[k] === 'object') Object.keys(b[k]).forEach(sh => { const r = withoutCage(b[k][sh]); if (r.hit) { b[k][sh] = r.value; removed.push(k + ' · ' + sh); } });
          else { const r = withoutCage(b[k]); if (r.hit) { b[k] = r.value; removed.push(k); } }
        });
      } catch (e) { stripError = e; }
    }
    const mask = s => String(s)
      .replace(/\b\d{1,2}\/\d{1,2}\/\d{4},? \d{1,2}:\d{2}:\d{2}\s?[AP]M\b/g, '<time>')
      .replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z/g, '<time>')
      .replace(/\bv\d{2,3}\b/g, '<build>')
      .replace(/\b[0-9a-f]{64}\b/g, '<hash>');
    const out = [];
    const cmp = (label, x, y) => {
      const sx = mask(typeof x === 'string' ? x : JSON.stringify(x)), sy = mask(typeof y === 'string' ? y : JSON.stringify(y));
      if (sx === sy) { out.push({ name: label + ' is identical' }); return; }
      let i = 0; while (i < sx.length && sx[i] === sy[i]) i++;
      out.push({ name: label + ' is identical', error: new Error('differs at ' + i + '\n          reference: ' +
        sx.slice(Math.max(0, i - 80), i + 120) + '\n          this build: ' + sy.slice(Math.max(0, i - 80), i + 120)) });
    };
    Object.keys(a).filter(k => k !== '__errors').forEach(k => {
      if (a[k] && typeof a[k] === 'object') {
        [...new Set(Object.keys(a[k]).concat(Object.keys(b[k] || {})))]
          .forEach(sh => cmp(k + ' · ' + sh, a[k][sh], (b[k] || {})[sh]));
      } else cmp(k, a[k], b[k]);
    });
    {
      const miss = CAGE_OUTPUTS.filter(k => removed.indexOf(k) < 0), extra = removed.filter(k => CAGE_OUTPUTS.indexOf(k) < 0);
      out.push({ name: strip ? 'the CAGE column is the only addition: it was found in exactly the ' + CAGE_OUTPUTS.length + ' outputs meant to carry it, and removed before comparing'
                             : 'no known addition to set aside: the reference build is v' + CAGE_SINCE + ' or later',
        error: stripError || (strip && (miss.length || extra.length) ? new Error((miss.length ? 'no CAGE column in: ' + miss.join(', ') + '. ' : '') + (extra.length ? 'a CAGE column where none was asked for: ' + extra.join(', ') : '')) : undefined) });
    }
    out.push({ name: 'neither build logged an error',
      error: (a.__errors.length || b.__errors.length) ? new Error(a.__errors.concat(b.__errors).slice(0, 4).join(' | ')) : undefined });
    return out.map(r => r.error ? r : { name: r.name });
  } catch (e) {
    return [{ name: 'the reference run completed', error: e }];
  } finally {
    await browser.close();
  }
}

// ── summary ────────────────────────────────────────────────────────────────
// EXPECTED_TESTS exists because a crashed suite costs ONE reported failure but
// silently skips every test after it. Without this, losing a third of the suite
// still prints a believable total. Bump it deliberately when adding tests.
const EXPECTED_TESTS = 692;
function summary() {
  console.log('═'.repeat(60));
  console.log('TOTAL: ' + TP + ' passed, ' + TF + ' failed');
  // v179 — the browser suite is opt-in and counted on top when it runs.
  const expected = EXPECTED_TESTS + (BROWSER_RUN ? BROWSER_EXPECTED : 0) + (REFERENCE ? REFERENCE_EXPECTED : 0);
  if (TP + TF !== expected) {
    console.log('');
    console.log('COUNT MISMATCH: ' + (TP + TF) + ' tests ran, ' + expected + ' expected.');
    console.log(TP + TF < expected
      ? 'Tests went missing — a suite crashed before finishing. Treat this as a failure.'
      : 'Tests were added without updating EXPECTED_TESTS. Update it.');
    process.exit(1);
  }
  if (FAILED.length) { console.log('Failing suites: ' + FAILED.join(', ')); process.exit(1); }
  console.log('All suites green.');
}
// v178 — the streaming-reader cases are async, so they settle first and the
// summary runs after them. The HARNESS.md table check runs last of all because
// it compares the table with every suite's final count.
streamCases().then(res => {
  suite('Tier 21 — streaming session reader', t => res.forEach(r => t(r.name, () => { if (r.error) throw r.error; })));
}, e => {
  suite('Tier 21 — streaming session reader', t => t('the streaming cases ran at all', () => { throw e; }));
}).then(() => BROWSER_RUN ? browserCases().then(res => {
  suite(BROWSER_SUITE, t => res.forEach(r => t(r.name, () => { if (r.error) throw r.error; })));
}) : null).then(() => REFERENCE ? referenceCases().then(res => {
  suite(REFERENCE_SUITE, t => res.forEach(r => t(r.name, () => { if (r.error) throw r.error; })));
}) : null).then(() => { harnessDocSuite(); summary(); });
