# Design note: Change Pedigree Alignment (build v182)

Status: agreed with the project owner on 2026-09-29. Built and tested in build v182 and Delta tool v3.5.

## The problem

Most programs send a full Change Pedigree (CHP) extract. Each row names a part
number, its next higher, and the DCN, ECN and ECR behind it. Comparator joins
those rows to EBOM lines on part number + next higher.

A few programs send a much thinner extract. Every row carries a **drawing
number** and an **ECR**. DCN and ECN columns may exist but are often blank.
For these programs the ECR belongs to a drawing, and the drawing is what links
it to EBOM line items. Part number + next higher either is not in the file or
is not the right link.

## The decision

Add a per-program setting, **Change Pedigree Alignment**, with two rules:

| Rule | Joins a CHP row to | Used by |
|---|---|---|
| **Part number + next higher** (default) | The EBOM line with that part number and next higher. If none, any EBOM line with that part number. | Every program today |
| **Drawing number** | Every EBOM line whose drawing number matches. Optionally drawing number + revision. | The few drawing + ECR programs |

It follows the pattern of Proc Code Behavior and EBOM Indenture Scope: chosen
per program, applied on the next run, saved with the session, printed on the
certificate, compared by the Delta tool.

## The guarantee for default programs

With the setting on its default, v182 behaves exactly as v181.

- Every result, badge, export and report is unchanged. An equivalence check
  (`--reference=` in the harness) ran the same files through v181 and v182 and compared 50 outputs. All were identical.
- The certificate prints no alignment row and the integrity hash does not
  include the rule. A default-rule certificate is built exactly as in v181.
- A session with no alignment field reads as the default rule. Sessions from
  earlier builds open unchanged.
- The Delta tool adds nothing when both sessions use the default rule.
- Visible differences: one collapsed panel reading "Default", under the upload
  zones beside the other two program settings.

## What the drawing rule changes, for that run only

- **Setup lives in the panel.** Pick the EBOM column that holds the drawing
  number from a list of the EBOM file's own headers, with three sample values.
  This is independent of Mapping 1, Mapping 2 and Manual, so no preset changes.
  Optionally match on drawing number + revision, with a revision column picked
  for the EBOM. The CHP side uses the Document/Drawing Number, Document Revision
  and ECR fields, through the existing CHP Manual map. Under this rule a
  field left blank in that map stays empty. It is not read from its default
  position, so a DCN or ECN cannot be picked up from the wrong column.
- **Run is blocked** until the required picks are made, so a missing mapping
  cannot look like a program with no change history.
- **CHP upload** keeps rows that carry a drawing number, not a part number.
- **Match** is exact after trimming and upper-casing. No fuzzy matching, and no
  stripping of prefixes or dashes.
- **An ECR attaches to every EBOM line on its drawing.** That is coarser than
  the default rule: a drawing often defines many parts, and the ECR may not have
  touched all of them. The badge, tooltip and certificate say which rule ran.
- **History badge**: RELEASED and DCN NOT RELEASED work as today when a DCN
  exists. New states: **ECR ONLY** (change history on the drawing, no DCN or
  ECN) and **NO DRAWING** (the EBOM line has no drawing number, typically COTS).
  The tooltip names the drawing the history came through.
- **Drawing column** comes from the EBOM itself.
- **ECN reports**: if the extract carries no ECNs, both reports say "not
  available" rather than showing an empty report that reads as clean. If ECNs
  exist, the footprint is by drawing and the report says so.
- **After a run** the panel reports how many CHP drawings matched an EBOM line,
  and in revision mode how many matched on number but not revision.
- **Certificate** adds a "Change Pedigree Alignment" row, and the rule enters
  the integrity hash.
- **Reset** returns the setting to the default. (Indenture scope survives Reset.
  This setting does not, because forgetting it costs more.)
- **Delta tool v3.5** warns when two sessions used different rules and names
  both on the Summary. The Change Pedigree Delta sheet carries a note that its
  rows may reflect the rule change rather than the pedigree.

## How it was built

1. **Consolidation, no behavior change.** Twelve places in the build each
   worked out the CHP join for themselves, using four different rules. They now
   call one module. Each kept its own v181 rule, so nothing moved. A test fails
   if any code outside the module reads the CHP part number, next higher or
   drawing columns.
2. **The setting**, added to that one module.

## Known issues, deliberately not changed

The v181 rules disagree. Example: a CHP row lists part 1234-5 under assembly A,
and the EBOM has it under B. The engine attaches the history through its
part-number fallback, so the line shows RELEASED. The Change Pedigree tab marks
the same CHP row NO MATCH, and the Drawing column is blank. The CHP tab also
compares case-sensitively where the engine does not. These are recorded, not
fixed, because fixing them would change results for default programs. They are
the owner's call for a later build.

A third, found while building: under any Change Pedigree manual map, the Change
Pedigree tab prints the file's own column headings over the re-laid columns,
so they sit over the wrong data (KI-3). It is fixed under the drawing rule,
whose extracts always need a manual map, and left as it was for the default.

## Other visible differences for everyone

- The panel itself, collapsed, reading "Default".
- The Badge Guide lists ECR ONLY and NO DRAWING, marked as drawing-rule only.
- The column-mapping reference (the i icon) names the drawing rule's required
  Change Pedigree fields.

