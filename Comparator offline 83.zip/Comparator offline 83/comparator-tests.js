#!/usr/bin/env node
/**
 * comparator-tests.js — complete, self-contained test harness for Comparator.
 *
 *   node comparator-tests.js [path-to-build.html]
 *
 * Finds the highest-numbered ./comparator_offline*.html, then ../ .
 * Node only: no install, no network, no other files. 94 tests.
 *
 * WHY ONE FILE: Comparator ships as a single self-contained HTML, and this
 * harness follows suit so it can live in a Project alongside it. An earlier
 * split-file version was lost between sessions, taking 72 tests with it.
 *
 * HOW IT WORKS: the build's testable functions are lifted out of the HTML by
 * marker, then evaluated in a per-suite sandbox that stubs the browser globals
 * they touch (document, state, COL, XLSX...). Each suite gets its own sandbox
 * because the modules expect different COL shapes.
 *
 * IF EXTRACTION FAILS: the error names the marker that moved. The build was
 * refactored; update the marker below. Failing loudly is deliberate — an empty
 * module would let every suite pass while testing nothing.
 */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');

// Explicit argument or env var wins. Otherwise find the HIGHEST-numbered
// comparator_offline*.html in ./ or ../ — so a version bump does not require
// editing this harness, and a stale older build sitting beside a new one is
// not silently picked up. The version-pin test still catches a wrong build.
function discover(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => /^comparator_offline\d+\.html$/.test(f))
      .sort((a, b) => parseInt(b.match(/\d+/)[0], 10) - parseInt(a.match(/\d+/)[0], 10))
      .map(f => path.join(dir, f));
  } catch (e) { return []; }
}
// v179 — flags are not paths. --browser adds the browser suite (see below).
const ARGS = process.argv.slice(2);
const BROWSER_RUN = ARGS.includes('--browser');
const CANDIDATES = [ARGS.find(a => !a.startsWith('--')), process.env.COMPARATOR_BUILD].filter(Boolean)
  .concat(discover(__dirname), discover(path.join(__dirname, '..')));
const BUILD = CANDIDATES.find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
if (!BUILD) {
  console.error('Build HTML not found. Looked for comparator_offline*.html in:\n  ' +
                __dirname + '\n  ' + path.join(__dirname, '..') +
                '\nPass one: node comparator-tests.js path/to/comparator_offline54.html');
  process.exit(1);
}
const SRC = fs.readFileSync(BUILD, 'utf8');

// The delta tool is a SECOND shipped file that carries its own copy of
// PROC_CODE_BASELINE. Nothing checked the two for drift until v154.
function discoverDelta(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => /^comparator_delta_v[\d_]+\.html$/.test(f))
      .sort((a, b) => (b.match(/[\d_]+/)[0].replace(/_/g, '.') * 1) -
                      (a.match(/[\d_]+/)[0].replace(/_/g, '.') * 1))
      .map(f => path.join(dir, f));
  } catch (e) { return []; }
}
const DELTA = [process.env.COMPARATOR_DELTA].filter(Boolean)
  .concat(discoverDelta(path.dirname(BUILD)), discoverDelta(__dirname),
          discoverDelta(path.join(__dirname, '..')))
  .find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
if (!DELTA) {
  console.error('Delta tool not found. Looked for comparator_delta_v*.html beside the build.\n' +
                'Set COMPARATOR_DELTA=path to point at it.');
  process.exit(1);
}
console.log('Delta tool under test: ' + DELTA);
const DSRC = fs.readFileSync(DELTA, 'utf8');
console.log('Build under test: ' + BUILD + '\n');

// ── extraction ─────────────────────────────────────────────────────────────
// EVERY boundary goes through at() / lastAt() / span(). A raw SRC.indexOf that
// misses returns -1, and -1 silently becomes a zero-length or inverted slice —
// which is the empty module this harness exists to prevent. v154 closed four
// such holes; the 'Tier 2 — extraction integrity' suite keeps them closed.
function at(marker, from) {
  const i = typeof marker === 'string'
    ? SRC.indexOf(marker, from || 0)
    : (function () { const m = SRC.slice(from || 0).match(marker); return m ? m.index + (from || 0) : -1; })();
  if (i < 0) throw new Error('BUILD MARKER MOVED: ' + marker);
  return i;
}
function lastAt(marker, before, label) {
  const i = SRC.lastIndexOf(marker, before);
  if (i < 0) throw new Error('BUILD MARKER MOVED (searching backwards from ' +
                             (label || before) + '): ' + marker);
  return i;
}
// A named slice that refuses a degenerate result. `label` is what gets printed,
// so a failure says which module lost its boundary rather than surfacing later
// as "P is not defined" inside an unrelated suite.
const MIN_SPAN = 200;
function span(a, b, label) {
  if (b <= a) throw new Error('BUILD MARKERS CROSSED for ' + label + ': end (' + b +
    ') is not after start (' + a + '). The build was reordered — fix the markers.');
  const s = SRC.slice(a, b);
  if (s.length < MIN_SPAN) throw new Error('MODULE SLICE TOO SMALL for ' + label +
    ': ' + s.length + ' chars, expected at least ' + MIN_SPAN + '.');
  return s;
}
function grabFrom(src, name, label) {
  const i = src.indexOf('function ' + name + '(');
  if (i < 0) throw new Error('BUILD MARKER MOVED in ' + (label || 'build') +
                             ': function ' + name);
  let d = 0, k = src.indexOf('{', i);
  if (k < 0) throw new Error('NO BODY FOUND for function ' + name);
  for (;; k++) {
    if (k >= src.length) throw new Error('UNBALANCED BRACES while reading function ' + name);
    if (src[k] === '{') d++; else if (src[k] === '}') { d--; if (!d) break; }
  }
  return src.slice(i, k + 1);
}
function grabFn(name) { return grabFrom(SRC, name, 'main build'); }
function grabDelta(name) { return grabFrom(DSRC, name, 'delta tool'); }
const MOD = {};
try {
{ // proc code table + behaviour panel
  const a = at('const PROC_CODE_BASELINE = {');
  const g = at('function getProcBehavior');
  const b = at('}', at('return PROC_CODE_EXCEPTIONS', g)) + 1;
  const m1 = at(/\/\/ ═+\n\/\/ v\d+ — PROC CODE BEHAVIOR PANEL/);
  const m2 = at('// ── EBOM manual column mapping (proof of concept)', m1);
  MOD.proc = span(a, b, 'proc:table') + '\n' + span(m1, m2, 'proc:panel') + `
globalThis.P = { abomProcCodeInventory, _procRowHtml, _procHeaderRow, PROC_JOB_SAMPLES,
  get PROC_CODE_EXCEPTIONS(){return PROC_CODE_EXCEPTIONS;},
  get PROC_CODE_BASELINE(){return PROC_CODE_BASELINE;},
  get dirty(){return _procDirtySinceRun;}, set dirty(v){_procDirtySinceRun=v;},
  setProcCodeMap, setProcCodeBehavior, getProcBehavior, isProcMapCustom,
  _procProfileLabel, _procCodesWithBehavior, _procCodeListText,
  exportProcProfile, importProcProfile, resetProcCodesToBaseline, _procMapEqualsBaseline,
  toggleProcCodePanel, renderProcCodePanel };`;
}
// v154 — buildEbomIndentureMap is now lifted from the build. It used to be a
// six-line stand-in written into the sandbox, and the ECN inheritance suites
// were certifying that stand-in rather than the shipping function. The two
// diverge on a self-referencing row (PN === NH), which is a real extract defect.
// v159 — the reconciliation ENGINE, plus every builder needed to feed it. The
// engine is pure (one params object in, results out, no globals, no DOM) and
// was completely untested until now: 543 lines deciding whether a part is
// reconciled, with every existing suite testing only the code AROUND it.
MOD.engine = (function () {
  // The status sets the rollup consults, lifted with the functions that use them.
  const sets = ['_STATUS_DIRECT_OK', '_STATUS_COVERED', '_STATUS_ADJUDICATED_LEAF']
    .map(n => { const a = at('const ' + n + ' = new Set([');
                return SRC.slice(a, at(']);', a) + 3); }).join('\n');
  // v159 — the engine's priority ladder, isolated so it can be compared with the
  // copy in computeEffectiveResults. Bounded at the Pass 3 fallback, which is
  // NOT part of the ladder: it depends on pool membership, not on leg statuses.
  const eng = grabFn('runReconciliationCore');
  const la = eng.indexOf('var legs = [];');
  const lb = eng.indexOf('// Pass 3 fallback', la);
  if (la < 0 || lb < la) throw new Error('BUILD MARKER MOVED: the engine rollup ladder');
  const ladder = 'function engineLadder(ms, as_, msUsedOn, asUsedOn) { var overall;' +
                 eng.slice(la, lb) + '\nreturn overall; }';
  return sets + '\n' +
    ['normPN', 'normIndenture', 'buildQtyMap', 'buildAbomMap', 'buildEbomIndentureMap',
     'buildAbomUsedOnMap', 'buildMbomUsedOnMap', 'getProcBehavior',
     'runReconciliationCore', 'computeEffectiveResults'].map(grabFn).join('\n') +
    '\n' + ladder +
    '\nglobalThis.E = { normPN, normIndenture, buildQtyMap, buildAbomMap, buildEbomIndentureMap,' +
    ' buildAbomUsedOnMap, buildMbomUsedOnMap, runReconciliationCore,' +
    ' computeEffectiveResults, engineLadder,' +
    ' get _STATUS_DIRECT_OK(){return _STATUS_DIRECT_OK;} };';
})();
// The delta tool's pure comparison layer. Its own file, its own baseline copy.
MOD.delta = (function () {
  // `var` here, `const` in the main build — hence the tolerant marker.
  const m = DSRC.match(/(?:var|const|let)\s+PROC_CODE_BASELINE\s*=\s*\{/);
  if (!m) throw new Error('BUILD MARKER MOVED in delta tool: PROC_CODE_BASELINE');
  const i = m.index;
  const j = DSRC.indexOf('}', i) + 1;
  // Status/column constants the report layer depends on.
  function constBlock(name) {
    const m = DSRC.match(new RegExp('(?:var|const|let)\\s+' + name + '\\s*=\\s*\\{'));
    if (!m) throw new Error('BUILD MARKER MOVED in delta tool: ' + name);
    const end = DSRC.indexOf('}', m.index);
    if (end < 0) throw new Error('unterminated ' + name + ' in delta tool');
    return DSRC.slice(m.index, end + 1) + ';';
  }
  const FNS = ['dNorm', 'normPN', 'pct', 'procTableOf', 'procProfileLabel', 'procTableDiff',
               'claimSig', 'claimRow', 'claimsDelta',
               'fscope', 'modeHasMbom', 'modeHasAbom', 'computeKpis', 'countByType',
               'ebomChanges', 'chpBom', 'ncrDispositionDelta',
               'collectorLevelsOf', 'collectorScopeLabel', 'indentureScopeDiff',
               'indentureContext'];
  return DSRC.slice(i, j) + ';\n' +
    ['DIRECT_OK', 'COVERED_OK', 'SCOPE_EXCLUDED', 'NCR_COL'].map(constBlock).join('\n') + '\n' +
    FNS.map(grabDelta).join('\n') +
    '\nglobalThis.D = { ' + FNS.join(', ') + ',' +
    ' get PROC_CODE_BASELINE(){return PROC_CODE_BASELINE;},' +
    ' get NCR_COL(){return NCR_COL;} };';
})();

// v159 — session restore. importSessionJson is async and DOM-heavy, but the
// STATE RESTORE — the part that reconstitutes an audit artefact — is the first
// 96 lines and runs unmodified against a stub document. Extracted as a function
// so the real code is exercised rather than a paraphrase of it.
// v162 — ME adjudication import. Pure planning layer: rows + results in, a plan
// out. Extracted with the overlay so a plan can be driven all the way through
// computeEffectiveResults in one sandbox.
MOD.adjimport = (function () {
  const a = at('// ── v162 — ME ADJUDICATION IMPORT');
  const b = at('// ── v162 — ME ADJUDICATION IMPORT: UI');
  const colA = at('const COL = {');
  const colB = at('};', colA) + 2;
  const sets = ['_STATUS_DIRECT_OK', '_STATUS_COVERED', '_STATUS_ADJUDICATED_LEAF']
    .map(n => { const i = at('const ' + n + ' = new Set(['); return SRC.slice(i, at(']);', i) + 3); }).join('\n');
  return SRC.slice(colA, colB) + '\n' + sets + '\n' + grabFn('normPN') + '\n' +
    SRC.slice(a, b) + '\n' + grabFn('computeEffectiveResults') +
    '\nglobalThis.IMP = { COL, scanNarrative, resolveImportedAdjRow, buildImportedClaims,' +
    ' replaceImportedClaims, partitionClaims, isImportedClaim, indexResultsByPn,' +
    ' planAdjImport, finalizeAdjImport, computeEffectiveResults };';
})();

MOD.session = (function () {
  const imp = grabFn('importSessionJson');
  const a = imp.indexOf('state.mode = payload.mode');
  const b = imp.indexOf('clearNearMatchCache()');
  if (a < 0 || b < a) throw new Error('BUILD MARKER MOVED: the session restore block');
  return grabFn('_cloneResultRow') + '\n' +
    'function restoreSession(payload) {' + imp.slice(a, b) + '}\n' +
    'globalThis.SS = { restoreSession };';
})();

// CHP release-state badge. Pure, and it drives a user-visible warning plus the
// release date printed on the freeze certificate.
MOD.chp = grabFn('_chpParseReleaseDate') + '\n' + grabFn('formatDcnDate') + '\n' +
  grabFn('chpReleaseState') + '\n' + grabFn('chpStateClass') + '\n' +
  '\nglobalThis.C = { _chpParseReleaseDate, formatDcnDate, chpReleaseState, chpStateClass };';
{ // ECN footprints
  const hit = at(/\/\/ v\d+ — ECN FOOTPRINT \(B1 \/ B2 \/ B4\)/);
  const a = lastAt('// ═══', hit, 'ECN FOOTPRINT header');
  MOD.ecn = span(a, at('function exportChangeCommitmentClosures()'), 'ecn:footprints') + '\n' +
    span(at('function _ecnStatusLooksClosed('), at('function exportPrematureEcnClosures('), 'ecn:status') +
    '\nglobalThis.B = { buildEcnFootprints, _chpEcnItemIndex, _ecnOpenDispositions, _ecnStatusLooksClosed };';
}
// v182 — CHANGE PEDIGREE ALIGNMENT. The one place that reads the CHP join
// columns, plus the worker-safe drawing builder that sits just above it. Taken
// as a span, so everything the build puts between the two markers is tested.
// grabFn('chpTraceTooltip') and friends come along because the history badge
// wrapper calls them.
MOD.chpalign = span(at('// ── v182 — CHANGE PEDIGREE ALIGNMENT: DRAWING RULE (worker-safe)'),
                    at('// ── v182 — CHANGE PEDIGREE ALIGNMENT: END'), 'chpalign') + '\n' +
  ['buildChpTraceMap', 'chpTraceTooltip', 'colIndexToLetter', 'getModeRequired', '_suppManualFieldDefsBase'].map(grabFn).join('\n') +
  '\nglobalThis.CA = { CHP_ALIGN_DEFAULT, chpAlignRule, isChpAlignCustom, _chpAlignSanitize,' +
  ' _chpAlignForSession, _chpAlignRuleLabel, _chpAlignLabel, _chpIngestKeyCol, _chpRequiredMapKeys,' +
  ' _ebomSourceRows, chpAlignRunBlocker, chpEbomDrawingIndex, chpAlignEnginePlan, chpAttachVia,' +
  ' _chpDwgKey, buildChpTraceMap, buildChpTraceMapByDrawing, chpEntry, chpDrawingForLine,' +
  ' chpEntriesForCiTrace, chpEntriesForLineExact, chpEntriesForPn, chpResultForChpRow,' +
  ' chpEcnItemIndex, chpEcnItemKeysOf, chpDocLookup, chpEcnReportUnavailable, chpHistoryState,' +
  ' chpHistoryTooltip, chpAlignStats, chpAlignFreezeBlocker, chpAlignMarkRun, chpViaText,' +
  ' setChpAlignRule, setChpAlignCol, setChpAlignMatchRev, resetChpAlign, renderChpAlignPanel,' +
  ' _chpResultsAreDrawingRule, chpRowSearchText, chpAlignMarkImported, chpTabHeaderLabel };';
{ // untraced NCR dispositions
  const a = at('function computeUntracedNcrs()');
  const b = at(/\/\/ ── v\d+ — NCR DISPOSITIONS WITHOUT EBOM TRACE \(EXPORT\)/, a);
  const c = at('function exportUntracedNcrDispositions()');
  MOD.ncr = span(a, b, 'ncr:helper') + '\n' + span(c, at('// ── ACN KPI HELPER', c), 'ncr:export') +
    '\nglobalThis.N = { computeUntracedNcrs, exportUntracedNcrDispositions };';
}
} catch (e) {
  // Fail loudly, in words, and stop. A partial extraction is worse than no run:
  // in v153 a moved marker produced "21 passed, 5 failed" while 33 tests never
  // executed at all — a plausible-looking summary hiding a third of the suite.
  console.error('═'.repeat(60));
  console.error('EXTRACTION FAILED — NO TESTS WERE RUN.');
  console.error('');
  console.error('  ' + e.message);
  console.error('');
  console.error('The build was refactored and a marker in this harness needs');
  console.error('updating. This is not a fault in the build. Fix the marker in');
  console.error('the extraction block near the top of comparator-tests.js.');
  console.error('═'.repeat(60));
  process.exit(1);
}

// v154 — REAL stylesheet blocks. The old code used SRC.indexOf('<style'),
// which matches `<style:master-page` — an OpenDocument XML tag inside the
// vendored SheetJS library on line 28. The "stylesheet" every CSS test scanned
// was therefore ~58KB of minified JavaScript with the real CSS appended. That
// is where the mysterious -2 brace baseline came from: JS object literals, not
// CSS. Requiring `>` or whitespace after the tag name excludes the XML tags.
const STYLE_BLOCKS = (function () {
  const out = [];
  const re = /<style(?:\s[^>]*)?>([\s\S]*?)<\/style>/g;
  let m;
  while ((m = re.exec(SRC))) out.push({ css: m[1], at: m.index,
                                        line: SRC.slice(0, m.index).split('\n').length });
  if (!out.length) throw new Error('NO STYLE BLOCK FOUND — the build has no <style> tag?');
  return out;
})();

// Comment- and string-aware brace scan. Returns the LINE NUMBERS of unmatched
// braces rather than a net delta, so a failure says where to look. A net delta
// can also be zero when one stray `{` and one stray `}` cancel out.
// ── Palettes ────────────────────────────────────────────────────────────────
// v173. The build ships three: :root (dark, the source of truth) plus a
// [data-theme=...] block per alternative. Every colour test below reads from
// here rather than scanning the stylesheet flat, because a flat scan silently
// takes the LAST definition of each token — with three palettes in the file
// that is whichever theme happens to be written last, and every assertion
// about "the palette" would then be an assertion about the mono greys.
const PALETTES = (function () {
  const css = STYLE_BLOCKS.map(b => b.css).join('\n');
  const read = (sel, label) => {
    const k = css.indexOf(sel);
    if (k < 0) throw new Error('PALETTE MISSING: ' + label + ' (' + sel + ')');
    let d = 0, s = css.indexOf('{', k);
    if (s < 0) throw new Error('PALETTE HAS NO BODY: ' + label);
    for (let i = s; i < css.length; i++) {
      if (css[i] === '{') d++;
      else if (css[i] === '}' && --d === 0) {
        const body = css.slice(s, i);
        const t = {};
        for (const m of body.matchAll(/(--[\w-]+)\s*:\s*(#[0-9a-fA-F]{6})\b/g))
          t[m[1]] = m[2].toLowerCase();
        if (Object.keys(t).length < 20)
          throw new Error('PALETTE TOO SMALL: ' + label + ' defines only ' +
                          Object.keys(t).length + ' colour tokens');
        return t;
      }
    }
    throw new Error('UNBALANCED PALETTE BLOCK: ' + label);
  };
  return { dark: read(':root', 'dark'),
           light: read('[data-theme="light"]', 'light'),
           mono: read('[data-theme="mono"]', 'mono') };
})();
// Reads the exported-palette list out of the build rather than restating it
// here, so the two cannot disagree without the parity test noticing.
function PALETTE_TOKENS_IN_BUILD() {
  const m = SRC.match(/const PALETTE_TOKENS = \[([\s\S]*?)\];/);
  if (!m) throw new Error('BUILD MARKER MOVED: const PALETTE_TOKENS');
  return [...m[1].matchAll(/'(--[\w-]+)'/g)].map(x => x[1]);
}
const LUM = h => 0.2126 * parseInt(h.slice(1, 3), 16) +
                 0.7152 * parseInt(h.slice(3, 5), 16) +
                 0.0722 * parseInt(h.slice(5, 7), 16);
// v180 — WCAG contrast ratio between two #rrggbb colours (1 to 21). LUM
// above is a rough 0-255 brightness used for ordering; this is the real ratio.
const CONTRAST = (a, b) => {
  if (!a || !b || !/^#[0-9a-f]{6}$/i.test(a) || !/^#[0-9a-f]{6}$/i.test(b)) return NaN;
  const rl = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255)
    .map(c => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4))
    .reduce((acc, c, i) => acc + c * [0.2126, 0.7152, 0.0722][i], 0);
  const x = rl(a), y = rl(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
};
// v180 — the type-scale tokens the exported report is given alongside the palette.
function TYPE_SCALE_TOKENS_IN_BUILD() {
  const m = SRC.match(/const TYPE_SCALE_TOKENS = \[([^\]]*)\]/);
  return m ? [...m[1].matchAll(/'(--[\w-]+)'/g)].map(x => x[1]) : [];
}

function scanCss(text) {
  let i = 0, line = 1; const open = [], close = [];
  while (i < text.length) {
    const c = text[i];
    if (c === '\n') { line++; i++; continue; }
    if (c === '/' && text[i + 1] === '*') {                       // comment
      const e = text.indexOf('*/', i + 2);
      line += (text.slice(i, e < 0 ? text.length : e).match(/\n/g) || []).length;
      i = e < 0 ? text.length : e + 2; continue;
    }
    if (c === '"' || c === "'") {                                 // quoted string
      const q = c; i++;
      while (i < text.length && text[i] !== q) {
        if (text[i] === '\\') i++;
        if (text[i] === '\n') line++;
        i++;
      }
      i++; continue;
    }
    if (c === '{') { open.push(line); i++; continue; }
    if (c === '}') { open.length ? open.pop() : close.push(line); i++; continue; }
    i++;
  }
  return { unmatchedOpen: open, unmatchedClose: close,
           balanced: !open.length && !close.length };
}

// What each module must contain and must define once evaluated. Checked by the
// 'Tier 2 — extraction integrity' suite, so a module that extracts to something
// plausible-but-wrong is caught before its suite quietly passes.
const MODULE_CONTRACT = {
  proc:   { min: 6000, global: 'P',
            needs: ['PROC_CODE_BASELINE', 'function setProcCodeMap', 'function exportProcProfile'],
            exports: ['setProcCodeMap', 'exportProcProfile', '_procProfileLabel', 'getProcBehavior'] },
  engine: { min: 12000, global: 'E',
            needs: ['function normPN', 'function buildAbomMap', 'function buildEbomIndentureMap',
                    'function runReconciliationCore'],
            exports: ['normPN', 'buildAbomMap', 'buildEbomIndentureMap',
                      'buildQtyMap', 'runReconciliationCore',
                      'computeEffectiveResults', 'engineLadder'] },
  ecn:    { min: 2000, global: 'B',
            needs: ['function buildEcnFootprints', 'function _ecnStatusLooksClosed'],
            exports: ['buildEcnFootprints', '_ecnStatusLooksClosed'] },
  ncr:    { min: 2000, global: 'N',
            needs: ['function computeUntracedNcrs', 'function exportUntracedNcrDispositions'],
            exports: ['computeUntracedNcrs', 'exportUntracedNcrDispositions'] },
  delta:  { min: 1500, global: 'D',
            needs: ['PROC_CODE_BASELINE', 'function claimSig', 'function procTableDiff'],
            exports: ['procTableOf', 'procTableDiff', 'claimSig', 'claimsDelta', 'dNorm',
                      'ebomChanges', 'computeKpis', 'ncrDispositionDelta', 'chpBom'] },
  adjimport:{ min: 3000, global: 'IMP',
            needs: ['function planAdjImport', 'function scanNarrative', 'function buildImportedClaims'],
            exports: ['planAdjImport', 'finalizeAdjImport', 'scanNarrative',
                      'resolveImportedAdjRow', 'buildImportedClaims', 'replaceImportedClaims'] },
  session:{ min: 2000, global: 'SS',
            needs: ['function restoreSession', 'payload.procOverrides'],
            exports: ['restoreSession'] },
  chpalign: { min: 12000, global: 'CA',
            needs: ['function buildChpTraceMapByDrawing', 'function chpHistoryState',
                    'function chpDrawingForLine', 'function renderChpAlignPanel'],
            exports: ['chpAlignRule', 'buildChpTraceMapByDrawing', 'chpHistoryState',
                      'chpDrawingForLine', 'chpEntriesForCiTrace', 'chpDocLookup'] },
  chp:    { min: 1500, global: 'C',
            needs: ['function chpReleaseState', 'function formatDcnDate'],
            exports: ['chpReleaseState', 'formatDcnDate', '_chpParseReleaseDate', 'chpStateClass'] },
};

// ── sandbox ────────────────────────────────────────────────────────────────
function el() { return { textContent:'', innerHTML:'', value:'',
  classList:{ c:new Set(), toggle(n,v){v?this.c.add(n):this.c.delete(n);}, add(n){this.c.add(n);}, remove(n){this.c.delete(n);} } }; }
function sandbox(extra, mods) {
  const els = {};
  const ctx = Object.assign({
    console, JSON, Math, Date, Set, Map, Array, Object, String, Number, Boolean,
    RegExp, Error, isNaN, parseFloat, parseInt, Buffer, prompt: () => 'Test',
    document: { getElementById: id => (els[id] = els[id] || el()), querySelectorAll: () => [] },
    toast: () => {}, showError: () => {}, applySheetFont: () => {},
    // Captures what a download would have contained, so a test can read the
    // exported payload rather than merely confirm a call happened.
    Blob: class { constructor(parts, opts) {
      this.parts = parts || []; this.type = (opts || {}).type || '';
      this.text = this.parts.join(''); } },
    tsFilename: (b, e) => b + '.' + e, downloadFile: () => {}, FileReader: class { readAsText(f){ this.onload({target:{result:f._text}}); } },
    _STATUS_ADJUDICATED_LEAF: new Set(['adj_ok']),
    // NOTE: buildEbomIndentureMap used to be stubbed here. It is now extracted
    // from the build in MOD.engine, so any suite needing it must load 'engine'.
    __els: els,
  }, extra);
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  (mods || []).forEach(m => vm.runInContext(MOD[m], ctx, { filename: m + '.js' }));
  return ctx;
}

// ── runner ─────────────────────────────────────────────────────────────────
let TP = 0, TF = 0; const FAILED = [];
// v178 — per-suite counts, so HARNESS.md's coverage table can be checked row by row.
const SUITE_COUNTS = {};
function suite(name, fn) {
  console.log('── ' + name + ' ' + '─'.repeat(Math.max(0, 56 - name.length)));
  let pass = 0, fail = 0;
  const t = (n, f) => { try { f(); console.log('  PASS  ' + n); pass++; }
                        catch (e) { console.log('  FAIL  ' + n + '\n        ' + e.message); fail++; } };
  const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b))
    throw new Error((m || '') + ' expected ' + JSON.stringify(b) + ' got ' + JSON.stringify(a)); };
  try { fn(t, eq); }
  catch (e) { console.log('  FAIL  SUITE CRASHED — its remaining tests did NOT run\n        ' + e.message); fail++; }
  console.log('  ' + pass + ' passed, ' + fail + ' failed\n');
  TP += pass; TF += fail; if (fail) FAILED.push(name);
  SUITE_COUNTS[name] = (SUITE_COUNTS[name] || 0) + pass + fail;
}


suite('Engine — tagging changes reconciliation output', (t, eq) => {
  const ctx = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,procOverrides:null,procProfileName:null} },
    ['proc','engine']);
  const P = ctx.P, buildAbomMap = ctx.E.buildAbomMap;
  // usedOn=8 pn=9 procCode=12 qty=13 woNo=35 woStatus=36
  const arow=(pn,nh,proc,qty,wo)=>{const r=new Array(40).fill('');
    r[8]=nh;r[9]=pn;r[12]=proc;r[13]=qty;r[35]=wo||'WO1';r[36]='CLOSED';return r;};
  const build = rows => buildAbomMap(rows, 9, 8, 13, 35, 36, 12);
  const K='P100||A1';

  console.log('\n== A new program\'s removal code, before and after tagging ==');
  t('untagged XR behaves as an install', ()=>{
    P.setProcCodeMap(null);
    const m=build([arow('P100','A1','XR',2)]);
    eq(m[K].allProcsAreRemovalOrSwap,false); eq(m[K].qty,2);
  });
  t('tagging XR as remove flips the same rows to proc-removed', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const m=build([arow('P100','A1','XR',2)]);
    eq(m[K].allProcsAreRemovalOrSwap,true,'flagged:'); eq(m[K].qty,-2,'net qty:');
  });
  t('an install row alongside the removal nets out', ()=>{
    const m=build([arow('P100','A1','AI',3),arow('P100','A1','XR',1)]);
    eq(m[K].allProcsAreRemovalOrSwap,false); eq(m[K].qty,2);
  });

  console.log('\n== Swap semantics on a user-tagged code ==');
  t('swap-only key is treated as present, not removed', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('TSW','swap');
    const m=build([arow('P100','A1','TSW',4)]);
    eq(m[K].allProcsAreRemovalOrSwap,false,'swap-only must not read as removed:');
    eq(m[K].qty,4);
  });
  t('swap alongside an install is net-zero', ()=>{
    const m=build([arow('P100','A1','AI',5),arow('P100','A1','TSW',5)]);
    eq(m[K].qty,5); eq(m[K].allProcsAreRemovalOrSwap,false);
  });

  console.log('\n== The founding program is unaffected ==');
  t('baseline codes produce identical maps', ()=>{
    P.setProcCodeMap(null);
    const m=build([arow('P1','A','BR',2),arow('P1','A','AI',5),arow('P2','A','DR',3),
                   arow('P3','A','MR',1),arow('P4','A','OTHER',7)]);
    eq(m['P1||A'].qty,3,'5 installed - 2 removed:');
    eq(m['P2||A'].allProcsAreRemovalOrSwap,false,'swap-only present:');
    eq(m['P3||A'].allProcsAreRemovalOrSwap,true,'removal-only:');
    eq(m['P4||A'].qty,7,'unknown code installs:');
  });
  t('untagging one default changes that code and nothing else', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('BR','add');
    const m=build([arow('P1','A','BR',2),arow('P2','A','MR',2)]);
    eq(m['P1||A'].qty,2); eq(m['P2||A'].allProcsAreRemovalOrSwap,true,'MR still removes:');
  });

  console.log('\n== Dedup reaches the engine ==');
  t('mixed-case spellings of a tagged code are all classified', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const m=build([arow('P100','A1','xr',1),arow('P100','A1',' XR ',1)]);
    eq(m[K].allProcsAreRemovalOrSwap,true); eq(m[K].qty,-2);
  });

  console.log('\n== Worker stays in lockstep ==');
  t('the serialized worker table is the ACTIVE table', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const decl='const PROC_CODE_EXCEPTIONS = '+JSON.stringify(P.PROC_CODE_EXCEPTIONS)+';';
    if(!decl.includes('"XR":"remove"')) throw new Error('worker would not see XR');
    const box={}; new Function('o', decl+' o.map = PROC_CODE_EXCEPTIONS;')(box);
    eq(box.map['XR'],'remove'); eq(box.map['BR'],'remove','defaults carried:');
  });
});

suite('Proc code panel — job number samples', (t, eq) => {
  const ctx = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,procOverrides:null,procProfileName:null} }, ['proc']);
  const T = ctx.P, state = ctx.state, els = ctx.__els;
  // Mapping 1 row: job at 5, desc at 10, proc at 12
  const row=(proc,job,desc)=>{const r=new Array(40).fill('');r[12]=proc;r[5]=job||'';r[10]=desc||'';return r;};
  const load=rows=>{state.boms.abom={data:rows};};
  const jobsOf=c=>[...(T.abomProcCodeInventory().codes.find(x=>x.code===c)||{jobs:new Set()}).jobs];

  console.log('\n== Job numbers collected and deduplicated ==');
  t('distinct job numbers only', ()=>{
    load([row('XR','J100'),row('XR','J100'),row('XR','J200'),row('XR','J100')]);
    eq(jobsOf('XR'),['J100','J200']);
  });
  t('job numbers are kept verbatim (no normalising)', ()=>{
    load([row('XR',' J-100/A ')]);
    eq(jobsOf('XR'),['J-100/A'],'trimmed but not uppercased:');
  });
  t('blank job numbers are skipped, not stored as empty', ()=>{
    load([row('XR',''),row('XR','   '),row('XR','J1')]);
    eq(jobsOf('XR'),['J1']);
  });
  t('each proc code keeps its own job set', ()=>{
    load([row('XR','J1'),row('TSW','J2'),row('XR','J3')]);
    eq(jobsOf('XR'),['J1','J3']); eq(jobsOf('TSW'),['J2']);
  });

  console.log('\n== Panel renders at most 3, one per line ==');
  function cell(html){const m=html.match(/<span class="pcm-jobs">([\s\S]*?)<\/span><span class="pcm-seg">/);return m?m[1]:'';}
  t('exactly 3 shown when more exist, with overflow count', ()=>{
    load([1,2,3,4,5,6,7].map(i=>row('XR','J'+i)));
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    const shown=(c.match(/class="pcm-job"/g)||[]).length;
    eq(shown,3,'job lines rendered:');
    if(!c.includes('+4 more')) throw new Error('overflow missing: '+c);
  });
  t('fewer than 3 renders only what exists, no overflow', ()=>{
    load([row('XR','J1'),row('XR','J2')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,2);
    if(c.includes('more')) throw new Error('false overflow');
  });
  t('exactly 3 shows no overflow', ()=>{
    load([row('XR','J1'),row('XR','J2'),row('XR','J3')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,3);
    if(c.includes('more')) throw new Error('false overflow at exactly 3');
  });
  t('each job is its own element (stacks as a row)', ()=>{
    load([row('XR','J1'),row('XR','J2')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq(c.match(/<span class="pcm-job">/g).length,2,'separate elements:');
  });
  t('no job numbers on the rows says so', ()=>{
    load([row('XR','')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    if(!c.includes('No job number')) throw new Error(c);
  });
  t('a code absent from the file says so', ()=>{
    load([row('XR','J1')]);
    const c=cell(T._procRowHtml({code:'BR',rows:0,jobs:new Set(),variants:new Set()}));
    if(!c.includes('Not present in this ABOM')) throw new Error(c);
  });
  t('job numbers are HTML-escaped', ()=>{
    load([row('XR','<script>x</script>')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    if(c.includes('<script>')) throw new Error('unescaped');
    if(!c.includes('&lt;script&gt;')) throw new Error('not escaped: '+c);
  });

  console.log('\n== The removed hint is gone ==');
  t('no removal hint anywhere in the rendered row', ()=>{
    load([row('XR','J1','PANEL, REMOVABLE, LH'),row('XR','J2','COVER, REMOVABLE')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(/desc says removal|removalish/i.test(h)) throw new Error('hint still present');
  });
  t('description is not rendered at all', ()=>{
    load([row('XR','J1','BRACKET, SUPPORT, LH')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(h.includes('BRACKET')) throw new Error('description still shown');
  });
  t('spellings-merged note survives (moved onto the code cell)', ()=>{
    load([row('XR','J1'),row('xr','J2')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(!h.includes('2 spellings merged')) throw new Error('lost the variant note');
  });

  console.log('\n== Mapping 2: description is blank, job numbers are not ==');
  t('panel still informative under Mapping 2 (desc always empty)', ()=>{
    // Mapping 2 sets COL.abom.desc = '' but populates jobNo from source col A.
    load([row('XR','J900',''),row('XR','J901','')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,2,'jobs present where desc never was:');
  });

  console.log('\n== Header aligns to the grid ==');
  t('header has the same 4 cells as a row', ()=>{
    const hd=T._procHeaderRow();
    eq((hd.match(/<span/g)||[]).length,4);
    if(!hd.includes('Job Numbers (samples)')) throw new Error('title wrong: '+hd);
  });
});

// ── TIER 1 ─────────────────────────────────────────────────────────────────
// Regression guards for two defects found in v153 and fixed in v154.
//
//   A. exportProcProfile()'s Cancel guard was dead code. `(prompt(...) || '')
//      .trim()` turned a null return into '' BEFORE the `=== null` check ran,
//      so pressing Cancel still downloaded a file and still overwrote
//      state.procProfileName with 'Unnamed profile'.
//
//   B. setProcCodeMap(map, profileName) ignored profileName on the `!map`
//      path and hard-set state.procProfileName = null. The session importer
//      calls exactly that path, so a profile NAME did not survive an export →
//      import round-trip even though the proc code BEHAVIOUR did. A re-opened
//      session reported 'Program baseline' where the original said the
//      program's name.
//
// The name is provenance; the overrides are the deviation. These tests pin
// that separation, because both defects were failures of exactly that
// distinction.
suite('Tier 1 — proc code profile name is provenance', (t, eq) => {
  // The two lines the session exporter writes and the one line the importer
  // reads. Lifted verbatim so that REWIRING the session — not just breaking
  // setProcCodeMap — also fails this suite.
  const SESSION_WRITE = ['procOverrides:   state.procOverrides   || null',
                         'procProfileName: state.procProfileName || null'];
  const SESSION_READ  = 'setProcCodeMap(payload.procOverrides || null, ' +
                        'payload.procProfileName || null)';

  let DL = [], PROMPT = null;
  const ctx = sandbox({
    COL: { abom: { procCode: 12, desc: 10, jobNo: 5 } },
    state: { boms:{abom:null}, results:[], isLocked:false,
             procOverrides:null, procProfileName:null },
    prompt: () => PROMPT,
    downloadFile: (n, b) => DL.push({ name: n, text: b && b.text }),
  }, ['proc']);
  const P = ctx.P, state = ctx.state;

  const reset = () => { DL = []; PROMPT = null; P.setProcCodeMap(null); };
  const payloadOf = () => JSON.parse(DL[0].text);
  // Push state through JSON exactly as a session file does, then restore it
  // the way the importer does, in a context that has been wiped first.
  function roundTrip() {
    ctx.__j = JSON.stringify({ procOverrides:   state.procOverrides   || null,
                               procProfileName: state.procProfileName || null });
    P.setProcCodeMap(null);                       // a fresh browser
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
  }
  ctx.__run = src => require('vm').runInContext(src, ctx, { filename: 'session.js' });

  console.log('\n== Defect A: Cancel must export nothing and change nothing ==');
  t('Cancel downloads no file', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = null;                                 // user pressed Cancel
    P.exportProcProfile();
    eq(DL.length, 0, 'files written on Cancel:');
  });
  t('Cancel leaves the existing profile name untouched', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    PROMPT = null;
    P.exportProcProfile();
    eq(state.procProfileName, 'Program Falcon', 'name after Cancel:');
  });
  t('confirming an EMPTY name still exports, as Unnamed profile', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = '';                                   // user pressed OK on a blank box
    P.exportProcProfile();
    eq(DL.length, 1, 'blank-but-confirmed must still export:');
    eq(payloadOf().profileName, 'Unnamed profile');
  });
  t('a real name reaches the payload and the state', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = '  Program Falcon  ';                 // and is trimmed
    P.exportProcProfile();
    eq(payloadOf().profileName, 'Program Falcon');
    eq(state.procProfileName, 'Program Falcon');
    eq(payloadOf().basedOn, 'custom', 'a tagged table is a deviation:');
  });

  console.log('\n== Defect B: the name survives a session round-trip ==');
  t('the session still carries both proc fields', () => {
    SESSION_WRITE.forEach(s => {
      if (!SRC.includes(s)) throw new Error('exporter no longer writes: ' + s); });
    if (!SRC.includes(SESSION_READ)) throw new Error('importer no longer reads it');
  });
  t('a CUSTOM profile keeps its name through export and import', () => {
    reset(); P.setProcCodeMap({ XR:'remove', TSW:'swap' }, 'Program Falcon');
    roundTrip();
    eq(state.procProfileName, 'Program Falcon', 'name after round-trip:');
    eq(P.PROC_CODE_EXCEPTIONS.XR, 'remove', 'and the behaviour came with it:');
    eq(P.isProcMapCustom(), true);
  });
  t('a BASELINE-EQUAL profile keeps its name through export and import', () => {
    // importProcProfile drops the custom flag but keeps the name when the
    // shared file happens to match the baseline. That is the exact shape that
    // hit the null path in setProcCodeMap and lost the name.
    reset();
    P.importProcProfile({ _text: JSON.stringify({
      schema: 'bom-comparator-proc-profile', profileName: 'Program Falcon',
      procCodes: P.PROC_CODE_BASELINE }) });
    eq(P.isProcMapCustom(), false, 'baseline-equal is not a deviation:');
    eq(state.procProfileName, 'Program Falcon', 'but the name is kept:');
    roundTrip();
    eq(state.procProfileName, 'Program Falcon', 'and survives the session:');
    eq(P.isProcMapCustom(), false, 'still not a deviation:');
  });
  t('a session with no proc fields at all restores as clean baseline', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = '{}';                                // a pre-v153 session file
    P.setProcCodeMap(null);
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq([state.procProfileName, state.procOverrides], [null, null]);
    eq(P.PROC_CODE_EXCEPTIONS.BR, 'remove', 'baseline is live:');
  });

  console.log('\n== The name/override split, stated directly ==');
  t('setProcCodeMap(null, name) keeps the name; setProcCodeMap(null) clears it', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.setProcCodeMap(null, 'Program Falcon');
    eq([state.procProfileName, state.procOverrides], ['Program Falcon', null],
       'named null-path:');
    P.setProcCodeMap(null);
    eq(state.procProfileName, null, 'bare null-path still clears:');
  });
  t('untagging back to baseline keeps the name, but Reset clears it', () => {
    // Two different acts. Editing your way back is not the same as declaring
    // you are done with the profile, and only the second should erase it.
    reset();
    P.setProcCodeMap(P.PROC_CODE_BASELINE, 'Program Falcon');
    P.setProcCodeBehavior('XR', 'remove');
    eq(P.isProcMapCustom(), true, 'tagging forks the table:');
    P.setProcCodeBehavior('XR', 'add');            // untag it again
    eq(P.isProcMapCustom(), false, 'back to baseline, flag dropped:');
    eq(state.procProfileName, 'Program Falcon', 'name held:');
    P.resetProcCodesToBaseline();
    eq(state.procProfileName, null, 'explicit Reset clears it:');
  });
  t('the freeze certificate label is identical before and after a round-trip', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    const before = P._procProfileLabel();
    roundTrip();
    eq(P._procProfileLabel(), before, 'label drift:');
    eq(before, 'Program Falcon');
  });
  t('an unnamed custom table reads as Custom, not as the baseline', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P._procProfileLabel(), 'Custom');
    roundTrip();
    eq(P._procProfileLabel(), 'Custom', 'and stays Custom after a round-trip:');
  });
  t('a rejected profile file changes nothing', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.importProcProfile({ _text: JSON.stringify({ schema: 'something-else',
      profileName: 'Hostile', procCodes: { BR:'swap' } }) });
    eq(state.procProfileName, 'Program Falcon', 'name untouched:');
    eq(P.PROC_CODE_EXCEPTIONS.XR, 'remove', 'table untouched:');
  });
});

// ── TIER 2 ─────────────────────────────────────────────────────────────────
// Until v154 the sandbox defined its own six-line buildEbomIndentureMap and the
// ECN inheritance suites tested THAT. The real function is ~60 lines and returns
// three structures, not one. They agree on clean data and diverge on a
// self-referencing row. These tests exercise the shipping function.
suite('Tier 2 — EBOM indenture map (the real one)', (t, eq) => {
  const ctx = sandbox({}, ['engine']);
  const build = ctx.E.buildEbomIndentureMap;
  // indenture=0, pn=1, nh=3 — the shape COL.ebom uses elsewhere in this file.
  const row = (ind, pn, nh) => { const r = new Array(10).fill('');
    r[0] = ind; r[1] = pn; r[3] = nh; return r; };
  const map  = rows => build(rows, 0, 1, 3);
  const kids = (m, k) => (m.keyInfo[k] ? [...m.keyInfo[k].childKeys].sort() : '(no such key)');

  console.log('\n== Structure the build actually consumes ==');
  t('returns all three structures, not just keyInfo', () => {
    const m = map([row('A', 'TOP', '')]);
    eq(Object.keys(m).sort(), ['keyInfo', 'pnToIndenture', 'pnToNh']);
  });
  t('a clean three-level tree links each level to the next, not transitively', () => {
    const m = map([row('A','TOP',''), row('B','MID','TOP'), row('C','LEAF','MID')]);
    eq(kids(m, 'TOP||'),     ['MID||TOP'], 'top:');
    eq(kids(m, 'MID||TOP'),  ['LEAF||MID'], 'middle:');
    eq(kids(m, 'LEAF||MID'), [], 'leaf:');
  });
  t('a deep chain stays one link per level', () => {
    const rows = [row('A','L0','')];
    for (let i = 1; i <= 8; i++) rows.push(row('B','L'+i,'L'+(i-1)));
    const m = map(rows);
    for (let i = 0; i < 8; i++)
      eq(kids(m, 'L'+i+'||'+(i ? 'L'+(i-1) : '')), ['L'+(i+1)+'||L'+i], 'level '+i+':');
  });
  t('a PN under two different NHs makes the child a child of BOTH keys', () => {
    const m = map([row('A','TOP',''), row('B','P1','TOP'), row('B','P1','OTHER'), row('C','KID','P1')]);
    eq(kids(m, 'P1||TOP'),   ['KID||P1'], 'first parent key:');
    eq(kids(m, 'P1||OTHER'), ['KID||P1'], 'second parent key:');
  });

  console.log('\n== Where the old stand-in was wrong ==');
  t('a self-referencing row (PN === NH) becomes its own child', () => {
    // A part listed as its own next-higher assembly — a real extract defect.
    // The shipping function creates a self-loop here. The old stand-in excluded
    // self and reported ["Y||X"], so this behaviour was invisible to the harness.
    const m = map([row('A','X','X'), row('B','Y','X')]);
    eq(kids(m, 'X||X'), ['X||X', 'Y||X'], 'self-loop is real:');
  });
  t('the ECN inheritance walk terminates on that self-loop and still inherits', () => {
    const c = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3}, chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
      state:{results:[], boms:{ebom:null, chp:null}} }, ['proc','engine','chp','chpalign','ecn']);
    const R = (pn, nh, ecn) => ({ key: pn+'||'+nh, pn, nh, overall:'ok', as:'ok',
      woStatus:'closed', woValues:['W1'],
      trace: ecn ? { dcn:new Map(), ecn:new Map(ecn), ecr:new Map() } : null,
      ncrEntriesPool1:[], ncrEntriesPool2:[] });
    c.state.results = [R('X','X',[['E1','']]), R('Y','X',null)];
    c.state.boms.ebom = { data:[row('A','X','X'), row('B','Y','X')] };
    const e = c.B.buildEcnFootprints().ecnMap.get('E1');   // must return, not hang
    eq(e.items.length, 2, 'child inherited across the self-loop:');
    eq(e.items.map(x => x.r.key).sort(), ['X||X', 'Y||X']);
    // Y holds no ECN of its own — it must be marked as inherited from X.
    const y = e.items.find(x => x.r.key === 'Y||X');
    eq(y.inheritedVia, 'X||X', 'inheritance provenance:');
    eq(e.items.find(x => x.r.key === 'X||X').inheritedVia, '', 'the anchor is direct:');
  });

  console.log('\n== Indexing rules ==');
  t('a row with a blank NH is indexed but never linked as a child', () => {
    const m = map([row('A','TOP',''), row('B','ORPHAN','')]);
    eq(kids(m, 'TOP||'), [], 'a blank NH must not read as "child of everything":');
    if (!m.keyInfo['ORPHAN||']) throw new Error('the orphan row was dropped from keyInfo');
  });
  t('a row with a blank PN is skipped entirely', () => {
    const m = map([row('A','TOP',''), row('B','','TOP')]);
    eq(Object.keys(m.keyInfo).sort(), ['TOP||']);
  });
  t('pnToIndenture keeps the FIRST occurrence and does not overwrite', () => {
    const m = map([row('B','P1','TOP'), row('E','P1','OTHER')]);
    eq(m.pnToIndenture['P1'], 'B', 'later rows must not win:');
  });
  t('pnToNh keeps the FIRST occurrence and does not overwrite', () => {
    const m = map([row('B','P1','TOP'), row('B','P1','OTHER')]);
    eq(m.pnToNh['P1'], 'TOP');
  });
  t('case and whitespace variants collapse to one key', () => {
    const m = map([row('a',' top ',''), row('b','MID','TOP'), row('b','mid','top')]);
    eq(Object.keys(m.keyInfo).sort(), ['MID||TOP', 'TOP||'], 'normalised:');
    eq(kids(m, 'TOP||'), ['MID||TOP']);
  });
});

// The harness's own safety net. HARNESS.md promises that a moved marker "fails
// loudly and names it" — before v154 that was true only for markers routed
// through at(). Four boundaries used raw indexOf, where a miss returns -1 and
// produces a silently EMPTY module: every suite green, nothing tested.
suite('Tier 2 — extraction integrity', (t, eq) => {
  const DEPS = { proc:['proc'], engine:['engine'],
                 ecn:['proc','engine','chp','chpalign','ecn'], ncr:['ncr'], chp:['chp'], delta:['delta'],
                 session:['chpalign','session'], adjimport:['adjimport'],
                 chpalign:['engine','chp','chpalign'] };   // v182

  t('every module is substantial and contains what it claims', () => {
    Object.keys(MODULE_CONTRACT).forEach(name => {
      const c = MODULE_CONTRACT[name], src = MOD[name];
      if (!src || src.length < c.min)
        throw new Error(name + ': ' + (src ? src.length : 0) + ' chars, expected >= ' + c.min);
      c.needs.forEach(n => { if (!src.includes(n))
        throw new Error(name + ' is missing ' + JSON.stringify(n) + ' — wrong slice'); });
    });
  });
  t('every module defines its global once evaluated', () => {
    Object.keys(MODULE_CONTRACT).forEach(name => {
      const c = MODULE_CONTRACT[name];
      const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3}, abom:{procCode:12,desc:10,jobNo:5},
        chp:{pn:3,nh:5,ecn:18}, ncr:{ncrNum:60,dispNo:71}},
        state:{results:[], boms:{}, isLocked:false, procOverrides:null, procProfileName:null} },
        DEPS[name]);
      if (!ctx[c.global]) throw new Error(name + ' did not define globalThis.' + c.global);
      c.exports.forEach(fn => { if (typeof ctx[c.global][fn] !== 'function')
        throw new Error(name + '.' + c.global + '.' + fn + ' is not a function'); });
    });
  });
  t('no global exists without its module — an empty run cannot pass', () => {
    const c = sandbox({}, []);
    ['P','E','B','N'].forEach(g => { if (c[g])
      throw new Error(g + ' exists with no module loaded'); });
  });

  console.log('\n== The guards themselves ==');
  const throws = (fn, want, label) => {
    let msg = null;
    try { fn(); } catch (e) { msg = e.message; }
    if (msg === null) throw new Error(label + ' did not throw');
    if (msg.indexOf(want) < 0) throw new Error(label + ' threw the wrong thing: ' + msg);
  };
  t('a missing marker throws and names itself', () => {
    throws(() => at('NO SUCH MARKER IN THIS BUILD'), 'BUILD MARKER MOVED', 'at()');
    throws(() => at('NO SUCH MARKER IN THIS BUILD'), 'NO SUCH MARKER', 'at() naming');
  });
  t('a backwards marker search is guarded too', () => {
    throws(() => lastAt('NO SUCH MARKER IN THIS BUILD', 5000, 'probe'),
           'BUILD MARKER MOVED', 'lastAt()');
  });
  t('crossed boundaries are refused, not silently emptied', () => {
    // This is the exact shape a raw indexOf miss produced: end before start.
    throws(() => span(1124358, 400, 'probe'), 'BUILD MARKERS CROSSED', 'span()');
  });
  t('a suspiciously small slice is refused', () => {
    throws(() => span(0, 50, 'probe'), 'MODULE SLICE TOO SMALL', 'span()');
  });
  t('grabFn refuses a function that is not there', () => {
    throws(() => grabFn('thisFunctionDoesNotExistAnywhere'), 'BUILD MARKER MOVED', 'grabFn()');
  });

  console.log('\n== The worker bundle must be self-contained ==');
  t('every function the worker bundle calls is also IN the bundle', () => {
    // The worker is built by serialising a hand-listed set of functions with
    // .toString(). A function that calls another top-level function which is
    // NOT on that list throws inside the worker and kills every comparison run.
    // This has now happened twice: buildEbomLineNoMap in v145, and
    // normIndenture in v160 — which shipped broken through v163 because every
    // suite here loads functions directly and never exercises the worker path.
    const i = at('const fns = [');
    const listSrc = SRC.slice(i + 13, at('].map(fn => fn.toString())', i));
    const bundled = new Set([...listSrc.replace(/\/\/[^\n]*/g, '')
      .matchAll(/\b([a-zA-Z_$][\w$]*)\b/g)].map(m => m[1]));
    if (bundled.size < 15) throw new Error('only found ' + bundled.size + ' bundled functions');
    const topLevel = new Set([...SRC.matchAll(/^function (\w+)\s*\(/gm)].map(m => m[1]));
    const missing = [];
    bundled.forEach(fn => {
      let src;
      try { src = grabFn(fn); } catch (e) { return; }
      // Bare calls only: a preceding '.' makes it a method, not a global.
      [...src.matchAll(/(^|[^.\w$])([a-zA-Z_$][\w$]*)\s*\(/g)].forEach(m => {
        const c = m[2];
        if (c === fn || !topLevel.has(c) || bundled.has(c)) return;
        missing.push(fn + '() calls ' + c + '()');
      });
    });
    if (missing.length)
      throw new Error('the worker would throw on:\n        ' +
                      [...new Set(missing)].join('\n        '));
  });
  t('normIndenture specifically is in the bundle', () => {
    // Named because it is the one that shipped broken, and because the failure
    // is invisible to every other test in this file.
    const i = at('const fns = [');
    const listSrc = SRC.slice(i + 13, at('].map(fn => fn.toString())', i))
      .replace(/\/\/[^\n]*/g, '');
    if (!/\bnormIndenture\b/.test(listSrc))
      throw new Error('normIndenture is missing from the worker bundle again');
  });

  console.log('\n== The build is still what it claims to be ==');
  t('no external script or stylesheet — the file is genuinely offline', () => {
    const ext = [...SRC.matchAll(/<script[^>]*\ssrc\s*=/gi)].length +
                [...SRC.matchAll(/<link[^>]*rel=["']stylesheet["']/gi)].length;
    if (ext) throw new Error(ext + ' external reference(s) — the build is no longer self-contained');
  });
  t('HARNESS.md reports the same test count as the harness', () => {
    // v163 — the header count had been stale since 262 tests: every update
    // since was rewriting a phrase that no longer matched, and silently doing
    // nothing. Documentation that quietly stops tracking is worse than none.
    const fs2 = require('fs'), pth = require('path');
    const candidates = [pth.join(__dirname, 'HARNESS.md'),
                        pth.join(__dirname, '..', 'HARNESS.md')];
    const f = candidates.find(p => { try { return fs2.statSync(p).isFile(); } catch (e) { return false; } });
    if (!f) return;                       // not shipped alongside: nothing to check
    const md = fs2.readFileSync(f, 'utf8');
    const m = md.match(/(\d+)\s+tests\./);
    if (!m) throw new Error('HARNESS.md no longer states a test count');
    // EXPECTED_TESTS is declared at the foot of this file, after every suite has
    // run, so it cannot be referenced here. Read the literal from source.
    const self = fs2.readFileSync(__filename, 'utf8');
    const want = parseInt(self.match(/EXPECTED_TESTS = (\d+)/)[1], 10);
    if (parseInt(m[1], 10) !== want)
      throw new Error('HARNESS.md says ' + m[1] + ' tests, the harness expects ' + want);
  });
  t('the file read is the file reported', () => {
    eq(fs.readFileSync(BUILD, 'utf8').length, SRC.length);
    if (!/^<!DOCTYPE html/i.test(SRC.trim())) throw new Error('not an HTML document');
  });
});

// ── TIER 3 ─────────────────────────────────────────────────────────────────
// The CHP release badge. Pure logic, user-visible warning, and the release date
// it produces is printed on the freeze certificate — an audit artefact.
suite('Tier 3 — CHP release state', (t, eq) => {
  const C = sandbox({}, ['chp']).C;
  const trace = (dcn, ecn, ecr) => ({
    dcn: new Map(dcn || []), ecn: new Map(ecn || []), ecr: new Map(ecr || []) });
  const st = (...a) => C.chpReleaseState(trace(...a));

  console.log('\n== No history, and history without a DCN ==');
  t('a null trace reads as NO HISTORY, not as a warning', () => {
    const s = C.chpReleaseState(null);
    eq([s.state, s.label, s.warn, s.dcnCount], ['none', 'NO HISTORY', false, 0]);
  });
  t('a trace with three empty maps also reads as NO HISTORY', () => {
    eq(st([], [], []).state, 'none');
  });
  t('an ECN with no DCN reads as NO DCN and is NOT a warning', () => {
    // Expected for COTS parts: release is held by the parent that owns the DCN.
    const s = st([], [['E1', 'Open']], []);
    eq([s.state, s.label, s.warn], ['no_dcn', 'NO DCN', false]);
  });
  t('an ECR alone also reads as NO DCN', () => {
    eq(st([], [], [['R1', '']]).state, 'no_dcn');
  });

  console.log('\n== Released ==');
  t('one dated DCN reads as RELEASED with no count suffix', () => {
    const s = st([['D1', '2024-03-15']]);
    eq([s.state, s.warn, s.dcnCount], ['released', false, 1]);
    eq(s.label, 'RELEASED MARCH 15, 2024');
  });
  t('several dated DCNs report the LATEST date and the count', () => {
    const s = st([['D1', '2024-01-05'], ['D2', '2024-06-30'], ['D3', '2024-03-15']]);
    eq(s.date, 'JUNE 30, 2024', 'latest wins:');
    eq(s.label, 'RELEASED JUNE 30, 2024 \u00b7 3 DCNs');
    eq(s.dcnCount, 3);
  });
  t('order of arrival does not change which date wins', () => {
    const a = st([['D1', '2024-06-30'], ['D2', '2024-01-05']]).date;
    const b = st([['D1', '2024-01-05'], ['D2', '2024-06-30']]).date;
    eq(a, b);
  });

  console.log('\n== Unreleased: the warning that matters ==');
  t('an undated DCN raises the warning and names the offender', () => {
    const s = st([['D1', 'Unknown']]);
    eq([s.state, s.warn, s.label], ['unreleased', true, '\u26a0 DCN NOT RELEASED']);
    eq(s.undated, ['D1']);
    if (!s.note.includes('D1')) throw new Error('the note must name the DCN');
  });
  t('ONE undated DCN outweighs any number of dated ones', () => {
    // The safe direction: a partially-scoped extract must not read as released.
    const s = st([['D1', '2024-03-15'], ['D2', ''], ['D3', '2024-06-30']]);
    eq([s.state, s.warn], ['unreleased', true]);
    eq(s.undated, ['D2']);
  });
  t('every undated DCN is listed, not just the first', () => {
    eq(st([['D1', ''], ['D2', 'TBD'], ['D3', '2024-03-15']]).undated, ['D1', 'D2']);
  });
  t('unparseable text counts as undated, not as a date', () => {
    ['Unknown', 'TBD', 'N/A', 'RELEASED', '   ', ''].forEach(v => {
      eq(C.chpReleaseState(trace([['D1', v]])).state, 'unreleased', JSON.stringify(v) + ':');
    });
  });

  console.log('\n== Date shapes the extract actually produces ==');
  t('a Date object from cellDates:true is accepted', () => {
    eq(st([['D1', new Date(2024, 2, 15)]]).date, 'MARCH 15, 2024');
  });
  t('a stringified Date is accepted — this is the real path', () => {
    // buildChpTraceMap does String(row[...]) before storing, so the Date object
    // branch is mostly bypassed in practice.
    eq(st([['D1', String(new Date(2024, 2, 15))]]).date, 'MARCH 15, 2024');
  });
  t('ISO, slash and DD-MON forms all give the same calendar date', () => {
    ['2024-03-15', '2024-03-15T08:30:00Z', '2024-03-15 08:30:00',
     '3/15/2024', '15-MAR-2024'].forEach(v => {
      eq(C.formatDcnDate(v), 'MARCH 15, 2024', JSON.stringify(v) + ':');
    });
  });
  t('an invalid Date object is treated as undated', () => {
    eq(st([['D1', new Date('nonsense')]]).state, 'unreleased');
  });

  console.log('\n== Defect C: the same day everywhere on earth ==');
  t('the displayed date does not depend on the reader\'s timezone', () => {
    // v153 read UTC components off a date built at LOCAL midnight, so a DCN
    // released 15 March showed as MARCH 14 in Tokyo, Sydney and Kolkata.
    // Node reads process.env.TZ at first Date use, so this runs a child.
    const cp = require('child_process');
    const probe = 'const v=process.argv[1];' + MOD.chp +
      ';console.log(formatDcnDate(v==="obj"?new Date(2024,2,15):v));';
    ['2024-03-15', '3/15/2024', '15-MAR-2024', 'obj'].forEach(shape => {
      ['UTC', 'America/New_York', 'Asia/Tokyo', 'Australia/Sydney', 'Asia/Kolkata',
       'Pacific/Kiritimati'].forEach(tz => {
        const got = cp.execFileSync(process.execPath, ['-e', probe, shape],
                     { env: Object.assign({}, process.env, { TZ: tz }) }).toString().trim();
        if (got !== 'MARCH 15, 2024')
          throw new Error(shape + ' in ' + tz + ' -> ' + got);
      });
    });
  });
  t('no UTC component read survives in the date formatter', () => {
    if (/getUTC(Month|Date|FullYear)/.test(MOD.chp))
      throw new Error('formatDcnDate is reading UTC components again');
  });

  console.log('\n== Badge styling ==');
  t('only the unreleased state is styled as a warning', () => {
    // v156 — 'none' used to return '', so NO HISTORY rendered as bare text
    // beside four real badges in the same column. It now gets the neutral badge.
    // Every state is a badge; only 'unreleased' is a WARNING badge.
    eq(C.chpStateClass('unreleased'), 'badge badge-chp-warn');
    eq(C.chpStateClass('none'), 'badge badge-neutral', 'no history must still be a badge:');
    eq(C.chpStateClass('released'), 'badge badge-history');
    eq(C.chpStateClass('no_dcn'), 'badge badge-history', 'NO DCN is not a warning:');
  });
  t('every state chpReleaseState can return has a class', () => {
    ['none', 'no_dcn', 'released', 'unreleased'].forEach(s => {
      if (typeof C.chpStateClass(s) !== 'string')
        throw new Error('no class for state ' + s);
    });
  });
});

// The proc code table under adversarial conditions: a frozen report, a
// hand-edited profile file, and a session carrying someone else's provenance.
suite('Tier 3 — proc table under lock, bad input, and session reuse', (t, eq) => {
  const SESSION_READ = 'setProcCodeMap(payload.procOverrides || null, ' +
                       'payload.procProfileName || null)';
  const ctx = sandbox({
    COL: { abom: { procCode: 12, desc: 10, jobNo: 5 } },
    state: { boms:{abom:null}, results:[], isLocked:false,
             procOverrides:null, procProfileName:null },
  }, ['proc']);
  const P = ctx.P, state = ctx.state;
  ctx.__run = src => require('vm').runInContext(src, ctx, { filename: 'session.js' });
  const reset = () => { state.isLocked = false; state.results = []; P.dirty = false;
                        P.setProcCodeMap(null); };
  const profile = o => ({ _text: JSON.stringify(Object.assign(
    { schema: 'bom-comparator-proc-profile' }, o)) });

  console.log('\n== A frozen report must not move ==');
  t('tagging a code is refused while the report is locked', () => {
    reset(); state.isLocked = true;
    P.setProcCodeBehavior('XR', 'remove');
    eq([P.isProcMapCustom(), state.procOverrides], [false, null], 'table changed under lock:');
  });
  t('reset to baseline is refused while the report is locked', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    state.isLocked = true;
    P.resetProcCodesToBaseline();
    eq([P.isProcMapCustom(), state.procProfileName], [true, 'Program Falcon'], 'reset ran anyway:');
  });
  t('unlocking restores both operations', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P.getProcBehavior('XR'), 'remove');
    P.resetProcCodesToBaseline();
    eq(P.isProcMapCustom(), false);
  });

  console.log('\n== A hand-edited profile file ==');
  t('a wrong schema is rejected and changes nothing', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.importProcProfile(profile({ schema:'something-else', procCodes:{ BR:'swap' } }));
    eq([P.PROC_CODE_EXCEPTIONS.XR, state.procProfileName], ['remove', 'Program Falcon']);
  });
  t('an invalid behaviour value is dropped, not installed', () => {
    reset();
    P.importProcProfile(profile({ profileName:'Bad', procCodes:{ XR:'remove', TSW:'delete' } }));
    eq(P.getProcBehavior('XR'), 'remove', 'the valid entry survives:');
    eq(P.getProcBehavior('TSW'), 'add', '"delete" is not a behaviour:');
  });
  t('an empty procCodes map installs a table with no removal codes', () => {
    // A deliberate act — every code untagged — not the same as the baseline.
    reset();
    P.importProcProfile(profile({ profileName:'Nothing', procCodes:{} }));
    eq(P.isProcMapCustom(), true, 'still a deviation:');
    eq(P.getProcBehavior('BR'), 'add', 'baseline BR no longer removes:');
  });
  t('a profile identical to the baseline keeps its name but drops the flag', () => {
    reset();
    P.importProcProfile(profile({ profileName:'Program Falcon',
                                  procCodes: P.PROC_CODE_BASELINE }));
    eq([P.isProcMapCustom(), state.procProfileName], [false, 'Program Falcon']);
  });

  console.log('\n== Defect D: provenance must not leak between loads ==');
  t('an unnamed custom session does NOT inherit the previous profile name', () => {
    // v153: setProcCodeMap fell back to `|| state.procProfileName`, so loading
    // "Program Falcon" and then importing an unnamed session left the freeze
    // certificate still claiming Falcon.
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = JSON.stringify({ procOverrides:{ TSW:'swap' }, procProfileName:null });
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq(state.procProfileName, null, 'stale name survived:');
    eq(P._procProfileLabel(), 'Custom');
  });
  t('a named session overwrites the previous name rather than merging', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = JSON.stringify({ procOverrides:{ TSW:'swap' }, procProfileName:'Program Kestrel' });
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq(state.procProfileName, 'Program Kestrel');
  });
  t('a baseline session clears a previously loaded profile entirely', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = '{}';
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq([state.procProfileName, state.procOverrides], [null, null]);
    eq(P.getProcBehavior('BR'), 'remove', 'baseline is live again:');
  });

  console.log('\n== The stale-results flag ==');
  t('tagging with no results on screen does not raise the dirty flag', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P.dirty, false, 'nothing to invalidate yet:');
  });
  t('tagging AFTER a run marks the results stale', () => {
    reset(); state.results = [{}];
    P.setProcCodeBehavior('XR', 'remove');
    eq(P.dirty, true);
  });
  t('resetting after a run also marks the results stale', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, null); state.results = [{}];
    P.resetProcCodesToBaseline();
    eq(P.dirty, true);
  });
  t('a locked report cannot be made dirty', () => {
    reset(); state.results = [{}]; state.isLocked = true;
    P.setProcCodeBehavior('XR', 'remove');
    P.resetProcCodesToBaseline();
    eq(P.dirty, false);
  });
});

// ── TIER 4 ─────────────────────────────────────────────────────────────────
// The delta tool: a second shipped file with no coverage at all until v154.
// Its whole job is to tell two sessions apart, so a field it fails to compare
// is a wrong answer, not a missing feature.
suite('Tier 4 — delta tool', (t, eq) => {
  const D = sandbox({}, ['delta']).D;
  const P = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,
           procOverrides:null,procProfileName:null} }, ['proc']).P;

  console.log('\n== The duplicated baseline ==');
  t('the delta tool\'s PROC_CODE_BASELINE matches the main build\'s, key for key', () => {
    // The delta tool ships its own copy. Its own comment says it "mirrors the
    // main build's shipped proc code table" — nothing enforced that. If the
    // main build gains a code and this copy does not, the delta tool reports
    // two sessions as agreeing on proc codes when they do not.
    const a = P.PROC_CODE_BASELINE, b = D.PROC_CODE_BASELINE;
    const ka = Object.keys(a).sort(), kb = Object.keys(b).sort();
    const onlyMain = ka.filter(k => !(k in b)), onlyDelta = kb.filter(k => !(k in a));
    if (onlyMain.length || onlyDelta.length)
      throw new Error('BASELINES HAVE DRIFTED — only in main build: [' + onlyMain +
                      ']; only in delta tool: [' + onlyDelta + ']');
    const differ = ka.filter(k => a[k] !== b[k]).map(k => k + ' (' + a[k] + ' vs ' + b[k] + ')');
    if (differ.length) throw new Error('BEHAVIOURS HAVE DRIFTED: ' + differ.join(', '));
  });
  t('both copies still classify every code as remove or swap', () => {
    Object.keys(D.PROC_CODE_BASELINE).forEach(k => {
      const v = D.PROC_CODE_BASELINE[k];
      if (v !== 'remove' && v !== 'swap') throw new Error(k + ' is "' + v + '"');
    });
  });

  console.log('\n== procTableOf and procTableDiff ==');
  t('a session with no overrides runs under the baseline', () => {
    eq(D.procTableOf({ procOverrides: null }), D.PROC_CODE_BASELINE);
    eq(D.procTableOf(null), D.PROC_CODE_BASELINE, 'a missing session too:');
  });
  t('overrides replace the baseline outright, they do not merge into it', () => {
    const tbl = D.procTableOf({ procOverrides: { XR: 'remove' } });
    eq(Object.keys(tbl), ['XR']);
    eq(tbl.BR, undefined, 'baseline BR must not leak through:');
  });
  t('codes are normalised and invalid behaviours dropped', () => {
    const tbl = D.procTableOf({ procOverrides: { ' xr ': 'REMOVE', TSW: 'delete', '': 'swap' } });
    eq(tbl, { XR: 'remove' });
  });
  t('two identical sessions report no proc difference', () => {
    eq(D.procTableDiff({ procOverrides: null }, { procOverrides: null }).same, true);
  });
  t('absent means install, so a code added on one side is a difference', () => {
    const d = D.procTableDiff({ procOverrides: { XR:'remove' } },
                              { procOverrides: { XR:'remove', TSW:'swap' } });
    eq(d.same, false);
    eq(d.codes, [{ code:'TSW', a:'install', b:'swap' }]);
  });
  t('a code reclassified from remove to swap is reported with both sides', () => {
    const d = D.procTableDiff({ procOverrides:{ XR:'remove' } }, { procOverrides:{ XR:'swap' } });
    eq(d.codes, [{ code:'XR', a:'remove', b:'swap' }]);
  });
  t('differences are sorted so the sheet is stable between runs', () => {
    const d = D.procTableDiff({ procOverrides:{} },
                              { procOverrides:{ ZZ:'swap', AA:'remove', MM:'swap' } });
    eq(d.codes.map(c => c.code), ['AA', 'MM', 'ZZ']);
  });
  t('a baseline session versus a custom one is a difference, not a match', () => {
    eq(D.procTableDiff({ procOverrides:null }, { procOverrides:{ XR:'remove' } }).same, false);
  });

  console.log('\n== procProfileLabel agrees with the main build ==');
  t('the two tools label the same session identically', () => {
    [[null, null], [{ XR:'remove' }, null], [{ XR:'remove' }, 'Program Falcon'],
     [null, 'Program Falcon']].forEach(([ov, nm]) => {
      P.setProcCodeMap(ov, nm);
      const main = P._procProfileLabel();
      const delta = D.procProfileLabel({ procOverrides: ov, procProfileName: nm });
      if (main !== delta)
        throw new Error('label drift for ' + JSON.stringify([ov, nm]) +
                        ': main says ' + JSON.stringify(main) +
                        ', delta says ' + JSON.stringify(delta));
    });
  });

  console.log('\n== Defect E: displayed but not compared ==');
  const claim = o => Object.assign({ id:'adj_1', type:'ebom_ncr_trace', mode:'embodiment',
    leg:'A', rowKey:'P1||TOP', reason:'ebom_ncr_trace', sme:'J.Doe',
    rationale:'traced', applied:false }, o);
  t('a changed NCR disposition number is reported as a modification', () => {
    // v3.1 compared c.dispNo only. On ebom_ncr_trace claims — the ones the
    // main build actually creates — the field is ncrDispNo, so this change
    // was invisible and the claim was omitted from the Claims sheet.
    const rows = D.claimsDelta({ adjudications:[claim({ ncrDispNo:'DISP-100' })] },
                               { adjudications:[claim({ ncrDispNo:'DISP-999' })] });
    eq(rows.length, 1, 'modification missed:');
    eq(rows[0].Change, 'Modified');
    eq(rows[0]['NCR Disp No'], 'DISP-999');
  });
  t('a claim moving from pending to applied is reported', () => {
    const rows = D.claimsDelta({ adjudications:[claim({ applied:false })] },
                               { adjudications:[claim({ applied:true })] });
    eq(rows.length, 1);
    eq(rows[0].Applied, 'yes');
  });
  t('every field the Claims sheet prints is a field the signature compares', () => {
    // The rule the defect broke. Vary one field at a time and require the
    // signature to move. Timestamp is excluded deliberately — see HARNESS.md.
    const base = claim({ ncrDispNo:'D1', woNo:'W1', claimedQty:2, ciKey:'C1',
                         smeRole:'Lead', rowKeys:['a','b'] });
    const vary = { type:'other', leg:'B', rowKey:'X||Y', ciKey:'C2', ncrDispNo:'D2',
                   woNo:'W2', claimedQty:5, sme:'A.Nother', smeRole:'Peer',
                   rationale:'different', applied:true };
    Object.keys(vary).forEach(f => {
      const changed = Object.assign({}, base); changed[f] = vary[f];
      if (D.claimSig(base) === D.claimSig(changed))
        throw new Error('claimSig ignores "' + f + '", which claimRow displays');
    });
  });
  t('an unchanged claim produces no row at all', () => {
    eq(D.claimsDelta({ adjudications:[claim({ ncrDispNo:'D1' })] },
                     { adjudications:[claim({ ncrDispNo:'D1' })] }).length, 0);
  });

  console.log('\n== claimsDelta bookkeeping ==');
  t('added, removed and modified claims are each labelled', () => {
    const A = { adjudications:[claim({ id:'a1' }), claim({ id:'a2', rationale:'old' })] };
    const B = { adjudications:[claim({ id:'a2', rationale:'new' }), claim({ id:'a3' })] };
    const rows = D.claimsDelta(A, B);
    eq(rows.map(r => r.Change + ':' + r['Claim ID']).sort(),
       ['Added in B:a3', 'Modified:a2', 'Removed in B:a1']);
  });
  t('claims with no id are ignored rather than crashing', () => {
    eq(D.claimsDelta({ adjudications:[{ rationale:'orphan' }] },
                     { adjudications:[] }).length, 0);
  });
  t('a session with no adjudications key is treated as empty', () => {
    eq(D.claimsDelta({}, {}).length, 0);
    eq(D.claimsDelta({}, { adjudications:[claim({ id:'z' })] }).length, 1);
  });

  console.log('\n== v3.3: the indenture scope must be surfaced, not silently diffed ==');
  t('a session without the field is read as the pre-v160 A/B rule', () => {
    // Sessions written before the setting existed ran under the fixed A/B rule.
    // Defaulting to an empty list would claim every level reconciled.
    eq(D.collectorLevelsOf({}), ['A', 'B']);
    eq(D.collectorLevelsOf(null), ['A', 'B']);
    eq(D.collectorLevelsOf({ collectorLevels: 'nonsense' }), ['A', 'B'], 'and junk too:');
  });
  t('the scope label reads the way the main build words it', () => {
    eq(D.collectorScopeLabel({ collectorLevels: ['A','B'] }), 'A + B excluded');
    eq(D.collectorScopeLabel({ collectorLevels: [] }), 'All levels reconcile');
    eq(D.collectorScopeLabel({ collectorLevels: ['A'] }), 'A excluded');
  });
  t('two sessions on the same scope report no difference', () => {
    eq(D.indentureScopeDiff({ collectorLevels:['A','B'] },
                            { collectorLevels:['A','B'] }).same, true);
    eq(D.indentureScopeDiff({}, { collectorLevels:['A','B'] }).same, true,
       'an old session matches an explicit default:');
  });
  t('order does not fake a difference', () => {
    eq(D.indentureScopeDiff({ collectorLevels:['B','A'] },
                            { collectorLevels:['A','B'] }).same, true);
  });
  t('a genuine scope difference is reported and explained', () => {
    const ctx = D.indentureContext({ collectorLevels:['A','B'] }, { collectorLevels:[] });
    eq(ctx.diff.same, false);
    if (!ctx.warning) throw new Error('a scope mismatch must produce a warning');
    ['A + B excluded', 'All levels reconcile'].forEach(x => {
      if (ctx.warning.indexOf(x) < 0) throw new Error('the warning must name both scopes');
    });
    if (ctx.warning.indexOf('build') < 0)
      throw new Error('the warning must say the change may not be a build change');
  });
  t('matching scopes produce no warning', () => {
    eq(D.indentureContext({ collectorLevels:['A','B'] }, {}).warning, '');
  });
  t('the scope appears as a provenance row and a load-time warning', () => {
    if (!/line\('EBOM indenture scope'/.test(DSRC))
      throw new Error('the summary does not report the scope');
    if (!/indentureContext\(state\.A, state\.B\)/.test(DSRC))
      throw new Error('the load-time guard does not check the scope');
    // It must not be gated on a leg being present — the scope governs the EBOM
    // side, which every comparison mode has.
    const seg = DSRC.slice(DSRC.indexOf("line('EBOM indenture scope'") - 400,
                           DSRC.indexOf("line('EBOM indenture scope'"));
    if (/if \(!procCtx \|\| procCtx\.relevant\)/.test(seg))
      throw new Error('the scope row is gated behind the ABOM-leg check');
  });
  t('scope exclusion is still driven by status, not by indenture level', () => {
    // The delta tool excludes on the 'collector' STATUS, so it inherits the
    // main build's setting automatically. If it ever started reading indenture
    // letters itself, that would be a second copy of the rule to keep in sync.
    if (/indenture\s*===?\s*'[A-Z]'/.test(DSRC))
      throw new Error('the delta tool now derives the collector rule itself');
    eq(D.fscope([{ overall:'collector' }, { overall:'ok' }]).length, 1);
  });

  console.log('\n== Small helpers ==');
  t('dNorm and normPN normalise identically to the main build', () => {
    ['  p1 ', 'p1', 'P1', '', null, undefined, 0, 123].forEach(v => {
      eq(D.dNorm(v), D.normPN(v), JSON.stringify(v) + ':');
    });
    eq(D.dNorm('  abc '), 'ABC');
  });
  t('pct guards against divide-by-zero', () => {
    eq(D.pct(1, 0), '\u2014', 'zero denominator:');
    eq(D.pct(1, 4), '25.0%');
    eq(D.pct(0, 4), '0.0%');
  });
  t('the delta tool reports a version consistent with its filename', () => {
    const m = DSRC.match(/<title>([^<]*)<\/title>/);
    const fileV = DELTA.match(/v([\d_]+)\.html$/)[1].replace(/_/g, '.');
    if (m[1].indexOf(fileV) < 0)
      throw new Error('title says ' + JSON.stringify(m[1]) +
                      ' but the file is v' + fileV);
  });
});

// ── TIER 6 ─────────────────────────────────────────────────────────────────
// The delta tool's report assembly: the two-pass EBOM matcher, the KPI counters
// and the NCR disposition diff. Tier 4 covered the comparison layer; this is
// what actually fills the sheets.
suite('Tier 6 — delta tool report assembly', (t, eq) => {
  const D = sandbox({}, ['delta']).D;
  const row = (pn, nh, o) => Object.assign({ key: pn + '||' + nh, pn, nh, eq: 1 }, o);
  const sess = (rows, o) => Object.assign({ results: rows }, o);
  const changes = (a, b) => D.ebomChanges(sess(a), sess(b));
  const typesOf = rows => rows.map(r => r['Change Type'] + ':' + r['Part Number']);

  console.log('\n== The four EBOM change types ==');
  t('an unchanged BOM produces no rows at all', () => {
    const r = [row('P1','TOP'), row('P2','TOP')];
    eq(changes(r, r).length, 0);
  });
  t('a quantity change is reported with both old and new values', () => {
    const out = changes([row('P1','TOP',{eq:2})], [row('P1','TOP',{eq:5})]);
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Old Qty'], out[0]['New Qty']], ['Qty Changed','2','5']);
  });
  t('eqText wins over eq, so display text drives the comparison', () => {
    // A row carrying '2 EA' as text must not read as quantity 2.
    const out = changes([row('P1','TOP',{eq:2, eqText:'2 EA'})],
                        [row('P1','TOP',{eq:2, eqText:'3 EA'})]);
    eq([out.length, out[0]['Old Qty'], out[0]['New Qty']], [1, '2 EA', '3 EA']);
  });
  t('a part only in B is Added, a part only in A is Removed', () => {
    const out = changes([row('GONE','TOP')], [row('NEW','TOP')]);
    eq(typesOf(out), ['Removed:GONE', 'Added:NEW']);
  });
  t('the same PN under a new parent is ONE Re-parented row, not add plus remove', () => {
    const out = changes([row('P1','OLD')], [row('P1','NEW')]);
    eq(out.length, 1, 'must not double-report:');
    eq([out[0]['Change Type'], out[0]['Old Next Higher'], out[0]['New Next Higher']],
       ['Re-parented', 'OLD', 'NEW']);
  });
  t('re-parenting carries the quantity change across with it', () => {
    const out = changes([row('P1','OLD',{eq:2})], [row('P1','NEW',{eq:7})]);
    eq([out[0]['Old Qty'], out[0]['New Qty']], ['2', '7']);
  });
  t('rows are ordered Removed, Re-parented, Qty Changed, Added', () => {
    const out = changes(
      [row('AGONE','T'), row('BMOVE','OLD'), row('CQTY','T',{eq:1})],
      [row('BMOVE','NEW'), row('CQTY','T',{eq:9}), row('DNEW','T')]);
    eq(out.map(r => r['Change Type']),
       ['Removed', 'Re-parented', 'Qty Changed', 'Added']);
  });

  console.log('\n== The greedy matcher\'s edges ==');
  t('two removals and one addition of the same PN leave one Removed row', () => {
    const out = changes([row('P1','A'), row('P1','B')], [row('P1','C')]);
    eq(typesOf(out).sort(), ['Re-parented:P1', 'Removed:P1']);
  });
  t('one removal and two additions of the same PN leave one Added row', () => {
    const out = changes([row('P1','A')], [row('P1','B'), row('P1','C')]);
    eq(typesOf(out).sort(), ['Added:P1', 'Re-parented:P1']);
  });
  t('a PN whose case or padding differs still matches as re-parented', () => {
    const out = changes([row(' p1 ','OLD')], [row('P1','NEW')]);
    eq(out[0]['Change Type'], 'Re-parented', 'normPN must drive the pairing:');
  });
  t('duplicate keys keep the FIRST row, matching the main build convention', () => {
    const out = changes([row('P1','TOP',{eq:1}), row('P1','TOP',{eq:99})],
                        [row('P1','TOP',{eq:1})]);
    eq(out.length, 0, 'the second duplicate must be ignored:');
  });
  t('EBOM line numbers are joined for the sheet', () => {
    const out = changes([row('P1','T',{eq:1})],
                        [row('P1','T',{eq:2, ebomLineNos:[10,20]})]);
    eq(out[0]['EBOM Line No(s)'], '10; 20');
    const bare = changes([row('P2','T',{eq:1})], [row('P2','T',{eq:2})]);
    eq(bare[0]['EBOM Line No(s)'], '', 'absent line numbers give an empty cell:');
  });

  console.log('\n== KPI counters ==');
  const kpiRow = (o) => Object.assign({ overall:'ok', ms:'ok', as:'ok' }, o);
  t('structural rows are excluded from the KPI scope', () => {
    const k = D.computeKpis(sess([kpiRow({}), kpiRow({overall:'pt_collector'}),
      kpiRow({overall:'pt_reference'}), kpiRow({overall:'pt_bulk'}),
      kpiRow({overall:'pt_removal'}), kpiRow({overall:'collector'})],
      { mode:'ebom_mbom_abom' }));
    eq(k.scopeTotal, 1, 'only the real line item counts:');
  });
  t('direct, covered and used-on all count toward "any", but only direct counts as direct', () => {
    const k = D.computeKpis(sess([
      kpiRow({ ms:'ok' }), kpiRow({ ms:'covered' }),
      kpiRow({ ms:'missing', msUsedOn:'pn_as_usedon' }), kpiRow({ ms:'missing' })],
      { mode:'ebom_mbom' }));
    eq([k.mbomDirect, k.mbomAny, k.mbomMissing], [1, 3, 2]);
  });
  t('adjudicated statuses count as satisfied', () => {
    const k = D.computeKpis(sess([kpiRow({ms:'direct_adjudicated'}),
      kpiRow({ms:'qty_mismatch_accepted'}), kpiRow({ms:'flex_ok'}),
      kpiRow({ms:'covered_adjudicated'})], { mode:'ebom_mbom' }));
    eq([k.mbomDirect, k.mbomAny], [3, 4]);
  });
  t('ABOM-only counters are reported separately', () => {
    const k = D.computeKpis(sess([kpiRow({as:'wo_open'}), kpiRow({as:'proc_removed'}),
      kpiRow({as:'qty_mismatch'})], { mode:'ebom_abom' }));
    eq([k.abomOpen, k.abomProcRemoved, k.abomQty], [1, 1, 1]);
    eq(k.mbomDirect, undefined, 'MBOM counters must be absent in an ABOM-only session:');
  });
  t('claims are counted and their applied state reported', () => {
    eq(D.computeKpis(sess([], { mode:'ebom_mbom' })).claims, 0);
    const k = D.computeKpis(sess([], { mode:'ebom_mbom',
      adjudications:[{id:'a'},{id:'b'}], adjudicationsApplied:true }));
    eq([k.claims, k.claimsApplied], [2, 'applied']);
  });

  console.log('\n== Mode vocabulary must not drift between the two files ==');
  t('the delta tool agrees with the main build about every mode it knows', () => {
    // Same class of risk as the duplicated PROC_CODE_BASELINE: the main build
    // owns the mode vocabulary in getModeRequired's table, and the delta tool
    // re-states it as two negative tests. Add a fifth mode to the main build
    // and the delta tool would silently report both MBOM and ABOM KPIs for it.
    const start = at('const modeZones = {');
    const block = SRC.slice(start, at('};', start));
    const modes = [...block.matchAll(/'([a-z_]+)':\s*\[([^\]]*)\]/g)]
      .map(m => ({ mode: m[1], zones: m[2].split(',').map(z => z.trim().replace(/'/g, '')) }));
    if (modes.length < 4) throw new Error('only found ' + modes.length + ' modes — table moved?');
    modes.forEach(({ mode, zones }) => {
      eq(D.modeHasMbom(mode), zones.indexOf('mbom') >= 0, mode + ' MBOM:');
      eq(D.modeHasAbom(mode), zones.indexOf('abom') >= 0, mode + ' ABOM:');
    });
  });
  t('a session with no mode recorded reports both sides rather than neither', () => {
    // Fail-open. Documented, not necessarily desirable: an old session missing
    // `mode` shows a full set of zeroed MBOM KPIs as though everything failed.
    eq([D.modeHasMbom(undefined), D.modeHasAbom(undefined)], [true, true]);
  });

  console.log('\n== Pre-rename sessions and missing files ==');
  t('the CHP zone is read under both its old and new key', () => {
    // v3.1 renamed 'cp' -> 'chp'. Sessions exported before that carry the old one.
    eq(D.chpBom({ boms:{ chp:{ data:[1] } } }).data, [1], 'new key:');
    eq(D.chpBom({ boms:{ cp:{ data:[2] } } }).data, [2], 'old key:');
    eq(D.chpBom({ boms:{} }), null, 'neither:');
    eq(D.chpBom(null), null, 'no session:');
  });
  t('a new-key CHP wins over a stale old-key one', () => {
    eq(D.chpBom({ boms:{ chp:{ data:['new'] }, cp:{ data:['old'] } } }).data, ['new']);
  });
  t('a missing NCR file returns a note naming which session lacked it', () => {
    const only = D.ncrDispositionDelta({ boms:{} }, { boms:{ ncr:{ data:[] } } });
    if (!only.note || only.note.indexOf('Session A') < 0)
      throw new Error('must name Session A: ' + JSON.stringify(only.note));
    const both = D.ncrDispositionDelta({ boms:{} }, { boms:{} });
    if (both.note.indexOf('Session A or Session B') < 0)
      throw new Error('must name both: ' + JSON.stringify(both.note));
  });
  t('NCR rows without a number are skipped rather than counted', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    // `results` is mandatory throughout the delta tool — inScopeSet, fscope and
    // computeKpis all read it unguarded, so a session without it is malformed.
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('', 'D1'), mk('N1', 'D1')]),
                                      s([mk('N1', 'D1')]));
    if (out.note) throw new Error('unexpected note: ' + out.note);
    eq(out.rows.length, 0, 'the blank-numbered row must not appear as a change:');
  });
  t('a disposition status change is reported with both statuses', () => {
    const N = D.NCR_COL;
    const mk = st => { const r = []; r[N.ncrNum] = 'N1'; r[N.dispNo] = 'D1';
                       r[N.dispStatus] = st; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('OPEN')]), s([mk('CLOSED')])).rows;
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Old Disposition Status'],
        out[0]['New Disposition Status']],
       ['Disposition status changed', 'OPEN', 'CLOSED']);
  });
  t('a brand new NCR is distinguished from a new disposition on an existing one', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('N1','D1')]),
                                      s([mk('N1','D1'), mk('N1','D2'), mk('N2','D9')])).rows;
    const byType = {}; out.forEach(r => { byType[r['Change Type']] = r['NCR Number']; });
    eq(byType['New disposition on existing NCR'], 'N1');
    eq(byType['New NCR'], 'N2');
  });
  t('a disposition present in A but not B is flagged for investigation', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('N1','D1'), mk('N1','D2')]), s([mk('N1','D1')])).rows;
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Disposition No']],
       ['Dropped from B — investigate', 'D2']);
  });
});

// ── TIER 7 ─────────────────────────────────────────────────────────────────
// Detailed View markers and raw-BOM badges. These are rendering rules, so the
// tests lift the real expressions out of the build and evaluate them rather
// than restating the logic — a restatement would drift the way the v149
// explanation modal drifted from the code it described.
suite('Tier 7 — Detailed View markers and raw-BOM badges', (t, eq) => {
  const _STATUS_COVERED = new Set(['covered', 'covered_adjudicated']);
  const lift = re => { const m = SRC.match(re);
    if (!m) throw new Error('BUILD MARKER MOVED: ' + re);
    return m[0].trim().replace(/^const /, 'var '); };

  const mbomCell = new Function('r', '_STATUS_COVERED',
    'var mDirActive = r.inMbomDirectPool;' +
    lift(/const mIsParentMark\s*=[\s\S]{0,160}?;/) +
    lift(/const mDirCls\s*=[\s\S]{0,260}?;/) +
    lift(/const mDirQty\s*=[\s\S]{0,160}?;/) +
    'return { cls: mDirCls, qty: mDirQty };');
  const abomCell = new Function('r', '_STATUS_COVERED',
    'var aDirActive = r.inAbomDirectPool || (r.as === "wo_open" && r.aq !== null);' +
    lift(/const aIsParentMark\s*=[\s\S]{0,160}?;/) +
    lift(/const aDirCls\s*=[\s\S]{0,200}?;/) +
    lift(/const aDirQty\s*=[\s\S]{0,160}?;/) +
    'return { cls: aDirCls, qty: aDirQty };');
  const M = (ms, o) => mbomCell(Object.assign({ ms, mq:null, inMbomDirectPool:false }, o), _STATUS_COVERED);
  const A = (as, o) => abomCell(Object.assign({ as, aq:null, inAbomDirectPool:false }, o), _STATUS_COVERED);
  const MARK = '\u2191 parent';

  console.log('\n== The marker carries exactly ONE style ==');
  t('every MBOM row showing the marker uses the same class', () => {
    const styles = new Set();
    ['covered', 'covered_adjudicated', 'collector'].forEach(ms => {
      [false, true].forEach(nh => {
        const c = M(ms, { nhMismatchMbom: nh });
        if (c.qty === MARK) styles.add(c.cls);
      });
    });
    eq([...styles], ['td-parent-mark'], 'distinct MBOM marker styles:');
  });
  t('every ABOM row showing the marker uses the same class', () => {
    const styles = new Set();
    ['covered', 'covered_adjudicated', 'collector'].forEach(as => {
      const c = A(as, { nhMismatchAbom: true });
      if (c.qty === MARK) styles.add(c.cls);
    });
    eq([...styles], ['td-parent-mark'], 'distinct ABOM marker styles:');
  });
  t('an NH mismatch no longer overrides the marker style', () => {
    // The v149 defect: nhMismatchMbom was tested first, so a covered row with
    // an NH mismatch rendered hl-parentage — a grey block, a third look.
    eq(M('covered', { nhMismatchMbom: true }).cls, 'td-parent-mark');
    eq(M('collector', { nhMismatchMbom: true }).cls, 'td-parent-mark');
  });
  t('the NH-mismatch highlight still applies to rows that show a real value', () => {
    // The flag must keep working where it is not competing with the marker.
    eq(M('ok', { nhMismatchMbom: true }).cls, 'hl-parentage');
    eq(M('missing', { nhMismatchMbom: true }).cls, 'hl-missing', 'missing still wins:');
  });
  t('a row with a real direct quantity shows the number, never the marker', () => {
    const c = M('covered', { mq: 4, inMbomDirectPool: true });
    eq([c.qty, c.cls], [4, ''], 'a real qty must not be styled as a marker:');
    eq(A('covered', { aq: 7, inAbomDirectPool: true }).qty, 7);
  });
  t('rows with no coverage show an em dash, not the marker', () => {
    ['missing', 'qty_mismatch', 'ok'].forEach(s => eq(M(s).qty, '\u2014', s + ':'));
  });
  t('the retired two-style classes are gone from the stylesheet and the code', () => {
    const live = SRC.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
    ['td-covered', 'td-collector'].forEach(c => {
      if (live.includes(c)) throw new Error(c + ' still referenced outside comments');
    });
  });

  console.log('\n== The explanation modal must match the code ==');
  t('the modal no longer claims two styles', () => {
    if (/carries exactly two styles/.test(SRC))
      throw new Error('the erroneous v149 explanation is still shipping');
  });
  t('the modal points the reader at the badge rather than a colour', () => {
    const p = SRC.match(/<p><strong>The "\u2191 parent" marker<\/strong>[\s\S]{0,900}?<\/p>/);
    if (!p) throw new Error('the marker explanation paragraph is gone');
    ['one style', 'PARENT IND. EMBODIED', 'COLLECTOR (A/B)'].forEach(s => {
      if (p[0].indexOf(s) < 0) throw new Error('explanation no longer mentions ' + JSON.stringify(s));
    });
    if (/green italic/.test(p[0])) throw new Error('still describes a green style');
  });

  console.log('\n== Raw-BOM view badges ==');
  const badgeFor = new Function('overall', '_STATUS_COVERED', `
    var result = { overall: overall };
    var issueKeys = new Set(['X']);
    var hasIssue = !(overall === 'pt_collector' || overall === 'pt_reference' ||
                     overall === 'pt_bulk' || overall === 'pt_removal') &&
                   overall !== 'ok' && overall !== 'covered' && overall !== 'collector' &&
                   overall !== 'flex_ok' && overall !== 'pn_as_usedon';
    ` + lift(/const isPtExclResult\s*=[\s\S]{0,260}?;/) + `
    var coveredLike = result && (_STATUS_COVERED.has(result.overall) ||
                       result.overall === 'collector' || result.overall === 'pn_as_usedon');
    if (isPtExclResult) return 'PT-BADGE';
    if (coveredLike) return 'COVERED-BADGE';
    if (!hasIssue) return 'OK';
    return 'CATCH-ALL';`);
  t('removal-scope rows no longer render a green tick', () => {
    // v154 and earlier: pt_removal was absent from isPtExclResult, so it fell
    // to the "no issue" branch and showed ✓ OK — a pass mark on a line that is
    // out of scope rather than one that passed.
    eq(badgeFor('pt_removal', _STATUS_COVERED), 'PT-BADGE');
  });
  t('the other part-type exclusions are unchanged', () => {
    ['pt_collector', 'pt_reference', 'pt_bulk'].forEach(s =>
      eq(badgeFor(s, _STATUS_COVERED), 'PT-BADGE', s + ':'));
  });
  t('genuinely clean rows still show OK', () => {
    ['ok', 'flex_ok'].forEach(s => eq(badgeFor(s, _STATUS_COVERED), 'OK', s + ':'));
  });
  t('every status reaching the catch-all is an unresolved outcome', () => {
    const caught = ['missing', 'qty_mismatch', 'flex_missing', 'wo_open', 'proc_removed']
      .filter(s => badgeFor(s, _STATUS_COVERED) === 'CATCH-ALL');
    eq(caught.length, 5, 'all five still route to the catch-all:');
  });
  t('the catch-all badge is neutral, not a warning', () => {
    // Two of the five statuses it covers are BY DESIGN — SUB/AR absence and
    // proc-code removal — so a ⚠ treatment flags correct rows as defects.
    const live = SRC.replace(/^\s*\/\/.*$/gm, '');
    if (live.includes('CHECK EBOM'))
      throw new Error('the old CHECK EBOM badge is still shipping');
    // Anchor on the final `} else {` of the chain — matching the first
    // statusBadge assignment would test the ✓ OK branch instead.
    // v158 — the assignment became a template literal when the tooltip went in;
    // accept either quoting so the test tracks the requirement, not the syntax.
    const m = SRC.match(/\}\s*else\s*\{\s*(?:\/\/[^\n]*\n\s*)*statusBadge = [`']<span class="badge ([\w-]+)"[^>]*>([^<$]+)<\/span>[`'];/);
    if (!m) throw new Error('the catch-all badge assignment moved');
    eq([m[1], m[2]], ['badge-neutral', 'SEE SUMMARY']);
    if (/\u26a0/.test(m[2])) throw new Error('the warning glyph is back');
  });
  t('badge-neutral is defined in the stylesheet', () => {
    if (!/\.badge-neutral\s*\{/.test(STYLE_BLOCKS.map(b => b.css).join('\n')))
      throw new Error('badge-neutral has no rule');
  });
});

// ── TIER 8 ─────────────────────────────────────────────────────────────────
// CI Traceability Report columns. Removing a column from a sheet means editing
// the header AND every row builder; miss one and XLSX writes the rows anyway,
// silently shifting every value after it into the wrong column. Nothing in the
// export path validates that, so the harness does.
suite('Tier 8 — CI Traceability Report columns', (t, eq) => {
  const FN = (() => {
    const a = at('function exportCIReport()');
    return SRC.slice(a, at('// ── ACN KPI HELPER', a) > a ? at('// ── ACN KPI HELPER', a) : a + 130000);
  })();
  // Split an array literal into its top-level elements, respecting strings,
  // parentheses and nested brackets. A naive split on ',' breaks any header
  // containing a comma — 'Part Qty (ABOM, per WO)' became two columns — which
  // silently miscounts and produces confusing failures.
  function splitTop(body) {
    // v158 — strip comments FIRST. A `// A  CI ID` note is harmless, but
    // `// If the discrepant part is this CI's own part number` contains an
    // apostrophe that opens a phantom string and swallows the rest of the
    // array, and any comma in a comment splits a column in two. Both produce a
    // wrong count that looks like a real header/row mismatch.
    body = body.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/[^\n]*/g, '$1');
    const out = []; let d = 0, q = null, cur = '';
    for (let i = 0; i < body.length; i++) {
      const c = body[i];
      if (q) { cur += c; if (c === '\\') { cur += body[++i]; continue; } if (c === q) q = null; continue; }
      if (c === '"' || c === "'" || c === '`') { q = c; cur += c; continue; }
      if (c === '(' || c === '[' || c === '{') d++;
      else if (c === ')' || c === ']' || c === '}') d--;
      if (c === ',' && d === 0) { out.push(cur.trim()); cur = ''; continue; }
      cur += c;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  }
  function items(body) { return splitTop(body).length; }
  function bracket(src, from) {
    const a = src.indexOf('[', from);
    if (a < 0) throw new Error('no array literal after offset ' + from);
    let d = 0, i = a;
    for (;; i++) {
      if (i >= src.length) throw new Error('unbalanced array literal');
      if (src[i] === '[') d++; else if (src[i] === ']') { d--; if (!d) break; }
    }
    return src.slice(a + 1, i);
  }
  function headerList(name) {
    const m = FN.match(new RegExp('const ' + name + '\\s*=\\s*\\['));
    if (!m) throw new Error('BUILD MARKER MOVED: ' + name);
    return splitTop(bracket(FN, m.index))
      .map(x => x.replace(/^\s*['"]|['"]\s*$/g, ''));
  }

  console.log('\n== The parser this suite depends on ==');
  t('header parsing survives commas inside a column name', () => {
    // 'Part Qty (ABOM, per WO)' is a real header. A naive comma split turned it
    // into two columns, which would miscount every sheet that still uses it.
    eq(splitTop("'A', 'Part Qty (ABOM, per WO)', 'B'").length, 3);
    eq(splitTop("'CI as \"Used On\" Number', 'B'").length, 2, 'embedded quotes:');
    eq(splitTop("'A', ['x','y'], 'B'").length, 3, 'nested arrays:');
    eq(splitTop("'A', f(1, 2), 'B'").length, 3, 'calls:');
    eq(splitTop("'A', 'B',").length, 2, 'trailing comma:');
  });
  t('a header containing a comma is still counted as one column', () => {
    // Sheet 6 carried 'Part Qty (ABOM, per WO)' until v155 and other sheets
    // still do, so this is live behaviour, not a hypothetical.
    const withComma = headerList('embHigherHdr').filter(c => c.indexOf(',') >= 0);
    withComma.forEach(c => { if (!/^[^,]*\(.*,.*\)[^,]*$/.test(c))
      throw new Error('suspicious split: ' + JSON.stringify(c)); });
  });

  console.log('\n== No sheet may write more values than it has headers ==');
  t('every header width matches every one of its row builders', () => {
    const hdrs = [...FN.matchAll(/const (\w+Hdr)\s*=\s*\[/g)];
    if (hdrs.length < 10) throw new Error('only found ' + hdrs.length + ' sheets — report restructured?');
    const bad = [];
    hdrs.forEach(m => {
      const want = items(bracket(FN, m.index));
      const rowsVar = m[1].replace(/Hdr$/, 'Rows');
      [...FN.matchAll(new RegExp(rowsVar + '\\.push\\(', 'g'))].forEach(p => {
        const got = items(bracket(FN, p.index + p[0].length - 1));
        if (got !== want) bad.push(m[1] + ': header ' + want + ' vs row ' + got);
      });
    });
    if (bad.length) throw new Error('COLUMN COUNT MISMATCH — data will be shifted:\n        ' +
                                    bad.join('\n        '));
  });

  console.log('\n== #13 / #14: the Part Qty Text column is gone ==');
  t('CI EBOM Drawings + Change Ped no longer carries Part Qty Text', () => {
    const h = headerList('ciChpHdr');
    if (h.indexOf('Part Qty Text') >= 0) throw new Error('still present');
    eq(h.slice(0, 3), ['CI ID', 'Part Number', 'Next Higher Part Number'], 'columns A–C:');
  });
  t('CI Next-Higher Change Pedigree no longer carries Part Qty Text', () => {
    const h = headerList('nhChpHdr');
    if (h.indexOf('Part Qty Text') >= 0) throw new Error('still present');
    eq(h.slice(0, 3), ['CI ID', 'Next Higher Part Number', 'Drawing Number'], 'columns A–C:');
  });
  t('neither sheet still reads partQtyText into a row', () => {
    ['ciChpRows', 'nhChpRows'].forEach(v => {
      [...FN.matchAll(new RegExp(v + '\\.push\\(', 'g'))].forEach(p => {
        if (bracket(FN, p.index + p[0].length - 1).includes('partQtyText'))
          throw new Error(v + ' still pushes partQtyText');
      });
    });
  });

  console.log('\n== #15: column B says what it actually holds ==');
  t('the Next-Higher sheet labels column B as Next Higher Part Number', () => {
    // It has always pushed t.nh; the label said 'Part Number'.
    eq(headerList('nhChpHdr')[1], 'Next Higher Part Number');
    const p = FN.match(/nhChpRows\.push\(\[\s*t\.ciId\|\|'—',\s*t\.nh\|\|'—'/);
    if (!p) throw new Error('column B no longer pushes t.nh — the label may now be wrong again');
  });

  console.log('\n== #16 / #17 / #18: work-order columns named for what they are ==');
  t('CIs Embodied as Used On Parts — columns C to G', () => {
    eq(headerList('embUsedOnHdr').slice(2, 7),
       ['CI as "Used On" Number', 'Work Order Part Number', 'Work Order Part Qty',
        'Work Order Number', 'Work Order Status']);
  });
  t('CIs Embodied via Higher Parts — columns D, F, H, I', () => {
    const h = headerList('embHigherHdr');
    eq([h[3], h[5], h[7], h[8]],
       ['Work Order Part Number', 'Work Order Part Qty',
        'Work Order Number', 'Work Order Status']);
  });
  t('CIs Embodied via Higher Parts — C, E, G deliberately unchanged', () => {
    // These are EBOM-side or used-on values, not work-order values.
    const h = headerList('embHigherHdr');
    eq([h[2], h[4], h[6]],
       ['CI EBOM Part Indenture', 'Part Indenture (EBOM)', 'Used On Number (ABOM)']);
  });
  t('CIs Embodied as WO Parts — columns C to G', () => {
    eq(headerList('embWoHdr').slice(2, 7),
       ['Work Order Part Number', '"Used On" Number', 'Work Order Part Qty',
        'Work Order Number', 'Work Order Status']);
  });
  t('no renamed sheet still carries an (ABOM) suffix on a work-order column', () => {
    ['embUsedOnHdr', 'embHigherHdr', 'embWoHdr', 'abomClaimsHdr'].forEach(n => {
      const stale = headerList(n).filter(c => /^(Part Number|Part Qty|Work Order Number|Work Order Status) \(ABOM/.test(c));
      if (stale.length) throw new Error(n + ' still has: ' + stale.join(', '));
    });
  });

  console.log('\n== NCR disposition sheets: the reader-facing column order ==');
  t('CI Discrep Part w Used On Match leads with the reader-facing columns', () => {
    eq(headerList('ncrDispHdr').slice(0, 12),
       ['CI ID', 'CI Part Number', 'Originating Work Order', 'Discrepant Part Qty',
        'NCR Number', 'NCR Status', 'Defect Code Description', 'Disposition Number',
        'Disp. Status', 'Disp. Type', 'Disp. Code',
        'RFV Linked to NCR Disp# (RFV File)']);
  });
  t('CIs as Used On NCRs leads with the same columns plus the discrepant PN', () => {
    eq(headerList('cisUsedOnHdr').slice(0, 13),
       ['CI ID', 'CI Part Number', 'Originating Work Order', 'Discrepant Part Number',
        'Discrepant Part Qty', 'NCR Number', 'NCR Status', 'Defect Code Description',
        'Disposition Number', 'Disp. Status', 'Disp. Type', 'Disp. Code',
        'RFV Linked to NCR Disp# (RFV File)']);
  });
  t('the shortened disposition names replaced the NCR-prefixed ones', () => {
    // Every column on these two sheets is an NCR column, so the prefix carried
    // no information. The prefix survives where it still distinguishes —
    // 'NCR Cause Code' sits beside a defect code, for instance.
    ['ncrDispHdr', 'cisUsedOnHdr'].forEach(n => {
      const stale = headerList(n).filter(c =>
        /^NCR Disp(#| Status| Type| Code)$/.test(c) || c === 'NCR Defect Code Desc');
      if (stale.length) throw new Error(n + ' still has: ' + stale.join(', '));
    });
  });
  t('no other sheet was renamed by accident', () => {
    // Seven header arrays carried disposition columns; only two were in scope.
    // These five keep whatever they had — note noAbomNcrHdr spells them out in
    // full ('NCR Disposition #'), which is a third convention nobody asked to
    // change. Worth knowing it exists; not worth changing unasked.
    // FOUR conventions are in use across the report — worth knowing, not worth
    // changing unasked: 'NCR Disp#' (detail, csa, claims), 'NCR Disposition #'
    // (noAbomNcr), 'Disposition #' (adj), and the two sheets v158 moved to
    // 'Disposition Number'. Pinned so a future rename is a decision, not a drift.
    const expect = { detailHdr: 'NCR Disp#', csaHdr: 'NCR Disp#',
                     noAbomNcrHdr: 'NCR Disposition #',
                     adjHdr: 'Disposition #', claimsHdr: 'NCR Disp#' };
    Object.keys(expect).forEach(n => {
      if (headerList(n).indexOf(expect[n]) < 0)
        throw new Error(n + ' lost its ' + JSON.stringify(expect[n]) +
                        ' column — that sheet was not in scope');
    });
  });

  console.log('\n== Paired sheets must label identical data identically ==');
  t('CI ABOM Claims Processed matches CIs Embodied as WO Parts, columns A to G', () => {
    // These are the SME-adjudicated and auto-detected halves of one idea. The
    // As-Built Records Guide states the pairing outright, so renaming one and
    // not the other would leave the same workbook disagreeing with itself.
    eq(headerList('abomClaimsHdr').slice(0, 7), headerList('embWoHdr').slice(0, 7));
  });
  t('the As-Built Records Guide still names both sheets it aligns to', () => {
    // The guide's alignment notes reference report sheets by NAME and describe
    // their semantics, not their column letters — so v155's column edits left
    // them accurate. This test fails if a sheet is ever renamed, which WOULD
    // break them.
    const guide = SRC.slice(at('function exportCIAsBuiltGuide()'),
                            at('XLSX.utils.book_append_sheet(wb, ws, \'CI As-Built Records Guide\')'));
    ['CIs Embodied as WO Parts', 'CIs Embodied as Used On Parts',
     'CIs Embodied via Higher Parts', 'CI ABOM Claims Processed',
     'NCR CI Claims Processed'].forEach(name => {
      if (guide.indexOf(name) < 0)
        throw new Error('the guide no longer references the sheet ' + JSON.stringify(name));
      if (SRC.indexOf("book_append_sheet(wb, ") < 0 || SRC.indexOf("'" + name + "'") < 0)
        throw new Error('the guide references a sheet that no longer exists: ' + name);
    });
  });
});

// ── TIER 9 ─────────────────────────────────────────────────────────────────
// The MBOM column trio appears on FOUR surfaces — the on-screen Detailed View,
// the context export, the CSV export and the XLSX export — each with its own
// header list and its own row builder. Move a header without its row builder
// and every column after it shifts silently. These tests pin header and data
// order together, on every surface.
suite('Tier 9 — MBOM column order across every surface', (t, eq) => {
  const HDR_NEW = /'MBOM Traceability'\s*,\s*'MBOM Reconciliation Notes'\s*,\s*'MBOM Job Number'/g;
  const HDR_OLD = /'MBOM Traceability'\s*,\s*'MBOM Job Number'/g;
  const ROW_NEW = /mbomTraceabilityText\(r\),\s*mbomNotesText\(r\),\s*\(_mJobs/g;
  const ROW_OLD = /mbomTraceabilityText\(r\),\s*\(_mJobs/g;

  console.log('\n== #3: Job Number sits right of Reconciliation Notes ==');
  t('no surface still carries the old order', () => {
    eq((SRC.match(HDR_OLD) || []).length, 0, 'headers in old order:');
    eq((SRC.match(ROW_OLD) || []).length, 0, 'row builders in old order:');
  });
  t('all four header lists and the banner grouping use the new order', () => {
    // 4 header pushes (screen, context, CSV, XLSX) + the mbomCols silo list.
    eq((SRC.match(HDR_NEW) || []).length, 5);
  });
  t('all three export row builders use the new order', () => {
    // The fourth surface is the on-screen table, which emits <td> directly.
    eq((SRC.match(ROW_NEW) || []).length, 3);
  });
  t('every surface with a Job Number header also builds a Job Number cell', () => {
    // The failure this guards: a header list moved, its row builder forgotten.
    // Count ONLY pushes that carry the Job Number — the HTML report pushes the
    // Traceability/Notes PAIR and has never had a Job Number column, so it is
    // correctly excluded rather than counted and subtracted.
    const withJob = (SRC.match(/(?:hdr|cols)\.push\('MBOM Traceability'[^;]*'MBOM Job Number'/g) || []).length;
    const rows    = (SRC.match(ROW_NEW) || []).length;
    eq(withJob, 4, 'header lists carrying Job Number (screen + 3 exports):');
    eq(withJob - rows, 1, 'the unmatched one must be the on-screen table:');
  });
  t('the HTML report still carries the pair and no Job Number column', () => {
    const m = SRC.match(/thdr\.push\('MBOM Traceability'[^;]*;/);
    if (!m) throw new Error('the HTML report header moved');
    if (m[0].indexOf('MBOM Job Number') >= 0)
      throw new Error('the HTML report gained a Job Number column without a row builder');
    if (m[0].indexOf('MBOM Reconciliation Notes') < 0)
      throw new Error('the HTML report lost Reconciliation Notes');
  });
  t('the on-screen cells are emitted in the same order as the header', () => {
    const td = SRC.match(/html \+= `<td class="td-gutter-l">\$\{buildMbomTraceability\(r\)\}<\/td>[\s\S]{0,260}?`;/);
    if (!td) throw new Error('the MBOM cell block moved');
    const order = ['buildMbomTraceability', 'buildMbomNotes', 'mJobHtml']
      .map(k => td[0].indexOf(k));
    if (order.some(i => i < 0)) throw new Error('a cell is missing: ' + td[0]);
    eq(order.slice().sort((a, b) => a - b), order,
       'screen order must be Traceability, Notes, Job:');
  });
  t('the gutter still falls on the first MBOM column', () => {
    // The left border marks where the MBOM silo begins. Traceability stayed
    // first, so it must still be the gutter column.
    const m = SRC.match(/const gutterCols = \[([\s\S]{0,600}?)\]/);
    if (!m) throw new Error('gutterCols moved');
    if (m[1].indexOf("'MBOM Traceability'") < 0)
      throw new Error('MBOM Traceability is no longer the gutter column');
    if (m[1].indexOf("'MBOM Job Number'") >= 0)
      throw new Error('the gutter moved onto the Job Number column');
  });

  console.log('\n== The prose describing the order ==');
  t('no comment or modal still says Job Number sits between the pair', () => {
    if (/Traceability\s*→\s*HERE\s*→\s*Reconciliation Notes/.test(SRC))
      throw new Error('the v149 design note still describes the old position');
    const modal = SRC.match(/<strong>MBOM Job Number<\/strong>[\s\S]{0,400}?\./);
    if (!modal) throw new Error('the Job Number modal paragraph is gone');
    if (modal[0].indexOf('right of MBOM Reconciliation Notes') < 0)
      throw new Error('the modal does not state the new position');
  });
});

// ── TIER 10 ────────────────────────────────────────────────────────────────
// The badge guide against the badge maps. A guide that drifts from the code is
// worse than no guide: it teaches the reader a vocabulary the tool no longer
// speaks. This suite derives the expected entries FROM the maps, so adding a
// badge without documenting it fails the build.
suite('Tier 10 — badge guide completeness', (t, eq) => {
  const GUIDE = (() => {
    const a = at('function showBadgeGuide()');
    return SRC.slice(a, at('_setReportHtml(html)', a));
  })();
  // Every [class, label] pair in the three status→badge maps.
  function mapLabels(fn) {
    const a = at('function ' + fn + '(');
    const blk = SRC.slice(a, SRC.indexOf('\n}', a));
    return [...blk.matchAll(/\[\s*'([\w\- ]+)'\s*,\s*'([^']+)'\s*\]/g)].map(m => m[2]);
  }
  const ALL = [...new Set([].concat(mapLabels('badgeBom'), mapLabels('badgeAbom'),
                                    mapLabels('badgeOverall')))];
  // Guide entries, glyphs stripped — the guide writes some labels without them.
  const bare = x => x.replace(/^[^A-Za-z0-9]+/, '').trim();
  const documented = new Set([...GUIDE.matchAll(/row\('([^']+)'/g)].map(m => bare(m[1])));

  console.log('\n== Every badge the maps can emit is documented ==');
  t('the three badge maps are all reachable', () => {
    eq(mapLabels('badgeBom').length > 15, true, 'badgeBom entries:');
    eq(ALL.length > 15, true, 'distinct labels across all three maps:');
  });
  t('no status-map badge is missing from the guide', () => {
    const missing = ALL.filter(l => !documented.has(bare(l)));
    if (missing.length)
      throw new Error('undocumented badge(s): ' + missing.join(', '));
  });

  console.log('\n== The guide shows the same badge the code renders ==');
  t('every guide entry uses the class the code actually emits', () => {
    // v157 — #3/#4/#5. v156 moved the used-on badges to --success-2 but left the
    // guide on badge-ok, so three entries showed the wrong green. The old test
    // compared LABELS with glyphs stripped, so a wrong class — or a wrong glyph —
    // passed silently. This compares class and exact label.
    const code = {};
    ['badgeBom', 'badgeAbom', 'badgeOverall'].forEach(fn => {
      const a = at('function ' + fn + '(');
      [...SRC.slice(a, SRC.indexOf('\n}', a)).matchAll(/\[\s*'([\w\- ]+)'\s*,\s*'([^']+)'\s*\]/g)]
        .forEach(m => { code[m[2]] = m[1]; });
    });
    [...SRC.matchAll(/dge\('(badge-[\w\-]+)',\s*'([^']+)'/g)].forEach(m => { code[m[2]] = m[1]; });
    const bad = [];
    [...GUIDE.matchAll(/row\('([^']+)',\s*'([\w\- ]+)'/g)].forEach(m => {
      const [, lbl, cls] = m;
      if (code[lbl] && code[lbl] !== cls)
        bad.push(lbl + ': guide says ' + cls + ', code emits ' + code[lbl]);
    });
    if (bad.length) throw new Error('guide/code class drift:\n        ' + bad.join('\n        '));
  });
  t('every badge the code emits appears in the guide with its exact label', () => {
    // Glyph-insensitive matching is what let the guide drift. Exact only.
    const labels = new Set();
    ['badgeBom', 'badgeAbom', 'badgeOverall'].forEach(fn => {
      const a = at('function ' + fn + '(');
      [...SRC.slice(a, SRC.indexOf('\n}', a)).matchAll(/\[\s*'[\w\- ]+'\s*,\s*'([^']+)'\s*\]/g)]
        .forEach(m => labels.add(m[1]));
    });
    const documented = new Set([...GUIDE.matchAll(/row\('([^']+)'/g)].map(m => m[1]));
    const missing = [...labels].filter(l => !documented.has(l));
    if (missing.length)
      throw new Error('label(s) not documented verbatim: ' + missing.join(' | '));
  });
  t('green badges carry no glyph; attention states keep theirs', () => {
    // v157 — #6. Green already says "fine"; a tick adds nothing. Glyphs are
    // reserved for states that need a second look.
    const GREEN = ['badge-ok', 'badge-usedon', 'badge-covered'];
    const bad = [];
    [...SRC.matchAll(/\[\s*'([\w\- ]+)'\s*,\s*'([^']+)'\s*\]/g)].forEach(m => {
      if (GREEN.indexOf(m[1]) >= 0 && /^[^A-Z0-9]/.test(m[2])) bad.push(m[1] + ' -> ' + m[2]);
    });
    if (bad.length) throw new Error('green badge(s) still glyphed: ' + bad.join(', '));
    // And the attention states must NOT have been stripped along with them.
    ['⚠ QTY MISMATCH', '✗ MISSING', '⊘ REMOVAL ITEM'].forEach(l => {
      if (SRC.indexOf("'" + l + "'") < 0)
        throw new Error('an attention badge lost its glyph: ' + l);
    });
  });

  console.log('\n== #6/#7/#8: the views that had no entries at all ==');
  t('the guide covers the whole Detailed View, not just the summary', () => {
    // badgeBom / badgeAbom are used ONLY by renderFullBom, so their vocabulary
    // never reached a guide scoped to the Comparison Summary. That is why
    // CHECK EBOM and NO MATCH had no explanation anywhere.
    if (!/Detailed View — Badge Guide/.test(SRC))
      throw new Error('the guide is still titled for the Comparison Summary only');
    ['EBOM / MBOM / ABOM Full View', 'Change Pedigree View'].forEach(s => {
      if (GUIDE.indexOf(s) < 0) throw new Error('no section for ' + s);
    });
  });
  t('the raw BOM badges are documented', () => {
    ['SEE SUMMARY', 'OK', 'ADJ DIRECT', 'REMOVAL ITEM'].forEach(l => {
      if (!documented.has(bare(l))) throw new Error(l + ' is not documented');
    });
  });
  t('every CHP release state is documented', () => {
    // Sourced from chpReleaseState, so a new state fails this test.
    const chp = sandbox({}, ['chp']).C;
    const trace = (d, e) => ({ dcn: new Map(d || []), ecn: new Map(e || []), ecr: new Map() });
    const states = [
      chp.chpReleaseState(null).label,
      chp.chpReleaseState(trace([], [['E1', '']])).label,
      chp.chpReleaseState(trace([['D1', '2024-03-15']])).label.split(' ')[0],
      chp.chpReleaseState(trace([['D1', 'Unknown']])).label,
    ];
    // A documented entry may be a MORE informative form of the emitted label —
    // the badge renders 'RELEASED MARCH 15, 2024' and the guide writes
    // 'RELEASED ⟨date⟩'. Prefix matching accepts that; it still fails if a
    // state is absent entirely.
    const docs = [...documented];
    states.concat(['NO MATCH']).forEach(l => {
      const b = bare(l);
      if (!docs.some(d => d === b || d.indexOf(b + ' ') === 0))
        throw new Error(l + ' is not documented');
    });
  });
  t('NO MATCH and NO HISTORY are distinguished, not conflated', () => {
    // v158 — the text moved into BADGE_HELP, which now feeds both the guide and
    // the hover tooltip. The requirement is unchanged: the two must be told
    // apart wherever a reader meets them.
    const help = SRC.slice(at('const BADGE_HELP = {'), at('function _badgeHelp'));
    const m = help.match(/'✗ NO MATCH':\s*'([^']*)'/);
    if (!m) throw new Error('✗ NO MATCH has no BADGE_HELP entry');
    if (m[1].indexOf('NO HISTORY') < 0)
      throw new Error('the NO MATCH explanation must contrast itself with NO HISTORY');
    if (!/'NO HISTORY':\s*'[^']+'/.test(help))
      throw new Error('NO HISTORY has no explanation of its own');
  });

  console.log('\n== One source for the guide and the tooltips ==');
  t('every badge the code renders carries a hover explanation', () => {
    // v158 — #7. The tooltip and the guide read the same BADGE_HELP strings, so
    // a badge cannot be explained in one place and silent in the other.
    const help = SRC.slice(at('const BADGE_HELP = {'), at('function _badgeHelp'));
    const keys = new Set([...help.matchAll(/'((?:[^'\\]|\\.)+)':\s*'/g)].map(m => m[1]));
    const missing = ALL.filter(l => !keys.has(l.replace(/'/g, "\\'")));
    if (missing.length)
      throw new Error('badge(s) with no hover explanation: ' + missing.join(' | '));
  });
  t('every badge span with a documented label carries a tooltip', () => {
    // v158 — this test used to name four helpers I had found by hand, so it
    // passed while tracBadge — the helper the Traceability and Reconciliation
    // Notes columns actually use — rendered every badge with no tooltip at all.
    // The rule is now DERIVED: scan every badge span in the build, and if its
    // label is one BADGE_HELP explains, it must carry a title. A hand-written
    // list of call sites can only ever be as complete as the person writing it.
    const help = SRC.slice(at('const BADGE_HELP = {'), at('function _badgeHelp'));
    const known = new Set([...help.matchAll(/'((?:[^'\\]|\\.)+)':\s*'/g)]
      .map(m => m[1].replace(/\\'/g, "'")));
    // The badge guide renders a SAMPLE of each badge with its description in the
    // next cell. A tooltip repeating that text would be noise, so the guide's own
    // preview is exempt — by position, not by a blanket rule.
    const guideFrom = at('function showBadgeGuide()'), guideTo = at('_setReportHtml(html)', guideFrom);
    const bad = [];
    [...SRC.matchAll(/<span class="badge[^"]*"([^>]{0,180}?)>([^<]{0,60})<\/span>/g)].forEach(m => {
      const attrs = m[1], label = m[2].trim();
      if (m.index >= guideFrom && m.index < guideTo) return;
      if (attrs.indexOf('title=') >= 0) return;
      // Dynamic labels resolve at runtime; the helper is what must be present.
      if (label.indexOf('${') >= 0) {
        if (attrs.indexOf('_badgeHelp') < 0)
          bad.push('dynamic label at offset ' + m.index + ' has no _badgeHelp');
        return;
      }
      if (known.has(label))
        bad.push(JSON.stringify(label) + ' is documented but renders with no tooltip');
    });
    if (bad.length) throw new Error(bad.length + ' untooltipped badge(s):\n        ' + bad.join('\n        '));
  });
  t('every helper that builds a badge span consults BADGE_HELP', () => {
    // Catches a NEW helper being added without tooltips, before it ships a label.
    const helpers = [...SRC.matchAll(/function (\w+)\s*\(([^)]*)\)\s*\{/g)]
      .filter(m => /\blabel\b|\blbl\b/.test(m[2]));
    const bad = helpers.filter(m => {
      const body = SRC.slice(m.index, SRC.indexOf('\n}', m.index));
      return /<span class="badge/.test(body) && body.indexOf('_badgeHelp(') < 0;
    }).map(m => m[1]);
    if (bad.length) throw new Error('badge helper(s) with no tooltip: ' + bad.join(', '));
  });
  t('the trace badge keeps its row-specific detail below the explanation', () => {
    // Those badges already carried adjudication metadata in their title. The
    // explanation is prepended, not substituted for it.
    const a = at('function adjTracBadge');
    const body = SRC.slice(a, SRC.indexOf('\n}', a));
    if (!/lines\.unshift\(_help/.test(body))
      throw new Error('the explanation must be prepended to the existing detail');
    if (body.indexOf("lines.join('\\n')") < 0)
      throw new Error('the multi-line title was lost');
  });
  t('the guide no longer carries its own copy of the text', () => {
    const rows = [...GUIDE.matchAll(/row\('(?:[^'\\]|\\.)*',\s*'[\w\- ]+',/g)];
    if (rows.length)
      throw new Error(rows.length + ' guide row(s) still pass their own description');
    if (GUIDE.indexOf('BADGE_HELP[badge]') < 0)
      throw new Error('the guide does not read BADGE_HELP');
  });

  console.log('\n== The guide describes only badges that exist ==');
  t('no guide entry names a label absent from the build', () => {
    const outside = SRC.slice(0, at('function showBadgeGuide()')) +
                    SRC.slice(at('_setReportHtml(html)', at('function showBadgeGuide()')));
    const stale = [...documented].filter(l => l && l !== 'RELEASED ⟨date⟩' &&
                                               l !== 'UNKNOWN' && outside.indexOf(l) < 0);
    if (stale.length) throw new Error('guide documents nonexistent badge(s): ' + stale.join(', '));
  });
  t('the unknown-status fallback is documented', () => {
    // badgeOverall renders '? ' + status for any label it does not know.
    if (!/'\? ' \+ String\(status/.test(SRC))
      throw new Error('the fallback changed shape');
    if (!documented.has('UNKNOWN'))
      throw new Error('the ? UNKNOWN fallback is not documented');
  });
});

// ── TIER 11 ────────────────────────────────────────────────────────────────
// Chart legibility. Every other suite reads the build; this one RUNS it. While
// making the v155 fix I introduced a ReferenceError into drawNcrCauseCodeChart
// — a string replacement landed in the wrong function — and all 228 existing
// tests stayed green, because nothing here had ever executed a renderer. These
// tests drive both charts through a recording 2D context.
suite('Tier 11 — chart rendering and label crispness', (t, eq) => {
  const vm = require('vm');
  function chartCtx(rectW, rectH, dpr) {
    const drawn = [];
    const c2d = { font:'', fillStyle:'', strokeStyle:'', lineWidth:1,
      textAlign:'', textBaseline:'', globalAlpha:1,
      clearRect(){}, fillRect(){}, strokeRect(){}, beginPath(){}, closePath(){},
      moveTo(){}, lineTo(){}, arc(){}, stroke(){}, fill(){}, save(){}, restore(){},
      scale(){}, setTransform(){}, translate(){}, measureText(){ return { width: 40 }; },
      fillText(txt, x, y){ drawn.push({ txt:String(txt), x, y }); } };
    const canvas = { width:0, height:0, style:{},
      getAttribute: k => (k === 'width' ? '960' : '220'),
      getBoundingClientRect: () => ({ width: rectW, height: rectH }),
      getContext: () => c2d };
    const ctx = sandbox({
      window: { devicePixelRatio: dpr },
      document: { getElementById: () => canvas, querySelectorAll: () => [] },
      state: { boms:{ abom:{ data:ABOM } }, results:[], woRollup: null },
      COL: { abom: { woNo:0, woStatus:1 } },
      getRfvCoveredWoSet: () => new Set(),
      getRowRfvLinks: () => [],
      // v173 — the renderers no longer hold literal hex; they call tok(), which
      // reads the live palette. Give the sandbox the REAL dark palette and the
      // real tok(), so this suite still proves what reaches fillStyle is a
      // resolved colour and not an unparseable var() the context would ignore.
      _tokCache: Object.create(null),
      getComputedStyle: () => ({
        getPropertyValue: k => PALETTES.dark[k] || '' }),
    }, []);
    vm.runInContext(
      grabFn('tok') + '\n' +
      grabFn('setupHiDpiCanvas') + '\n' + grabFn('_crisp') + '\n' +
      grabFn('colorForStatus') + '\n' + grabFn('buildWoRollup') + '\n' +
      grabFn('drawNcrCauseCodeChart') + '\n' +
      grabFn('drawWoStatusRollup'), ctx, { filename: 'charts.js' });
    // Build the rollup with the BUILD's own function rather than hand-stubbing
    // its shape — a stub guessed 'byStatus' where the real field is
    // 'statusCounts', which made the test fail for a reason the code did not have.
    vm.runInContext('state.woRollup = buildWoRollup(state.boms.abom.data, 0, 1);', ctx);
    return { ctx, canvas, drawn };
  }
  const FRACTIONAL = [703.328, 161.012];   // what a flex:1 container actually measures
  const ABOM = [['W1','CLOSED'],['W2','OPEN'],['W3','CLOSED'],['W4','IN WORK'],['W5','CANCELLED']];

  console.log('\n== The renderers actually run ==');
  t('drawNcrCauseCodeChart executes without throwing', () => {
    const { ctx, drawn } = chartCtx(FRACTIONAL[0], FRACTIONAL[1], 2);
    ctx.state.results = [
      { ncrEntriesPool1:[{ causeCode:'C1', causeCodeDesc:'Damaged' }], ncrEntriesPool2:[] },
      { ncrEntriesPool1:[{ causeCode:'C2', causeCodeDesc:'Wrong part' }], ncrEntriesPool2:[] }];
    vm.runInContext('drawNcrCauseCodeChart("ncr-cause-chart", state.results)', ctx);
    if (!drawn.length) throw new Error('no labels were drawn at all');
  });
  t('drawWoStatusRollup executes without throwing', () => {
    const { ctx, drawn } = chartCtx(FRACTIONAL[0], FRACTIONAL[1], 2);
    vm.runInContext('drawWoStatusRollup("wo-rollup-chart")', ctx);
    if (!drawn.length) throw new Error('no labels were drawn at all');
  });
  t('both renderers still draw when there is no data', () => {
    ['drawWoStatusRollup("x")', 'drawNcrCauseCodeChart("x", [])'].forEach(call => {
      const { ctx } = chartCtx(FRACTIONAL[0], FRACTIONAL[1], 2);
      ctx.state.woRollup = null;
      vm.runInContext(call, ctx);   // must render an empty-state caption, not throw
    });
  });

  console.log('\n== Cause A: the buffer must not be resampled ==');
  t('the backing buffer is exactly the CSS size in device pixels', () => {
    [[703.328, 161.012, 2], [703.328, 161.012, 1.25], [886.66, 200.5, 1.5],
     [560, 180, 1], [437.5, 140.25, 3]].forEach(([w, h, dpr]) => {
      const { ctx, canvas } = chartCtx(w, h, dpr);
      vm.runInContext('setupHiDpiCanvas(document.getElementById("x"))', ctx);
      const devW = parseFloat(canvas.style.width) * dpr;
      const devH = parseFloat(canvas.style.height) * dpr;
      if (Math.abs(devW - canvas.width) > 1e-9 || Math.abs(devH - canvas.height) > 1e-9)
        throw new Error('dpr ' + dpr + ': buffer ' + canvas.width + 'x' + canvas.height +
                        ' vs displayed ' + devW + 'x' + devH + ' — the canvas is resampled');
    });
  });
  t('the reported drawing size matches the CSS size', () => {
    const { ctx, canvas } = chartCtx(703.328, 161.012, 2);
    const r = vm.runInContext('setupHiDpiCanvas(document.getElementById("x"))', ctx);
    eq([r.w, r.h], [parseFloat(canvas.style.width), parseFloat(canvas.style.height)]);
  });
  t('a zero-size canvas falls back to its width/height attributes', () => {
    const { ctx, canvas } = chartCtx(0, 0, 2);
    vm.runInContext('setupHiDpiCanvas(document.getElementById("x"))', ctx);
    eq([canvas.width, canvas.height], [1920, 440], 'fallback 960x220 at dpr 2:');
  });

  console.log('\n== Cause C: the canvas must be able to reflow ==');
  t('the sizer clears its own inline size before measuring', () => {
    // v155 snapped the CSS size for crispness, but that inline width overrides
    // `.chart-card canvas { width: 100% }` FOREVER — the canvas froze at its
    // first-draw width and never reflowed. Clearing first lets CSS decide.
    const fn = grabFn('setupHiDpiCanvas');
    const clearAt = fn.indexOf("canvas.style.width  = ''");
    const measureAt = fn.indexOf('getBoundingClientRect');
    if (clearAt < 0) throw new Error('the sizer no longer clears its inline width');
    if (clearAt > measureAt)
      throw new Error('the inline size is cleared AFTER measuring — the measurement is stale');
  });
  t('a resized container gives the canvas a new buffer', () => {
    const first = chartCtx(703.328, 161.012, 2);
    vm.runInContext('setupHiDpiCanvas(document.getElementById("x"))', first.ctx);
    const wide = first.canvas.width;
    // Same canvas object, narrower container: the buffer must follow.
    first.canvas.getBoundingClientRect = () => ({ width: 421.5, height: 161.012 });
    vm.runInContext('setupHiDpiCanvas(document.getElementById("x"))', first.ctx);
    if (first.canvas.width >= wide)
      throw new Error('buffer stayed ' + first.canvas.width + ' after the container shrank');
    eq(first.canvas.width, Math.round(421.5 * 2), 'new buffer:');
  });
  t('charts are registered for redraw when their container changes', () => {
    if (!/function registerChartRedraw/.test(SRC))
      throw new Error('no chart redraw helper');
    ['wo-rollup-chart', 'ncr-cause-chart'].forEach(id => {
      if (!new RegExp("registerChartRedraw\\('" + id + "'").test(SRC))
        throw new Error(id + ' is never registered for redraw');
    });
    const h = SRC.slice(at('function registerChartRedraw'), at('function _crisp'));
    if (h.indexOf('ResizeObserver') < 0) throw new Error('the helper does not observe anything');
    if (h.indexOf('_chartRedraw.has') < 0)
      throw new Error('repeated renders would stack observers');
  });
  t('chart text is no smaller than the type scale\u2019s floor', () => {
    // 9px mono on a dark panel was the smallest text in the product.
    // v180 — the limit is read from --fs-xs, not written here as 11.
    const floor = parseFloat((SRC.match(/--fs-xs:\s*(\d+(?:\.\d+)?)px/) || [])[1]);
    if (!floor) throw new Error('--fs-xs is not defined');
    const seg = SRC.slice(at('function drawNcrCauseCodeChart'),
                          at('function drawWoStatusRollup') + 9000);
    const sizes = [...seg.matchAll(/ctx\.font = '(?:bold )?(\d+)px/g)].map(m => +m[1]);
    if (!sizes.length) throw new Error('no chart fonts found');
    const small = sizes.filter(v => v < floor);
    if (small.length) throw new Error('chart text at ' + [...new Set(small)].join(', ') + 'px');
  });

  console.log('\n== Cause B: no label on a fractional device pixel ==');
  const fractional = drawn => drawn.filter(d =>
    Math.abs(Math.round(d.x * 2) - d.x * 2) > 1e-9 ||
    Math.abs(Math.round(d.y * 2) - d.y * 2) > 1e-9);
  t('every WO roll-up label lands on a whole device pixel', () => {
    const { ctx, drawn } = chartCtx(FRACTIONAL[0], FRACTIONAL[1], 2);
    vm.runInContext('drawWoStatusRollup("wo-rollup-chart")', ctx);
    const bad = fractional(drawn);
    if (bad.length) throw new Error(bad.length + ' fuzzy label(s), e.g. ' + JSON.stringify(bad[0]));
  });
  t('every NCR cause-code label lands on a whole device pixel', () => {
    const { ctx, drawn } = chartCtx(FRACTIONAL[0], FRACTIONAL[1], 2);
    ctx.state.results = [1,2,3,4,5].map(n => ({
      ncrEntriesPool1:[{ causeCode:'C'+n, causeCodeDesc:'Cause number '+n }], ncrEntriesPool2:[] }));
    vm.runInContext('drawNcrCauseCodeChart("ncr-cause-chart", state.results)', ctx);
    const bad = fractional(drawn);
    if (bad.length) throw new Error(bad.length + ' fuzzy label(s), e.g. ' + JSON.stringify(bad[0]));
  });
  t('labels stay crisp across bar counts that make barH odd', () => {
    // barH = max(14, floor((h - pad) / bars) - 3). Odd values put a centred
    // baseline on a half pixel, which is what made the labels fuzzy.
    [1,2,3,4,5,6].forEach(n => {
      const { ctx, drawn } = chartCtx(FRACTIONAL[0], FRACTIONAL[1], 2);
      ctx.state.results = Array.from({ length: n }, (_, k) => ({
        ncrEntriesPool1:[{ causeCode:'C'+k, causeCodeDesc:'d' }], ncrEntriesPool2:[] }));
      vm.runInContext('drawNcrCauseCodeChart("x", state.results)', ctx);
      const bad = fractional(drawn);
      if (bad.length) throw new Error(n + ' bars: ' + JSON.stringify(bad[0]));
    });
  });
  t('_crisp snaps to the device pixel grid, not the CSS grid', () => {
    const { ctx } = chartCtx(100, 100, 2);
    eq(vm.runInContext('_crisp(10.4)', ctx), 10.5, 'dpr 2 keeps half CSS pixels:');
    eq(vm.runInContext('_crisp(10.3)', ctx), 10.5);
    const one = chartCtx(100, 100, 1);
    eq(vm.runInContext('_crisp(10.4)', one.ctx), 10, 'dpr 1 snaps to whole pixels:');
  });
});

// ── TIER 12 ────────────────────────────────────────────────────────────────
// Colour discipline. The build has a good token system; the problem was that
// 99 inline declarations bypassed it, including a SECOND muted grey 15
// luminance from the real one and a SECOND teal for RFV while --rfv already
// existed. Individually invisible, collectively the "haphazard" impression.
suite('Tier 12 — colour tokens', (t, eq) => {
  const CSS = STYLE_BLOCKS.map(b => b.css).join('\n');
  const BODY = SRC.slice(at('</style>'));
  const TOKENS = {};
  [...CSS.matchAll(/(--[\w-]+)\s*:\s*(#[0-9a-fA-F]{6})/g)]
    .forEach(m => { TOKENS[m[1]] = m[2].toLowerCase(); });
  const byValue = {};
  Object.keys(TOKENS).forEach(k => { (byValue[TOKENS[k]] = byValue[TOKENS[k]] || []).push(k); });
  const lum = h => { const n = i => parseInt(h.slice(1 + i * 2, 3 + i * 2), 16);
    return 0.2126 * n(0) + 0.7152 * n(1) + 0.0722 * n(2); };

  console.log('\n== Nothing bypasses the tokens ==');
  // WHY THIS IS BROADER THAN IT LOOKS (v174): the guard this replaces checked
  // BODY only, matched `color:` only, and did not recognise rgba(). All three
  // blind spots were occupied. #21262d sat in a border-bottom inside the
  // stylesheet; ten dark-mode row tints sat in rgba() inside render functions.
  // Both themes shipped carrying dark colours for six versions. Narrow the
  // property list or the notation list again and the same class of bug returns.
  const COLOUR_PROPS = 'color|background|background-color|border|border-color|' +
                       'border-top|border-right|border-bottom|border-left|' +
                       'outline|outline-color|fill|stroke|box-shadow|text-shadow';
  const LITERAL = '(#[0-9a-fA-F]{3,8}\\b|rgba?\\([^)]*\\))';
  const scanRaw = (text) =>
    [...text.matchAll(new RegExp('(?:' + COLOUR_PROPS + ')\\s*:\\s*[^;{}"\'`]*?' +
                                 LITERAL, 'gi'))].map(m => m[1]);

  t('no inline style sets a raw colour', () => {
    // One deliberate exception: the KPI render-error banner. It reports that
    // rendering has failed, so it must not depend on the stylesheet resolving —
    // tokenising it would risk an invisible error message. The exception is
    // narrow and asserted below, not a blanket allowance.
    const EXEMPT = /id="kpi-render-error-banner"[^>]*>/;
    const banner = BODY.match(EXEMPT);
    if (!banner) throw new Error('the render-error banner moved — re-check this exemption');
    const raw = scanRaw(BODY.replace(banner[0], ''));
    if (raw.length)
      throw new Error(raw.length + ' raw colour(s) outside the token system: ' +
                      [...new Set(raw)].join(', '));
  });
  t('no stylesheet rule sets a raw colour outside the palette blocks', () => {
    // The palette blocks are where literals belong; everything after them must
    // go through var(). Strip the four known blocks, then scan what is left.
    let css = STYLE_BLOCKS.map(b => b.css).join('\n');
    for (const sel of [':root', '[data-theme="light"]', '[data-theme="mono"]',
                       '[data-theme="dark"]']) {
      const k = css.indexOf(sel);
      if (k < 0) continue;
      let d = 0, start = css.indexOf('{', k);
      for (let i = start; i < css.length; i++) {
        if (css[i] === '{') d++;
        else if (css[i] === '}' && --d === 0) {
          css = css.slice(0, k) + css.slice(i + 1);
          break;
        }
      }
    }
    // @font-face and keyframes carry no palette colours; comments are noise.
    css = css.replace(/\/\*[\s\S]*?\*\//g, '');
    const raw = scanRaw(css);
    if (raw.length)
      throw new Error(raw.length + ' raw colour(s) in the stylesheet: ' +
                      [...new Set(raw)].slice(0, 12).join(', '));
  });
  t('the render-error banner stays self-contained on purpose', () => {
    const banner = BODY.match(/id="kpi-render-error-banner"[^>]*>/)[0];
    if (banner.indexOf('var(--') >= 0)
      throw new Error('the emergency banner now depends on CSS variables resolving');
    if (!/background:#[0-9a-f]{6}/i.test(banner) || !/color:#[0-9a-f]{3,6}/i.test(banner))
      throw new Error('the emergency banner lost its literal colours');
  });
    t('every badge fill keeps its own text legible', () => {
    // The real mono defect in v173 was not that the greys were close, it was
    // that --ci-dim, --surface2 and --cert-bg were the SAME value, so a CI
    // badge had no fill against the panel behind it. Checked per theme because
    // a token pair can pass in dark and collapse in light.
    const lum = h => {
      const f = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
      return 0.2126 * f(parseInt(h.slice(1, 3), 16)) +
             0.7152 * f(parseInt(h.slice(3, 5), 16)) +
             0.0722 * f(parseInt(h.slice(5, 7), 16));
    };
    const ratio = (a, b) => { const x = lum(a), y = lum(b);
      return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
    const PAIRS = ['--accent', '--success', '--warn', '--danger', '--wo-open',
                   '--adj', '--wo5', '--ncr', '--ci', '--rfv'];
    const bad = [];
    for (const [theme, pal] of Object.entries(PALETTES))
      for (const k of PAIRS) {
        const fg = pal[k], bg = pal[k + '-dim'];
        if (!fg || !bg) continue;
        const r = ratio(fg, bg);
        if (r < 4.5) bad.push(theme + ' ' + k + ' ' + r.toFixed(2) + ':1');
      }
    if (bad.length) throw new Error('badge text below 4.5:1 on its own fill: ' + bad.join(', '));
  });
  t('no theme collapses two tokens onto one value by accident', () => {
    // --bg and --on-accent legitimately coincide in the light themes: the page
    // is white and text on a filled accent is white. Everything else sharing a
    // value means one of the two is invisible wherever they meet.
    // mono also merges --accent onto --text on purpose: the high-contrast mode
    // is black on white by definition, and accent elements are distinguished
    // there by rule and underline rather than by hue.
    // v181 — the funnel count inks are dedicated copies, so they may equal the
    // general tokens they started from: ink = page (dark) or white (light,
    // mono); track text = body text. Owning a copy is the point — either can
    // be retuned without moving any other text.
    const ALLOWED = [['--bg', '--on-accent'], ['--surface', '--on-accent'],
                     ['--accent', '--text'], ['--funnel-count-ink', '--on-accent'],
                     ['--funnel-count-ink', '--bg'], ['--funnel-count-ink', '--surface'],
                     ['--funnel-count-track', '--text'], ['--funnel-count-track', '--accent']];
    const ok = (a, b) => ALLOWED.some(p => p.indexOf(a) >= 0 && p.indexOf(b) >= 0);
    // Two deliberate mono collapses, each asserted by its own test above:
    // outline chips share white with the surface, and --success-fill shares a
    // value with --danger-fill because a ladder bar and a residual segment
    // never appear in the same shape group.
    const MONO_OUTLINE = /^(--bg|--surface|--on-accent|.*-dim)$/;
    const MONO_FILL_PAIR = ['--success-fill', '--danger-fill'];
    const bad = [];
    for (const [theme, pal] of Object.entries(PALETTES)) {
      const byVal = {};
      for (const [k, v] of Object.entries(pal)) (byVal[v] = byVal[v] || []).push(k);
      for (const [v, ks0] of Object.entries(byVal)) {
        let ks = ks0;
        if (theme === 'mono' && v === '#ffffff') ks = ks.filter(k => !MONO_OUTLINE.test(k));
        if (theme === 'mono' && ks.length === 2 &&
            MONO_FILL_PAIR.every(k => ks.indexOf(k) >= 0)) continue;
        // Compare within a namespace only: a -fill paints a shape, everything
        // else inks a letter or draws a rule. The two sharing a grey in mono
        // is not a collision anyone can see.
        const inks = ks.filter(k => !/-fill$/.test(k));
        const fills = ks.filter(k => /-fill$/.test(k));
        [inks, fills].forEach(group => {
          // Every pair in the group must be allowed (v181: groups of three occur
          // now that the funnel count inks are dedicated copies).
          const pairsOk = group.every((a, i) => group.slice(i + 1).every(b => ok(a, b)));
          if (group.length > 1 && !pairsOk)
            bad.push(theme + ' ' + v + ' = ' + group.join(' & '));
        });
      }
    }
    if (bad.length) throw new Error('colliding tokens: ' + bad.join('; '));
  });
  t('no script hands out a palette colour as a bare string', () => {
    // The property-anchored scans above cannot see these: the literal is
    // returned from a helper and only reaches a style attribute later. Three
    // shipped this way until v174, which is why the exported report and the
    // RFV match table stayed dark-mode-coloured under every theme.
    const banner = BODY.match(/id="kpi-render-error-banner"[^>]*>/)[0];
    // tok() keeps one literal on purpose: it is the fallback for a token that
    // fails to resolve, so it must not itself depend on a token resolving.
    const TOK_FALLBACK = "v || '#8b949e'";
    if (BODY.indexOf(TOK_FALLBACK) < 0)
      throw new Error('the tok() fallback moved - re-check this exemption');
    const darkValues = new Set(Object.values(PALETTES.dark));
    const found = [...BODY.replace(banner, '').replace(TOK_FALLBACK, '').matchAll(/['"`](#[0-9a-fA-F]{6})['"`]/g)]
      .filter(v => darkValues.has(v));
    if (found.length)
      throw new Error(found.length + ' script literal(s) pinned to the dark palette: ' +
                      [...new Set(found)].join(', '));
  });
  t('the -fill tokens exist in every theme; dark aliases, light and mono may carry their own ramp', () => {
    // WHY THESE EXIST (v175): the category tokens are text far more than fill
    // - --success is a text colour 74 times and a fill 18 times - so they
    // cannot double as a lightness ramp for shapes. Making --success a light
    // grey to separate the chart bars would have blanked 74 text sites. The
    // -fill tokens carry the shapes; the category tokens stay legible.
    const NAMES = ['--success-fill','--success-2-fill','--success-3-fill',
                   '--warn-fill','--danger-fill','--rfv-fill','--muted-fill'];
    const PARENT = { '--success-fill':'--success', '--success-2-fill':'--success-2',
                     '--success-3-fill':'--success-3', '--warn-fill':'--warn',
                     '--danger-fill':'--danger', '--rfv-fill':'--rfv',
                     '--muted-fill':'--text-muted' };
    for (const sel of [':root', '[data-theme="light"]', '[data-theme="mono"]']) {
      const k = STYLE_BLOCKS[0].css.indexOf(sel);
      if (k < 0) throw new Error('palette block missing: ' + sel);
      const body = STYLE_BLOCKS[0].css.slice(k, STYLE_BLOCKS[0].css.indexOf('}', k));
      for (const n of NAMES) {
        const m = body.match(new RegExp(n.replace(/-/g, '\\-') + '\\s*:\\s*([^;]+);'));
        if (!m) throw new Error(sel + ' does not define ' + n);
        const v = m[1].trim();
        // v180 — light carries a darker ladder ramp so white counts on it are
        // legible; the ink contrast is asserted in 'text drawn on a fill'.
        if (sel === '[data-theme="mono"]' || (sel === '[data-theme="light"]' && /^--success(-\d)?-fill$/.test(n))) {
          if (!/^#[0-9a-f]{6}$/i.test(v) && v !== 'var(' + PARENT[n] + ')')
            throw new Error(sel + ' ' + n + ' should be a literal or alias its parent, got ' + v);
        } else if (v !== 'var(' + PARENT[n] + ')') {
          throw new Error(sel + ' ' + n + ' should alias ' + PARENT[n] + ', got ' + v);
        }
      }
    }
  });
  t('the mono fill ramp keeps competing shapes apart', () => {
    // Three places draw filled shapes that sit next to each other. Within each
    // group every fill must be visibly separated; across groups they may share
    // a value, because they never appear together.
    const GROUPS = {
      'funnel ladder':   ['--success-fill','--success-2-fill','--success-3-fill'],
      'WO roll-up':      ['--success-fill','--warn-fill','--muted-fill','--rfv-fill'],
      'funnel residual': ['--danger-fill','--warn-fill','--muted-fill'],
    };
    const mono = PALETTES.mono;
    const lvl = h => parseInt(h.slice(1, 3), 16);   // grey, so one channel is enough
    const bad = [];
    for (const [g, names] of Object.entries(GROUPS))
      for (let i = 0; i < names.length; i++)
        for (let j = i + 1; j < names.length; j++) {
          const d = Math.abs(lvl(mono[names[i]]) - lvl(mono[names[j]]));
          if (d < 24) bad.push(g + ': ' + names[i] + ' vs ' + names[j] + ' only ' + d + ' apart');
        }
    if (bad.length) throw new Error(bad.join('; '));
  });
  t('the ladder fills stay dark enough for the count printed on them', () => {
    // .funnel-bar-inline-count draws in var(--bg), which is white in mono.
    const mono = PALETTES.mono;
    for (const n of ['--success-fill','--success-2-fill','--success-3-fill']) {
      const g = parseInt(mono[n].slice(1, 3), 16);
      if (g > 0x60) throw new Error(n + ' is too light for white text: ' + mono[n]);
    }
  });
  t('mono chips are outlines except the one that must not be missed', () => {
    // The contract that replaces ten greys: the LABEL identifies the category,
    // so every chip is black on white - except MISSING, which keeps a fill and
    // a heavier rule. Collapsing the -dim tokens onto white is the design, not
    // drift, which is why the collision test below exempts them.
    const mono = PALETTES.mono;
    // --accent-dim is the selected/active state, not a category chip.
    const filled = Object.keys(mono).filter(
      k => /-dim$/.test(k) && k !== '--accent-dim' && mono[k] !== '#ffffff');
    if (filled.length !== 1 || filled[0] !== '--danger-dim')
      throw new Error('expected only --danger-dim to be filled, got: ' + filled.join(', '));
    const rule = STYLE_BLOCKS[0].css;
    if (rule.indexOf('[data-theme="mono"] .badge,') < 0)
      throw new Error('the mono chip ink rule is gone - chip text would fall back to the category grey');
  });
  t('no user-facing copy names a colour', () => {
    // Five strings said "teal" or "green" until v175. That is accurate in dark
    // and wrong in the other two themes, where RFV is a muted brass or a grey.
    // Comments may name colours; anything the user reads may not.
    const WORDS = /\b(teal|amber|purple|crimson|magenta)\b/i;
    const bad = [];
    // HTML comments may name colours too, including ones written mid-line.
    BODY.replace(/<!--[\s\S]*?-->/g, '').split('\n').forEach((line, i) => {
      const t = line.trim();
      if (!t || t.startsWith('//') || t.startsWith('*') || t.startsWith('/*')) return;
      if (WORDS.test(t)) bad.push('line ~' + (i + 1) + ': ' + t.slice(0, 70));
    });
    if (bad.length) throw new Error(bad.length + ' colour word(s) in user copy: ' + bad[0]);
  });
  t('the deleted renderer stayed deleted', () => {
    // drawBarChart was dead for 128 versions and every palette change had to
    // maintain its colour map anyway. If it comes back, it comes back with a
    // call site and a test, not by accident.
    if (SRC.indexOf('function drawBarChart') >= 0)
      throw new Error('drawBarChart is back without a call site');
  });
  t('the token palette is defined once and is not itself duplicated', () => {
    // Scoped to :root deliberately. The dark palette is the source of truth and
    // two names sharing a value there is drift — that is the v155 guard and it
    // still applies. It CANNOT apply to the other themes: in the mono palette
    // --bg and --on-accent are both #ffffff on purpose, because a white page
    // and a foreground sitting on a near-black accent fill really are the same
    // white. Structural parity across themes is asserted separately below.
    // v181 — one named exception: the funnel count tokens are dedicated copies
    // of --bg and --text by the owner's decision, so the ladder counts can be
    // retuned without moving any other text. They are checked on their own
    // (contrast on the fill and on the track), not as drift.
    const DEDICATED = { '--funnel-count-ink': '--bg', '--funnel-count-track': '--text' };
    const byValue = {};
    Object.keys(PALETTES.dark).filter(k => !(k in DEDICATED)).forEach(k => {
      (byValue[PALETTES.dark[k]] = byValue[PALETTES.dark[k]] || []).push(k); });
    const dupes = Object.keys(byValue).filter(v => byValue[v].length > 1)
      .map(v => v + ' = ' + byValue[v].join(' and '));
    if (dupes.length) throw new Error('two tokens share a value: ' + dupes.join('; '));
  });
  t('every theme defines every token the dark palette defines', () => {
    // -fill tokens are excluded: in dark and light they are declared as
    // var(--parent) aliases, which PALETTES cannot see because it reads hex.
    // They get their own contract test immediately below.
    // The failure this catches is the one a half-written theme produces: a
    // white background with the dark theme's near-black status fills still on
    // it, because the theme covered the seven chrome tokens and left the
    // twenty-two semantic ones to fall through to :root.
    const want = Object.keys(PALETTES.dark).filter(k => !/-fill$/.test(k)).sort();
    ['light', 'mono'].forEach(name => {
      const got = Object.keys(PALETTES[name]).filter(k => !/-fill$/.test(k)).sort();
      const missing = want.filter(k => !PALETTES[name][k]);
      const extra = got.filter(k => !PALETTES.dark[k]);
      if (missing.length)
        throw new Error(name + ' does not define: ' + missing.join(', '));
      if (extra.length)
        throw new Error(name + ' defines tokens the dark palette does not: ' + extra.join(', '));
    });
  });
  t('no theme leaves a token pointing at another theme’s value', () => {
    // A token copied across unchanged is almost always an oversight rather
    // than a decision — a dark-theme fill surviving into the light palette.
    // Neutrals are exempt: pure black and pure white legitimately recur.
    const neutral = v => v === '#000000' || v === '#ffffff';
    ['light', 'mono'].forEach(name => {
      const shared = Object.keys(PALETTES.dark)
        .filter(k => PALETTES[name][k] === PALETTES.dark[k] && !neutral(PALETTES.dark[k]));
      if (shared.length)
        throw new Error(name + ' reuses the dark value for: ' + shared.join(', '));
    });
  });
  t('the mono palette is actually monochrome', () => {
    // What makes this mode useful on a photocopied audit packet. Asserted, so
    // a later token added to mono cannot quietly reintroduce a hue.
    const coloured = Object.keys(PALETTES.mono).filter(k => {
      const v = PALETTES.mono[k];
      return !(v.slice(1, 3) === v.slice(3, 5) && v.slice(3, 5) === v.slice(5, 7));
    });
    if (coloured.length)
      throw new Error('mono tokens carrying a hue: ' +
                      coloured.map(k => k + ' ' + PALETTES.mono[k]).join(', '));
  });
  t('the summary table uses two text tiers and only two', () => {
    // v156 — #8. White marks what a reader compares or acts on; dim is context.
    // --text-faint survives for chrome (chart captions, funnel footnotes) but
    // must not appear in a table cell, where a third tier re-creates the mush.
    const TABLE = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    if (/<td[^>]*var\(--text-faint\)/.test(TABLE))
      throw new Error('a table cell uses the chrome-only faint tier');
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/td\s*\{[^}]*color:\s*var\(--text-muted\)/.test(css))
      throw new Error('td no longer defaults to dim');
    if (!/td\.cell-key\s*\{[^}]*color:\s*var\(--text\)/.test(css))
      throw new Error('.cell-key no longer marks the white tier');
  });
  t('every column on the white list is marked, and no others', () => {
    const TABLE = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    const marked = (TABLE.match(/<td class="cell-key/g) || []).length;
    // Next Higher, EBOM Qty, Δ Qty, MBOM Direct Qty, ABOM Direct Qty, ABOM
    // Direct NH, ABOM Direct WO#, per-WO Qty, WO Status, Used-On WO#,
    // Used-On WO Status. Part Number is white via .pn-col; NCR disposition
    // numbers and statuses and RFV numbers carry their own semantic colour.
    eq(marked, 11, 'cells marked white:');
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/\.pn-col\s*\{[^}]*color:\s*var\(--text\)/.test(css))
      throw new Error('the Part Number column is no longer white');
  });
  t('there are two text tiers, and --text-faint is retired', () => {
    // v180 — --text-faint survived v156 for chart captions and funnel
    // footnotes. At #484f58 it was 2.1:1 against the dark panel, and this test
    // REQUIRED it to sit 40 luminance steps below --text-muted — which on a
    // dark page forces a third grey below any legible contrast. The rule was
    // the defect. Two tiers, each legible (next test).
    if (/--text-faint/.test(stripComments(SRC.slice(at('</script>')))))
      throw new Error('--text-faint is still defined or used');
    ['dark', 'light', 'mono'].forEach(name => {
      const p = PALETTES[name];
      if (!p['--text'] || !p['--text-muted']) throw new Error(name + ' lacks a text tier');
      if (!(Math.abs(LUM(p['--bg']) - LUM(p['--text'])) > Math.abs(LUM(p['--bg']) - LUM(p['--text-muted']))))
        throw new Error(name + ': --text-muted is not quieter than --text');
    });
  });
  t('both text tiers clear 4.5:1 against the page and the panel in every theme', () => {
    // WCAG AA for normal text. Checked against --bg AND --surface: panels are
    // where most small text sits.
    const bad = [];
    ['dark', 'light', 'mono'].forEach(name => {
      const p = PALETTES[name];
      ['--text', '--text-muted'].forEach(t => ['--bg', '--surface'].forEach(b => {
        const c = CONTRAST(p[t], p[b]);
        if (c < 4.5) bad.push(name + ' ' + t + ' on ' + b + ' ' + c.toFixed(2));
      }));
    });
    if (bad.length) throw new Error(bad.join('; '));
  });
  t('text drawn on a coverage fill clears 4.5:1 in every theme', () => {
    // v180 — the ladder's inline counts were drawn in --bg, which is only dark
    // in the dark theme: 2.9:1 on the light theme's lightest green. v180 gave
    // them --on-fill; v181 renamed it --funnel-count-ink (funnel counts only).
    // PALETTES reads hex only; dark (and light, for some tokens) declares
    // aliases as var(--x). Follow them in the raw palette block.
    const css0 = STYLE_BLOCKS[0].css;
    const blockOf = sel => { const k = css0.indexOf(sel); return css0.slice(k, css0.indexOf('}', k)); };
    const SEL = { dark: ':root', light: '[data-theme="light"]', mono: '[data-theme="mono"]' };
    const val = (name, k, depth) => {
      const hex = PALETTES[name][k];
      if (hex) return hex;
      const m = blockOf(SEL[name]).match(new RegExp(k.replace(/-/g, '\\-') + '\\s*:\\s*var\\((--[\\w-]+)\\)'));
      return m && (depth || 0) < 5 ? val(name, m[1], (depth || 0) + 1) : undefined;
    };
    // v181 — and the count that sits beside a short bar is on the empty track,
    // whose background is --bg. It has its own token, checked against that.
    const bad = [];
    ['dark', 'light', 'mono'].forEach(name => {
      ['--success-fill', '--success-2-fill', '--success-3-fill'].forEach(f => {
        const c = CONTRAST(val(name, '--funnel-count-ink'), val(name, f));
        if (!(c >= 4.5)) bad.push(name + ' ink on ' + f + ' ' + (c ? c.toFixed(2) : 'unresolved'));
      });
      const t = CONTRAST(val(name, '--funnel-count-track'), val(name, '--bg'));
      if (!(t >= 4.5)) bad.push(name + ' track text ' + (t ? t.toFixed(2) : 'unresolved'));
    });
    if (bad.length) throw new Error(bad.join('; '));
    if (!/\.funnel-bar-track\s*\{[^}]*background:\s*var\(--bg\)/.test(css0))
      throw new Error('the track is no longer --bg; re-point the track-text check');
  });
  t('a ladder count is coloured by the two funnel count tokens and nothing else', () => {
    // v181 — v180 checked the base rule only. A .light modifier, applied to every
    // bar between 18% and 39%, drew the count in --text-muted: about 1.1:1 on
    // the dark theme's green. The owner photographed it. Every colour a ladder
    // count can take must come from these two tokens.
    const css = STYLE_BLOCKS[0].css;
    const rules = [...css.matchAll(/([^{}]*funnel-bar-inline-count[^{}]*)\{([^}]*)\}/g)]
      .filter(m => /(^|;|\s)color\s*:/.test(m[2]));
    const colours = rules.map(m => (m[2].match(/(?:^|;|\s)color\s*:\s*([^;]+)/) || [])[1].trim());
    const stray = colours.filter(c => c !== 'var(--funnel-count-ink)' && c !== 'var(--funnel-count-track)');
    if (stray.length) throw new Error('ladder count coloured by ' + stray.join(', '));
    ['var(--funnel-count-ink)', 'var(--funnel-count-track)'].forEach(k => {
      if (colours.indexOf(k) < 0) throw new Error('no ladder-count rule uses ' + k);
    });
    // Dedicated means dedicated: nothing else is drawn in them.
    const other = [...css.matchAll(/([^{}]*)\{([^}]*var\(--funnel-count-(?:ink|track)\)[^}]*)\}/g)]
      .map(m => m[1].trim()).filter(sel => sel.indexOf('funnel-bar-inline-count') < 0);
    if (other.length) throw new Error('the count tokens also colour: ' + other.join(', '));
    if (/funnel-bar-inline-count light/.test(SRC)) throw new Error('the .light modifier is back');
  });
  t('hovering a ladder bar does not change its fill colour', () => {
    // v181 — brightness(1.18) on hover lifted the light theme's darkest green
    // enough to pull the white count under 4.5:1. Hover is shown by an outline.
    const css = STYLE_BLOCKS[0].css;
    const m = css.match(/\.funnel-ladder-stage:hover \.funnel-bar-fill-cov\s*\{([^}]*)\}/);
    if (m && /filter|opacity|background/.test(m[1])) throw new Error('hover alters the fill: ' + m[1].trim());
    // And hover is still shown somehow (review: the check above passes silently
    // if the selector is renamed).
    if (!/\.funnel-ladder-stage:hover \.funnel-bar-track\.cov\s*\{[^}]*box-shadow/.test(css))
      throw new Error('a hovered ladder bar has no outline');
  });
  t('a ladder bar takes its length from --pct, set per bar in the markup', () => {
    // v181 review — the length moved from an inline width to a rule. Deleting
    // that rule would draw every Direct/Used-On/Ancestor bar at zero length and
    // pass every other test.
    if (!/\.funnel-bar-fill-cov\s*\{[^}]*width:\s*var\(--pct\)/.test(STYLE_BLOCKS[0].css))
      throw new Error('.funnel-bar-fill-cov does not take width from --pct');
    const cov = grabFn('renderFunnelPanel');
    if (!/class="funnel-bar-track cov" style="--pct:\$\{pctVal\}%"/.test(cov))
      throw new Error('the track no longer sets --pct from the bar percentage');
  });
  t('reference bars are visible against their panel', () => {
    // v180 — the reference bars' fill was 1.2-1.3:1 against the panel in every
    // theme: context, but invisible. They keep the quiet fill and gain an
    // outline in --text-muted, which clears 3:1 (the non-text minimum).
    if (!/\.funnel-bar-fill-ref \{[^}]*box-shadow:\s*inset 0 0 0 1px var\(--text-muted\)/.test(STYLE_BLOCKS[0].css))
      throw new Error('reference bars have no visible edge');
    ['dark', 'light', 'mono'].forEach(name => {
      const p = PALETTES[name];
      if (CONTRAST(p['--text-muted'], p['--surface']) < 3) throw new Error(name + ' reference bar edge below 3:1');
    });
  });
  t('anything inactive is dimmed by one token, --disabled-opacity', () => {
    // v180 — disabled buttons and inactive cards used 0.3, 0.35, 0.4 and 0.5.
    const app = SRC.slice(at('</script>'));
    const js = [...app.matchAll(/style\.opacity\s*=\s*([^;\n]+)/g)].map(m => m[1])
      .filter(v => /'0?\.\d+'/.test(v));
    if (js.length) throw new Error('script sets a literal opacity: ' + js.slice(0, 4).join(' | '));
    const css = STYLE_BLOCKS[0].css;
    const dis = [...css.matchAll(/([^{}]*:disabled[^{}]*)\{([^}]*)\}/g)]
      .filter(m => /opacity:\s*0?\.\d/.test(m[2])).map(m => m[1].trim());
    if (dis.length) throw new Error('disabled rule with a literal opacity: ' + dis.join(', '));
    if (!/--disabled-opacity:\s*0?\.\d+/.test(css)) throw new Error('--disabled-opacity is not defined');
    // v180 review — the two checks above missed four inactive controls written as
    // inline markup (0.3, 0.35, 0.4), and 0.78–0.85 fades on Comparison Summary
    // cells that measured 3.97:1 in light. So: no literal opacity anywhere in app
    // code, except these four, none of which fades text a reader must read.
    const ALLOWED = [
      /\.btn-primary:hover\s*\{[^}]*$/,        // hover feedback on the whole button
      /@keyframes lock-pulse[^\n]*$/,            // a pulse animation
      /\.explain-btn::before\s*\{[^}]*$/,        // the decorative ⓘ glyph
      /\.funnel-curve-path\s*\{[^}]*$/,          // an SVG stroke, not text
    ];
    const lit = [];
    for (const m of app.matchAll(/(?<![\w-])opacity\s*:\s*0?\.\d+/g)) {
      const before = app.slice(Math.max(0, m.index - 200), m.index);
      if (ALLOWED.some(r => r.test(before))) continue;
      lit.push(m[0] + ' @' + SRC.slice(0, SRC.indexOf(app) + m.index).split('\n').length);
    }
    if (lit.length) throw new Error('literal opacity outside the token: ' + lit.slice(0, 6).join(', '));
  });
  t('no funnel text is faded with opacity', () => {
    // A tier is a token, not an opacity: .75 on the delta percentages and a 50%
    // mix on the light inline count were a third and fourth grey by other means.
    const css = STYLE_BLOCKS[0].css;
    const bad = [...css.matchAll(/(\.funnel[\w-]*[^{]*)\{([^}]*)\}/g)]
      // Text rules only: a rule that sets a font size or a text colour. The
      // coverage curve's SVG stroke is drawn translucent on purpose.
      .filter(m => /font-size|(^|;|\s)color:/.test(m[2]))
      .filter(m => /opacity:\s*0?\.\d|color-mix\(in srgb, var\(--text\) \d+%/.test(m[2])).map(m => m[1].trim());
    if (bad.length) throw new Error('faded: ' + bad.join(', '));
  });
  t('every theme keeps body text legible against its own background', () => {
    // A theme is free to choose its greys, but not to choose ones nobody can
    // read. The dark palette clears this by 219; the bar is set well below
    // that so it catches a mistake rather than a preference.
    ['dark', 'light', 'mono'].forEach(name => {
      const p = PALETTES[name];
      const d = Math.abs(LUM(p['--bg']) - LUM(p['--text']));
      if (d < 120)
        throw new Error(name + ' body text is only ' + Math.round(d) + ' from its background');
    });
  });

  console.log('\n== A standalone download carries its own palette ==');
  t('the exported report writes the type scale into its own :root', () => {
    // v180 review — the test below trusts TYPE_SCALE_TOKENS as "emitted"; if
    // exportPaletteCss() stopped writing them it would still pass, and every
    // var(--fs-*) in the download would fall back to browser defaults. Run it.
    const fn = new Function('PALETTE_TOKENS', 'TYPE_SCALE_TOKENS', 'tok',
      grabFn('exportPaletteCss') + '; return exportPaletteCss();');
    const out = fn(['--bg'], TYPE_SCALE_TOKENS_IN_BUILD(), k => 'X');
    const miss = TYPE_SCALE_TOKENS_IN_BUILD().filter(k => out.indexOf(k + ':') < 0);
    if (!TYPE_SCALE_TOKENS_IN_BUILD().length) throw new Error('TYPE_SCALE_TOKENS not found in the build');
    if (miss.length) throw new Error('the download does not define: ' + miss.join(', '));
  });
  t('every var() in the exported report has a definition to resolve against', () => {
    // The live defect this fixes. The second style block belongs to a file the
    // user downloads and opens on its own; it referenced 52 tokens and shipped
    // no :root. An unresolvable var() on `color` computes to unset, which for
    // an inherited property means inherit, which bottoms out at black — so the
    // report rendered black text on a near-black background.
    //
    // Scanning only the export's <style> block is not enough: most of those 52
    // references are in inline styles on the rows and the certificate, in the
    // body of the template. Take the whole template, bounded at both ends —
    // an unbounded slice runs to EOF and reports the main application's tokens
    // as if the report used them.
    const tpl = span(at('const html = `<!DOCTYPE html>'),
                     at("downloadFile(tsFilename('bom_comparison_report'"),
                     'exported HTML report template');
    const used = [...new Set([...tpl.matchAll(/var\((--[\w-]+)\)/g)].map(m => m[1]))];
    if (used.length < 5) throw new Error('only ' + used.length + ' tokens found — the template moved');
    if (tpl.indexOf('exportPaletteCss()') < 0)
      throw new Error('the exported report no longer emits a :root block');
    const emitted = new Set(PALETTE_TOKENS_IN_BUILD().concat(TYPE_SCALE_TOKENS_IN_BUILD()));
    const missing = used.filter(k => !emitted.has(k));
    if (missing.length)
      throw new Error('the download references tokens it does not define: ' + missing.join(', '));
  });
  t('the exported palette list has not drifted from the stylesheet', () => {
    // The list is written by hand, so it is exactly the kind of thing that
    // rots. Derive the truth from :root and compare, rather than trusting it.
    const listed = PALETTE_TOKENS_IN_BUILD().slice().sort();
    const defined = Object.keys(PALETTES.dark).sort();
    const missing = defined.filter(k => listed.indexOf(k) < 0);
    const extra = listed.filter(k => defined.indexOf(k) < 0);
    if (missing.length) throw new Error('PALETTE_TOKENS omits: ' + missing.join(', '));
    if (extra.length) throw new Error('PALETTE_TOKENS names tokens :root does not define: ' + extra.join(', '));
  });
  t('the exported report holds no colour literal of its own', () => {
    // v137 tried to solve this by inlining hex, which is what left the report
    // frozen in the dark palette while the rest of the build gained themes.
    const exp = STYLE_BLOCKS[1].css;
    const hex = [...new Set(exp.match(/#[0-9a-fA-F]{3,8}/g) || [])]
      .filter(h => !/^#\{/.test(h));
    if (hex.length) throw new Error('literal colour(s) in the export stylesheet: ' + hex.join(', '));
  });

  console.log('\n== The palette is a view, not a record ==');
  t('the theme is not written into the session or the certificate', () => {
    // Two auditors opening the same frozen session must compute the same hash
    // whatever palette each is looking at. The theme is a viewing preference
    // and belongs in browser storage only.
    const exporter = grabFrom(SRC, 'exportSessionJson', 'session exporter');
    if (/theme/i.test(exporter))
      throw new Error('the session exporter mentions the theme');
    const setT = grabFrom(SRC, 'setTheme', 'theme switch');
    if (!/localStorage/.test(setT))
      throw new Error('setTheme does not persist to localStorage');
    if (/auditCert|state\.\w*[Hh]ash/.test(setT))
      throw new Error('setTheme touches the audit certificate');
  });
  t('dark is the absence of a theme attribute, not a fourth palette', () => {
    // :root is the default. If dark were also a [data-theme="dark"] block there
    // would be two definitions of the same palette to keep in step.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (/\[data-theme="dark"\]/.test(css))
      throw new Error('a dark theme block exists alongside :root');
    const setT = grabFrom(SRC, 'setTheme', 'theme switch');
    if (setT.indexOf('removeAttribute') < 0)
      throw new Error('setTheme does not clear the attribute for the default palette');
  });
  t('every canvas colour equals a defined token value', () => {
    // A 2D context silently ignores an unresolvable fillStyle and keeps the
    // previous colour, so these must stay hex — but they must not DRIFT from
    // the palette. #39c5cf was an RFV teal while --rfv was #2dd4bf.
    const canvas = [...BODY.matchAll(/fillStyle\s*=\s*'(#[0-9a-fA-F]{6})/g)]
      .concat([...BODY.matchAll(/return\s*'(#[0-9a-fA-F]{6})'/g)])
      .map(m => m[1].toLowerCase());
    const orphan = [...new Set(canvas)].filter(v => !byValue[v]);
    if (orphan.length)
      throw new Error('canvas colour(s) with no matching token: ' + orphan.join(', '));
  });
  t('no canvas fillStyle tries to use a CSS variable', () => {
    if (/fillStyle\s*=\s*['"`]?\s*var\(/.test(BODY))
      throw new Error('canvas cannot resolve var() — the colour would silently not change');
  });
  t('RFV is one colour, not two', () => {
    // v173 — read from the dark palette explicitly. A flat scan of the
    // stylesheet now returns whichever theme is written last, so this used to
    // compare the RFV teal against the mono grey and fail for no reason.
    const rfv = PALETTES.dark['--rfv'];
    if (!rfv) throw new Error('--rfv is not defined');
    const teals = [...new Set([...BODY.matchAll(/#(3[0-9a-f]c[0-9a-f]{3}|2dd4bf)/gi)]
      .map(m => m[0].toLowerCase()))];
    if (teals.length)
      throw new Error('a second RFV teal is in use: ' + teals.join(', ') +
                      ' (--rfv is ' + rfv + ', and canvas colours go through tok())');
  });
  t('no chart renderer holds a colour literal', () => {
    // v173 — replaces the old "every canvas hex equals a token value". That
    // rule matched `fillStyle = '#hex'` and `return '#hex'`, so it never saw a
    // colour sitting in an OBJECT LITERAL. Three did: the WO status map (which
    // is how the second muted grey #7d8590 survived v155), the stacked-bar
    // segment list, and colorForStatus's fallback. Renderers now resolve every
    // colour through tok(), so the contract is simply that none of them
    // contains a hex at all — a rule with nowhere to hide.
    // drawBarChart left this list in v176 along with the function itself.
    const RENDERERS = ['drawNcrCauseCodeChart', 'drawNcrDispStatusChart',
                       'drawWoStatusRollup'];
    RENDERERS.forEach(name => {
      const src = grabFrom(SRC, name, 'chart renderers');
      const hex = [...new Set((src.match(/'#[0-9a-fA-F]{3,8}'/g) || []))];
      if (hex.length)
        throw new Error(name + ' holds colour literal(s): ' + hex.join(', '));
    });
  });
  t('tok() resolves through the live palette and cannot return empty', () => {
    // The whole reason canvas colours were literal: a 2D context given an
    // unresolvable fillStyle does not throw, it KEEPS THE PREVIOUS COLOUR. So
    // tok() returning '' would not fail loudly, it would silently draw the
    // last bar's colour over the next one.
    const src = grabFrom(SRC, 'tok', 'token reader');
    if (!/getComputedStyle/.test(src))
      throw new Error('tok() no longer reads the live document');
    if (!/\|\|\s*'#[0-9a-fA-F]{6}'/.test(src))
      throw new Error('tok() has no fallback — an unknown token would return empty');
    if (!/getPropertyValue/.test(src))
      throw new Error('tok() is not reading a custom property');
  });
  t('a palette change forces the charts to redraw', () => {
    // Canvas holds resolved hex, so a theme swap is invisible to it until it
    // redraws. Without this the charts keep the old theme's colours on the new
    // theme's background. The resize observer does not help: a palette change
    // alters no geometry, so nothing fires.
    const src = grabFrom(SRC, 'setTheme', 'theme switch');
    ['clearTokenCache', 'redrawAllCharts'].forEach(f => {
      if (src.indexOf(f + '(') < 0)
        throw new Error('setTheme does not call ' + f + '()');
    });
    const reg = grabFrom(SRC, 'registerChartRedraw', 'chart registry');
    if (!/drawFn/.test(reg) || !/_chartRedraw\.set\([^)]*drawFn/.test(reg))
      throw new Error('the registry does not keep the draw function, so nothing can replay it');
  });
});

// ── TIER 13 ────────────────────────────────────────────────────────────────
// The Comparison Summary type scale, plus a syntax check of the whole build.
// v155 stripped 26 inline font-size overrides out of renderSummaryTable with a
// regex; a regex loose enough to do that is loose enough to break a template
// literal, and nothing here would have noticed.
suite('Tier 13 — summary table type scale', (t, eq) => {
  const CSS = STYLE_BLOCKS.map(b => b.css).join('\n');
  const TABLE = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
  const rule = sel => {
    const m = CSS.match(new RegExp('(?:^|\\})\\s*' + sel + '\\s*\\{([^}]*)\\}', 'm'));
    if (!m) throw new Error('rule not found: ' + sel);
    return m[1].split('\n').join(' ').replace(/\s+/g, ' ');
  };
  const px = decl => { const m = decl.match(/font-size:\s*(?:var\((--[\w-]+)\)|(\d+)px)/);
    return m ? (m[1] || m[2] + 'px') : null; };
  // v180 — tokens may alias the type scale (--fs-cell: var(--fs-sm)), so follow the chain.
  const token = n => { const m = CSS.match(new RegExp(n + '\\s*:\\s*([^;]+);'));
    if (!m) throw new Error(n + ' is not defined');
    const v = m[1].trim(), a = v.match(/^var\((--[\w-]+)\)$/);
    return a ? token(a[1]) : parseFloat(v); };

  console.log('\n== The build still parses ==');
  t('every inline script block is syntactically valid', () => {
    const cp = require('child_process'), fs2 = require('fs'), os = require('os'), pth = require('path');
    const blocks = [...SRC.matchAll(/<script(?![^>]*\ssrc=)[^>]*>([\s\S]*?)<\/script>/g)]
      .map(m => m[1]).filter(b => b.length > 50);
    if (blocks.length < 2) throw new Error('expected at least 2 script blocks, found ' + blocks.length);
    blocks.forEach((b, i) => {
      const f = pth.join(os.tmpdir(), 'cmp-syntax-' + process.pid + '-' + i + '.js');
      fs2.writeFileSync(f, b);
      const r = cp.spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
      fs2.unlinkSync(f);
      if (r.status !== 0)
        throw new Error('script block ' + i + ' does not parse:\n        ' +
                        String(r.stderr).split('\n').slice(0, 4).join('\n        '));
    });
  });
  t('no style attribute was left malformed', () => {
    // Scoped to style attributes: `;;` is ordinary JavaScript — `for(;;)` and
    // SheetJS's own escaping account for 11 legitimate occurrences file-wide.
    const attrs = [...SRC.matchAll(/style="([^"]*)"/g)].map(m => m[1]);
    const bad = attrs.filter(a => /^\s*;/.test(a) || /;;/.test(a) || /^\s*$/.test(a));
    if (bad.length)
      throw new Error(bad.length + ' malformed style attribute(s), e.g. ' +
                      JSON.stringify(bad[0].slice(0, 60)));
  });

  console.log('\n== One size for every cell ==');
  t('the scale is declared as tokens, not repeated literals', () => {
    eq(px(rule('td')), '--fs-cell', 'td:');
    eq(px(rule('th')), '--fs-head', 'th:');
  });
  t('no cell in the summary table overrides the base size', () => {
    const over = TABLE.match(/font-size:\s*\d+px/g);
    if (over) throw new Error(over.length + ' inline override(s) remain: ' +
                              [...new Set(over)].join(', '));
  });
  t('no stylesheet rule re-sizes a table cell either', () => {
    const bad = [];
    ['td.td-indenture', 'td.ctx-rel', '.badge-ncr-none'].forEach(sel => {
      const p = px(rule(sel));
      if (p && p !== '--fs-cell') bad.push(sel + ' = ' + p);
    });
    if (bad.length) throw new Error(bad.join('; '));
  });

  console.log('\n== Weight is not an emphasis channel ==');
  t('no data cell in the summary table sets its own weight', () => {
    // v156 — #7. Weight belongs to the Part Number column and to badges. It was
    // also on NCR numbers, part-type codes, quantity deltas and adjudication
    // glyphs — emphasis with no shared rule. Colour already carries all of it.
    const TABLE = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    const bold = TABLE.match(/font-weight:\s*[67]00/g);
    if (bold) throw new Error(bold.length + ' inline bold declaration(s) remain in the table');
  });
  t('the two places weight IS allowed still have it', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/\.pn-col\s*\{[^}]*font-weight:\s*600/.test(css))
      throw new Error('the Part Number column lost its weight');
    if (!/\.badge\s*\{[^}]*font-weight:\s*700/.test(css))
      throw new Error('badges lost their weight');
  });

  console.log('\n== Row separation ==');
  t('rows are separated by a visible line', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const m = css.match(/--row-line:\s*#([0-9a-fA-F]{8})/);
    if (!m) throw new Error('--row-line is not defined as an 8-digit hex');
    const alpha = parseInt(m[1].slice(6), 16);
    if (alpha < 0x18) throw new Error('row separator alpha is 0x' + m[1].slice(6) +
      ' — too faint to locate a row on a wide scrolled table');
    if (!/border-bottom:\s*1px solid var\(--row-line\)/.test(css))
      throw new Error('td no longer uses --row-line');
  });

  console.log('\n== Headers and badges ==');
  t('the header is smaller than the cell, not larger', () => {
    // A header is a label, not content. It is already distinguished by
    // uppercase, letter-spacing, a surface fill and muted colour, and it is
    // sticky — so enlarging it would cost permanent vertical space.
    const head = token('--fs-head'), cell = token('--fs-cell');
    if (head >= cell) throw new Error('head ' + head + 'px vs cell ' + cell + 'px');
    ['text-transform: uppercase', 'letter-spacing'].forEach(sig => {
      if (rule('th').indexOf(sig) < 0)
        throw new Error('the header lost a non-size signal: ' + sig);
    });
  });
  t('every badge is one size, set in one place', () => {
    // v155 matched badges to cell text. On review that made OVERALL badges
    // larger than the trace-column badges beside them in the same row, because
    // the trace columns carried an inline 9px override. v156 makes the smaller
    // size the rule and removes the overrides — one token, no exceptions.
    eq(px(rule('\\.badge')), '--fs-badge');
    const inline = SRC.match(/class="badge[^"]*"[^>]{0,80}font-size:\s*\d+px/g);
    if (inline) throw new Error(inline.length + ' badge(s) still override the size: ' +
                                inline[0].slice(0, 80));
    const cls = [...STYLE_BLOCKS.map(b => b.css).join('\n')
      .matchAll(/\.(badge-[\w-]+)\s*\{[^}]*font-size:\s*(\d+)px/g)].map(m => m[1]);
    if (cls.length) throw new Error('badge class(es) re-size themselves: ' + cls.join(', '));
  });
  t('badge tracking stays tight', () => {
    // Size and tracking compound. At 0.12em, matching cell size widened the two
    // stacked-badge columns by about a third in a table that already scrolls.
    // v180: tracking is a token now, so resolve var() before measuring.
    const m = rule('\\.badge').match(/letter-spacing:\s*(var\((--[\w-]+)\)|([\d.]+)em)/);
    if (!m) throw new Error('badge letter-spacing is gone');
    const em = m[2] ? parseFloat(String(token(m[2]))) : parseFloat(m[3]);
    if (!(em > 0)) throw new Error('badge tracking token ' + m[2] + ' does not resolve');
    if (em > 0.05)
      throw new Error('tracking is ' + em + 'em — too wide at ' + token('--fs-cell') + 'px');
  });
  t('badges keep a non-size difference from the cell text', () => {
    // The user asked for same size, different style. Weight and case carry it.
    const b = rule('\\.badge');
    ['font-weight: 700', 'text-transform: uppercase'].forEach(sig => {
      if (b.indexOf(sig) < 0) throw new Error('badge lost ' + sig);
    });
  });
});

// ── TIER 14 ────────────────────────────────────────────────────────────────
// Detailed View table structure. .table-wrap is overflow-x/y auto with a
// max-height, so anything placed inside it scrolls away from the reader and
// slides under the sticky header row — and attachTopScrollbar inserts its
// mirror as the wrap's previous sibling, so a caption inside the wrap pushes
// the horizontal scrollbar above the caption instead of onto the table.
// Exactly two of the eight views did that, and they are the two that were
// reported as looking different.
suite('Tier 14 — Detailed View table structure', (t, eq) => {
  const VIEWS = ['renderSummaryTable', 'renderFullBom', 'renderChpTable', 'renderWo5Table',
                 'renderWo5DiscrepancyView', 'renderNcrTable', 'renderCITraceTable',
                 'renderRFVTable'];
  const body = fn => { const a = at('function ' + fn);
    const b = SRC.indexOf('\nfunction ', a + 10);
    return SRC.slice(a, b > 0 ? b : a + 26000); };

  console.log('\n== Every view is wired the same way ==');
  t('every Detailed View renderer targets a .table-wrap and attaches a top scrollbar', () => {
    VIEWS.forEach(fn => {
      const b = body(fn);
      const m = b.match(/getElementById\(([^)]+)\)\.innerHTML = html/);
      if (!m) throw new Error(fn + ' does not fill a wrapper');
      if (b.indexOf('attachTopScrollbar') < 0)
        throw new Error(fn + ' has no top scrollbar');
    });
  });
  t('every wrapper element carries the table-wrap class', () => {
    ['summary', 'ebom', 'chp', 'wo5', 'wo5disc', 'ncr', 'ci', 'rfv'].forEach(k => {
      const re = new RegExp('<div[^>]*id="' + k + '-table-wrap"[^>]*>');
      const m = SRC.match(re);
      if (!m) throw new Error(k + '-table-wrap is not declared');
      if (m[0].indexOf('table-wrap') < 0)
        throw new Error(k + ' wrapper lost its class: ' + m[0]);
    });
  });

  console.log('\n== #11 / #12: nothing but the table inside the scroller ==');
  t('no renderer puts a caption inside the scroll container', () => {
    const bad = VIEWS.filter(fn => {
      const b = body(fn);
      const i = b.indexOf('<table');
      return i > 0 && /html\s*\+?=\s*[`'"]<div/.test(b.slice(0, i));
    });
    if (bad.length)
      throw new Error('caption inside .table-wrap in: ' + bad.join(', ') +
                      ' — it will scroll sideways with the table and sit under the sticky header');
  });
  t('both captions are written to elements outside their wrapper', () => {
    [['wo5disc', 'renderWo5DiscrepancyView'], ['rfv', 'renderRFVTable']].forEach(([k, fn]) => {
      const cap = SRC.indexOf('id="' + k + '-table-caption"');
      const wrap = SRC.indexOf('id="' + k + '-table-wrap"');
      if (cap < 0) throw new Error(k + '-table-caption is not declared');
      if (cap > wrap) throw new Error(k + ' caption is declared after its wrapper');
      if (body(fn).indexOf("setTableCaption('" + k + "-table-caption'") < 0)
        throw new Error(fn + ' no longer writes its caption');
    });
  });
  t('the caption helper writes outside the wrapper, not into it', () => {
    const h = SRC.slice(at('function setTableCaption'), at('function attachTopScrollbar'));
    if (h.indexOf('table-wrap') >= 0)
      throw new Error('setTableCaption touches the scroll container');
    if (h.indexOf('innerHTML') < 0) throw new Error('setTableCaption stopped writing');
  });
  t('.table-caption is styled and collapses when empty', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/\.table-caption\s*\{/.test(css)) throw new Error('.table-caption has no rule');
    if (!/\.table-caption:empty\s*\{[^}]*display:\s*none/.test(css))
      throw new Error('an empty caption must not leave a gap above the table');
  });

  console.log('\n== Row selection survives re-render ==');
  t('every summary row carries its key and a click handler', () => {
    const T = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    if (!/data-rk="\$\{esc\(r\.key\)\}"/.test(T))
      throw new Error('rows no longer carry their key');
    if (!/onclick="selectSummaryRow\(this\)"/.test(T))
      throw new Error('rows are not clickable');
  });
  t('the selection lives in state, not only in the DOM', () => {
    // A DOM-only highlight would vanish on paging, filtering or any re-render —
    // exactly when a reader most needs to keep their place.
    if (!/summarySelectedKey:\s*null/.test(SRC))
      throw new Error('state has no summarySelectedKey');
    const T = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    if (!/state\.summarySelectedKey === r\.key/.test(T))
      throw new Error('render does not re-apply the stored selection');
  });
  t('clicking the selected row clears it, and only one row is ever selected', () => {
    const h = SRC.slice(at('function selectSummaryRow'), at('function renderSummaryTable'));
    if (!/state\.summarySelectedKey === key/.test(h))
      throw new Error('no toggle-off path');
    if (!/querySelectorAll\('tr\.row-selected'\)/.test(h))
      throw new Error('a previous selection is not cleared');
  });
  t('selection paints the cells, so an inline row background cannot hide it', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    if (!/tbody tr\.row-selected > td\s*\{[^}]*background[^}]*!important/.test(css))
      throw new Error('selection must paint td with !important — rows carry inline status backgrounds');
    if (!/tbody tr\.row-selected > td:first-child\s*\{[^}]*box-shadow/.test(css))
      throw new Error('the left marker is gone');
  });

  console.log('\n== Pagination is uniform ==');
  t('every paginated view uses the shared PAGE_SIZE and page-bar', () => {
    VIEWS.filter(fn => fn !== 'renderCITraceTable').forEach(fn => {
      const b = body(fn);
      if (b.indexOf('PAGE_SIZE') < 0) throw new Error(fn + ' does not use PAGE_SIZE');
      if (b.indexOf('class="page-bar"') < 0) throw new Error(fn + ' has no page-bar');
      ['← Prev', 'Next →'].forEach(lbl => {
        if (b.indexOf(lbl) < 0) throw new Error(fn + ' is missing the ' + lbl + ' control');
      });
    });
  });
  t('the CI Traceability view is the one deliberate exception', () => {
    // Documented rather than silently tolerated: it renders every row. If it
    // ever gains pagination, this test fails and the exception list shrinks.
    const b = body('renderCITraceTable');
    if (b.indexOf('class="page-bar"') >= 0)
      throw new Error('renderCITraceTable now paginates — move it into the rule above');
  });
});

// ── TIER 15 ────────────────────────────────────────────────────────────────
// The reconciliation engine. 543 lines that decide whether a part is
// reconciled, and until v159 not one test executed it — every other suite
// tested the code AROUND it: the proc table that feeds it, the badges that
// display its output, the exports that format it.
//
// Fixtures go through the REAL map builders, never hand-built. Building them by
// hand got the shapes wrong twice while this suite was being written: a Map
// where the engine wants a plain object, and an object where primaryQtyMap
// wants a bare number. Both times the engine ran without error and returned
// plausible-but-wrong results. A fixture that lies is worse than no test.
suite('Tier 15 — reconciliation engine', (t, eq) => {
  const E = sandbox({ PROC_CODE_EXCEPTIONS: { BR:'remove', 'BR-S':'remove', RS:'remove',
    CR:'remove', FR:'remove', MR:'remove', DR:'swap', 'DR-S':'swap', TRRI:'swap', PIP:'swap' } },
    ['engine']).E;

  // EBOM row: [indenture, pn, desc, nh, qty]. Indenture C = a real line item;
  // A and B are structural collector levels and are excluded from scope.
  const eb = (pn, nh, q, ind) => { const r = new Array(6).fill('');
    r[0] = ind || 'C'; r[1] = pn; r[3] = nh; r[4] = String(q); return r; };
  // ABOM row: [pn, usedOn, qty, woNo, woStatus, procCode]
  const ab = (pn, uo, q, wo, st, pc) => [pn, uo, String(q), wo, st || 'CLOSED', pc || ''];

  function run(ebom, mbom, abom, extra) {
    const closed = (abom || []).filter(r => String(r[4]).toUpperCase() === 'CLOSED');
    const open   = (abom || []).filter(r => String(r[4]).toUpperCase() !== 'CLOSED');
    return E.runReconciliationCore(Object.assign({
      mode: 'ebom_mbom_abom', required: ['ebom', 'mbom', 'abom'], serializeMaps: false,
      // v160 — the collector rule is now a parameter. The default matches the
      // shipped default; tests that vary it pass their own.
      collectorLevels: ['A', 'B'],
      primaryQtyMap: E.buildQtyMap(ebom, 1, 3, 4, true),
      mbomMap: mbom ? E.buildQtyMap(mbom, 1, 3, 4) : null,
      abomMap: abom ? E.buildAbomMap(closed, 0, 1, 2, 3, 4, 5) : null,
      openAbomMap: abom ? E.buildAbomMap(open, 0, 1, 2, 3, 4, 5) : null,
      mbomUsedOnMap: mbom ? E.buildMbomUsedOnMap(mbom, 1, 3, 4) : null,
      abomUsedOnMap: abom ? E.buildAbomUsedOnMap(closed, 0, 1, 2, 3, 4, 5) : null,
      openAbomUsedOnMap: abom ? E.buildAbomUsedOnMap(open, 0, 1, 2, 3, 4, 5) : null,
      abomWoToUsedOns: {}, ebomFlex: {}, ebomRef: {}, removalScope: {}, ptTypeMap: {},
      ebomLineNoMap: {}, ebomQtyTextMap: {},
      indentureInfo: E.buildEbomIndentureMap(ebom, 0, 1, 3),
      chpTrace: {}, chpPnTrace: {}, ncrByDiscPn: {}, ncrByOrigWo: {}, wo5Map: {},
    }, extra || {}));
  }
  const row = (res, key) => res.find(r => r.key === (key || 'P1||TOP'));
  const legs = (res, key) => { const r = row(res, key);
    if (!r) throw new Error('no row for ' + (key || 'P1||TOP'));
    return [r.ms, r.as, r.overall]; };

  console.log('\n== The fixture builders agree with the engine ==');
  t('buildQtyMap produces the bare-number shape the engine reads', () => {
    // `var eq = primaryMap[key]` — the value IS the quantity. Wrapping it in an
    // object makes every comparison silently false.
    const m = E.buildQtyMap([eb('P1', 'TOP', 2)], 1, 3, 4, true);
    eq(m['P1||TOP'], 2);
    if (typeof m['P1||TOP'] !== 'number') throw new Error('not a number');
  });
  t('buildAbomMap produces the fields the engine destructures', () => {
    const m = E.buildAbomMap([ab('P1', 'TOP', 2, 'W1')], 0, 1, 2, 3, 4, 5);
    ['qty', 'woValues', 'allProcsAreRemovalOrSwap'].forEach(k => {
      if (!(k in m['P1||TOP'])) throw new Error('buildAbomMap no longer emits ' + k);
    });
    eq(Array.isArray(m['P1||TOP'].woValues), true, 'woValues must be an array:');
  });

  console.log('\n== Pass 1 — direct match ==');
  t('a line present and equal on all three legs reconciles', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')])),
       ['ok', 'ok', 'ok']);
  });
  t('a line absent from both target legs is missing', () => {
    eq(legs(run([eb('P1','TOP',2)], [], [])), ['missing', 'missing', 'missing']);
  });
  t('each leg is judged independently', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [])),
       ['ok', 'missing', 'missing'], 'planned but not built:');
  });

  console.log('\n== Quantity: a shortfall, not any difference ==');
  t('less in the target than the EBOM is a mismatch', () => {
    eq(legs(run([eb('P1','TOP',3)], [eb('P1','TOP',3)], [ab('P1','TOP',1,'W1')]))[1],
       'qty_mismatch');
    eq(legs(run([eb('P1','TOP',3)], [eb('P1','TOP',1)], [ab('P1','TOP',3,'W1')]))[0],
       'qty_mismatch', 'MBOM side too:');
  });
  t('MORE in the target than the EBOM is NOT a mismatch', () => {
    // Deliberate: the rule is `aq < eq`. An overage is not a reconciliation
    // failure — the design quantity is satisfied.
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',5)], [ab('P1','TOP',5,'W1')])),
       ['ok', 'ok', 'ok']);
  });
  t('exact equality is not a mismatch', () => {
    eq(legs(run([eb('P1','TOP',7)], [eb('P1','TOP',7)], [ab('P1','TOP',7,'W1')])),
       ['ok', 'ok', 'ok']);
  });

  console.log('\n== Work order status and proc codes ==');
  t('an open work order is wo_open, not ok and not missing', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1','OPEN')]))[1],
       'wo_open');
  });
  t('a REMOVE proc code on every record reads as proc_removed', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1','CLOSED','BR')]))[1],
       'proc_removed');
  });
  t('an install alongside a removal nets out rather than reading as removed', () => {
    const r = run([eb('P1','TOP',2)], [eb('P1','TOP',2)],
                  [ab('P1','TOP',2,'W1','CLOSED'), ab('P1','TOP',2,'W2','CLOSED','BR')]);
    if (row(r).as === 'proc_removed')
      throw new Error('a key with an effective install must not read as proc_removed');
  });
  t('a SWAP code is not a removal', () => {
    // DR is net-zero by design — removed then reinstalled before the WO closes.
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1','CLOSED','DR')]))[1],
       'ok');
  });

  console.log('\n== Scope exclusions ==');
  t('indenture A and B rows are structural collectors, not line items', () => {
    const r = run([eb('TOP','',1,'A'), eb('P1','TOP',2)], [eb('P1','TOP',2)],
                  [ab('P1','TOP',2,'W1')]);
    eq(legs(r, 'TOP||'), ['collector', 'collector', 'collector']);
    eq(legs(r), ['ok', 'ok', 'ok'], 'the real line item beneath it is unaffected:');
  });
  t('a REF line is excluded from the results entirely', () => {
    const r = run([eb('P1','TOP',2)], [], [], { ebomRef: { 'P1||TOP': true } });
    eq(r.length, 0, 'REF lines must not appear as rows at all:');
  });
  t('a removal-scope line is reported as pt_removal, not as missing', () => {
    eq(legs(run([eb('P1','TOP',2)], [], [], { removalScope: { 'P1||TOP': true } })),
       ['pt_removal', 'pt_removal', 'pt_removal']);
  });
  t('a SUB/AR flex line absent from the target is flex_missing, and overall ok', () => {
    // Any quantity satisfies a flex line, and absence is expected — so the leg
    // records flex_missing while the rollup stays clean.
    const l = legs(run([eb('P1','TOP',2)], [], [], { ebomFlex: { 'P1||TOP': true } }));
    eq([l[0], l[2]], ['flex_missing', 'ok']);
  });

  console.log('\n== The overall rollup takes the worst leg ==');
  t('missing beats qty_mismatch', () => {
    eq(legs(run([eb('P1','TOP',3)], [eb('P1','TOP',1)], []))[2], 'missing');
  });
  t('qty_mismatch beats wo_open', () => {
    const r = run([eb('P1','TOP',3)], [eb('P1','TOP',1)], [ab('P1','TOP',3,'W1','OPEN')]);
    eq(row(r).overall, 'qty_mismatch');
  });
  t('wo_open beats ok', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1','OPEN')]))[2],
       'wo_open');
  });
  t('overall is only ok when no leg is worse', () => {
    eq(legs(run([eb('P1','TOP',2)], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')]))[2], 'ok');
  });

  console.log('\n== Keys, normalisation and multiple rows ==');
  t('the key is part number plus next higher, not part number alone', () => {
    const r = run([eb('P1','TOP',2), eb('P1','OTHER',3)],
                  [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')]);
    eq(r.length, 2, 'the same PN under two parents is two rows:');
    eq(legs(r, 'P1||TOP')[0], 'ok');
    eq(legs(r, 'P1||OTHER')[0], 'missing', 'the second parent is unplanned:');
  });
  t('case and padding differences still match', () => {
    eq(legs(run([eb(' p1 ', 'top', 2)], [eb('P1', 'TOP', 2)], [ab('P1', 'TOP', 2, 'W1')])),
       ['ok', 'ok', 'ok']);
  });
  t('every EBOM line in scope produces exactly one row', () => {
    const r = run([eb('P1','TOP',1), eb('P2','TOP',1), eb('P3','TOP',1)],
                  [eb('P1','TOP',1)], [ab('P2','TOP',1,'W1')]);
    eq(r.length, 3);
    // Each row is judged on its own evidence: P1 is planned only, P2 is built
    // only, P3 is in neither. All three roll up to missing, by different routes.
    eq([row(r,'P1||TOP').ms, row(r,'P1||TOP').as], ['ok', 'missing'], 'planned, not built:');
    eq([row(r,'P2||TOP').ms, row(r,'P2||TOP').as], ['missing', 'ok'], 'built, not planned:');
    eq([row(r,'P3||TOP').ms, row(r,'P3||TOP').as], ['missing', 'missing'], 'neither:');
  });
  t('an empty EBOM produces no rows and does not throw', () => {
    eq(run([], [], []).length, 0);
  });
});

// ── TIER 16 ────────────────────────────────────────────────────────────────
// computeEffectiveResults applies SME claims on top of raw engine output. Its
// own comments say Phase C "mirrors runReconciliationCore's priority rollup" —
// the same shape of risk as the duplicated PROC_CODE_BASELINE in the delta
// tool, which did drift. Nothing enforced the agreement until now.
suite('Tier 16 — effective results and the duplicated rollup', (t, eq) => {
  const E = sandbox({ state: { results: [], adjudications: [] },
                      PROC_CODE_EXCEPTIONS: {} }, ['engine']).E;
  const CE = (rows, claims) => E.computeEffectiveResults(rows, claims || []);
  const raw = o => Object.assign({ key:'P1||TOP', pn:'P1', nh:'TOP',
    ms:'ok', as:'ok', msUsedOn:'n/a', asUsedOn:'n/a', overall:'ok' }, o);

  console.log('\n== The two rollups must agree, exhaustively ==');
  t('both ladders return the same overall for every leg combination', () => {
    // 12 statuses across 4 legs = 20,736 combinations. Each row is fed the
    // overall the ENGINE produced, because that is the real precondition —
    // Phase C reads the existing overall to decide whether to skip a row.
    const V = ['ok','missing','qty_mismatch','wo_open','proc_removed','covered',
               'pn_as_usedon','n/a','flex_ok','flex_missing','collector','wo_cancelled'];
    // A claim MUST be supplied: computeEffectiveResults returns early when the
    // claim list is empty, so comparing with no claims would skip Phase C
    // entirely and pass without testing anything. The claim targets a row that
    // does not exist, so it changes no leg — it only gets us past the guard.
    const wake = [{ id: 'probe', rowKey: 'NOSUCH||ROW', leg: 'mbom',
                    reason: 'direct', applied: true }];
    const diff = [];
    V.forEach(ms => V.forEach(as => V.forEach(mu => V.forEach(au => {
      const engine = E.engineLadder(ms, as, mu, au);
      const eff = CE([raw({ ms, as, msUsedOn: mu, asUsedOn: au, overall: engine })], wake)[0].overall;
      if (engine !== eff) diff.push(ms + '/' + as + '/' + mu + '/' + au +
                                    ': engine=' + engine + ' effective=' + eff);
    }))));
    if (diff.length)
      throw new Error(diff.length + ' of 20736 combinations disagree, e.g.\n        ' +
                      diff.slice(0, 5).join('\n        '));
  });
  t('the worst-leg order is identical in both copies', () => {
    // Compare the ladders as code, not only as behaviour: a reordering that
    // happens to be behaviourally equivalent today is still drift.
    const rungs = src => (src.match(/'(missing|qty_mismatch|wo_open|proc_removed)'/g) || [])
      .map(x => x.replace(/'/g, '')).filter((v, i, a) => a.indexOf(v) === i);
    const engSrc = SRC.slice(at('var legs = [];'), at('// Pass 3 fallback'));
    const effA = at('// ── Phase C');
    const effSrc = SRC.slice(effA, SRC.indexOf('return effective', effA));
    eq(rungs(effSrc), rungs(engSrc), 'rung order:');
    eq(rungs(engSrc), ['missing', 'qty_mismatch', 'wo_open', 'proc_removed']);
  });

  console.log('\n== With no claims, nothing changes ==');
  t('an empty claim list is a pass-through', () => {
    const rows = [raw({}), raw({ key:'P2||TOP', pn:'P2', ms:'missing', overall:'missing' })];
    const out = CE(rows, []);
    eq(out.length, 2);
    eq(out.map(r => r.overall), ['ok', 'missing']);
  });
  t('the raw rows are not mutated', () => {
    // The audit trail depends on raw and effective staying separable — the
    // session exports both.
    const rows = [raw({ ms:'missing', overall:'missing' })];
    CE(rows, [{ id:'a1', rowKey:'P1||TOP', leg:'mbom', reason:'direct',
                type:'row', applied:true }]);
    eq(rows[0].ms, 'missing', 'the raw row must survive untouched:');
    eq(rows[0].overall, 'missing');
  });
  t('structural rows are never re-rolled', () => {
    ['pt_collector', 'pt_reference', 'pt_bulk', 'pt_removal', 'collector'].forEach(st => {
      const out = CE([raw({ ms:'missing', as:'missing', overall: st })]);
      eq(out[0].overall, st, st + ' must pass through untouched:');
    });
  });

  console.log('\n== Adjudicated statuses roll up as their plain equivalents ==');
  t('an adjudicated direct leg counts as a direct-OK leg', () => {
    eq(CE([raw({ ms:'direct_adjudicated', as:'ok', overall:'ok' })])[0].overall,
       E.engineLadder('ok', 'ok', 'n/a', 'n/a'));
  });
  t('an accepted quantity mismatch no longer rolls up as a mismatch', () => {
    const out = CE([raw({ ms:'qty_mismatch_accepted', as:'ok', overall:'ok' })])[0];
    if (out.overall === 'qty_mismatch')
      throw new Error('an accepted mismatch must not still read as a mismatch');
  });
  t('Phase C does not run at all when there are no claims', () => {
    // `if (!adjudications || !adjudications.length) return effective;` — an
    // early return before Phase C. So adjudicated leg statuses in the raw rows
    // are NOT re-rolled unless a claim exists. Correct (an adjudicated status
    // cannot appear without a claim) but easy to misread: every test of the
    // promotion branch must supply a claim or it silently tests nothing.
    const out = CE([raw({ ms:'covered_adjudicated', as:'covered_adjudicated',
                          overall:'covered' })], []);
    eq(out[0].overall, 'covered', 'unchanged, because Phase C was skipped:');
  });
  t('with a claim present, an adjudicated covered leg is surfaced at overall', () => {
    const out = CE([raw({ ms:'covered_adjudicated', as:'covered_adjudicated',
                          overall:'covered' })],
                   [{ id:'a1', rowKey:'OTHER||ROW', leg:'mbom', reason:'direct',
                      applied:true }]);
    eq(out[0].overall, 'covered_adjudicated');
  });
  t('a mix of covered and covered_adjudicated surfaces the adjudication', () => {
    const out = CE([raw({ ms:'covered', as:'covered_adjudicated', overall:'covered' })],
                   [{ id:'a1', rowKey:'OTHER||ROW', leg:'mbom', reason:'direct',
                      applied:true }]);
    eq(out[0].overall, 'covered_adjudicated');
  });
  t('plain covered legs stay plain', () => {
    eq(CE([raw({ ms:'covered', as:'covered', overall:'covered' })])[0].overall, 'covered');
  });

  console.log('\n== Malformed input must not corrupt the audit trail ==');
  t('a claim naming a row that does not exist is ignored', () => {
    const out = CE([raw({})], [{ id:'x', rowKey:'NOSUCH||ROW', leg:'mbom',
                                 reason:'direct', applied:true }]);
    eq([out.length, out[0].overall], [1, 'ok']);
  });
  t('a claim with no rowKey does not throw', () => {
    eq(CE([raw({})], [{ id:'x', leg:'mbom', reason:'direct', applied:true }]).length, 1);
  });
  t('an empty result set returns an empty array', () => {
    eq(CE([], [{ id:'x', rowKey:'K', leg:'mbom' }]).length, 0);
  });
});

// ── TIER 17 ────────────────────────────────────────────────────────────────
// Session restore. The session file IS the audit artefact — it is what gets
// re-opened months later to answer "what did we certify, and on what basis".
// A field that fails to restore is a silently wrong answer, not a crash.
suite('Tier 17 — session restore', (t, eq) => {
  const el = () => ({ style:{}, classList:{ add(){}, remove(){}, toggle(){} },
    textContent:'', value:'', innerHTML:'', disabled:false,
    querySelectorAll: () => [], appendChild(){} });
  const fresh = () => ({ mode:'ebom_mbom', boms:{}, results:[], resultsRaw:[],
                         adjudications:[] });
  function load(payload) {
    const ctx = sandbox({
      document: { getElementById: el, querySelector: el, querySelectorAll: () => [] },
      state: fresh(), COL: { ebom:{ pn:1, nh:3 } },
      deserializeResults: r => r,
      setProcCodeMap: function (m, n) { ctx.state.procOverrides = m || null;
                                        ctx.state.procProfileName = n || null; },
      buildEbomLineNoMap: () => ({}), setMode: () => {}, clearNearMatchCache: () => {},
    }, ['chpalign', 'session']);   // v182 — the importer restores the alignment rule
    ctx.SS.restoreSession(payload);
    return ctx.state;
  }

  console.log('\n== The exporter and the importer agree on every field ==');
  t('every key the importer reads is a key the exporter writes', () => {
    // The one exception is cpManualMap — a deliberate back-compat read for
    // sessions written before the cp → chp rename. Anything else appearing here
    // means a field that can never restore, however carefully it was saved.
    const exp = SRC.slice(at('const head = {'), at('downloadFile', at('const head = {')));
    const written = new Set(
      [...exp.matchAll(/parts\.push\('?,?"(\w+)"/g)].map(m => m[1])
      .concat([...exp.matchAll(/^\s{6}(\w+):/gm)].map(m => m[1])));
    const imp = grabFn('importSessionJson');
    const read = [...new Set([...imp.matchAll(/payload\.(\w+)/g)].map(m => m[1]))];
    const orphan = read.filter(k => !written.has(k) && k !== 'cpManualMap');
    if (orphan.length)
      throw new Error('read but never written: ' + orphan.join(', '));
  });
  t('a session with no schema is refused', () => {
    const imp = grabFn('importSessionJson');
    if (!/payload\.schema !== 'bom-comparator-session'/.test(imp))
      throw new Error('the schema gate is gone — any JSON would be accepted');
    if (imp.indexOf('showError') < 0) throw new Error('a refusal must tell the user');
  });

  console.log('\n== A complete session restores completely ==');
  t('every audit-relevant field comes back', () => {
    const st = load({ mode:'ebom_abom', boms:{ ebom:{ data:[] } }, isLocked:true,
      abomColumnMapping:2, ebomColumnMapping:2, adjudicationsApplied:true,
      adjudications:[{ id:'a1' }, { id:'a2' }],
      procOverrides:{ XR:'remove' }, procProfileName:'Program Falcon',
      auditCert:{ hash:'abc123' }, woRollup:{ total:5 } });
    eq(st.mode, 'ebom_abom', 'mode:');
    eq(st.isLocked, true, 'the frozen flag:');
    eq([st.abomColumnMapping, st.ebomColumnMapping], [2, 2], 'column mappings:');
    eq(st.adjudications.length, 2, 'claims:');
    eq(st.adjudicationsApplied, true, 'whether they were applied:');
    eq(st.procProfileName, 'Program Falcon', 'proc profile provenance:');
    eq(st.auditCert.hash, 'abc123', 'the certificate:');
  });
  t('the lock survives, so a frozen report reopens frozen', () => {
    eq(load({ isLocked:true }).isLocked, true);
    eq(load({ isLocked:false }).isLocked, false);
    eq(load({}).isLocked, false, 'absent means unlocked, not undefined:');
  });

  console.log('\n== Older and malformed sessions ==');
  t('a pre-v153 session using the old cp zone key is mapped forward', () => {
    const st = load({ boms:{ ebom:{ data:[] }, cp:{ data:[[1]] } },
                      cpManualMap:{ pn:3 } });
    eq(!!st.boms.chp, true, 'the Change Pedigree zone must survive the rename:');
    eq(st.boms.cp, undefined, 'the old key is removed, not left as a duplicate:');
    eq(st.chpManualMap, { pn:3 }, 'and its manual column map carries forward:');
  });
  t('a new-key session is not overwritten by the back-compat path', () => {
    const st = load({ boms:{ chp:{ data:[['new']] }, cp:{ data:[['old']] } } });
    eq(st.boms.chp.data, [['new']], 'the current key wins:');
  });
  t('an empty payload restores usable defaults rather than throwing', () => {
    const st = load({});
    eq(st.mode, 'ebom_mbom', 'the current mode is kept:');
    eq(st.adjudications, [], 'claims default to empty, not undefined:');
    eq(st.abomColumnMapping, 1, 'column mapping falls back to 1:');
    eq(Object.keys(st.boms).length, 9, 'all nine zones are present as null:');
  });
  t('a null boms object does not leave the app without zones', () => {
    eq(Object.keys(load({ boms:null }).boms).sort(),
       ['abom','acn','chp','ci','ebom','mbom','ncr','rfv','wo5']);
  });
  t('an out-of-range column mapping falls back to 1, not to itself', () => {
    // Only 2 is a valid alternative. A hand-edited or corrupted session must
    // not select a mapping that does not exist.
    [99, 'two', null, 0, -1].forEach(v => {
      eq(load({ abomColumnMapping:v }).abomColumnMapping, 1, JSON.stringify(v) + ':');
    });
    eq(load({ abomColumnMapping:2 }).abomColumnMapping, 2, 'but 2 is honoured:');
  });
  t('proc code behaviour and its name both restore', () => {
    const st = load({ procOverrides:{ XR:'remove' }, procProfileName:'Falcon' });
    eq([st.procOverrides, st.procProfileName], [{ XR:'remove' }, 'Falcon']);
    const base = load({});
    eq([base.procOverrides, base.procProfileName], [null, null], 'absent means baseline:');
  });
  t('a session with claims but no results does not throw', () => {
    eq(load({ adjudications:[{ id:'a1' }] }).adjudications.length, 1);
  });
});

// ── TIER 18 ────────────────────────────────────────────────────────────────
// v160 — two program-level conventions: which indenture levels are structural
// collectors, and whether the source file writes indenture as alpha or numeric.
// Both change what reconciles, so both must travel with the session and be
// named on the certificate.
suite('Tier 18 — indenture scope and normalisation', (t, eq) => {
  const E = sandbox({ PROC_CODE_EXCEPTIONS: {} }, ['engine']).E;
  const eb = (pn, nh, q, ind) => { const r = new Array(6).fill('');
    r[0] = ind == null ? 'C' : ind; r[1] = pn; r[3] = nh; r[4] = String(q); return r; };
  const ab = (pn, uo, q, wo) => [pn, uo, String(q), wo, 'CLOSED', ''];
  function run(ebom, mbom, abom, levels) {
    return E.runReconciliationCore({
      mode: 'ebom_mbom_abom', required: ['ebom', 'mbom', 'abom'], serializeMaps: false,
      collectorLevels: levels === undefined ? ['A', 'B'] : levels,
      primaryQtyMap: E.buildQtyMap(ebom, 1, 3, 4, true),
      mbomMap: E.buildQtyMap(mbom, 1, 3, 4),
      abomMap: E.buildAbomMap(abom, 0, 1, 2, 3, 4, 5), openAbomMap: {},
      mbomUsedOnMap: E.buildMbomUsedOnMap(mbom, 1, 3, 4),
      abomUsedOnMap: E.buildAbomUsedOnMap(abom, 0, 1, 2, 3, 4, 5), openAbomUsedOnMap: {},
      abomWoToUsedOns: {}, ebomFlex: {}, ebomRef: {}, removalScope: {}, ptTypeMap: {},
      ebomLineNoMap: {}, ebomQtyTextMap: {},
      indentureInfo: E.buildEbomIndentureMap(ebom, 0, 1, 3),
      chpTrace: {}, chpPnTrace: {}, ncrByDiscPn: {}, ncrByOrigWo: {}, wo5Map: {} });
  }
  const of = (res, key) => (res.find(r => r.key === key) || {}).overall;

  console.log('\n== Numeric indenture is read as alpha ==');
  t('1 through 26 map to A through Z', () => {
    eq([1,2,3,26].map(n => E.normIndenture(n)), ['A','B','C','Z']);
    eq(E.normIndenture('2'), 'B', 'strings too:');
    eq(E.normIndenture(' 2 '), 'B', 'and padded values:');
  });
  t('alpha values pass through untouched', () => {
    eq(['A','b','C'].map(v => E.normIndenture(v)), ['A','B','C']);
  });
  t('values outside 1-26 are left alone rather than remapped', () => {
    // 0 and 27 have no alpha equivalent. Silently turning 0 into '@' would be
    // worse than leaving a value the program can still recognise.
    eq(['0','27','99'].map(v => E.normIndenture(v)), ['0','27','99']);
  });
  t('blank and junk values do not become a level', () => {
    eq([null, undefined, '', '  '].map(v => E.normIndenture(v)), ['','','','']);
    eq(E.normIndenture('AA'), 'AA', 'multi-letter levels are a program\'s own:');
  });
  t('a numeric EBOM reconciles identically to the same alpha EBOM', () => {
    // The whole point: one rule, either convention.
    const alpha = run([eb('TOP','',1,'A'), eb('P1','TOP',2,'C')],
                      [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')]);
    const numeric = run([eb('TOP','',1,'1'), eb('P1','TOP',2,'3')],
                        [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')]);
    eq(of(numeric, 'TOP||'), of(alpha, 'TOP||'), 'the apex row:');
    eq(of(numeric, 'P1||TOP'), of(alpha, 'P1||TOP'), 'the line item:');
    eq(of(numeric, 'TOP||'), 'collector', 'and level 1 IS a collector:');
  });

  console.log('\n== The collector rule is a setting, not a constant ==');
  t('the default still excludes A and B', () => {
    const r = run([eb('TOP','',1,'A'), eb('MID','TOP',1,'B'), eb('P1','MID',2,'C')],
                  [eb('P1','MID',2)], [ab('P1','MID',2,'W1')]);
    eq([of(r,'TOP||'), of(r,'MID||TOP')], ['collector', 'collector']);
    eq(of(r,'P1||MID'), 'ok', 'and C still reconciles:');
  });
  t('an empty list makes every level reconcile', () => {
    const r = run([eb('TOP','',1,'A'), eb('P1','TOP',2,'C')],
                  [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')], []);
    if (of(r,'TOP||') === 'collector')
      throw new Error('level A should reconcile when no level is a collector');
    // It reads as pn_as_usedon: once in scope, the apex IS found — as the
    // used-on parent of the row beneath it. That is the engine judging it on
    // its own evidence, which is exactly what removing the exclusion means.
    eq(of(r,'TOP||'), 'pn_as_usedon', 'the apex is now judged on its own evidence:');
  });
  t('a program can exclude A only, leaving B as real parts', () => {
    // The case a boolean could not express, and the reason this is a list.
    const r = run([eb('TOP','',1,'A'), eb('MID','TOP',1,'B'), eb('P1','MID',2,'C')],
                  [eb('MID','TOP',1), eb('P1','MID',2)],
                  [ab('MID','TOP',1,'W1'), ab('P1','MID',2,'W1')], ['A']);
    eq(of(r,'TOP||'), 'collector', 'A is still structural:');
    if (of(r,'MID||TOP') === 'collector')
      throw new Error('B must reconcile when only A is excluded');
    eq(of(r,'MID||TOP'), 'pn_as_usedon', 'B is now reconciled on its own evidence:');
  });
  t('a level can be excluded that the default never touched', () => {
    const r = run([eb('P1','TOP',2,'C')], [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')], ['C']);
    eq(of(r,'P1||TOP'), 'collector');
  });
  t('the setting works on a numeric EBOM too', () => {
    const r = run([eb('TOP','',1,'1'), eb('P1','TOP',2,'3')],
                  [eb('P1','TOP',2)], [ab('P1','TOP',2,'W1')], ['C']);
    if (of(r,'TOP||') === 'collector')
      throw new Error('level 1 should reconcile when only C is excluded');
    eq(of(r,'P1||TOP'), 'collector', 'level 3 = C is excluded:');
  });

  console.log('\n== It travels with the session and the certificate ==');
  t('every engine call site passes the setting', () => {
    // Worker AND synchronous fallback. If only one carried it, a worker failure
    // would silently reconcile a different set of rows.
    const calls = [...SRC.matchAll(/runReconciliationCore\(\{/g)];
    eq(calls.length, 2, 'engine call sites:');
    calls.forEach(m => {
      const seg = SRC.slice(m.index, m.index + 900);
      if (seg.indexOf('collectorLevels') < 0)
        throw new Error('an engine call site does not pass collectorLevels');
    });
  });
  t('the worker is sent the setting, and reads it', () => {
    const post = SRC.slice(at('worker.postMessage({'), at('worker.postMessage({') + 900);
    if (post.indexOf('collectorLevels') < 0)
      throw new Error('postMessage does not carry collectorLevels');
    if (!/var collectorLevels = d\.collectorLevels/.test(SRC))
      throw new Error('the worker does not read it from the message');
  });
  t('the session writes it and reads it back', () => {
    const exp = SRC.slice(at('const head = {'), at('downloadFile', at('const head = {')));
    if (exp.indexOf('collectorLevels') < 0)
      throw new Error('the session export omits collectorLevels');
    const imp = grabFn('importSessionJson');
    if (!/state\.collectorLevels\s*=\s*Array\.isArray\(payload\.collectorLevels\)/.test(imp))
      throw new Error('the session import does not restore collectorLevels');
    if (imp.indexOf("['A', 'B']") < 0)
      throw new Error('a session without the field must fall back to A/B, not to an empty list');
  });
  t('the certificate names the scope', () => {
    if (!/indentureScope:\s*_collectorScopeLabel\(\)/.test(SRC))
      throw new Error('the certificate does not record the indenture scope');
    // v178 — this counted two copies of the row, and passed partly BECAUSE the
    // CI report printed it twice. There is now one certificate definition,
    // used by every export (Tier 20 checks that every sheet comes from it).
    if (!/\['EBOM Indenture Scope', c\.indentureScope/.test(grabFn('_auditCertRows')))
      throw new Error('the certificate sheet does not carry the scope');
  });
  t('the panel refuses to change a frozen report', () => {
    ['setCollectorLevel', 'resetCollectorLevels'].forEach(fn => {
      const body = SRC.slice(at('function ' + fn), SRC.indexOf('\n}', at('function ' + fn)));
      if (body.indexOf('state.isLocked') < 0)
        throw new Error(fn + ' can change the scope while the report is frozen');
    });
  });
  t('changing the scope marks existing results stale', () => {
    const body = SRC.slice(at('function setCollectorLevel'),
                           SRC.indexOf('\n}', at('function setCollectorLevel')));
    if (body.indexOf('_procDirtySinceRun') < 0)
      throw new Error('results computed under the old rule must be marked stale');
  });
});

// ── TIER 19 ────────────────────────────────────────────────────────────────
// v162 — importing Manufacturing Engineering's adjudications. Their COTS export
// is keyed on part number only: no next higher, no quantity, no leg. All three
// are inferred at import, so every inference needs a test — an adjudication
// landing on the wrong position changes the reconciliation numbers.
suite('Tier 19 — ME adjudication import', (t, eq) => {
  const IMP = sandbox({}, ['adjimport']).IMP;
  const C = IMP.COL.adj;
  const R = (pn, nh, ms, as, eq_) => ({ key: pn + '||' + nh, pn, nh, eq: eq_ || 4,
    ms, as, msUsedOn: 'n/a', asUsedOn: 'n/a',
    overall: (ms === 'missing' || as === 'missing') ? 'missing' : (ms !== 'ok' ? ms : as) });
  // a source row in the canonical layout
  const src = o => { const r = new Array(20).fill('');
    r[C.pn] = o.pn || ''; r[C.claimNo] = o.claimNo || ''; r[C.claimStatus] = o.status || '';
    r[C.createDate] = o.date || ''; r[C.lastName] = o.last || ''; r[C.firstName] = o.first || '';
    r[C.description] = o.desc || ''; r[C.narrative] = o.narr || ''; return r; };

  console.log('\n== Resolving a bare part number to a position ==');
  t('a part at one failing position resolves automatically', () => {
    eq(IMP.resolveImportedAdjRow('P1', [R('P1','TOP','missing','ok')]).verdict, 'auto');
  });
  t('a part at several positions where only ONE fails still resolves automatically', () => {
    // The reason the picker stays small: a position that already reconciles is
    // never a candidate for adjudication.
    const v = IMP.resolveImportedAdjRow('P2',
      [R('P2','TOP','ok','ok'), R('P2','OTHER','missing','ok')]);
    eq(v.verdict, 'auto');
    eq(v.rows[0].key, 'P2||OTHER');
  });
  t('a part at several FAILING positions needs a human', () => {
    const v = IMP.resolveImportedAdjRow('P3',
      [R('P3','A','missing','ok'), R('P3','B','qty_mismatch','ok')]);
    eq([v.verdict, v.rows.length], ['picker', 2]);
  });
  t('a part that already reconciles everywhere is reported, not dropped', () => {
    const v = IMP.resolveImportedAdjRow('P4', [R('P4','A','ok','ok'), R('P4','B','ok','ok')]);
    eq(v.verdict, 'none');
    if (!v.reason) throw new Error('a no-action row must carry a reason');
  });
  t('a part not in this EBOM is rejected with a reason', () => {
    const v = IMP.resolveImportedAdjRow('P9', [R('P1','TOP','missing','ok')]);
    eq(v.verdict, 'reject');
  });
  t('rows reconciled by pass 2 or pass 3 are not adjudication candidates', () => {
    ['pn_as_usedon', 'covered', 'covered_adjudicated', 'flex_ok'].forEach(st => {
      eq(IMP.resolveImportedAdjRow('P5', [R('P5','A', st, 'ok')]).verdict, 'none', st + ':');
    });
  });

  console.log('\n== Claims are built only for legs that actually fail ==');
  t('a healthy leg produces no claim, so ME is not credited with it', () => {
    const c = IMP.buildImportedClaims({ claimNo:'AC-1', lastName:'Rodriguez', firstName:'J' },
                                      R('P1','TOP','missing','ok'));
    eq(c.length, 1);
    eq(c[0].leg, 'mbom');
  });
  t('both legs failing produces two claims', () => {
    eq(IMP.buildImportedClaims({ claimNo:'AC-1' }, R('P1','TOP','missing','missing')).length, 2);
  });
  t('a row needing nothing produces nothing', () => {
    eq(IMP.buildImportedClaims({ claimNo:'AC-1' }, R('P1','TOP','ok','ok')).length, 0);
  });
  t('the quantity always makes the line whole', () => {
    const c = IMP.buildImportedClaims({ claimNo:'AC-1' }, R('P1','TOP','missing','ok', 7));
    eq(c[0].claimedQty, 7, 'claimed qty must be the EBOM qty:');
  });
  t('the reason is derived from the row status, not from their spreadsheet', () => {
    eq(IMP.buildImportedClaims({claimNo:'A'}, R('P1','TOP','missing','ok'))[0].reason, 'mbom_missing');
    eq(IMP.buildImportedClaims({claimNo:'A'}, R('P1','TOP','qty_mismatch','ok'))[0].reason,
       'qty_mismatch_mbom');
    eq(IMP.buildImportedClaims({claimNo:'A'}, R('P1','TOP','ok','missing'))[0].reason, 'abom_missing');
  });
  t('imported claims arrive PENDING and carry their provenance', () => {
    const c = IMP.buildImportedClaims({ claimNo:'AC-1', lastName:'Rodriguez', firstName:'J',
      narrative:'Built per MPP.', date:'2026-08-01' }, R('P1','TOP','missing','ok'))[0];
    eq(c.applied, false, 'must not self-apply:');
    eq(c.createdFrom, 'external_import');
    eq(c.sme, 'Rodriguez, J');
    eq(c.extClaimNo, 'AC-1', 'the external claim number is retained:');
  });
  t('a row with no SME name is marked unattributed rather than blank', () => {
    eq(IMP.buildImportedClaims({claimNo:'A'}, R('P1','TOP','missing','ok'))[0].sme,
       'ME (unattributed)');
  });

  console.log('\n== The narrative scanner finds known values in prose ==');
  const NARR = 'Reviewed the package on 14 AUG. Confirmed it hangs under next higher ' +
               '88421-7 on this tail, not 88421-9 as originally routed. Work on DWO 4471102.';
  t('an identifier buried mid-sentence is found', () => {
    const h = IMP.scanNarrative(NARR, ['88421-7']);
    eq(h.length, 1);
    if (h[0].sentence.indexOf('hangs under') < 0)
      throw new Error('the containing sentence must be captured for the reader');
  });
  t('a longer identifier containing the candidate does NOT match', () => {
    eq(IMP.scanNarrative('see reference 588421-70 instead', ['88421-7']).length, 0);
    eq(IMP.scanNarrative('88421-70 applies', ['88421-7']).length, 0);
    eq(IMP.scanNarrative('88421-7A applies', ['88421-7']).length, 0);
  });
  t('punctuation and brackets are boundaries, but hyphens are not', () => {
    ['ends here 88421-7.', '(88421-7)', 'is 88421-7, yes'].forEach(txt =>
      eq(IMP.scanNarrative(txt, ['88421-7']).length, 1, JSON.stringify(txt) + ':'));
  });
  t('a run-together identifier does not match', () => {
    eq(IMP.scanNarrative('DWO4471102 done', ['4471102']).length, 0);
    eq(IMP.scanNarrative('DWO 4471102 done', ['4471102']).length, 1);
  });
  t('very short candidates are never searched for', () => {
    // Searching prose for 'A' or 'B' would match constantly.
    eq(IMP.scanNarrative('the A position applies', ['A']).length, 0);
  });

  console.log('\n== Suggest only when the prose is unambiguous ==');
  t('one candidate mentioned is suggested', () => {
    const plan = IMP.planAdjImport(
      [src({ pn:'P3', claimNo:'AC-3', narr:'It hangs under 88421-7 on this tail.' })],
      [R('P3','88421-7','missing','ok'), R('P3','77310-2','missing','ok')]);
    eq(plan.picker.length, 1);
    eq(plan.picker[0].suggestedKey, 'P3||88421-7');
  });
  t('several candidates mentioned suggests NOTHING', () => {
    // The narrative here explicitly rules one out in words. A matcher cannot
    // read negation, so suggesting either would be a coin flip dressed as an
    // answer. The sentences are shown instead.
    const plan = IMP.planAdjImport(
      [src({ pn:'P3', claimNo:'AC-3', narr:NARR })],
      [R('P3','88421-7','missing','ok'), R('P3','88421-9','missing','ok')]);
    eq(plan.picker[0].suggestedKey, null, 'must not guess:');
    if (plan.picker[0].mentions.length < 2)
      throw new Error('both mentions must still be shown to the reader');
  });
  t('an unresolved picker entry contributes no claims', () => {
    const plan = IMP.planAdjImport(
      [src({ pn:'P3', claimNo:'AC-3', narr:'no identifiers here' })],
      [R('P3','A1234','missing','ok'), R('P3','B5678','missing','ok')]);
    eq(IMP.finalizeAdjImport(plan).length, 0, 'nothing may be applied unchosen:');
    plan.picker[0].chosenKey = 'P3||B5678';
    eq(IMP.finalizeAdjImport(plan).length, 1, 'and one claim once chosen:');
  });

  console.log('\n== The plan sorts every row into a visible bucket ==');
  t('auto, picker, no-action and rejected are all accounted for', () => {
    const results = [R('P1','TOP','missing','ok'),
                     R('P3','A1234','missing','ok'), R('P3','B5678','missing','ok'),
                     R('P4','A','ok','ok')];
    const plan = IMP.planAdjImport([
      src({ pn:'P1', claimNo:'AC-1' }), src({ pn:'P3', claimNo:'AC-3' }),
      src({ pn:'P4', claimNo:'AC-4' }), src({ pn:'P9', claimNo:'AC-9' })], results);
    eq(plan.sourceRows, 4);
    eq([plan.claims.length, plan.picker.length, plan.noAction.length, plan.rejected.length],
       [1, 1, 1, 1]);
  });
  t('blank lines are ignored without inflating the count', () => {
    eq(IMP.planAdjImport([new Array(20).fill(''), src({ pn:'P1', claimNo:'AC-1' })],
                         [R('P1','TOP','missing','ok')]).sourceRows, 1);
  });

  console.log('\n== CM\u2019s CI-to-NCR claims are out of scope for an ME batch ==');
  t('a CI-to-NCR trace is never treated as an imported claim', () => {
    // Belt and braces: an imported batch could only carry createdFrom
    // 'external_import', but deleting another team's work would be silent and
    // serious, so the claim TYPE is checked as well as its provenance.
    eq(IMP.isImportedClaim({ id:'a', type:'ncr_ci_trace', createdFrom:'ncr_ci_helper' }), false);
    eq(IMP.isImportedClaim({ id:'x', type:'ncr_ci_trace', createdFrom:'external_import' }), false,
       'type must veto provenance:');
    eq(IMP.isImportedClaim({ id:'x', type:'ebom_ncr_trace', createdFrom:'external_import' }), false);
    eq(IMP.isImportedClaim({ id:'y', type:'row', createdFrom:'external_import' }), true);
  });
  t('a re-import cannot withdraw a CM trace', () => {
    const cm = { id:'adj_ci_9', type:'ncr_ci_trace', createdFrom:'ncr_ci_helper',
                 rowKey:'P1||TOP', leg:'abom', claimedQty:4, applied:true,
                 mode:'embodiment', ciKey:'CI-77||P1||TOP', reason:'ncr_ci_manual_trace' };
    const me = { id:'imp_1', type:'row', createdFrom:'external_import', rowKey:'P1||TOP',
                 leg:'mbom', claimedQty:4, applied:true, reason:'mbom_missing' };
    const rows = [{ key:'P1||TOP', pn:'P1', nh:'TOP', eq:4, ms:'missing', as:'missing',
                    msUsedOn:'n/a', asUsedOn:'n/a', overall:'missing' }];
    const after = IMP.replaceImportedClaims([cm, me], []);
    eq(after.map(c => c.id), ['adj_ci_9'], 'only the ME claim is withdrawn:');
    const r = IMP.computeEffectiveResults(rows, after)[0];
    eq(r.ms, 'missing', 'the ME claim is gone:');
    eq(r.as, 'direct_adjudicated', 'the CM trace still resolves the ABOM leg:');
  });
  t('the two organisations\u2019 work is reported separately', () => {
    const p = IMP.partitionClaims([
      { id:'a', type:'ncr_ci_trace', createdFrom:'ncr_ci_helper' },
      { id:'b', type:'row', createdFrom:'external_import' },
      { id:'c', type:'row', createdFrom:'qty_modal' }]);
    eq([p.imported.length, p.native.length, p.ciNcr.length], [1, 2, 1]);
  });

  console.log('\n== Staging has to drive the workbench, not just the array ==');
  t('every path that adds claims refreshes the workbench', () => {
    // v164 — the workbench is what applies claims, and it only re-reads
    // state.adjudications when told. stageAdjImport pushed claims and told
    // nobody, so Process Adjudications stayed greyed out and the staged claims
    // could not be applied at all. Every NATIVE claim path calls
    // _adjRefreshWorkbench; the import path must too.
    const paths = ['_adjSubmitClaim', '_adjSubmitNcrCiClaim', '_adjSubmitEbomNcrClaim',
                   'stageAdjImport'];
    const missing = paths.filter(fn => {
      let body;
      try { body = grabFn(fn).replace(/\/\/[^\n]*/g, ''); } catch (e) { return true; }
      return !/_adjRefreshWorkbench\s*\(/.test(body);
    });
    if (missing.length)
      throw new Error('claims can be added without refreshing the workbench: ' + missing.join(', '));
  });
  t('staging reveals the workbench even when the run produced no candidates', () => {
    // The section is hidden unless the reconciliation surfaced helper
    // candidates of its own. An import can be the only source of claims, so
    // staging must reveal it or the button is not merely disabled — it is
    // nowhere on the page.
    // Strip comments first: the body explains WHY it calls _adjShowWorkbench,
    // and matching that prose made this test pass against a build where the
    // call itself had been removed.
    const body = grabFn('stageAdjImport').replace(/\/\/[^\n]*/g, '');
    if (!/_adjShowWorkbench\s*\(/.test(body))
      throw new Error('staging does not reveal the workbench section');
  });
  t('the Process button enables on any pending claim, whatever its origin', () => {
    // The gate is origin-agnostic by design: pending count, not claim type.
    const wb = grabFn('_adjRefreshWorkbench');
    if (!/btnProc\.disabled = pending === 0/.test(wb))
      throw new Error('the Process gate is no longer a simple pending count');
    if (/createdFrom|external_import/.test(wb))
      throw new Error('the Process gate must not discriminate by claim origin');
  });

  console.log('\n== The review panel is built around the exceptions ==');
  t('every bucket is surfaced in the panel', () => {
    const ui = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    ['auto-resolved', 'need a decision', 'no action needed', 'not in this EBOM'].forEach(b => {
      if (ui.indexOf(b) < 0) throw new Error('the panel does not report: ' + b);
    });
  });
  t('the panel states that CM claims are untouched', () => {
    const ui = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    if (ui.indexOf('NCR trace claim') < 0)
      throw new Error('the panel must say CI-to-NCR traces survive the import');
  });
  t('staging refuses while the report is frozen, and uses the scoped replace', () => {
    const body = SRC.slice(at('function stageAdjImport'), at('function discardAdjImport'));
    if (body.indexOf('state.isLocked') < 0) throw new Error('staging can alter a frozen report');
    if (body.indexOf('replaceImportedClaims') < 0)
      throw new Error('staging must go through the scoped replace');
  });
  t('an ME file loaded before a run is refused with a reason', () => {
    const h = SRC.slice(at('function handleFile'), at('function handleFile') + 12000);
    const i = h.indexOf("if (type === 'adj')");
    if (i < 0) throw new Error('the adj hook is gone from handleFile');
    const seg = h.slice(i, i + 800);
    if (seg.indexOf('state.results') < 0 || seg.indexOf('showError') < 0)
      throw new Error('loading before a run must be refused, not silently planned');
  });
  t('the picker shows the matched sentence, full narrative on request', () => {
    const q = SRC.slice(at('function _adjQueueHtml'), at('function setAdjFilter'));
    if (q.indexOf('m.sentence') < 0) throw new Error('the matched sentence is not shown');
    if (q.indexOf('full narrative') < 0)
      throw new Error('the full narrative must stay available behind a disclosure');
    if (q.indexOf('adj-sug-tag') < 0) throw new Error('the suggestion is not marked');
  });

  console.log('\n== It has to survive a real file ==');
  t('a 3,000-row import against an 80k-line EBOM stays responsive', () => {
    // A real ME export runs to ~3,000 rows. Resolving each by scanning the full
    // result set is O(rows x results) — measured at 3.2s on an 80k EBOM, which
    // freezes the tab. planAdjImport indexes by part number first.
    const results = [];
    for (let i = 0; i < 80000; i++) {
      const fail = i % 12 === 0;
      results.push({ key: 'PN' + i + '||NH' + (i % 900), pn: 'PN' + i, nh: 'NH' + (i % 900),
        eq: 2, ms: fail ? 'missing' : 'ok', as: 'ok', msUsedOn: 'n/a', asUsedOn: 'n/a',
        overall: fail ? 'missing' : 'ok' });
    }
    const rows = [];
    for (let i = 0; i < 3000; i++) {
      const r = new Array(20).fill('');
      r[C.pn] = 'PN' + ((i * 12) % 80000); r[C.claimNo] = 'AC-' + i;
      r[C.narrative] = 'Reviewed the planning package. Installed on DWO ' + (4400000 + i) + '.';
      rows.push(r);
    }
    const t0 = Date.now();
    const plan = IMP.planAdjImport(rows, results);
    const ms = Date.now() - t0;
    eq(plan.claims.length, 3000, 'every row resolved:');
    if (ms > 1500) throw new Error('planAdjImport took ' + ms + 'ms — the tab would freeze');
  });
  t('the planner indexes by part number rather than rescanning', () => {
    // Structural, so the guarantee survives even on a fast machine where the
    // timing test above would pass anyway.
    if (!/function indexResultsByPn/.test(SRC))
      throw new Error('the part-number index is gone');
    const body = SRC.slice(at('function planAdjImport'), at('function finalizeAdjImport'));
    if (body.indexOf('indexResultsByPn(results)') < 0)
      throw new Error('planAdjImport no longer builds the index');
    // Building the index is not enough — it must be PASSED to the resolver.
    // The first version of this test checked only that it was built, and passed
    // while the planner rescanned per row and took 3s.
    if (!/resolveImportedAdjRow\([^)]*pnIndex\)/.test(body))
      throw new Error('the index is built but not passed to resolveImportedAdjRow');
  });

  console.log('\n== Re-import replaces the batch, never the native work ==');
  t('a second import drops the previous batch only', () => {
    const native = { id:'adj_ci_9', createdFrom:'ncr_ci_helper', rowKey:'P2||TOP', leg:'abom' };
    const first  = [{ id:'imp_1', createdFrom:'external_import' },
                    { id:'imp_2', createdFrom:'external_import' }, native];
    const out = IMP.replaceImportedClaims(first, [{ id:'imp_3', createdFrom:'external_import' }]);
    eq(out.map(c => c.id), ['adj_ci_9', 'imp_3']);
  });
  t('a withdrawn claim reverts its row', () => {
    const rows = [R('P1','TOP','missing','ok')];
    const c = IMP.buildImportedClaims({ claimNo:'AC-1' }, rows[0])
      .map(x => Object.assign({}, x, { applied: true }));
    eq(IMP.computeEffectiveResults(rows, c)[0].overall, 'direct_adjudicated');
    eq(IMP.computeEffectiveResults(rows, IMP.replaceImportedClaims(c, []))[0].overall, 'missing',
       'dropping the claim must restore the raw status:');
  });
  t('every native provenance value survives a replace', () => {
    // v178 — derived from the build. The hand-written list named seven and the
    // build has eight: missing_abom was absent, and the test still passed.
    const vals = createdFromValues();
    vals.delete('external_import');
    if (vals.size < 8) throw new Error('only ' + vals.size + ' native provenance values found');
    const natives = [...vals].map((cf, i) => ({ id: 'n' + i, createdFrom: cf }));
    const out = IMP.replaceImportedClaims(
      natives.concat([{ id:'imp_1', createdFrom:'external_import' }]), []);
    eq(out.length, natives.length);
  });
});

suite('NCR dispositions without EBOM trace — one row per disposition', (t, eq) => {
  let SHEET = null;
  const ctx = sandbox({
    XLSX:{utils:{book_new:()=>({}),aoa_to_sheet:a=>{SHEET=a;return{};},book_append_sheet:()=>{}},writeFile:()=>{}},
    COL:{ncr:{ncrNum:60,ncrStatus:61,originatingWo:62,discrepantPart:63,discNum:64,discStatus:65,
      discSummary:66,defectQty:67,causeCode:68,causeCodeDesc:69,defectCode:74,defectCodeDesc:75,
      discrepancyText:70,dispNo:71,dispStatus:72,dispType:76,dispCode:77,dispText:82}},
    state:{results:[],boms:{ncr:null}} }, ['ncr']);
  const M = ctx.N, COL = ctx.COL, state = ctx.state;
  function nrow(o){const r=new Array(90).fill('');const N=COL.ncr;
   r[N.ncrNum]=o.ncr;r[N.dispNo]=o.disp;r[N.ncrStatus]=o.ncrStatus||'OPEN';
   r[N.dispStatus]=o.dispStatus||'WORKING';r[N.discrepantPart]=o.part||'';
   r[N.originatingWo]=o.wo||'';r[N.dispText]=o.text||'';return r;}
  function run(ncrRows,results){state.boms.ncr={data:ncrRows};
   state.results=(results&&results.length)?results:[{ncrEntriesPool1:[],ncrEntriesPool2:[]}];
   SHEET=null;M.exportUntracedNcrDispositions();
   const hi=SHEET.findIndex(r=>r[0]==='NCR Number');
   return {hdr:SHEET[hi],rows:SHEET.slice(hi+1),meta:Object.fromEntries(SHEET.filter(r=>r.length===2).map(r=>[r[0],r[1]]))};}

  console.log('\n== Grain: one row per disposition number ==');
  t('4 file rows for 1 disposition collapse to 1 export row', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'}),
                 nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'})]);
    eq(r.rows.length,1,'export rows:');
    eq(r.meta['Dispositions without EBOM trace'],1);
    eq(r.meta['Source NCR file rows'],4,'source count still reported:');
    eq(r.rows[0][18],4,'Source Rows Merged:');
  });
  t('distinct dispositions under one NCR stay separate', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N1',disp:'D2'}),nrow({ncr:'N1',disp:'D3'})]);
    eq(r.rows.length,3);
    eq(r.rows.map(x=>x[1]),['D1','D2','D3']);
  });
  t('same disposition number under different NCRs stays separate', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D1'})]);
    eq(r.rows.length,2,'must not collapse across NCRs:');
  });
  t('differing values are joined, not dropped', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P2'})]);
    eq(r.rows.length,1);
    eq(r.rows[0][8],'P1 | P2','discrepant parts merged:');
    eq(r.rows[0][18],2);
  });
  t('identical values do not duplicate in the join', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'})]);
    eq(r.rows[0][8],'P1');
  });
  t('Source Rows Merged is 1 when nothing collapsed', ()=>{
    eq(run([nrow({ncr:'N1',disp:'D1'})]).rows[0][18],1);
  });

  console.log('\n== Predicate matches the on-screen helper ==');
  t('a traced disposition is excluded', ()=>{
    const res=[{ncrEntriesPool1:[{ncrNum:'N1',dispNo:'D1'}],ncrEntriesPool2:[]}];
    eq(run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D9'})],res).rows.length,1);
  });
  t('Pool 2 traces also exclude', ()=>{
    const res=[{ncrEntriesPool1:[],ncrEntriesPool2:[{ncrNum:'N1',dispNo:'D1'}]}];
    eq(run([nrow({ncr:'N1',disp:'D1'})],res).rows.length,0);
  });
  t('CANCELLED NCRs are excluded', ()=>{
    eq(run([nrow({ncr:'N1',disp:'D1',ncrStatus:'CANCELLED'}),nrow({ncr:'N2',disp:'D2'})]).rows.length,1);
  });
  t('export count equals the helper count', ()=>{
    const rows=[nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D2'})];
    state.boms.ncr={data:rows};state.results=[{ncrEntriesPool1:[],ncrEntriesPool2:[]}];
    const helper=M.computeUntracedNcrs().length;
    const r=run(rows);
    eq(helper,3,'helper is per file row:');
    eq(r.rows.length,2,'export is per disposition:');
    eq(r.meta['Source NCR file rows'],helper,'and reconciles to the helper:');
  });
  t('sorted by NCR then disposition, numerically', ()=>{
    const r=run([nrow({ncr:'N10',disp:'D2'}),nrow({ncr:'N2',disp:'D10'}),nrow({ncr:'N2',disp:'D2'})]);
    eq(r.rows.map(x=>x[0]+'/'+x[1]),['N2/D2','N2/D10','N10/D2']);
  });
  t('empty result set produces headers and a zero count', ()=>{
    const res=[{ncrEntriesPool1:[{ncrNum:'N1',dispNo:'D1'}],ncrEntriesPool2:[]}];
    const r=run([nrow({ncr:'N1',disp:'D1'})],res);
    eq(r.rows.length,0); eq(r.meta['Dispositions without EBOM trace'],0);
  });
});

suite('ECN footprint completeness', (t, eq) => {
  const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3},chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
    state:{results:[],boms:{ebom:null,chp:null}} }, ['proc','engine','chp','chpalign','ecn']);
  const B = ctx.B, state = ctx.state, normPN = ctx.E.normPN;
  function R(pn,nh,o){o=o||{};return{key:normPN(pn)+'||'+normPN(nh),pn,nh,overall:'ok',as:'ok',
   woStatus:o.wo===undefined?'closed':o.wo,woValues:['W1'],
   trace:o.ecn?{dcn:new Map(),ecn:new Map(o.ecn),ecr:new Map()}:null,
   ncrEntriesPool1:o.ncr||[],ncrEntriesPool2:[]};}
  const chpRow=(pn,nh,ecn)=>{const r=new Array(25).fill('');r[3]=pn;r[5]=nh;r[18]=ecn;return r;};

  console.log('\n== The completeness hole is now closed ==');
  t('CHP lists 12, only 9 joined: ECN NO LONGER recommended', ()=>{
    const rows=[];for(let i=1;i<=9;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;state.boms.ebom=null;
    state.boms.chp={data:Array.from({length:12},(_,i)=>chpRow('P'+(i+1),'A','E1'))};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.allAccepted,true,'joined items all fine:');
    eq(e.complete,false,'but footprint incomplete:');
    eq(e.chpItemCount,12); eq(e.items.length,9);
    eq(e.unjoined,['P10','P11','P12'],'unmatched parts named:');
  });
  t('all 12 join: ECN qualifies', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    state.boms.chp={data:Array.from({length:12},(_,i)=>chpRow('P'+(i+1),'A','E1'))};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq([e.allAccepted,e.complete],[true,true]);
  });
  t('the two failure reasons stay distinguishable', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']],wo:'open'})];
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('P9','A','E1')]};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.allAccepted,false,'unembodied item:'); eq(e.complete,false,'AND missing item:');
  });
  t('PN-only matching: different NH still counts as joined', ()=>{
    state.results=[R('P1','ASSY-X',{ecn:[['E1','']]})];
    state.boms.chp={data:[chpRow('P1','ASSY-Y','E1')]};
    eq(B.buildEcnFootprints().ecnMap.get('E1').complete,true,'NH mismatch must not false-alarm:');
  });
  t('no CHP loaded: degrades without false alarms', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]})]; state.boms.chp=null;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq([e.complete,e.chpItemCount],[true,0]);
  });
  t('inherited COTS children count toward coverage', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]}),R('C1','P1',{})];
    state.boms.ebom={data:[[0,'P1',0,'A'],[0,'C1',0,'P1']].map(r=>{const x=new Array(30).fill('');x[1]=r[1];x[3]=r[3];return x;})};
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('C1','P1','E1')]};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.complete,true,'child joined via inheritance:'); eq(e.items.length,2);
  });
  t('incompleteEcns is counted for the report footer', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]})]; state.boms.ebom=null;
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('P2','A','E1')]};
    eq(B.buildEcnFootprints().incompleteEcns,1);
  });
});

suite('Many EBOM line items to one ECN', (t, eq) => {
  const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3},chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
    state:{results:[],boms:{ebom:null,chp:null}} }, ['proc','engine','chp','chpalign','ecn']);
  const B = ctx.B, state = ctx.state, normPN = ctx.E.normPN;
  function R(pn,nh,o){o=o||{};return{key:normPN(pn)+'||'+normPN(nh),pn,nh,overall:'ok',as:'ok',
   woStatus:o.wo===undefined?'closed':o.wo,woValues:['W1'],
   trace:o.ecn?{dcn:new Map(),ecn:new Map(o.ecn),ecr:new Map()}:null,
   ncrEntriesPool1:o.ncr||[],ncrEntriesPool2:[]};}

  console.log('\n== Many EBOM line items -> one ECN ==');
  t('12 items all embodied: ECN qualifies', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','OPEN']]}));
    state.results=rows;state.boms.ebom=null;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,12,'footprint size:');eq(e.allAccepted,true);
  });
  t('12 items, ONE open WO: ECN excluded', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','OPEN']],wo:i===7?'open':'closed'}));
    state.results=rows;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,12);eq(e.allAccepted,false,'one bad item must exclude:');
    eq(e.items.filter(x=>!x.accepted).length,1);
  });
  t('12 items, ONE open disposition: ECN excluded', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']],
      ncr:i===3?[{ncrNum:'N1',dispNo:'D1',dispStatus:'WORKING'}]:[]}));
    state.results=rows;
    eq(B.buildEcnFootprints().ecnMap.get('E1').allAccepted,false);
  });
  t('order independent: bad item first still excludes', ()=>{
    const rows=[R('P1','A',{ecn:[['E1','']],wo:'open'})];
    for(let i=2;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    eq(B.buildEcnFootprints().ecnMap.get('E1').allAccepted,false);
  });
  t('an item on TWO ECNs blocks both', ()=>{
    state.results=[R('P1','A',{ecn:[['E1',''],['E2','']],wo:'open'}),R('P2','A',{ecn:[['E1','']]})];
    const m=B.buildEcnFootprints().ecnMap;
    eq(m.get('E1').allAccepted,false);eq(m.get('E2').allAccepted,false);
  });

  console.log('\n== COMPLETENESS: can a CHP-listed item be missing from the footprint? ==');
  t('CHP lists 12 items for E1 but only 9 are EBOM result rows', ()=>{
    // Simulates: CHP file rows for P1..P12 under E1, but P10-P12 have no EBOM
    // result row (no key match). Those three never enter the footprint.
    const rows=[];for(let i=1;i<=9;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,9,'footprint sees only the joined rows:');
    eq(e.allAccepted,true,'and therefore RECOMMENDS closure:');
    console.log('        >> CHP says 12 items, footprint counted 9, ECN recommended anyway');
  });
});

suite('Stylesheet and chrome integrity', (t, eq) => {
  const css = STYLE_BLOCKS.map(b => b.css).join('\n');   // ALL blocks, not just the first

  console.log('\n== The slice is CSS, not the vendored spreadsheet library ==');
  t('the naive "<style" search still lands inside vendored JavaScript', () => {
    // Documents the trap this suite fell into for its whole existence. If
    // SheetJS is ever removed and this starts failing, the guarded regex in
    // STYLE_BLOCKS can be simplified — but not before.
    const naive = SRC.indexOf('<style');
    if (naive === STYLE_BLOCKS[0].at)
      throw new Error('naive search is now safe — re-check whether the guard is still needed');
    if (!/^<style:/.test(SRC.slice(naive, naive + 8)))
      throw new Error('naive search hit something unexpected: ' + JSON.stringify(SRC.substr(naive, 40)));
  });
  t('every extracted block is a stylesheet, not markup', () => {
    STYLE_BLOCKS.forEach((b, i) => {
      if (b.css.includes('<style') || b.css.includes('<script'))
        throw new Error('block ' + (i + 1) + ' contains markup — the slice is wrong');
      if (!b.css.includes('{'))
        throw new Error('block ' + (i + 1) + ' has no rules at all');
    });
  });
  t('both style blocks are found and neither is trivial', () => {
    eq(STYLE_BLOCKS.length, 2, 'block count:');
    STYLE_BLOCKS.forEach((b, i) => { if (b.css.length < 500)
      throw new Error('block ' + (i + 1) + ' is only ' + b.css.length + ' chars'); });
  });

  console.log('\n== Brace balance: an assertion, not a baseline ==');
  t('every style block is brace-balanced', () => {
    // Replaces the old "delta must equal -2". That -2 was never a real
    // imbalance; it was minified JS being counted as CSS. Both real blocks
    // balance exactly, so the correct expectation is zero.
    STYLE_BLOCKS.forEach((b, i) => {
      const r = scanCss(b.css);
      if (r.balanced) return;
      const fileLine = l => l + b.line - 1;
      const parts = [];
      if (r.unmatchedOpen.length)  parts.push('unclosed rule opened at file line(s) ' +
        r.unmatchedOpen.map(fileLine).join(', '));
      if (r.unmatchedClose.length) parts.push('stray closing brace at file line(s) ' +
        r.unmatchedClose.map(fileLine).join(', '));
      throw new Error('block ' + (i + 1) + ': ' + parts.join('; '));
    });
  });
  t('the scanner ignores braces inside quoted strings', () => {
    eq(scanCss('a{content:"{"}').balanced, true, 'quoted open:');
    eq(scanCss("a{content:'}'}").balanced, true, 'quoted close:');
  });
  t('the scanner ignores braces inside comments', () => {
    eq(scanCss('a{color:red} /* } stray in a comment { */').balanced, true);
  });
  t('a stray closing brace is caught and located', () => {
    const r = scanCss('a{color:red}\nb{color:blue}\n}\n');
    eq([r.balanced, r.unmatchedClose], [false, [3]], 'line of the stray }:');
  });
  t('an unclosed rule is caught and located', () => {
    const r = scanCss('a{color:red}\n\nb{color:blue;\n');
    eq([r.balanced, r.unmatchedOpen], [false, [3]], 'line of the unclosed {:');
  });
  t('one stray open and one stray close do not cancel out', () => {
    // A net-delta counter reports 0 here and passes. This is why the check
    // tracks positions rather than a total.
    const r = scanCss('}\na{color:red\n');
    eq(r.balanced, false, 'a delta-based check would have said 0:');
  });

  console.log('\n== Variables and keyframes, across every block ==');
  t('no orphaned keyframes remain', () => {
    const defs = [...new Set([...css.matchAll(/@keyframes\s+([\w-]+)/g)].map(m => m[1]))];
    const orphans = defs.filter(k => !new RegExp('animation:[^;]*\\b' + k + '\\b').test(SRC));
    if (orphans.length) throw new Error('orphans: ' + orphans.join(', '));
  });
  t('--text-dim is fully retired', () => {
    if (SRC.includes('var(--text-dim)')) throw new Error('references remain');
    if (/^\s*--text-dim:/m.test(SRC)) throw new Error('definition remains');
  });
  t('no CSS var is referenced without a definition', () => {
    const defined = new Set([...css.matchAll(/^\s*(--[\w-]+):/gm)].map(m => m[1]));
    const used = new Set([...SRC.matchAll(/var\((--[\w-]+)\)/g)].map(m => m[1]));
    const missing = [...used].filter(v => !defined.has(v));
    if (missing.length) throw new Error('undefined vars used: ' + missing.join(', '));
  });

  console.log('\n== The import zone lives where the workflow needs it ==');
  t('the ME ADJ zone sits inside the Adjudication Workbench, not the upload grid', () => {
    // v166 — an ME export is not reconciliation INPUT: it is a batch of claims
    // about a run that must already exist. In the upload grid it read as a
    // tenth BOM source and the ordering had to be enforced with an error.
    // Inside the workbench the ordering enforces itself.
    const secA = at('id="adjudication-workbench-section"');
    const secB = at('<!-- /adjudication-workbench-section -->');
    const zone = at('id="zone-adj"');
    if (zone < secA || zone > secB)
      throw new Error('the ME ADJ zone is outside the Adjudication Workbench section');
    const panel = at('id="adj-import-panel"');
    if (panel < secA || panel > secB)
      throw new Error('the import review panel is outside the workbench section');
  });
  t('it sits between the Candidates Helpers and the Claim Ledger', () => {
    const helpers = at('id="kpi-adjudication-zone"');
    const imp     = at('id="adj-import-zone-wrap"');
    const ledger  = at('id="adj-workbench"');
    if (!(helpers < imp && imp < ledger))
      throw new Error('the import block is not between discovery and execution');
  });
  t('the upload grid no longer carries a tenth zone', () => {
    const grid = SRC.slice(at('id="zone-ebom"'), at('id="adjudication-workbench-section"'));
    if (grid.indexOf('id="zone-adj"') >= 0)
      throw new Error('the ME ADJ zone is still in the pre-run upload grid');
  });
  t('the workbench section appears after ANY completed run', () => {
    // A run with no helper candidates is exactly when an SME may still want to
    // import ME's decisions. Gating on "something to adjudicate" would hide the
    // upload zone precisely then.
    const fn = SRC.slice(at('const unifiedSec = document.getElementById'),
                         at('const unifiedSec = document.getElementById') + 1400);
    if (!/hasRun/.test(fn))
      throw new Error('section visibility still ignores whether a run exists');
    if (!/state\.results && state\.results\.length/.test(fn))
      throw new Error('hasRun is not derived from the results');
  });

  console.log('\n== The three workbench blocks read as three blocks ==');
  t('Imported Claims is enclosed like the Claim Ledger', () => {
    // v167 — without a border it read as a continuation of the Candidates
    // Helpers above, which is a different activity: helpers find candidates in
    // THIS run; imports bring in decisions taken elsewhere.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const m = css.match(/#adj-import-zone-wrap\s*\{([^}]*)\}/);
    if (!m) throw new Error('the import block has no enclosure rule');
    ['border', 'padding', 'border-radius'].forEach(prop => {
      if (m[1].indexOf(prop) < 0) throw new Error('the enclosure is missing ' + prop);
    });
  });
  t('each block carries exactly ONE subhead', () => {
    // v169 — the Candidates Helpers zone already had a subhead INSIDE it, and
    // v167 added a second outside. Both rendered, giving the reader
    // "Candidates Helpers Candidates Helpers". Counting, not just presence.
    const sec = SRC.slice(at('id="adjudication-workbench-section"'),
                          at('<!-- /adjudication-workbench-section -->'));
    const found = [...sec.matchAll(/adj-section-subhead">([^<]+)</g)].map(m => m[1].trim());
    ['Candidates Helpers', 'Imported Claims'].forEach(h => {
      const n = found.filter(x => x === h).length;
      if (n === 0) throw new Error('no subhead for ' + h);
      if (n > 1) throw new Error(h + ' has ' + n + ' subheads — it will render twice');
    });
  });

  console.log('\n== Staging says what it did, and is repeatable ==');
  t('re-staging preserves claims that were already applied', () => {
    // Staging rebuilds the whole imported batch and replaceImportedClaims swaps
    // the old one out. Without carrying the applied flag forward by id, a
    // second stage would silently REVERT everything already applied.
    const body = grabFn('stageAdjImport').replace(/\/\/[^\n]*/g, '');
    if (body.indexOf('wasApplied') < 0)
      throw new Error('re-staging does not preserve applied state');
    if (!/c\.applied\s*=\s*true/.test(body))
      throw new Error('the applied flag is never carried forward');
    if (!/isImportedClaim\(c\)\s*&&\s*c\.applied/.test(body))
      throw new Error('applied state must be carried for IMPORTED claims only');
  });
  t('the import panel refreshes whenever claim state changes', () => {
    // v170 — the panel reports how many of ITS claims are applied vs pending,
    // so it goes stale the moment anything applies, reverts or removes a claim.
    // It said "none applied yet" for ever, because Process never told it.
    // Hung off _adjRefreshWorkbench, which EVERY state-changing path already
    // calls, so no path can forget it — patching each caller would have left
    // the next one to be written broken again.
    const wb = grabFn('_adjRefreshWorkbench').replace(/\/\/[^\n]*/g, '');
    if (!/renderAdjImportPanel\s*\(/.test(wb))
      throw new Error('the import panel is not refreshed from the shared refresh point');
    // and every state-changing path must go through that point
    ['_adjProcessClaims', '_adjRevertClaims', '_adjConfirmRemove', 'stageAdjImport'].forEach(fn => {
      const body = grabFn(fn).replace(/\/\/[^\n]*/g, '');
      if (!/_adjRefreshWorkbench\s*\(/.test(body))
        throw new Error(fn + ' changes claim state without refreshing');
    });
  });
  t('refreshing cannot recurse', () => {
    // renderAdjImportPanel must not call back into _adjRefreshWorkbench.
    const panel = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    if (/_adjRefreshWorkbench\s*\(/.test(panel))
      throw new Error('the panel calls the refresher that calls it');
  });
  t('the panel reports what is already in the ledger', () => {
    const ui = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    if (ui.indexOf('adj-staged-state') < 0)
      throw new Error('the panel gives no confirmation that staging happened');
    ['already applied', 'pending'].forEach(bit => {
      if (ui.indexOf(bit) < 0) throw new Error('the confirmation omits: ' + bit);
    });
  });
  t('the button changes once a batch is staged', () => {
    const ui = SRC.slice(at('function renderAdjImportPanel'), at('function _adjQueueHtml'));
    if (ui.indexOf('Re-stage') < 0)
      throw new Error('the action button never becomes a re-stage');
    if (!/newSinceStage/.test(ui))
      throw new Error('the button does not distinguish new decisions from none');
  });

  console.log('\n== The funnel legend matches the bars it describes ==');
  const FUNNEL = (() => {
    const a = at('<div id="funnel-info-overlay"');
    let d = 0, i = a;
    for (;;) {
      if (SRC.startsWith('<div', i)) d++;
      else if (SRC.startsWith('</div>', i)) { d--; if (!d) break; }
      i++;
      if (i > a + 40000) throw new Error('the funnel overlay never closes');
    }
    return SRC.slice(a, i + 6);
  })();
  const RESSEGS = (() => {
    const a = at('const resSegs = [');
    const seg = SRC.slice(a, at('].filter', a));
    const out = {};
    [...seg.matchAll(/color:\s*([^,]+),\s*w:[^,]+,\s*stage:[^,]+,\s*count:[^,]+,\s*lbl:\s*'([^']+)'/g)]
      .forEach(m => { out[m[2].trim()] = m[1].trim(); });
    return out;
  })();

  t('the legend draws no emoji swatches', () => {
    // v167 — #11. The legend used 🟥 🟧 🟪 🟨 ⬛ ▒, none of which were tied to the
    // colours the bars use. THREE of them stood for the same token (--warn),
    // teaching a distinction the chart does not draw.
    const emoji = FUNNEL.match(/[\u{1F7E0}-\u{1F7EB}\u2B1B\u2592]/gu);
    if (emoji) throw new Error('emoji swatches are back: ' + [...new Set(emoji)].join(' '));
    if (!/class="fn-sw"/.test(FUNNEL))
      throw new Error('the legend has no token-driven swatches');
  });
  t('every colour the residual bar uses appears in the legend', () => {
    const tokens = new Set(Object.values(RESSEGS)
      .map(v => v.replace(/^'|'$/g, ''))
      .map(v => v === 'C.missing' ? 'var(--danger)'
              : v === 'C.qty'     ? 'var(--warn)'
              : v === 'C.other'   ? 'var(--text-muted)' : v));
    const shown = new Set([...FUNNEL.matchAll(/class="fn-sw" style="background:([^"]+)"/g)].map(m => m[1]));
    const missing = [...tokens].filter(t2 => !shown.has(t2));
    if (missing.length)
      throw new Error('residual colours with no legend swatch: ' + missing.join(', '));
  });
  t('WO Not Closed is shown as the two colours it actually draws', () => {
    // The segment is SPLIT: teal for RFV-authorised open WOs, amber for bare.
    // One swatch cannot represent it.
    const m = FUNNEL.match(/(?:<span class="fn-sw"[^>]*><\/span>\s*){1,3}<strong>WO Not Closed<\/strong>/);
    if (!m) throw new Error('the WO Not Closed legend entry moved');
    const n = (m[0].match(/fn-sw/g) || []).length;
    if (n !== 2) throw new Error('WO Not Closed shows ' + n + ' swatch(es); the bar draws two colours');
    // v173 — the bare half moved from --warn to --wo-open. The token existed
    // and was named for exactly this, but the WO NOT CLOSED badge used --warn,
    // so open WO / proc removed / qty mismatch all drew one amber.
    ['var(--rfv)', 'var(--wo-open)'].forEach(t2 => {
      if (m[0].indexOf(t2) < 0) throw new Error('the split entry is missing ' + t2);
    });
  });
  t('reference bars are described as uncoloured, because they are', () => {
    // Every reference bar renders in one neutral fill: they are context, not
    // findings. Giving them category colours in the legend was the worst of the
    // errors — colour where the tool draws none.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const fill = css.match(/\.funnel-bar-fill-ref\s*\{[^}]*background:\s*([^;]+)/);
    if (!fill) throw new Error('the reference bar fill rule is gone');
    const neutral = fill[1].trim();
    ['Part Qty Mismatch', 'Part WO Not Closed'].forEach(lbl => {
      // Locate the legend paragraph by its label, then read the swatch that
      // immediately precedes it. A regex over the whole modal matched an
      // unrelated 'EBOM-MBOM Part Qty Mismatch' bullet instead.
      const at2 = FUNNEL.indexOf('<strong>' + lbl + '</strong>');
      if (at2 < 0) throw new Error('no legend entry for ' + lbl);
      const before = FUNNEL.slice(Math.max(0, at2 - 120), at2);
      const sw = before.match(/background:([^"]+)"><\/span>$/);
      if (!sw) throw new Error(lbl + ' has no swatch immediately before it');
      if (sw[1] !== neutral)
        throw new Error(lbl + ' is shown as ' + sw[1] + ' but reference bars render ' + neutral);
    });
    if (FUNNEL.indexOf('deliberately uncoloured') < 0)
      throw new Error('the legend does not say reference bars carry no category colour');
  });

  console.log('\n== The residual is measured, not just divided ==');
  (() => {
    const RES = SRC.slice(at('const resSegs = ['), at('funnel-residual-rows'));
    t('no residual row sets flex, which would override its width', () => {
      // THE defect. Each segment carried width:${s.w}% AND flex:${s.count}.
      // `flex:N` is shorthand for flex-grow:N flex-shrink:1 flex-basis:0%, and
      // that basis beats the width declaration outright. Every computed width
      // was dead code and the track always filled 100%, so a residual of 3 and
      // a residual of 3,000 drew an identical bar. Nothing in the suite noticed
      // because Tier 11 executes the CANVAS renderers; this one is HTML.
      if (/flex:\$\{/.test(RES))
        throw new Error('a residual row sets flex from a count — widths are dead again');
    });
    t('residual widths are on the same axis as the coverage ladder', () => {
      // Both must be a share of scopeN, or a residual row and a ladder bar of
      // equal length mean different things in the same panel.
      const decl = [...SRC.slice(at('const missPct'), at('const resSegs = ['))
        .matchAll(/const\s+\w+Pct\s*=\s*([^;]+);/g)].map(m => m[1].trim());
      if (!decl.length) throw new Error('the residual percentage block moved');
      const bad = decl.filter(d => !/^pct\(/.test(d));
      if (bad.length)
        throw new Error('residual widths not measured against scope: ' + bad.join(' | '));
    });
    t('every residual category is measured, including Other', () => {
      // `other` used to be a rounding remainder (pRes minus the rest), so its
      // label and its geometry could disagree. It is a real count; measure it.
      if (/othPct\s*=\s*Math\.max/.test(SRC))
        throw new Error('Other is back-filled from a remainder instead of counted');
    });
    t('each residual category renders its own labelled row', () => {
      ['funnel-res-row', 'funnel-res-label', 'funnel-res-track', 'funnel-res-fill']
        .forEach(c => { if (RES.indexOf(c) < 0)
          throw new Error('the residual row layout lost ' + c); });
      if (RES.indexOf('${s.lbl}') < 0)
        throw new Error('rows no longer carry their own label — back to a legend hunt');
    });
    t('the label column matches the ladder, so the tracks line up', () => {
      const css = STYLE_BLOCKS.map(b => b.css).join('\n');
      // v180 — compared as the declared value, so a shared token counts.
      const w = r => (css.match(new RegExp('\\.' + r + '\\s*\\{[^}]*?[^-]width:\\s*([^;]+);')) || [])[1];
      const ladder = w('funnel-stage-label'), res = w('funnel-res-label');
      if (!ladder || !res) throw new Error('a label-column width rule is missing');
      eq(res, ladder, 'residual label width vs ladder label width:');
    });
  })();

  console.log('\n== The residual is rendered, not just described ==');
  (() => {
    // Tier 11's lesson applied to HTML. Reading the percentage block would
    // never have revealed this defect: the widths were computed correctly and
    // then discarded by a CSS shorthand three lines away. Only running it and
    // measuring the output catches that class of bug, so run it.
    const fnSrc = grabFrom(SRC, 'renderFunnelPanel', 'funnel panel');
    const ctx = sandbox({ _funnelActiveStage: null, _funnelCurveOn: false });
    vm.runInContext(fnSrc, ctx);
    const BASE = { total: 1200, scopeN: 1000, d1: 300, d2: 340, d3: 360, residual: 640,
      missing: 400, woopen: 180, qty: 60, flexmiss: 20, other: 10,
      res_woopen: 150, res_proc: 30, res_qty: 30, res_woopen_rfv: 50, res_woopen_bare: 100,
      newDirect: new Set(), newUsedOn: new Set(), newParent: new Set(),
      adjDirect: 0, adjParent: 0 };
    const SMALL = Object.assign({}, BASE, { d1: 900, d2: 960, d3: 990, residual: 10,
      missing: 6, woopen: 2, qty: 1, res_woopen: 2, res_woopen_rfv: 1, res_woopen_bare: 1,
      res_proc: 1, res_qty: 1, flexmiss: 1, other: 0 });
    const render = d => { ctx.__d = d;
      return vm.runInContext('renderFunnelPanel(__d, "abom", "ABOM", "sub")', ctx); };
    const widths = h => [...h.matchAll(/funnel-res-fill" style="width:(\d+)%/g)].map(m => +m[1]);
    const sum = a => a.reduce((x, y) => x + y, 0);

    t('the residual block draws to the size of the residual', () => {
      // The old track was display:flex with flex-grow per segment, so it filled
      // 100% of its width for ANY residual. 3 items and 3,000 items drew the
      // same bar. This is the assertion that would have failed then.
      const big = sum(widths(render(BASE)));
      const small = sum(widths(render(SMALL)));
      eq([big, small], [64, 1], 'total residual width at 640/1000 and 10/1000 scope:');
      if (big <= small) throw new Error('a larger residual does not draw larger');
    });
    t('a residual row and a ladder bar of equal length mean equal counts', () => {
      // The two live in one panel; if they are on different axes the panel
      // lies. Each residual width must be its count as a share of scope.
      const html = render(BASE);
      const rows = [...html.matchAll(
        /funnel-res-fill" style="width:(\d+)%[^>]*><\/div>\s*<div class="funnel-res-count">([\d,]+)</g)];
      if (rows.length < 5) throw new Error('only ' + rows.length + ' residual rows rendered');
      rows.forEach(m => {
        const w = +m[1], n = +m[2].replace(/,/g, '');
        const want = Math.round(n / BASE.scopeN * 100);
        if (w !== want)
          throw new Error(n + ' items drew ' + w + '% where scope share is ' + want + '%');
      });
    });
    t('no residual row is drawn to zero width', () => {
      // At a small residual every row rounds to 0%. A row the reader can click
      // must still be visible, which is what the fill min-width is for.
      const css = STYLE_BLOCKS.map(b => b.css).join('\n');
      const rule = css.match(/\.funnel-res-fill\s*\{[^}]*\}/);
      if (!rule || !/min-width:\s*[1-9]/.test(rule[0]))
        throw new Error('.funnel-res-fill has no min-width; small categories vanish');
      if (!widths(render(SMALL)).length)
        throw new Error('a 10-item residual rendered no rows at all');
    });
  })();

  console.log('\n== One finding, one colour ==');
  t('WO NOT CLOSED wears the token named for it', () => {
    // --wo-open existed and was used for open-WO numbers in three table cells,
    // but the badge for the concept used --warn — the same token as PROC
    // REMOVED and QTY MISMATCH. Three unrelated findings, one amber, on the
    // badges and therefore in the funnel that inherits them.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const rule = css.match(/\.badge-woopen\s*\{[^}]*\}/);
    if (!rule) throw new Error('.badge-woopen is gone');
    if (rule[0].indexOf('var(--wo-open)') < 0)
      throw new Error('WO NOT CLOSED is not using --wo-open: ' + rule[0]);
    if (/var\(--warn\)/.test(rule[0]))
      throw new Error('WO NOT CLOSED still carries the shared amber');
  });
  t('the funnel and the badge agree on the bare open-WO colour', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const badge = (css.match(/\.badge-woopen\s*\{[^}]*color:\s*var\((--[\w-]+)\)/) || [])[1];
    const bar = (RESSEGS['WO Not Closed (bare)'] || '').replace(/^'|'$/g, '');
    if (!badge) throw new Error('cannot read the badge colour');
    eq(bar, 'var(' + badge + ')', 'residual bar vs badge:');
  });

  console.log('\n== Long notes stay inside the column-mapping modal ==');
  t('the mapping table is fixed-layout so notes wrap rather than widen', () => {
    // v167 — #10. With an auto layout a long note widened its own column and
    // pushed the table past the panel border. Two of the three columns have
    // fixed widths, so table-fixed gives Notes the remainder and wraps it.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const tbl = css.match(/\.col-map-panel table\s*\{([^}]*)\}/);
    if (!tbl) throw new Error('the mapping table rule is gone');
    if (tbl[1].indexOf('table-layout: fixed') < 0)
      throw new Error('the table can still be widened by its content');
    const notes = css.match(/\.col-map-panel td\.col-notes\s*\{([^}]*)\}/g) || [];
    const joined = notes.join(' ');
    if (!/overflow-wrap|word-break/.test(joined))
      throw new Error('a single unbroken token in a note has nowhere to wrap');
  });
  t('the two fixed columns still leave room for the notes', () => {
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const widths = ['col-field', 'col-letter'].map(c => {
      const m = css.match(new RegExp('\\\\.col-map-panel td\\\\.' + c + '\\\\s*\\\\{([^}]*)\\\\}'));
      const w = m && m[1].match(/width:\s*(\d+)px/);
      return w ? parseInt(w[1], 10) : 0;
    });
    const panel = css.match(/\.col-map-panel\s*\{[^}]*max-width:\s*(\d+)px/);
    if (!panel) throw new Error('the panel has no max-width');
    const remaining = parseInt(panel[1], 10) - widths[0] - widths[1];
    if (remaining < 300)
      throw new Error('only ' + remaining + 'px left for notes — they will be unreadable');
  });

  console.log('\n== Job Number search, on all three tables ==');
  t('the summary bar puts Job Number between Part Number and Work Order', () => {
    const bar = SRC.slice(at('class="summary-search-bar"'), at('class="summary-search-bar"') + 1400);
    const order = ['id="search-input"', 'id="job-search-input"', 'id="wo-search-input"']
      .map(k => bar.indexOf(k));
    if (order.some(i => i < 0)) throw new Error('a summary search input is missing');
    eq(order.slice().sort((a, b) => a - b), order, 'order must be PN, Job, WO:');
  });
  t('the MBOM and ABOM bars put Job Number between Used On and Work Order', () => {
    ['mbom', 'abom'].forEach(leg => {
      const order = ['-search-uo', '-search-job', '-search-wo'].map(k => SRC.indexOf('id="' + leg + k + '"'));
      if (order.some(i => i < 0)) throw new Error(leg + ' is missing a search input');
      eq(order.slice().sort((a, b) => a - b), order, leg + ' order:');
    });
  });
  t('the summary job search matches ANY job planned against the line', () => {
    // A line can be planned on several jobs, so the match is "any", read from
    // the cached _meta map rather than rescanning the MBOM per row.
    if (!/function _rowMbomJobs/.test(SRC))
      throw new Error('the job lookup helper is gone');
    const h = grabFn('_rowMbomJobs');
    if (h.indexOf('mbomJobsByKey') < 0)
      throw new Error('the helper no longer reads the cached job map');
    eq((SRC.match(/_rowMbomJobs\(r\)\.some/g) || []).length, 2,
       'both the context and plain match paths must honour it:');
  });
  t('BOM job search uses the DATA path, not a DOM filter', () => {
    // A matching row may sit on another page. Filtering only what is rendered
    // would report "no matches" for data that exists — the same reason WO#
    // search re-renders rather than hiding rows.
    const f = grabFn('filterBomTable');
    if (!/\(woQ \|\| jobQ\)/.test(f))
      throw new Error('job search does not trigger the data-level re-render');
    const cfg = SRC.slice(at('const _bomSearchConfig'), at('const _bomSearchConfig') + 400);
    ['mbom', 'abom'].forEach(leg => {
      if (!new RegExp(leg + ':[^}]*jobCol').test(cfg))
        throw new Error(leg + ' has no jobCol in the search config');
    });
  });
  t('clearing a search clears the job box too', () => {
    const bom = grabFn('clearBomSearch');
    if (!/\['pn','uo','job','wo'\]/.test(bom))
      throw new Error('clearBomSearch leaves the job box populated');
    const sum = grabFn('clearSummarySearch');
    if (sum.indexOf('job-search-input') < 0)
      throw new Error('clearSummarySearch leaves the job box populated');
  });
  t('an empty job box does not suppress collapsed rows', () => {
    // The collapse guard lists every active search; omitting one would keep
    // rows hidden after the box is cleared.
    const T = SRC.slice(at('function renderSummaryTable'), at('function badgeBom('));
    if (!/!search && !woSearch && !ncrDispSearch && !rfvSearch && !jobSearch && isHiddenByCollapse/.test(T))
      throw new Error('jobSearch is missing from the collapse guard');
  });

  console.log('\n== RFV: one glyph rule, one badge colour, and documented ==');
  t('the RFV Links column drops the glyph, as an approved exception', () => {
    // v167 — #8. The build carries a glyph CONTRACT: ◈ means RFV everywhere,
    // ◆ is reserved for structural part-type badges. Dropping it in a column
    // literally headed "RFV Links" is a considered exception, not drift: there
    // the glyph restates the header on every row. It stays everywhere else,
    // where context is ambiguous.
    const cell = SRC.match(/<span style="font-family:var\(--mono\);color:var\(--text\)">[^`]{0,40}esc\(lnk\.rfvNum/);
    if (!cell) throw new Error('the RFV link cell moved');
    if (cell[0].indexOf('\u25c8') >= 0)
      throw new Error('the diamond is back in the RFV Links column');
    // and the contract still holds elsewhere
    ['\u25c8 = RFV authorized', '\u25c8 RFV'].forEach(k => {
      if (SRC.indexOf(k) < 0) throw new Error('the glyph contract was broken elsewhere: ' + k);
    });
  });
  t('all three RFV pass badges are the same colour', () => {
    // The pass is carried by the LABEL. Colouring them differently was a second
    // encoding needing a legend — the argument that retired the green glyphs.
    const cols = [...SRC.matchAll(/passLabel:\s*'P\d[^']*',\s*passColor:\s*'([^']+)'/g)].map(m => m[1]);
    if (cols.length !== 3) throw new Error('expected 3 pass badges, found ' + cols.length);
    if (new Set(cols).size !== 1)
      throw new Error('pass badges use different colours: ' + JSON.stringify(cols));
    eq(cols[0], 'var(--text-muted)');
  });
  t('the RFV Information legend and its MATCH PASS badges are both flat', () => {
    // v169 — the first version of this test checked only the legend LINE at the
    // top of the view. The MATCH PASS column badges are built somewhere else
    // entirely, from addMatch(), and stayed blue/red while the legend went dim.
    // Checking one and not the other is how a half-done change passes.
    const seg = SRC.slice(at('function renderRFVTable'), at('function renderRFVTable') + 4000);
    const legend = [...seg.matchAll(/<span style="color:(var\(--[\w-]+\))">P\d/g)].map(m => m[1]);
    if (legend.length < 3) throw new Error('the pass legend moved');
    if (new Set(legend).size !== 1)
      throw new Error('the legend colours the passes differently: ' + JSON.stringify(legend));

    // The badges themselves, from the addMatch() calls.
    const calls = [...SRC.matchAll(/addMatch\(rfvRow,\s*(\d),\s*'([^']+)',\s*([^)]+)\)/g)]
      .map(m => ({ pass: +m[1], label: m[2], color: m[3].trim() }));
    if (calls.length < 4) throw new Error('the MATCH PASS badge builders moved');
    const physical = calls.filter(c => c.pass <= 3);
    if (new Set(physical.map(c => c.color)).size !== 1)
      throw new Error('P1-P3 badges use different colours: ' +
                      JSON.stringify(physical.map(c => c.pass + '=' + c.color)));
    // The SME-linked pass is a PROVENANCE distinction, not a pass ranking, and
    // keeps the manual-provenance purple used across the whole tool.
    const sme = calls.find(c => c.pass === 4);
    if (!sme) throw new Error('the SME-linked pass is gone');
    if (sme.color === physical[0].color)
      throw new Error('the SME-linked pass lost its provenance colour');
    if (sme.color.indexOf('a371f7') < 0 && sme.color.indexOf('--adj') < 0)
      throw new Error('the SME-linked pass is no longer the adjudication purple');
  });
  t('the RFV pass badges are documented', () => {
    // They are built INLINE rather than through the badge maps, which is why
    // the guide never carried them and Tier 10 never noticed.
    const help = SRC.slice(at('const BADGE_HELP = {'), at('function _badgeHelp'));
    ['P1\u00b7PN+NH', 'P2\u00b7NCR', 'P3\u00b7WO'].forEach(k => {
      if (help.indexOf("'" + k + "'") < 0)
        throw new Error('no explanation for the ' + k + ' badge');
    });
    // at() searches from the START of the file, and _setReportHtml appears
    // earlier than showBadgeGuide — so anchoring on it produced an INVERTED
    // slice and an empty string, which failed for the wrong reason. Search
    // forward from the guide.
    const gA = at('function showBadgeGuide()');
    const guide = SRC.slice(gA, at('_setReportHtml(html)', gA));
    if (guide.indexOf('RFV Links column') < 0)
      throw new Error('the badge guide has no RFV section');
  });
  t('RFV is explained in the Detailed View modal', () => {
    const m = SRC.slice(at("'detailed-view': {"), at("'adjudication-workbench': {"));
    if (m.indexOf('RFV Links') < 0)
      throw new Error('the Detailed View explanation still never mentions RFV');
    ['P1', 'P2', 'P3', 'not</em> ranked'].forEach(bit => {
      if (m.indexOf(bit) < 0) throw new Error('the RFV explanation omits: ' + bit);
    });
  });
  t('the Has RFV filter behaves like every other conditional filter', () => {
    // There was already an RFV SEARCH ("where is RFV-1234"); there was no way
    // to ask "which lines carry variance coverage at all".
    //
    // v168 — the first cut gated visibility on state.boms.rfv, i.e. on the FILE
    // being loaded. Every other conditional filter gates on count > 0 and shows
    // its count in the label. File-gating meant the button was invisible with no
    // RFV file (reads as "not implemented" rather than "not applicable") and
    // would have offered an always-empty filter for a file matching nothing.
    const btn = SRC.match(/<button[^>]*data-fk="has_rfv"[\s\S]{0,240}?<\/button>/);
    if (!btn) throw new Error('the Has RFV filter is missing');
    if (btn[0].indexOf('var(--rfv)') < 0)
      throw new Error('the filter does not wear the RFV colour');
    const uf = grabFn('updateFilterCounts');
    if (!/has_rfv:\s*\S/.test(uf))
      throw new Error('has_rfv has no entry in the counts object, so it renders with no count');
    if (!/filter-has-rfv'\)[\s\S]{0,160}counts\.has_rfv > 0/.test(SRC))
      throw new Error('the filter is not revealed by its count, like pt_removal is');
    if (/filter-has-rfv'\)[\s\S]{0,120}state\.boms\.rfv/.test(SRC))
      throw new Error('the old file-presence gate is still there — two rules, one button');
    eq((SRC.match(/activeFilter === 'has_rfv'/g) || []).length, 2,
       'both the render and count paths must honour it:');
  });
  t('every conditional filter is revealed the same way', () => {
    // pt_removal, abom_proc_removed and has_rfv all key on count > 0. A filter
    // revealed by a different rule is the one that surprises the reader.
    ['filter-pt-removal', 'filter-abom-proc-removed', 'filter-has-rfv'].forEach(id => {
      const re = new RegExp("getElementById\\('" + id + "'\\)[\\s\\S]{0,200}counts\\.\\w+ > 0");
      if (!re.test(SRC)) throw new Error(id + ' is not revealed by a count');
    });
  });

  console.log('\n== updateFilterCounts may only call what it can see ==');
  t('updateFilterCounts calls nothing that is local to another function', () => {
    // v172 — the counts object is built as ONE literal. A single unresolvable
    // call throws before any button is labelled, so every filter count vanishes
    // and every count-based reveal stops firing. v169 called getRowRfvLinks(),
    // which is local to renderSummaryTable and runs AFTER this — the reported
    // symptom was "no Has RFV button", the actual damage was every count.
    const uf = grabFn('updateFilterCounts').replace(/\/\/[^\n]*/g, '');
    const called = new Set([...uf.matchAll(/(^|[^.\w$])([a-zA-Z_$][\w$]*)\s*\(/g)].map(m => m[2]));
    const BUILTIN = new Set(['if','for','while','switch','return','function','catch','typeof',
      'Set','Map','Array','Object','String','Number','Boolean','parseInt','parseFloat','filter',
      'forEach','some','every','map','has','add','get','set','includes','indexOf','join','split',
      'slice','sort','push','trim','toUpperCase','toLowerCase','querySelectorAll','getElementById',
      'getAttribute','setAttribute','hasAttribute','normPN','esc','fmt']);
    const bad = [];
    called.forEach(fn => {
      if (BUILTIN.has(fn)) return;
      const at2 = SRC.indexOf('function ' + fn + '(');
      if (at2 < 0) return;                       // not a build function
      // is it declared at column 0 (top level) or indented (nested)?
      const lineStart = SRC.lastIndexOf('\n', at2) + 1;
      if (at2 !== lineStart) bad.push(fn);
    });
    if (bad.length)
      throw new Error('updateFilterCounts calls function(s) local to another scope: ' +
                      bad.join(', ') + ' — this throws and kills every filter count');
  });
  t('the RFV row count is computed at top level', () => {
    if (!/^function _rfvLinkedRowCount\(/m.test(SRC))
      throw new Error('_rfvLinkedRowCount is not a top-level function');
    const body = grabFn('_rfvLinkedRowCount');
    if (/getRowRfvLinks/.test(body))
      throw new Error('it delegates to the function that is out of scope');
  });

  console.log('\n== A filter wears the colour of what it finds ==');
  t('the Adjudicated filter matches its badges, not the interaction blue', () => {
    const btn = SRC.match(/<button[^>]*data-fk="adjudicated"[\s\S]{0,260}?<\/button>/);
    if (!btn) throw new Error('the Adjudicated filter is gone');
    if (/var\(--accent\)/.test(btn[0]))
      throw new Error('the filter is still interaction-blue while its badges are purple');
    if (!/var\(--adj\)/.test(btn[0]))
      throw new Error('the filter does not use the adjudication colour');
  });

  console.log('\n== The bar no longer shares its name with the section ==');
  t('the action bar is the Claim Ledger, distinct from the section', () => {
    const bar = SRC.match(/<span class="adj-title">([^<]*)<\/span>/);
    if (!bar) throw new Error('the action bar title is gone');
    if (/Adjudication Workbench/.test(bar[1]))
      throw new Error('the bar still carries the same name as the section it sits inside');
    eq(bar[1].replace(/[^A-Za-z ]/g, '').trim(), 'Claim Ledger');
  });
  t('the explanation modal covers all three blocks in order', () => {
    const m = SRC.slice(at("'adjudication-workbench': {"), at("'adjudication-workbench': {") + 20000);
    const order = ['The Candidates Helpers', 'Imported Claims', 'The Claim Ledger']
      .map(h => m.indexOf('<h3>' + h));
    order.forEach((i, k) => { if (i < 0)
      throw new Error('the explanation modal is missing a block: ' + k); });
    eq(order.slice().sort((a, b) => a - b), order, 'blocks must read in workflow order:');
  });
  t('the modal explains the CM boundary and the pending arrival', () => {
    const m = SRC.slice(at("'adjudication-workbench': {"), at("'adjudication-workbench': {") + 20000);
    ['never touches CI-to-NCR', 'arrive <em>pending</em>'].forEach(bit => {
      if (m.indexOf(bit) < 0) throw new Error('the modal no longer states: ' + bit);
    });
  });

  console.log('\n== The ten upload zones look like one another ==');
  t('every zone tag uses the shared uniform treatment', () => {
    // v163 — adding the tenth zone put a coloured .tag-adj rule INSIDE the
    // shared no-op selector, which turned nine tags purple and left ACN alone.
    // The zones are meant to be visually identical; .bom-tag owns the styling.
    const css = STYLE_BLOCKS.map(b => b.css).join('\n');
    const coloured = [...css.matchAll(/\.tag-[\w-]+[^{}]*\{([^}]*)\}/g)]
      .filter(m => /background|color|border/.test(m[1]));
    if (coloured.length)
      throw new Error('a per-zone tag rule sets its own colour: ' +
                      coloured[0][0].replace(/\s+/g, ' ').slice(0, 90));
  });
  t('every zone offers the same column-mapping help control', () => {
    const icons = [...SRC.matchAll(/class="abom-cm-help"[^>]*>([^<]*)<\/a>/g)].map(m => m[1].trim());
    if (icons.length < 5) throw new Error('only found ' + icons.length + ' help controls');
    const distinct = [...new Set(icons)];
    if (distinct.length !== 1)
      throw new Error('zones use different help icons: ' + JSON.stringify(distinct));
  });
  t('the ME ADJ zone is wired like the other supplemental zones', () => {
    const zone = SRC.slice(at('id="zone-adj"'), at('id="zone-adj"') + 1400);
    ['handleFile(\'adj\'', 'setSuppMappingMode(\'adj\'', 'openSuppManualMap(\'adj\'',
     'id="fn-adj"', 'id="rows-adj"'].forEach(bit => {
      if (zone.indexOf(bit) < 0) throw new Error('the ME ADJ zone is missing ' + bit);
    });
  });

  console.log('\n== Export menu wiring ==');
  t('every menu item is wired, and every wire has a button', () => {
    // The count is derived from the build, not pinned to 13, so ADDING an
    // export is not a failure — leaving one unwired is.
    const items = [...SRC.matchAll(/class="export-menu-item"[^>]*>\s*([^<]{1,60})/g)].map(m => m[1].trim());
    const wired = [...SRC.matchAll(/id="(export-menu-[\w-]+)"[^>]*onclick="invokeExport\('([^']+)'\)/g)];
    if (!items.length) throw new Error('no export menu items found at all');
    eq(wired.length, items.length, 'menu items vs invokeExport wires:');
    const dead = wired.filter(w => !SRC.includes('id="' + w[2] + '"')).map(w => w[2]);
    if (dead.length) throw new Error('wired to missing button(s): ' + dead.join(', '));
  });
  t('menu ids are unique', () => {
    const ids = [...SRC.matchAll(/id="(export-menu-[\w-]+)"/g)].map(m => m[1]);
    const dupes = ids.filter((v, i) => ids.indexOf(v) !== i);
    if (dupes.length) throw new Error('duplicate menu ids: ' + [...new Set(dupes)].join(', '));
  });
  t('export menu uses one arrow convention', () => {
    const items = [...SRC.matchAll(/class="export-menu-item"[^>]*>\s*([^<]{1,60})/g)].map(m => m[1].trim());
    const arr = items.filter(i => i.startsWith('\u2b07'));
    if (arr.length !== 0 && arr.length !== items.length)
      throw new Error('mixed: ' + arr.length + '/' + items.length);
  });
});

// ── TIER 20 ────────────────────────────────────────────────────────────────
// v178 — provenance. Three copies of "which build, which rules, which claims"
// had drifted apart: the session file said v142 for 36 builds, the certificate
// hash stopped growing when claims gained fields at v85/v87/v162, and the two
// Audit Certificate sheets disagreed with each other. Every rule here is
// DERIVED from the build where it can be, because each of those drifts
// happened to a hand-maintained list.
function stripComments(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`\\])\/\/[^\n]*/g, '$1');
}
// Every createdFrom value the build can write: quoted directly, mapped through
// _ADJ_CREATED_FROM, or held in a variable named *CreatedFrom first. The first
// version of this looked only at the first two and missed the two
// "_paired" values, which are chosen by a ternary into a variable.
function createdFromValues() {
  const vals = new Set([...SRC.matchAll(/createdFrom:\s*'([a-z_]+)'/g)].map(m => m[1]));
  const cf = SRC.match(/const _ADJ_CREATED_FROM = \{([\s\S]*?)\};/);
  if (!cf) throw new Error('BUILD MARKER MOVED: _ADJ_CREATED_FROM');
  [...cf[1].matchAll(/:\s*'([a-z_]+)'/g)].forEach(m => vals.add(m[1]));
  for (const m of SRC.matchAll(/\b\w*CreatedFrom\s*=\s*([^;]+);/g))
    // the quoted RESULTS only — a string compared in the condition is not a value
    for (const q of m[1].replace(/[!=]==\s*'[a-z_]+'/g, '').matchAll(/'([a-z_]+)'/g)) vals.add(q[1]);
  return vals;
}
// Every key written by an object literal pushed onto state.adjudications, or
// built by the ME importer. This is the claim schema as the build actually
// writes it — no hand list.
function claimFieldsWritten() {
  const keys = new Set();
  const re = /state\.adjudications\.push\(\{|out\.push\(\{\s*\n\s*id:\s*'imp_/g;
  let m;
  while ((m = re.exec(SRC))) {
    let k = SRC.lastIndexOf('{', m.index + m[0].length), d = 0;
    const i = k;
    for (;; k++) { if (SRC[k] === '{') d++; else if (SRC[k] === '}' && !--d) break; }
    for (const x of SRC.slice(i + 1, k).matchAll(/^\s*([A-Za-z_]+)\s*:/gm)) keys.add(x[1]);
  }
  if (keys.size < 10) throw new Error('claim literals not found — marker moved?');
  return keys;
}
// The per-claim projection the certificate hash covers.
function hashedClaimFields() {
  const f = grabFn('freezeReport');
  const s = f.indexOf('const adjSerializable');
  if (s < 0) throw new Error('BUILD MARKER MOVED: adjSerializable in freezeReport');
  const blk = stripComments(f.slice(s, f.indexOf('}));', s)));
  // Keys only: a key follows '{', ',' or a line start. A bare word before ':'
  // elsewhere is a ternary branch (`? null : x`), not a field.
  return new Set([...blk.matchAll(/(?:^|[{,])\s*([A-Za-z]+)\s*:/gm)].map(m => m[1]));
}
// Fields a claim carries that the hash deliberately does NOT cover, and why.
const HASH_EXEMPT = {
  applied:      'hashed once for the whole batch as adjudicationsApplied',
  ncrSnapshot:  'a copy of NCR file content taken at claim time; the disposition numbers that identify it are hashed',
  ncrSnapshots: 'as ncrSnapshot, for multi-disposition claims',
};

suite('Tier 20 — provenance: version, certificate and claims', (t, eq) => {
  console.log('\n== The build says which build it is, everywhere ==');
  t('the session file is stamped from APP_VERSION, not a literal', () => {
    const b = stripComments(grabFn('exportSessionJson'));
    if (/toolVersion:\s*['"`]/.test(b))
      throw new Error('toolVersion is a literal: ' + b.match(/toolVersion:\s*['"`][^'"`]*['"`]/)[0]);
    if (!/toolVersion:\s*APP_VERSION\b/.test(b)) throw new Error('toolVersion is not read from APP_VERSION');
  });
  t('APP_VERSION is the only quoted version string in any code', () => {
    // The header-only check below missed toolVersion: 'v142' for 36 builds.
    const hits = [...stripComments(SRC).matchAll(/['"`]v\d{2,3}(?:\.\d+)?['"`]/g)].map(m => m[0]);
    if (hits.length !== 1) throw new Error(hits.length + ' quoted version strings: ' + hits.join(', '));
  });
  t('the certificate records which build computed it, outside the hash', () => {
    const f = stripComments(grabFn('freezeReport'));
    const c = f.slice(f.indexOf('state.auditCert = {'), f.indexOf('};', f.indexOf('state.auditCert = {')));
    if (!/toolVersion:\s*APP_VERSION/.test(c)) throw new Error('auditCert has no toolVersion');
    const h = f.slice(f.indexOf('const hashPayload'), f.indexOf('};', f.indexOf('const hashPayload')));
    if (/toolVersion|APP_VERSION/.test(h))
      throw new Error('the build version must stay OUT of the hash: it labels the certificate, it is not attested');
  });
  t('the certificate banner shows the build, including after a session import', () => {
    if (!/id="cert-build"/.test(SRC)) throw new Error('no cert-build element in the banner');
    if (!/cert-build'\)\.textContent\s*=\s*APP_VERSION/.test(stripComments(grabFn('freezeReport'))))
      throw new Error('freezeReport does not fill cert-build');
    if (!/setIf\('cert-build'/.test(grabFn('importSessionJson')))
      throw new Error('a re-imported frozen session would show a blank build');
  });

  console.log('\n== One Audit Certificate sheet, not two copies ==');
  t('one function defines the Audit Certificate sheet', () => {
    const rows = grabFn('_auditCertRows');
    ['exportXLSX', 'exportCIReport'].forEach(fn => {
      const b = grabFn(fn);
      if (b.includes('CERTIFICATE OF CONFIGURATION AUDIT'))
        throw new Error(fn + ' still builds its own certificate rows');
      if (!/_auditCertRows\(/.test(b)) throw new Error(fn + ' does not call _auditCertRows');
    });
    if (!rows.includes('CERTIFICATE OF CONFIGURATION AUDIT')) throw new Error('title row missing');
  });
  t('the certificate sheet carries every provenance row exactly once', () => {
    const labels = [...grabFn('_auditCertRows').matchAll(/\[\s*'([^']+)'\s*,/g)].map(m => m[1]);
    const dup = labels.filter((v, i) => labels.indexOf(v) !== i);
    if (dup.length) throw new Error('repeated rows: ' + dup.join(', '));
    ['Auditor', 'Frozen', 'Mode', 'Build', 'Proc Code Profile', 'EBOM Indenture Scope',
     'Removal Proc Codes', 'Swap Proc Codes', 'SHA-256 Integrity Hash'].forEach(l => {
      if (labels.indexOf(l) < 0) throw new Error('missing row: ' + l);
    });
  });
  t('every Audit Certificate sheet in the build comes from that function', () => {
    // Discovery, so a third copy written later fails here by line.
    const bad = [];
    for (const m of SRC.matchAll(/'Audit Certificate'\s*\)/g)) {
      const before = SRC.slice(Math.max(0, m.index - 400), m.index);
      if (!/_auditCertRows\(/.test(before)) bad.push('line ' + (SRC.slice(0, m.index).split('\n').length));
    }
    if (bad.length) throw new Error('certificate sheet not built from _auditCertRows at ' + bad.join(', '));
  });
  t('every certificate the build writes (Excel, CSV, HTML) comes from that function', () => {
    // v179 — v178 unified the two Excel copies and missed two more: the CSV and
    // HTML exports each wrote their own certificate, still without the build,
    // the proc code profile, the codes or the scope. Found by searching for the
    // title text, which every copy has to print.
    const code = stripComments(SRC);
    const at0 = code.indexOf('function _auditCertRows(');
    const own = grabFrom(code, '_auditCertRows', 'build');
    const hits = [];
    let i = -1;
    while ((i = code.indexOf('CERTIFICATE OF CONFIGURATION AUDIT', i + 1)) >= 0) hits.push(i);
    const outside = hits.filter(h => h < at0 || h > at0 + own.length);
    if (outside.length) throw new Error(outside.length + ' certificate title(s) written outside _auditCertRows');
    ['exportCSV', 'exportHTML'].forEach(fn => {
      if (!/_auditCertRows\(/.test(grabFn(fn))) throw new Error(fn + ' does not use _auditCertRows');
    });
  });
  t('a certificate frozen before v178 says so rather than borrowing today’s build', () => {
    if (!/c\.toolVersion\s*\|\|\s*'not recorded/.test(grabFn('_auditCertRows')))
      throw new Error('an old certificate would print no build, or the wrong one');
  });

  console.log('\n== The hash covers everything that changes what a claim does ==');
  t('every field a claim is written with is hashed, or exempt for a stated reason', () => {
    const hashed = hashedClaimFields();
    const miss = [...claimFieldsWritten()].filter(k => !hashed.has(k) && !(k in HASH_EXEMPT));
    if (miss.length) throw new Error('claims carry fields the certificate does not attest: ' + miss.join(', '));
  });
  t('the exemptions are still real fields, so the list cannot rot', () => {
    const written = claimFieldsWritten();
    const stale = Object.keys(HASH_EXEMPT).filter(k => !written.has(k));
    if (stale.length) throw new Error('exempt but no longer written: ' + stale.join(', '));
  });
  t('the hash covers the indenture scope', () => {
    const f = stripComments(grabFn('freezeReport'));
    const h = f.slice(f.indexOf('const hashPayload'), f.indexOf('};', f.indexOf('const hashPayload')));
    if (!/collectorLevels\s*:/.test(h)) throw new Error('the scope decides what reconciles but is not hashed');
  });

  console.log('\n== Claim origins are readable ==');
  t('every createdFrom value the build emits has a readable source label', () => {
    const vals = createdFromValues();
    if (!vals.has('nh_mismatch_helper_paired')) throw new Error('the variable-assigned values were not found');
    const lm = SRC.match(/^const CLAIM_SOURCE_LABEL = \{([\s\S]*?)\};/m);
    if (!lm) throw new Error('CLAIM_SOURCE_LABEL is not declared at top level');
    const keys = new Set([...lm[1].matchAll(/'([a-z_]+)'\s*:/g)].map(m => m[1]));
    const miss = [...vals].filter(v => !keys.has(v));
    if (miss.length) throw new Error('no label for: ' + miss.join(', '));
  });
  t('no local copy of the label map survives', () => {
    if (/_claimSourceLabel\b/.test(stripComments(SRC))) throw new Error('_claimSourceLabel still referenced');
  });

  console.log('\n== Session parity for every column map ==');
  t('every *ManualMap in state is exported, restored and reset', () => {
    const s0 = at('const state = {');
    const init = SRC.slice(s0, SRC.indexOf('\n};', s0));
    const maps = [...init.matchAll(/\b([a-z]+ManualMap):/g)].map(m => m[1]);
    if (maps.length < 7) throw new Error('found only ' + maps.length + ' manual maps in state');
    const ex = grabFn('exportSessionJson'), im = grabFn('importSessionJson'), rs = grabFn('resetAll');
    const bad = [];
    maps.forEach(k => {
      if (!ex.includes(k + ':'))                                  bad.push(k + ' not exported');
      if (!im.includes('payload.' + k))                           bad.push(k + ' not restored');
      if (!new RegExp('state\\.' + k + '\\s*=\\s*null').test(rs)) bad.push(k + ' not reset');
    });
    if (bad.length) throw new Error(bad.join('; '));
  });
  t('Reset leaves the indenture scope alone, by decision', () => {
    // D4 (v178 audit): the scope is a program convention, so Reset keeps it,
    // while proc codes return to baseline. Pinned so a change is a decision.
    if (/collectorLevels\s*=/.test(stripComments(grabFn('resetAll'))))
      throw new Error('resetAll now changes the indenture scope — update the guide (3.4) if intended');
  });

  console.log('\n== One glyph for Proc Removed ==');
  t('the Proc Removed window uses the badge’s glyph, not the Removal Item one', () => {
    const b = grabFn('showProcRemovedModal');
    if (b.includes('⊘')) throw new Error('⊘ is the Removal Item glyph');
    if (!b.includes('⬇')) throw new Error('the window title has lost its glyph');
  });
});

// ── TIER 4b ────────────────────────────────────────────────────────────────
// Delta v3.4 — the delta tool against the main build it reads. Each test
// derives its expectation from the main build where it can: every copy the
// delta tool keeps (the streaming reader, the claim-source labels, the KPI
// predicates, the palette) is compared, not trusted.
function deltaSlice(src, startMarker, endMarker) {
  const a = src.indexOf(startMarker);
  if (a < 0) throw new Error('marker not found: ' + startMarker);
  const b = src.indexOf(endMarker, a);
  if (b < 0) throw new Error('marker not found: ' + endMarker);
  return src.slice(a, src.lastIndexOf('\n}\n', b) + 3);
}
function streamReaderText(src) {
  return deltaSlice(src, 'async function _parseJsonStream(', 'async function _readSessionPayload(') +
         grabFrom(src, '_readSessionPayload', 'reader');
}
const norm = s => s.replace(/\s+/g, ' ').trim();
function deltaSandbox(names, consts) {
  const ctx = { console, JSON, Math, Array, Object, String, Number, Boolean, Set, Map };
  ctx.globalThis = ctx; vm.createContext(ctx);
  // A name prefixed '?' is optional: absent, it is declared empty, so a test
  // about something else does not fail for this reason.
  const code = (consts || []).map(c0 => {
    const opt = c0[0] === '?', c = opt ? c0.slice(1) : c0;
    const m = DSRC.match(new RegExp('(?:var|const|let)\\s+' + c + '\\s*=\\s*\\{'));
    if (!m && opt) return 'var ' + c + ' = {};';
    if (!m) throw new Error('delta tool has no ' + c);
    return DSRC.slice(m.index, DSRC.indexOf('};', m.index) + 2);
  }).join('\n') + '\n' + names.map(grabDelta).join('\n') +
    '\nglobalThis.X = {' + names.concat((consts || []).map(c => c.replace('?', ''))).map(n => n + ':' + n).join(',') + '};';
  vm.runInContext(code, ctx);
  return ctx.X;
}

suite('Tier 4b — delta tool follows the main build', (t, eq) => {
  console.log('\n== It can open every session the main build can write ==');
  t('the delta tool’s streaming reader is identical to the main build’s', () => {
    let d;
    try { d = streamReaderText(DSRC); }
    catch (e) { throw new Error('delta tool has no streaming reader (' + e.message + ')'); }
    if (norm(d) !== norm(streamReaderText(SRC))) throw new Error('the two copies differ');
  });
  t('readSession goes through the streaming reader, never a bare JSON.parse', () => {
    const b = stripComments(grabDelta('readSession'));
    if (!/_readSessionPayload\(/.test(b)) throw new Error('readSession does not use _readSessionPayload');
    if (/JSON\.parse\(/.test(b)) throw new Error('readSession still parses the whole file as one string');
  });

  console.log('\n== The Claims sheet compares what the certificate attests ==');
  const hashedForDelta = () => [...hashedClaimFields()].filter(f => f !== 'id' && f !== 'timestamp');
  t('every claim field the main build hashes is a field the delta compares', () => {
    // timestamp is excluded deliberately (HARNESS.md): it moves on every re-save.
    const sig = grabDelta('claimSig');
    const miss = hashedForDelta().filter(x => !new RegExp('c\\.' + x + '\\b').test(sig));
    if (miss.length) throw new Error('hashed but not compared: ' + miss.join(', '));
  });
  t('changing any one of those fields reports the claim as Modified', () => {
    const X = deltaSandbox(['claimSig', 'claimRow', 'claimsDelta'], ['?CLAIM_SOURCE_LABEL']);
    const base = { id: 'c1', type: 'row', reason: 'abom_missing', mode: 'embodiment', leg: 'abom',
      rowKey: 'P||N', rowKeys: ['P||N'], ciKey: 'CI1', dispNo: 'D1', ncrDispNo: 'D1',
      ncrDispNos: ['D1'], woNo: 'W1', woPn: 'P', woUsedOn: 'N', claimedQty: 1,
      nhPayload: { nh: 'N2' }, pairedClaimId: 'c2', createdFrom: 'missing_abom',
      extClaimNo: 'E1', extStatus: 'OPEN', sme: 'A', smeRole: 'R', rationale: 'x', applied: false };
    const alt = v => Array.isArray(v) ? v.concat('Z') : typeof v === 'number' ? v + 1 :
                     typeof v === 'boolean' ? !v : (v && typeof v === 'object') ? { nh: 'OTHER' } : v + 'Z';
    const missed = hashedForDelta().filter(f => {
      const b = Object.assign({}, base, { [f]: alt(base[f]) });
      const r = X.claimsDelta({ adjudications: [base] }, { adjudications: [b] });
      return !(r.length === 1 && r[0].Change === 'Modified');
    });
    if (missed.length) throw new Error('a change to these went unreported: ' + missed.join(', '));
  });
  t('the delta tool’s claim-source labels match the main build’s', () => {
    const main = SRC.match(/^const CLAIM_SOURCE_LABEL = (\{[\s\S]*?\});/m);
    const dm = DSRC.match(/var CLAIM_SOURCE_LABEL = (\{[\s\S]*?\});/);
    if (!main || !dm) throw new Error('label map missing in ' + (main ? 'delta tool' : 'main build'));
    const ev = s => vm.runInNewContext('(' + s + ')');
    eq(ev(dm[1]), ev(main[1]));
  });
  t('the Claims sheet says where each claim came from', () => {
    const X = deltaSandbox(['claimRow'], ['CLAIM_SOURCE_LABEL']);
    const imp = X.claimRow('Added in B', { id: 'imp_9_abom', type: 'row', createdFrom: 'external_import', extClaimNo: '9' });
    eq(imp.Origin, 'ME adjudication import');
    eq(imp['External Claim No'], '9');
    const nat = X.claimRow('Added in B', { id: 'adj_1', reason: 'abom_missing', createdFrom: 'missing_abom' });
    eq(nat.Reason, 'abom_missing', 'an issue-card claim has no type, so its reason must show:');
    const multi = X.claimRow('Modified', { id: 'x', ncrDispNos: ['D1', 'D2'], ncrDispNo: 'D1' });
    eq(multi['NCR Disp No'], 'D1; D2');
  });

  console.log('\n== Provenance of the sessions being compared ==');
  t('old version stamps are labelled as the range they cover, not as a build', () => {
    const X = deltaSandbox(['toolVersionLabel']);
    eq(X.toolVersionLabel({ toolVersion: 'v142' }), 'v142–v177 (exact build not recorded)');
    eq(X.toolVersionLabel({ toolVersion: 'v83' }), 'v83–v141 (exact build not recorded)');
    eq(X.toolVersionLabel({ toolVersion: 'v178' }), 'v178');
    eq(X.toolVersionLabel({}), 'not recorded');
  });
  t('the Summary names each session’s build through that label', () => {
    if (!/toolVersionLabel\(A\)/.test(grabDelta('buildSummaryRows')))
      throw new Error('Summary prints the raw stamp');
  });

  console.log('\n== One delta version, stated once ==');
  t('DELTA_VERSION is the only version literal in the delta tool’s code', () => {
    const script = DSRC.slice(DSRC.lastIndexOf('<script>'));
    const hits = [...stripComments(script).matchAll(/['"`]v\d+(?:\.\d+)+['"`]/g)].map(m => m[0]);
    if (hits.length !== 1 || !/var DELTA_VERSION = /.test(script))
      throw new Error('version literals: ' + hits.join(', '));
    if (/Delta <span class="fam">v\d/.test(DSRC)) throw new Error('the header still carries a literal version');
    if (!/id="delta-version"/.test(DSRC)) throw new Error('no element renders DELTA_VERSION');
  });
  t('the file name, the page title and DELTA_VERSION agree', () => {
    const v = DSRC.match(/var DELTA_VERSION = '(v[\d.]+)'/)[1];
    const fileV = 'v' + DELTA.match(/v([\d_]+)\.html$/)[1].replace(/_/g, '.');
    eq(v, fileV, 'DELTA_VERSION vs file name:');
    if (DSRC.match(/<title>([^<]*)<\/title>/)[1].indexOf(v) < 0) throw new Error('title disagrees');
  });
  t('the exported workbook names the delta version', () => {
    if (!/DELTA_VERSION/.test(grabDelta('exportXlsx'))) throw new Error('the workbook does not say which delta tool produced it');
    if (!/DELTA_VERSION/.test(grabDelta('buildSummaryRows'))) throw new Error('the Summary has no delta version row');
  });

  console.log('\n== The same number means the same thing in both tools ==');
  t('Part WO Status: Not Closed counts what the dashboard card counts', () => {
    // Lift the dashboard's predicates rather than restating them.
    const pick = name => {
      const m = SRC.match(new RegExp('const ' + name + '\\s*=\\s*\\w+\\.filter\\((x\\s*=>[^\\n]*?)\\)\\.length'));
      if (!m) throw new Error('BUILD MARKER MOVED: ' + name);
      return vm.runInNewContext('(' + m[1] + ')');
    };
    const cardOpen = pick('woopen_m'), cardUo = pick('abomUoWoOpen');
    const X = deltaSandbox(['fscope', 'modeHasMbom', 'modeHasAbom', 'computeKpis'],
                           ['DIRECT_OK', 'COVERED_OK', 'SCOPE_EXCLUDED']);
    const rows = [['wo_open', 'n/a'], ['ok', 'wo_open'], ['wo_open', 'wo_open'], ['ok', 'pn_as_usedon'], ['missing', 'n/a']]
      .map(([as, uo], i) => ({ key: 'k' + i, overall: 'ok', ms: 'ok', as, asUsedOn: uo }));
    const k = X.computeKpis({ mode: 'ebom_abom', results: rows });
    eq(k.abomOpen, rows.filter(cardOpen).length, 'Part WO Status: Not Closed:');
    eq(k.abomUoOpen, rows.filter(cardUo).length, 'Used-On WO Not Closed:');
  });
  t('the Summary uses the dashboard’s card names for those rows', () => {
    const b = grabDelta('buildSummaryRows');
    ['Part WO Status: Not Closed', 'Used-On WO Not Closed'].forEach(n => {
      if (!b.includes("'" + n + "'")) throw new Error('no Summary row named ' + n);
    });
    if (b.includes('ABOM Open-WO items')) throw new Error('the old label is still there');
  });
  t('the Summary says the dashboard rounds these percentages', () => {
    if (!/whole percent/.test(grabDelta('buildSummaryRows')))
      throw new Error('93.6% here vs 94% on the card needs explaining where it is read');
  });
  t('ME-imported claims are counted separately on the Summary', () => {
    if (!/external_import/.test(grabDelta('computeKpis'))) throw new Error('no imported-claim count');
  });

  console.log('\n== Purple still means a human decided ==');
  t('an unresolved cause is not drawn in the adjudication purple', () => {
    const b = stripComments(grabDelta('renderTable'));
    if (/c === 'Cause' && v !== 'Build data'\) cls = ' class="adj"'/.test(b))
      throw new Error('every non-build cause is purple, including Unresolved');
    if (!/Unresolved[\s\S]{0,80}class="warn"/.test(b)) throw new Error('Unresolved has no warning style');
    if (!/td\.warn\s*\{/.test(DSRC)) throw new Error('td.warn is not styled');
  });

  console.log('\n== One palette ==');
  t('every token the delta tool defines has the main build’s dark value', () => {
    const vars = src => {
      const m = src.replace(/\/\*[\s\S]*?\*\//g, '').match(/:root\s*\{([^}]*)\}/);
      return Object.fromEntries([...m[1].matchAll(/(--[\w-]+)\s*:\s*([^;]+);/g)].map(x => [x[1], x[2].trim()]));
    };
    const mainRoot = vars(SRC.slice(SRC.search(/<style(?:\s[^>]*)?>/)));
    const d = vars(DSRC.slice(DSRC.search(/<style(?:\s[^>]*)?>/)));
    const bad = Object.keys(d).filter(k => mainRoot[k] !== undefined && mainRoot[k] !== d[k])
      .map(k => k + ' ' + d[k] + ' vs ' + mainRoot[k]);
    const unknown = Object.keys(d).filter(k => mainRoot[k] === undefined);
    if (bad.length || unknown.length)
      throw new Error((bad.length ? 'differ: ' + bad.join('; ') : '') + (unknown.length ? ' unknown: ' + unknown.join(', ') : ''));
  });
  t('the delta stylesheet holds no raw colour outside :root', () => {
    const css = DSRC.slice(DSRC.search(/<style(?:\s[^>]*)?>/), DSRC.indexOf('</style>'))
      .replace(/@font-face\{[^}]*\}/g, '').replace(/:root\s*\{[^}]*\}/, '');
    const hits = css.match(/#[0-9a-fA-F]{3,8}\b/g) || [];
    if (hits.length) throw new Error('raw colours: ' + hits.join(', '));
  });

  console.log('\n== Pedigree values say what they are ==');
  t('each pedigree row says whether its value is a release date or a status', () => {
    const X = deltaSandbox(['chpBom', 'pedigreeDelta', 'chpAlignOf', '_colLetter', 'chpAlignLabel', 'chpAlignDiff', 'chpAlignContext']);
    const tr = (dcn, ecn) => ({ dcn: [[dcn[0], dcn[1]]], ecn: [[ecn[0], ecn[1]]], ecr: [] });
    const A = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr(['D1', '2024-01-01'], ['E1', 'OPEN']) }] };
    const B = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr(['D1', '2024-02-01'], ['E1', 'CLOSED']) }] };
    const rows = X.pedigreeDelta(A, B).rows;
    const by = Object.fromEntries(rows.map(r => [r['Record Type'], r['Value Meaning']]));
    eq(by, { DCN: 'release date', ECN: 'status' });
  });

  // v3.5 — Change Pedigree Alignment (main build v182).
  console.log('\n== Change Pedigree Alignment (v3.5) ==');
  const CAX = () => deltaSandbox(['chpBom', 'pedigreeDelta', 'chpAlignOf', '_colLetter', 'chpAlignLabel', 'chpAlignDiff', 'chpAlignContext']);
  const drawingSess = (o) => Object.assign({ rule: 'drawing', ebomDrawCol: 12, matchRev: false, ebomRevCol: null }, o || {});
  t('the delta tool names the rules in the main build\u2019s words', () => {
    const X = CAX();
    const main = sandbox({ state: { chpAlign: null } }, ['chpalign']).CA;
    [null, drawingSess(), drawingSess({ matchRev: true, ebomRevCol: 13 })].forEach(a => {
      const words = X.chpAlignLabel({ chpAlign: a }).replace(/ \(EBOM [^)]*\)$/, '');
      eq(words, main._chpAlignRuleLabel(a || { rule: 'pn_nh' }));
    });
    eq(X.chpAlignLabel({ chpAlign: drawingSess({ matchRev: true, ebomRevCol: 13 }) }),
       'Drawing number + revision (EBOM drawing column M, revision column N)', 'with columns:');
  });
  t('a session without the field, or with a rule it does not know, is the default', () => {
    const X = CAX();
    eq([X.chpAlignOf({}), X.chpAlignOf({ chpAlign: { rule: 'pn_nh' } }), X.chpAlignOf({ chpAlign: { rule: 'other' } })], [null, null, null]);
    eq(X.chpAlignDiff({}, { chpAlign: { rule: 'pn_nh' } }), { same: true, anyCustom: false });
  });
  t('two default sessions: no warning, no caveat, no Via Drawing column', () => {
    const X = CAX();
    const tr = e => ({ dcn: [], ecn: [], ecr: [[e, 'OPEN']] });
    const A = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr('R1') }] };
    const B = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr('R2') }] };
    eq(X.chpAlignContext(A, B).warning, '');
    const d = X.pedigreeDelta(A, B);
    eq(d.caveat, undefined);
    if (d.rows.some(r => 'Via Drawing' in r)) throw new Error('a default report gained a column');
  });
  t('different rules: warned at load, noted on the pedigree sheet, drawings named', () => {
    const X = CAX();
    const tr = e => ({ dcn: [], ecn: [], ecr: [[e, 'OPEN']] });
    const A = { boms: { chp: {} }, results: [{ key: 'P||N', pn: 'P', nh: 'N', trace: tr('R1') }] };
    const B = { boms: { chp: {} }, chpAlign: drawingSess(),
                results: [{ key: 'P||N', pn: 'P', nh: 'N', chpVia: ['D-1'], trace: tr('R2') }] };
    const w = X.chpAlignContext(A, B).warning;
    if (!/Part number \+ next higher/.test(w) || !/Drawing number \(EBOM drawing column M\)/.test(w)) throw new Error('warning: ' + w);
    const d = X.pedigreeDelta(A, B);
    eq(d.caveat, w, 'the sheet carries the same words:');
    eq(d.rows.map(r => r['Via Drawing']), ['D-1', 'D-1'], 'every row names the drawing:');
    eq(X.chpAlignDiff(B, Object.assign({}, B, { chpAlign: drawingSess({ ebomDrawCol: 13 }) })).same, false, 'same rule, different column:');
  });
  t('the summary row is gated on a non-default rule, and the load warning is wired', () => {
    const b = grabDelta('buildSummaryRows');
    if (!/if \(_caDiff\.anyCustom\)[\s\S]{0,200}line\('Change Pedigree alignment'/.test(b)) throw new Error('summary row not gated on a non-default rule');
    if (DSRC.indexOf('var _ca = chpAlignContext(state.A, state.B);') < 0) throw new Error('no load warning');
  });
});

// ── v177 visual grammar ────────────────────────────────────────────────────
// v177 shipped a visual refactor with no tests. These pin what its own
// comments say must not come back, and pin the one thing it left open.
suite('Visual grammar and type scale', (t, eq) => {
  const css = [...SRC.matchAll(/<style(?:\s[^>]*)?>([\s\S]*?)<\/style>/g)].map(m => m[1]).join('\n');
  t('the metric bar is gone and stays gone', () => {
    if (/metric-bar/.test(SRC)) throw new Error('a metric bar is back: a KPI card reports a finding, not progress');
  });
  t('the three component primitives exist', () => {
    ['.panel', '.toolbar', '.u-label'].forEach(c => {
      if (!new RegExp('\\' + c + '\\b[^{]*\\{').test(css)) throw new Error(c + ' is not defined');
    });
  });
  t('section jump links are text, underlined when active, like .tab', () => {
    const r = css.match(/\.section-nav a\s*\{([^}]*)\}/);
    if (!r) throw new Error('no .section-nav a rule');
    if (!/border:\s*0/.test(r[1]) || !/background:\s*none/.test(r[1])) throw new Error('jump links look like buttons again');
    if (!/\.section-nav a\.active\s*\{[^}]*border-bottom-color/.test(css)) throw new Error('active link is not underlined');
  });
  t('the type scale has four steps and an 11px floor', () => {
    // v180 — before this, seven declarations used a size token and ~630 wrote
    // 8-13px directly, so there was no floor to raise. The scale is the floor.
    const v = n => parseFloat((SRC.match(new RegExp(n + ':\\s*(\\d+(?:\\.\\d+)?)px')) || [])[1]);
    const steps = ['--fs-xs', '--fs-sm', '--fs-md', '--fs-lg'].map(v);
    if (steps.some(x => !x)) throw new Error('a scale step is missing: ' + steps.join(', '));
    if (steps[0] < 11) throw new Error('the floor is ' + steps[0] + 'px');
    steps.forEach((x, i) => { if (i && x <= steps[i - 1]) throw new Error('the scale does not ascend: ' + steps.join(', ')); });
  });
  t('every size below 14px comes from the scale, never a literal', () => {
    // Stylesheets, inline styles and script-built markup alike. The vendored
    // SheetJS is not ours and is skipped. One named exception: the render-error
    // banner, which must not depend on CSS variables (Tier 12).
    const app = SRC.slice(at('</script>'));
    const hits = [];
    for (const m of app.matchAll(/font-size:\s*(\d+(?:\.\d+)?)px/g)) {
      if (+m[1] >= 14) continue;
      const ctx = app.slice(Math.max(0, m.index - 300), m.index);
      if (/id="kpi-render-error-banner"[^>]*$/.test(ctx)) continue;
      hits.push(m[0] + ' @' + (SRC.slice(0, SRC.indexOf(app) + m.index).split('\n').length));
    }
    // v180 review — sizes set from script bypass the "font-size:" spelling:
    // el.style.fontSize = '9px', and canvas fonts anywhere, not only in the
    // chart functions. Canvas cannot read CSS variables, so a canvas size may be
    // literal, but not below the floor.
    const line = i => SRC.slice(0, SRC.indexOf(app) + i).split('\n').length;
    for (const m of app.matchAll(/\.fontSize\s*=\s*['"`](\d+(?:\.\d+)?)px/g))
      if (+m[1] < 14) hits.push(m[0] + ' @' + line(m.index));
    for (const m of app.matchAll(/\.font\s*=\s*['"`][^'"`\n]*?(\d+(?:\.\d+)?)px/g))
      if (+m[1] < 11) hits.push('canvas ' + m[1] + 'px @' + line(m.index));
    if (hits.length) throw new Error(hits.length + ' literal size(s): ' + hits.slice(0, 6).join(', '));
  });
  t('every size token resolves at or above the floor', () => {
    const css = STYLE_BLOCKS[0].css;
    const raw = n => (css.match(new RegExp(n + '\\s*:\\s*([^;]+);')) || [])[1];
    const px = (n, d) => { const v = (raw(n) || '').trim(); const a = v.match(/^var\((--[\w-]+)\)$/);
      return a && (d || 0) < 5 ? px(a[1], (d || 0) + 1) : parseFloat(v); };
    const floor = px('--fs-xs');
    const toks = [...new Set([...css.matchAll(/(--fs-[\w-]+)\s*:/g)].map(m => m[1]))];
    const low = toks.filter(t => !(px(t) >= floor)).map(t => t + '=' + px(t));
    if (low.length) throw new Error('below the floor: ' + low.join(', '));
  });
});

// ── USER GUIDE ─────────────────────────────────────────────────────────────
// v179. The guide drifted for twenty builds — a stale version stamp, a symbol
// the tool had stopped using, colour and theme names that changed at v173-175,
// section numbers that skipped — because nothing compared it with the tool.
// Its source now ships as Comparator_User_Guide.md (build_guide.py turns it
// into the .docx) and this suite reads it. Every expectation is derived from
// the build: the badge map, the theme menu, the certificate rows, the versions.
// Not shipped alongside: nothing to check, and the suite says so.
function guideSource() {
  const dirs = [__dirname, path.join(__dirname, '..')];
  for (const d of dirs) {
    const f = path.join(d, 'Comparator_User_Guide.md');
    try { if (fs.statSync(f).isFile()) return fs.readFileSync(f, 'utf8'); } catch (e) {}
  }
  return null;
}
suite('User guide agrees with the build', (t, eq) => {
  const G = guideSource();
  const need = fn => () => { if (G === null) return; fn(); };
  if (G === null) console.log('  (Comparator_User_Guide.md not shipped alongside — nothing to compare)');
  const badgeKeys = () => {
    const a = at('const BADGE_HELP = {');
    const body = SRC.slice(a, SRC.indexOf('\n};', a));
    return new Set([...body.matchAll(/^\s*'([^']+)'\s*:/gm)].map(m => m[1]));
  };
  const known = (label, keys) => keys.has(label) || [...keys].some(k => k.startsWith(label + ' '));

  t('the guide is written for the build under test', need(() => {
    const v = SRC.match(/const APP_VERSION = '(v\d+)'/)[1];
    const stamps = [...G.matchAll(/for build (v\d+)|against build (v\d+)/g)].map(m => m[1] || m[2]);
    if (!stamps.length) throw new Error('no "for build vNNN" stamp in the guide');
    const wrong = stamps.filter(s => s !== v);
    if (wrong.length) throw new Error('guide says ' + wrong.join(', ') + '; the build is ' + v);
  }));
  t('the guide names the delta tool version that ships beside it', need(() => {
    const dv = (DSRC.match(/var DELTA_VERSION = '(v[\d.]+)'/) || [])[1];
    const named = [...G.matchAll(/Delta tool (v[\d.]+\d)/g)].map(m => m[1]);
    if (!named.length) throw new Error('the guide does not say which delta tool it describes');
    const wrong = named.filter(x => x !== dv);
    if (wrong.length) throw new Error('guide says Delta tool ' + wrong.join(', ') + '; the file is ' + dv);
  }));
  t('every symbol-led badge the guide names is a badge the build renders', need(() => {
    // "⬇ PROC REMOVED" yes; "⊘ PROC REMOVED" was the guide's for twenty builds.
    const keys = badgeKeys();
    const found = new Set();
    for (const m of G.matchAll(/([⚠✗⊘⬇⚑▲▼✓?◆]) ((?:[A-Z0-9][A-Z0-9./&()-]*(?![a-z])(?: |$))*[A-Z0-9][A-Z0-9./&()-]*(?![a-z]))/gm)) {
      let lab = (m[1] + ' ' + m[2]).replace(/[).]+$/, '');
      if ((lab.match(/\(/g) || []).length > (lab.match(/\)/g) || []).length) lab += ')';
      found.add(lab.trim());
    }
    const bad = [...found].filter(l => !known(l, keys));
    if (bad.length) throw new Error('not a badge in this build: ' + bad.join(', '));
  }));
  t('every label in the status table is a badge the build renders', need(() => {
    const keys = badgeKeys();
    const a = G.indexOf('What the statuses mean');
    if (a < 0) throw new Error('the status table heading moved');
    const tbl = G.slice(a, G.indexOf('\n\n', G.indexOf('| --- |', a) + 10));
    const labels = [...tbl.matchAll(/^\| ([^|]+?) \|/gm)].map(m => m[1]).filter(l => !/^Status|^---/.test(l))
      .flatMap(c => c.split(' / ')).map(s => s.replace(/\*/g, '').trim());
    if (labels.length < 8) throw new Error('only ' + labels.length + ' labels found — table format changed?');
    const bad = labels.filter(l => !known(l, keys));
    if (bad.length) throw new Error('not a badge in this build: ' + bad.join(', '));
  }));
  t('the guide uses the theme names the menu shows', need(() => {
    const sel = SRC.slice(at('id="theme-select"'), SRC.indexOf('</select>', at('id="theme-select"')));
    const names = [...sel.matchAll(/<option[^>]*>([^<]+)<\/option>/g)].map(m => m[1].replace(/&amp;/g, '&'));
    if (names.length !== 3) throw new Error('theme menu has ' + names.length + ' options');
    const missing = names.filter(n => G.indexOf(n) < 0);
    if (missing.length) throw new Error('the guide never names: ' + missing.join(', '));
    // A retired name may survive only in the history appendix, where it is true.
    const body = G.slice(0, G.indexOf('What changed since'));
    if (/high contrast/i.test(body)) throw new Error('"High contrast" outside the history appendix; the menu says ' + names[2]);
  }));
  t('every section the guide refers to exists, and numbering has no gaps', need(() => {
    const heads = [...G.matchAll(/^#{1,3} (\d+)\.(\d+)?/gm)].map(m => m[2] ? m[1] + '.' + m[2] : m[1]);
    const set = new Set(heads);
    const refs = [...G.matchAll(/(?:\(|[Ss]ee |[Ii]n |§)(\d{1,2}\.\d{1,2})\b/g)].map(m => m[1]);
    const dangling = [...new Set(refs)].filter(r => !set.has(r));
    if (dangling.length) throw new Error('refers to missing section(s): ' + dangling.join(', '));
    // A section must sit inside its own chapter (v176 had 3.6 inside chapter 4).
    let cur = null;
    heads.forEach(h => {
      if (h.indexOf('.') < 0) { cur = h; return; }
      if (h.split('.')[0] !== cur) throw new Error('section ' + h + ' sits inside chapter ' + cur);
    });
    const chapters = heads.filter(h => h.indexOf('.') < 0).map(Number);
    chapters.forEach((c, i) => { if (c !== i + 1) throw new Error('chapter ' + c + ' follows ' + (chapters[i - 1] || 'the title')); });
    chapters.forEach(c => {
      const subs = heads.filter(h => h.startsWith(c + '.')).map(h => +h.split('.')[1]);
      subs.forEach((n, i) => { if (n !== i + 1) throw new Error('section ' + c + '.' + n + ' follows ' + (i ? c + '.' + subs[i - 1] : 'chapter ' + c)); });
    });
  }));
  t('the certificate description names every row the certificate prints', need(() => {
    // Phrase per certificate row. A row added to _auditCertRows with no phrase
    // here fails by name: the guide has to learn about it too.
    const PHRASE = { 'Auditor': 'auditor', 'Frozen': 'timestamp', 'Mode': 'comparison mode', 'Build': 'build',
      'Proc Code Profile': 'proc code profile', 'EBOM Indenture Scope': 'indenture scope',
      'Removal Proc Codes': 'removal', 'Swap Proc Codes': 'swap', 'SHA-256 Integrity Hash': 'hash',
      'Change Pedigree Alignment': 'change pedigree alignment' };   // v182
    const rows = [...grabFn('_auditCertRows').matchAll(/\[\s*'([^']+)'\s*,/g)].map(m => m[1]);
    const a = G.indexOf('Finalize & Freeze'); const sec = G.slice(a, G.indexOf('\n# ', a)).toLowerCase();
    const bad = rows.filter(r => !PHRASE[r] || sec.indexOf(PHRASE[r]) < 0);
    if (bad.length) throw new Error('10.2 does not describe: ' + bad.join(', '));
  }));
  t('the history appendix has a row for the build under test', need(() => {
    const v = SRC.match(/const APP_VERSION = '(v\d+)'/)[1];
    if (!new RegExp('^\\| ' + v + ' \\|', 'm').test(G)) throw new Error('no "What changed" row for ' + v);
  }));
});

suite('Version single-source', (t, eq) => {
  t('exactly one hardcoded version string in the file', ()=>{
    const m = SRC.match(/const APP_VERSION = '(v\d+)'/);
    if(!m) throw new Error('APP_VERSION not found');
    // no other vNNN literal in visible markup
    const body = SRC.slice(SRC.indexOf('<div class="header"'), SRC.indexOf('<script', SRC.indexOf('<div class="header"')));
    const stripped = body.replace(/<!--[\s\S]*?-->/g,'');
    // Dev/Logic tooltip blocks legitimately cite the release a behaviour landed
    // in ("v66 pre-filters the ABOM"). Those are provenance prose, not a claim
    // about which version is running. Exclude them; anything else is a drift risk.
    const noDev = stripped.replace(/<div class="metric-tooltip-dev"[\s\S]*?<\/div>\s*<\/div>/g,'');
    const vis = noDev.replace(/<[^>]+>/g,' ');
    const hits = vis.match(/\bv\d{2,3}\b/g) || [];
    if(hits.length) throw new Error('version literals still in chrome: '+hits.join(', '));
  });
  t('the pill has an id and no literal', ()=>{
    if(!SRC.includes('id="app-version-pill"')) throw new Error('no id');
    if(/<span class="pill">v\d+<\/span>/.test(SRC)) throw new Error('literal pill remains');
  });
  t('renderVersionPill is called at boot', ()=>{
    if(!/renderVersionPill\(\);/.test(SRC)) throw new Error('never called');
  });
  t('APP_VERSION matches the build', ()=>{
    const m=SRC.match(/const APP_VERSION = '(v\d+)'/);
    if(m[1]!=='v182') throw new Error('says '+m[1]);
  });
});


// ── TIER 22 ────────────────────────────────────────────────────────────────
// v182 — CHANGE PEDIGREE ALIGNMENT. Two promises, tested separately.
//
// 1. The default rule is v181, unchanged. Twelve places used to work out the
//    CHP-to-EBOM join for themselves, with four different rules between them.
//    They now call one module, and each call must reproduce ITS OWN v181 rule,
//    including the two disagreements kept on purpose (KI-1, KI-2). A guard
//    fails if code outside the module reads the CHP join columns again.
//    The strongest check is the browser equivalence run (--reference), which
//    compares every output with a v181 build; these tests pin the rules.
// 2. The drawing rule does what the owner agreed: an ECR attaches to every
//    EBOM line on its drawing, matched exactly after trim and upper-case, with
//    no part-number fallback, and it is visible everywhere results go.
const REAL_COL = (function () {
  const a = at('const COL = {');
  const ctx = {}; vm.createContext(ctx);
  vm.runInContext(SRC.slice(a, at('};', a) + 2).replace('const COL', 'globalThis.COL'), ctx);
  return ctx.COL;
})();

// The source with the alignment module cut out, for the guards below.
function srcOutsideChpAlign(src) {
  const a = src.indexOf('// ── v182 — CHANGE PEDIGREE ALIGNMENT: DRAWING RULE (worker-safe)');
  const b = src.indexOf('// ── v182 — CHANGE PEDIGREE ALIGNMENT: END');
  if (a < 0 || b < a) throw new Error('BUILD MARKER MOVED: the CHANGE PEDIGREE ALIGNMENT block');
  return src.slice(0, a) + src.slice(b);
}
// Every place outside the module that reads a CHP join column. The COL table
// itself is not a read.
function chpJoinReadsOutside(src) {
  const out = stripComments(srcOutsideChpAlign(src));
  const colA = out.indexOf('const COL = {'), colB = out.indexOf('};', colA);
  const body = out.slice(0, colA) + out.slice(colB);
  const hits = [];
  for (const m of body.matchAll(/COL\.chp\.(pn|nh|docNo|docRev)\b/g)) hits.push(m[0]);
  for (const m of body.matchAll(/\bcr\[10\]/g)) hits.push(m[0]);
  return hits;
}

suite('Tier 22 — Change Pedigree Alignment', (t, eq) => {
  const mk = (extraState) => sandbox({ COL: REAL_COL,
    state: Object.assign({ results: [], boms: {}, isLocked: false, chpManualMap: null, ebomManualMap: null, mode: 'ebom_mbom_abom' }, extraState || {}),
    esc: s => String(s) }, ['engine', 'chp', 'chpalign']);
  const chpRow = o => { const r = new Array(25).fill(''); const C = REAL_COL.chp;
    Object.keys(o).forEach(k => { r[C[k]] = o[k]; }); return r; };
  const trace = (d, e, r) => ({ dcn: new Map(d || []), ecn: new Map(e || []), ecr: new Map(r || []) });
  const R = (pn, nh, o) => Object.assign({ key: pn + '||' + nh, pn, nh, trace: trace() }, o || {});

  console.log('\n== One place reads the CHP join columns ==');
  t('no code outside the module reads the CHP part number, next higher or drawing columns', () => {
    const hits = chpJoinReadsOutside(SRC);
    if (hits.length) throw new Error(hits.length + ' direct read(s) outside CHANGE PEDIGREE ALIGNMENT: ' + [...new Set(hits)].join(', '));
  });
  t('the guard would catch a join written the old way', () => {
    const planted = SRC.replace('function exportCSV(', "function _planted(cr){ return normPN(cr[COL.chp.pn]) + String(cr[10]); }\nfunction exportCSV(");
    eq(chpJoinReadsOutside(planted).length, 2, 'planted reads found:');
  });
  t('every former join site calls the module', () => {
    const out = stripComments(srcOutsideChpAlign(SRC));
    const n = re => (out.match(re) || []).length;
    eq(n(/chpDrawingForLine\(/g), 5, 'Drawing column sites (Detailed View + four exports):');
    eq(n(/chpHistoryState\(/g) >= 6, true, 'History label sites:');
    eq(n(/_chpIngestKeyCol\(\)/g), 2, 'CHP upload and re-read filters:');
    ['chpEntriesForCiTrace(', 'chpEntriesForLineExact(', 'chpEntriesForPn(', 'chpResultForChpRow(',
     'chpEcnItemIndex()', 'chpEcnItemKeysOf(', 'chpDocLookup()'].forEach(f => {
      if (out.indexOf(f) < 0) throw new Error('no call to ' + f);
    });
    if (/'\|\|'/.test(grabFn('renderChpTable'))) throw new Error('renderChpTable builds its own join key again');
  });

  console.log('\n== The default rule is v181, site by site ==');
  t('a state without the field reads as the default rule', () => {
    const c = mk(); delete c.state.chpAlign;
    eq([c.CA.chpAlignRule(), c.CA.isChpAlignCustom(), c.CA.chpAlignRunBlocker(), c.CA.chpAlignEnginePlan()],
       ['pn_nh', false, '', null]);
    eq(c.CA._chpAlignForSession(), undefined, 'nothing is written to the session:');
  });
  t('the upload filter column is v181’s: part number, manual position when mapped', () => {
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    eq(c.CA._chpIngestKeyCol(), REAL_COL.chp.pn);
    c.state.chpManualMap = { pn: 7, docNo: 2 };
    eq(c.CA._chpIngestKeyCol(), 7);
    eq(c.CA._chpRequiredMapKeys(), ['pn', 'nh'], 'required manual-map fields:');
  });
  t('Drawing column: first non-blank drawing for the exact PN + NH, no fallback (KI-1)', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'p1', nh: 'a', docNo: '' }), chpRow({ pn: 'P1', nh: 'A', docNo: 'D-1' }),
                               chpRow({ pn: 'P1', nh: 'A', docNo: 'D-2' }), chpRow({ pn: 'P2', nh: 'X', docNo: 'D-9' })] };
    eq(c.CA.chpDrawingForLine(R('P1', 'A')), 'D-1', 'first non-blank, case-insensitive key:');
    eq(c.CA.chpDrawingForLine(R('P2', 'A')), '', 'no part-number fallback:');
    eq(c.CA.chpDrawingForLine(R('P9', '')), '');
  });
  t('CI Traceability detail: exact PN + NH, else every row for the part number', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'P1', nh: 'A', ecr: 'R1' }), chpRow({ pn: 'P1', nh: 'B', ecr: 'R2' })] };
    eq(c.CA.chpEntriesForCiTrace('P1', 'A', null).map(e => e.ecr), ['R1']);
    eq(c.CA.chpEntriesForCiTrace('P1', 'Z', null).map(e => e.ecr), ['R1', 'R2'], 'fallback:');
  });
  t('CI report sheets: exact next higher, and part number alone for the next-higher sheet', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'P1', nh: 'A', ecr: 'R1' }), chpRow({ pn: 'P1', nh: 'B', ecr: 'R2' })] };
    eq(c.CA.chpEntriesForLineExact('P1', 'B').map(e => e.ecr), ['R2']);
    eq(c.CA.chpEntriesForLineExact('P1', 'Z'), [], 'no fallback on this sheet:');
    eq(c.CA.chpEntriesForPn('P1').map(e => e.ecr), ['R1', 'R2']);
  });
  t('Change Pedigree tab: raw PN + NH, case-sensitive (KI-2)', () => {
    const c = mk();
    c.state.results = [R('P1', 'A')];
    eq(!!c.CA.chpResultForChpRow(chpRow({ pn: ' P1 ', nh: 'A' })), true, 'trimmed match:');
    eq(c.CA.chpResultForChpRow(chpRow({ pn: 'p1', nh: 'A' })), null, 'lower case does not match, as in v181:');
    eq(c.CA.chpResultForChpRow(chpRow({ pn: 'P1', nh: 'B' })), null, 'no fallback:');
  });
  t('ECN completeness: part numbers, matched on part number alone', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'p1', nh: 'A', ecn: 'E1' }), chpRow({ pn: 'P2', nh: 'B', ecn: 'E1' }), chpRow({ pn: 'P3', ecn: '' })] };
    const idx = c.CA.chpEcnItemIndex();
    eq([...idx.get('E1')], ['P1', 'P2']);
    eq(c.CA.chpEcnItemKeysOf(R('p9', 'X')), ['P9']);
  });
  t('ECN report document lookup: PN + NH, else PN with a blank next higher', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ pn: 'P1', nh: '', docNo: 'D-0', docRev: 'Z' }), chpRow({ pn: 'P1', nh: 'A', docNo: 'D-1', docRev: 'A' })] };
    const look = c.CA.chpDocLookup();
    eq(look('P1', 'A'), { docNo: 'D-1', docRev: 'A' });
    eq(look('P1', 'Q'), { docNo: 'D-0', docRev: 'Z' });
    eq(look('P9', 'Q'), { docNo: '', docRev: '' });
  });
  t('the History badge and tooltip are chpReleaseState and chpTraceTooltip, unchanged', () => {
    const c = mk();
    [trace(), trace([], [['E1', 'OPEN']]), trace([['D1', '2024-03-15']]), trace([['D1', '']], [], [['R1', 'x']])].forEach(tr => {
      const r = R('P1', 'A', { trace: tr });
      eq(JSON.stringify(c.CA.chpHistoryState(r)), JSON.stringify(c.C.chpReleaseState(tr)));
      eq(c.CA.chpHistoryTooltip(r), c.chpTraceTooltip(tr));
    });
  });
  t('Change Pedigree tab search: the part number, plus the drawing number under the drawing rule', () => {
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    const row = chpRow({ pn: 'P1', docNo: 'D-7' });
    eq(c.CA.chpRowSearchText(row), 'P1', 'default, as v181:');
    c.state.chpAlign = { rule: 'drawing' };
    if (c.CA.chpRowSearchText(row).indexOf('D-7') < 0) throw new Error('drawing number not searchable');
  });
  t('Change Pedigree tab headings: the file\u2019s own, except under the drawing rule with a manual map', () => {
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    const bom = { header: ['Drawing Number', 'Rev', 'ECR'] };
    c.state.chpManualMap = { docNo: 0, ecr: 2 };
    eq([0, 1, 10, 19].map(i => c.CA.chpTabHeaderLabel(bom, i)), ['Drawing Number', 'Rev', 'K', 'T'], 'default, as v181 (KI-3):');
    c.state.chpAlign = { rule: 'drawing' };
    eq([10, 19, 0].map(i => c.CA.chpTabHeaderLabel(bom, i)), ['Document/Drawing Number', 'ECR', 'A'], 'drawing rule:');
  });
  t('a default run adds nothing to its results', () => {
    const c = mk();
    const rows = [R('P1', 'A')];
    c.CA.chpAttachVia(rows, null);
    eq(Object.keys(rows[0]).indexOf('chpVia'), -1, 'no chpVia field:');
    c.state.results = rows;
    eq(c.CA.chpEcnReportUnavailable(), '', 'ECN reports stay available:');
    eq(c.CA.chpAlignStats(), null, 'no match summary:');
  });

  console.log('\n== The drawing rule ==');
  const eb = (pn, nh, dwg, rev) => { const r = new Array(40).fill(''); r[1] = pn; r[3] = nh; r[12] = dwg == null ? '' : dwg; r[13] = rev == null ? '' : rev; return r; };
  const drawingState = (ebomRows, align) => {
    const c = mk({ chpAlign: Object.assign({ rule: 'drawing', ebomDrawCol: 12, matchRev: false, ebomRevCol: null }, align || {}) });
    c.state.boms.ebom = { raw: [new Array(40).fill('H')].concat(ebomRows), data: ebomRows.map(r => r.slice()) };
    return c;
  };
  t('an ECR attaches to every EBOM line on its drawing, and to nothing else', () => {
    const c = drawingState([eb('P1', 'A', 'D-1'), eb('P2', 'A', 'd-1 '), eb('P3', 'A', 'D-2'), eb('P4', 'A', '')]);
    const lines = c.CA.chpEbomDrawingIndex();
    eq(lines, { 'P1||A': ['D-1'], 'P2||A': ['D-1'], 'P3||A': ['D-2'], 'P4||A': [] });
    const m = c.CA.buildChpTraceMapByDrawing([chpRow({ docNo: 'D-1', ecr: 'R1' }), chpRow({ docNo: 'D-9', ecr: 'R9' })],
                                             REAL_COL.chp, { matchRev: false, ebomDrawings: lines });
    eq(Object.keys(m.map).sort(), ['P1||A', 'P2||A'], 'lines on D-1:');
    eq([...m.map['P2||A'].ecr.keys()], ['R1']);
    eq(m.pnMap, {}, 'no part-number fallback under this rule:');
  });
  t('the match is exact after trim and upper-case: no fuzzy matching', () => {
    const c = drawingState([eb('P1', 'A', 'D-100'), eb('P2', 'A', 'D100')]);
    const m = c.CA.buildChpTraceMapByDrawing([chpRow({ docNo: ' d-100 ', ecr: 'R1' })], REAL_COL.chp,
                                             { matchRev: false, ebomDrawings: c.CA.chpEbomDrawingIndex() });
    eq(Object.keys(m.map), ['P1||A'], 'D100 is not D-100:');
  });
  t('drawing + revision attaches only where the revision matches too', () => {
    const c = drawingState([eb('P1', 'A', 'D-1', 'A'), eb('P2', 'A', 'D-1', 'B')], { matchRev: true, ebomRevCol: 13 });
    const lines = c.CA.chpEbomDrawingIndex();
    eq(lines['P1||A'], ['D-1||A']);
    const m = c.CA.buildChpTraceMapByDrawing([chpRow({ docNo: 'D-1', docRev: 'a', ecr: 'R1' })], REAL_COL.chp,
                                             { matchRev: true, ebomDrawings: lines });
    eq(Object.keys(m.map), ['P1||A']);
  });
  t('merged duplicate lines collect every drawing, and the traces merge', () => {
    const c = drawingState([eb('P1', 'A', 'D-1'), eb('P1', 'A', 'D-2')]);
    const lines = c.CA.chpEbomDrawingIndex();
    eq(lines['P1||A'], ['D-1', 'D-2']);
    const m = c.CA.buildChpTraceMapByDrawing([chpRow({ docNo: 'D-1', ecr: 'R1' }), chpRow({ docNo: 'D-2', ecr: 'R2' })], REAL_COL.chp,
                                             { matchRev: false, ebomDrawings: lines });
    eq([...m.map['P1||A'].ecr.keys()], ['R1', 'R2']);
  });
  t('the EBOM drawing column is read from the file as uploaded, under Mapping 2 too', () => {
    // Mapping 2 keeps only canonical columns after ingest, so column M is gone
    // from data. It must come from raw, row for row.
    const raw = [eb('P1', 'A', 'D-1'), eb('P2', 'A', 'D-2')];
    const c = drawingState(raw);
    c.state.boms.ebom.data = raw.map(r => { const x = new Array(40).fill(''); x[1] = r[1]; x[3] = r[3]; return x; });
    eq(c.CA.chpEbomDrawingIndex(), { 'P1||A': ['D-1'], 'P2||A': ['D-2'] });
  });
  t('raw rows that do not line up with the parsed EBOM are refused, not guessed', () => {
    const c = drawingState([eb('P1', 'A', 'D-1'), eb('P2', 'A', 'D-2')]);
    c.state.boms.ebom.data = [c.state.boms.ebom.data[1], c.state.boms.ebom.data[0]];
    eq(c.CA._ebomSourceRows(), null);
    c.state.boms.chp = { data: [] };
    if (!/Re-upload the EBOM/.test(c.CA.chpAlignRunBlocker())) throw new Error('run not blocked: ' + c.CA.chpAlignRunBlocker());
  });
  t('a run is blocked, in words, until the picks are made', () => {
    const c = drawingState([eb('P1', 'A', 'D-1')], { ebomDrawCol: null });
    eq(c.CA.chpAlignRunBlocker(), '', 'no CHP file: nothing to align, nothing to block:');
    c.state.boms.chp = { data: [] };
    if (!/Choose the EBOM column/.test(c.CA.chpAlignRunBlocker())) throw new Error('no-column message missing');
    c.state.chpAlign.ebomDrawCol = 12; c.state.chpAlign.matchRev = true;
    if (!/revision column/.test(c.CA.chpAlignRunBlocker())) throw new Error('no-revision-column message missing');
    c.state.chpAlign.matchRev = false; c.state.chpManualMap = { docNo: null, ecr: 3 };
    if (!/Document\/Drawing Number and ECR/.test(c.CA.chpAlignRunBlocker())) throw new Error('manual-map message missing');
    c.state.chpManualMap = null; c.state.mode = 'mbom_abom';
    if (!/has no EBOM/.test(c.CA.chpAlignRunBlocker())) throw new Error('no-EBOM mode not blocked');
    c.state.mode = 'ebom_mbom_abom';
    eq(c.CA.chpAlignRunBlocker(), '', 'ready:');
    if (!c.CA.chpAlignEnginePlan().ebomDrawings['P1||A']) throw new Error('plan has no drawings');
  });
  t('History badge: NO DRAWING, ECR ONLY, and the DCN states unchanged', () => {
    const c = mk();
    const st = (via, tr) => c.CA.chpHistoryState(R('P1', 'A', { chpVia: via, trace: tr }));
    eq([st([], trace()).label, st([], trace()).state], ['NO DRAWING', 'no_drawing']);
    eq(st(['D-1'], trace([], [], [['R1', '']])).label, 'ECR ONLY');
    eq(st(['D-1'], trace([], [['E1', 'OPEN']], [['R1', '']])).label, 'NO DCN', 'an ECN present is not ECR only:');
    eq(st(['D-1'], trace([['D1', '2024-03-15']])).state, 'released');
    eq(st(['D-1'], trace()).label, 'NO HISTORY');
    eq(c.C.chpStateClass('no_drawing'), 'badge badge-neutral');
    if (!/Via drawing D-1/.test(c.CA.chpHistoryTooltip(R('P1', 'A', { chpVia: ['D-1'], trace: trace([], [], [['R1', '']]) }))))
      throw new Error('tooltip does not name the drawing');
  });
  t('every consumer follows the run’s rule', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ docNo: 'D-1', docRev: 'A', ecr: 'R1', ecn: '' }), chpRow({ docNo: 'D-9', ecr: 'R9' })] };
    c.state.results = [R('P1', 'A', { chpVia: ['D-1'] }), R('P2', 'A', { chpVia: [] })];
    eq(c.CA.chpDrawingForLine(c.state.results[0]), 'D-1', 'Drawing column is the EBOM’s own:');
    eq(c.CA.chpEntriesForCiTrace('P1', 'A', c.state.results[0]).map(e => e.ecr), ['R1']);
    eq(c.CA.chpEntriesForCiTrace('P2', 'A', c.state.results[1]), []);
    eq(c.CA.chpEntriesForLineExact('P1', 'A').map(e => e.ecr), ['R1']);
    eq(c.CA.chpEntriesForPn('P1').map(e => e.ecr), ['R1']);
    eq(c.CA.chpResultForChpRow(chpRow({ docNo: 'd-1' })).pn, 'P1', 'CHP tab matches by drawing:');
    eq(c.CA.chpResultForChpRow(chpRow({ docNo: 'D-9' })), null, 'a drawing not in the EBOM is NO MATCH:');
    eq(c.CA.chpDocLookup()('P1', 'A', c.state.results[0]), { docNo: 'D-1', docRev: 'A' });
    const st = c.CA.chpAlignStats();
    eq([st.rows, st.matchedRows, st.drawings, st.unmatched, st.lines], [2, 1, 2, 1, 1], 'match summary:');
  });
  t('ECN reports: not available when the extract has no ECNs, by drawing when it has', () => {
    const c = mk();
    c.state.boms.chp = { data: [chpRow({ docNo: 'D-1', ecr: 'R1' })] };
    c.state.results = [R('P1', 'A', { chpVia: ['D-1'] })];
    if (!/Not available/.test(c.CA.chpEcnReportUnavailable())) throw new Error('no-ECN extract not refused');
    c.state.boms.chp.data.push(chpRow({ docNo: 'D-1', ecn: 'E1' }), chpRow({ docNo: 'D-7', ecn: 'E1' }));
    eq(c.CA.chpEcnReportUnavailable(), '');
    eq([...c.CA.chpEcnItemIndex().get('E1')], ['D-1', 'D-7'], 'listed by drawing:');
    eq(c.CA.chpEcnItemKeysOf(c.state.results[0]), ['D-1']);
  });
  t('the drawing rule keeps CHP rows by drawing number and requires drawing + ECR', () => {
    const c = mk({ chpAlign: { rule: 'drawing' } });
    eq(c.CA._chpIngestKeyCol(), REAL_COL.chp.docNo);
    c.state.chpManualMap = { pn: null, docNo: 0 };
    eq(c.CA._chpIngestKeyCol(), 0);
    eq(c.CA._chpRequiredMapKeys(), ['docNo', 'ecr']);
    const save = grabFn('_saveSuppManualMap');
    if (!/if \(bom === 'chp' && chpAlignRule\(\) === 'drawing'\) \{\s*map\[d\.key\] = null;/.test(save))
      throw new Error('under the drawing rule an unmapped CHP field would be read from a default column');
  });

  console.log('\n== It travels, and it is named ==');
  t('the engine is sent the plan on both paths, and results are stamped before the raw snapshot', () => {
    const post = SRC.slice(at('worker.postMessage({'), at('worker.postMessage({') + 1200);
    if (!/chpAlign:\s*chpPlan/.test(post)) throw new Error('postMessage does not carry the plan');
    if (!/d\.chpAlign \? buildChpTraceMapByDrawing\(d\.chpData, C\.chp, d\.chpAlign\)/.test(SRC)) throw new Error('the worker does not use the plan');
    const sync = grabFn('runSynchronous');
    if (!/const chpPlan = chpAlignEnginePlan\(\)/.test(sync) || !/chpPlan \? buildChpTraceMapByDrawing/.test(sync))
      throw new Error('the synchronous fallback does not use the same plan');
    [SRC.slice(at('worker.onmessage = function(e)'), at('worker.onerror')), sync].forEach((body, i) => {
      const a = body.indexOf('chpAttachVia(state.results, chpPlan)'), b = body.indexOf('state.resultsRaw');
      if (a < 0 || b < 0 || a > b) throw new Error((i ? 'sync' : 'worker') + ' path: results are not stamped before the raw snapshot');
    });
    const bundle = SRC.slice(at('const fns = ['), at('].map(fn => fn.toString())'));
    ['_chpDwgKey', 'buildChpTraceMapByDrawing'].forEach(f => { if (bundle.indexOf(f) < 0) throw new Error(f + ' is not in the worker bundle'); });
  });
  t('the session writes the rule only when it is not the default, and reads it back safely', () => {
    const exp = stripComments(grabFn('exportSessionJson'));
    if (!/chpAlign:\s*_chpAlignForSession\(\)/.test(exp)) throw new Error('the exporter does not write the rule');
    const imp = grabFn('importSessionJson');
    if (!/state\.chpAlign = _chpAlignSanitize\(payload\.chpAlign\)/.test(imp)) throw new Error('the importer does not restore it');
    const c = mk();
    eq(c.CA._chpAlignSanitize(undefined).rule, 'pn_nh', 'absent:');
    eq(c.CA._chpAlignSanitize({ rule: 'bogus', ebomDrawCol: 3 }).rule, 'pn_nh', 'unknown rule:');
    eq(c.CA._chpAlignSanitize({ rule: 'drawing', ebomDrawCol: -4, matchRev: 'yes', ebomRevCol: 2.5 }),
       { rule: 'drawing', ebomDrawCol: null, matchRev: false, ebomRevCol: null }, 'damaged fields:');
    c.state.chpAlign = { rule: 'drawing', ebomDrawCol: 12, matchRev: false, ebomRevCol: null };
    eq(c.CA._chpAlignForSession().label, 'Drawing number');
  });
  t('the hash and the certificate carry the rule only when it is not the default', () => {
    const f = stripComments(grabFn('freezeReport'));
    if (!/chpAlign:\s*_chpAlignForSession\(\)/.test(f)) throw new Error('the hash payload does not cover the rule');
    if (!/chpAlignment:\s*isChpAlignCustom\(\) \? _chpAlignLabel\(\) : undefined/.test(f)) throw new Error('the certificate does not name it');
    const ctx = sandbox({ _procProfileLabel: () => 'P', _collectorScopeLabel: () => 'S', _procCodesWithBehavior: () => [] });
    vm.runInContext(grabFn('_auditCertRows') + '\nglobalThis.rows = _auditCertRows;', ctx);
    const names = c => ctx.rows(c).map(r => r[0]);
    if (names({ hash: 'h' }).indexOf('Change Pedigree Alignment') >= 0) throw new Error('a default certificate prints an alignment row');
    const withRule = ctx.rows({ hash: 'h', chpAlignment: 'Drawing number · EBOM drawing column M' });
    eq(withRule.find(r => r[0] === 'Change Pedigree Alignment')[1], 'Drawing number · EBOM drawing column M');
    const c2 = drawingState([eb('P1', 'A', 'D-1')]);
    c2.state.boms.ebom.raw[0][12] = 'Drawing No.';
    eq(c2.CA._chpAlignLabel(), 'Drawing number · EBOM drawing column M (Drawing No.)', 'the label names the column:');
  });
  t('Reset returns to the default; a frozen report refuses changes; changes mark results stale', () => {
    if (!/state\.chpAlign = Object\.assign\(\{\}, CHP_ALIGN_DEFAULT\)/.test(grabFn('resetAll'))) throw new Error('Reset keeps the rule');
    const c = mk({ chpAlign: { rule: 'pn_nh' }, isLocked: true });
    c.CA.setChpAlignRule('drawing'); c.CA.setChpAlignCol('draw', '12'); c.CA.setChpAlignMatchRev(true);
    eq(c.state.chpAlign, { rule: 'pn_nh' }, 'frozen report unchanged:');
    ['setChpAlignRule', 'setChpAlignCol', 'setChpAlignMatchRev', 'resetChpAlign'].forEach(fn => {
      if (grabFn(fn).indexOf('_procDirtySinceRun') < 0 && fn !== 'resetChpAlign') throw new Error(fn + ' does not mark results stale');
    });
  });
  t('freezing is refused while the rule differs from the run, never for a default program', () => {
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    eq(c.CA.chpAlignFreezeBlocker(), '', 'before any run:');
    c.CA.chpAlignMarkRun();
    eq(c.CA.chpAlignFreezeBlocker(), '', 'default run, default rule:');
    c.state.chpAlign = { rule: 'drawing', ebomDrawCol: 12 };
    if (!/changed since the last run/.test(c.CA.chpAlignFreezeBlocker())) throw new Error('not refused');
    c.CA.chpAlignMarkRun();
    eq(c.CA.chpAlignFreezeBlocker(), '', 'after a run under the new rule:');
    if (grabFn('freezeReport').indexOf('chpAlignFreezeBlocker()') < 0) throw new Error('freezeReport does not ask');
    // A session exported after the rule was changed, but before re-running.
    const s2 = mk({ chpAlign: { rule: 'drawing', ebomDrawCol: 12 } });
    s2.state.boms.chp = { data: [] }; s2.state.results = [R('P1', 'A')];
    s2.CA.chpAlignMarkImported();
    if (!s2.CA.chpAlignFreezeBlocker()) throw new Error('a session whose results predate its rule can be frozen');
    s2.state.chpAlign = { rule: 'pn_nh' }; s2.CA.chpAlignMarkImported();
    eq(s2.CA.chpAlignFreezeBlocker(), '', 'a consistent default session:');
  });
  t('the panel is on the page, reads Default, and the two new badges are explained', () => {
    ['chpa-panel', 'chpa-summary', 'chpa-body', 'chpa-caret'].forEach(id => { if (SRC.indexOf('id="' + id + '"') < 0) throw new Error('no #' + id); });
    const c = mk({ chpAlign: { rule: 'pn_nh' } });
    c.CA.renderChpAlignPanel();
    eq(c.__els['chpa-summary'].textContent, 'Default');
    const help = SRC.slice(at('const BADGE_HELP = {'), at('};', at('const BADGE_HELP = {')));
    ['ECR ONLY', 'NO DRAWING'].forEach(l => { if (help.indexOf("'" + l + "'") < 0) throw new Error(l + ' has no BADGE_HELP entry'); });
    const guide = grabFn('showBadgeGuide');
    ["row('ECR ONLY'", "row('NO DRAWING'"].forEach(l => { if (guide.indexOf(l) < 0) throw new Error('badge guide lacks ' + l); });
  });
});

// ── TIER 21 ────────────────────────────────────────────────────────────────
// v178 — the streaming session reader. _parseJsonStream is a hand-written JSON
// parser (v143) that every large session goes through, in the main build and,
// from delta v3.4, in the delta tool. Its own comment says it was verified by a
// separate session_stream_test.js; that file is not in the project, so the
// verification lives here now.
//
// The parser is async and t() is synchronous — a rejected promise inside t()
// would count as a PASS. So the cases run first, here, and their settled
// results are reported through t() afterwards. Nothing is awaited inside t().
async function streamCases() {
  const ctx = { console, JSON, Math, Array, Object, String, Number, Boolean, Error, Promise };
  ctx.globalThis = ctx; vm.createContext(ctx);
  vm.runInContext(deltaSlice(SRC, 'async function _parseJsonStream(', 'async function _readSessionPayload(') +
                  '\nglobalThis.P = _parseJsonStream;', ctx);
  const feed = (s, size) => { let i = 0;
    return async () => { if (i >= s.length) return null; const c = s.slice(i, i + size); i += size; return c; }; };
  const SIZES = [1, 2, 3, 7, 64, 1e9];
  const same = async (name, value) => {
    const s = JSON.stringify(value);
    for (const size of SIZES) {
      const got = await ctx.P(feed(s, size));
      if (JSON.stringify(got) !== s) return { name, error: new Error('differs from JSON.parse at chunk size ' + size) };
    }
    return { name };
  };
  const rejects = async (name, text) => {
    for (const size of SIZES) {
      let ok = false;
      try { await ctx.P(feed(text, size)); } catch (e) { ok = true; }
      if (!ok) return { name, error: new Error('accepted malformed input at chunk size ' + size) };
    }
    return { name };
  };
  // A payload shaped like exportSessionJson's streamed output: head, boms with
  // row arrays, both result arrays with Map-serialised traces, then the tail.
  const session = {
    schema: 'bom-comparator-session', schemaVersion: '2.0', toolVersion: 'v178',
    exportedAt: '2026-09-23T10:00:00.000Z', mode: 'ebom_mbom_abom',
    boms: { ebom: { header: ['A', 'B'], filename: 'e.xlsx', data: [['A', 'P1'], ['B', 'P2 "quoted"']] }, rfv: null },
    resultsRaw: [{ key: 'P1||T', pn: 'P1', ms: 'ok', aq: 2.5, trace: { dcn: [['D1', '2024-03-15']], ecn: [], ecr: [] } }],
    results: [{ key: 'P1||T', pn: 'P1', ms: 'direct_adjudicated', aq: null }],
    adjudications: [{ id: 'imp_1_abom', rationale: 'line1\nline2\té 😀', applied: false }],
    isLocked: false, collectorLevels: ['A', 'B'], procOverrides: null,
  };
  return Promise.all([
    same('strings: quotes, backslashes, control escapes and the line separator', ['a"b', 'c\\d', '\n\r\t\b\f', '  ', '']),
    same('non-ASCII and a surrogate pair survive being split between chunks', ['été', '😀', '中文']),
    same('numbers: negative, fractional, exponent and zero', [0, -1, 3.25, -1.5e-3, 6.02e23, 1e-7]),
    same('literals: true, false and null', [true, false, null, { a: null }]),
    same('empty and deeply nested containers', [{}, [], [[[]]], { a: { b: { c: [{}] } } }]),
    same('an object whose keys need escaping', { 'k\n': 1, 'k"q': 2, '': 3 }),
    same('a session shaped exactly like the exporter writes it', session),
    same('a top-level string on its own', 'plain'),
    rejects('a file cut off mid-string is rejected, not half-loaded', '{"a":"unterminated'),
    rejects('a file cut off mid-array is rejected, not half-loaded', '{"results":[{"k":1},'),
  ]);
}

// ── HARNESS.md must describe this run ──────────────────────────────────────
// The headline count was already checked (Tier 2). The coverage TABLE was not,
// and drifted to 363 while the run was 473. Every suite that ran must appear
// in the table by its exact name with the count it actually ran.
function harnessDocSuite() {
  suite('HARNESS.md describes this run', (t, eq) => {
    const f = [path.join(__dirname, 'HARNESS.md'), path.join(__dirname, '..', 'HARNESS.md')]
      .find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
    if (!f) { console.log('  (HARNESS.md not shipped alongside — skipped)'); return; }
    const md = fs.readFileSync(f, 'utf8');
    const rows = [...md.matchAll(/^\|\s*([^|]+?)\s*\|\s*(\d+)\s*\|[^\n]*\|\s*$/gm)]
      .map(m => [m[1].replace(/\*/g, '').trim(), +m[2]]).filter(([n]) => SUITE_COUNTS[n] !== undefined || /^(Tier|v1|HARNESS|Engine|Proc|NCR|ECN|Many|Stylesheet|Version)/.test(n));
    const table = Object.fromEntries(rows);
    t('every suite that ran is in the coverage table with its real count', () => {
      const bad = Object.keys(SUITE_COUNTS).filter(n => n !== 'HARNESS.md describes this run' && table[n] !== SUITE_COUNTS[n])
        .map(n => n + ': table ' + (table[n] === undefined ? 'missing' : table[n]) + ', ran ' + SUITE_COUNTS[n]);
      if (bad.length) throw new Error(bad.join('; '));
    });
    t('the table names no suite that did not run', () => {
      // The browser suite is opt-in: listed in the table, absent from a plain run.
      const extra = Object.keys(table).filter(n => SUITE_COUNTS[n] === undefined &&
        n !== 'HARNESS.md describes this run' && !(n === BROWSER_SUITE && !BROWSER_RUN) &&
        !(n === REFERENCE_SUITE && !REFERENCE));
      if (extra.length) throw new Error('not a suite: ' + extra.join(', '));
    });
  });
}

// ── BROWSER — the product actually runs ────────────────────────────────────
// v179. Every other suite reads or sandboxes the source. None of them opens the
// page, runs a comparison through the real worker, or opens a file the build
// wrote — which is how v160 to v163 shipped unable to run a comparison at all
// while 397 tests passed. This suite drives the shipped HTML in a real browser.
//
// Opt-in, because it needs Playwright, which this file otherwise does not:
//   npm install playwright            (once, beside this file or globally)
//   node comparator-tests.js --browser
// To use a browser already on the machine instead of Playwright's download:
//   COMPARATOR_BROWSER="C:\Program Files\Google\Chrome\Application\chrome.exe" node comparator-tests.js --browser
//
// Asked for and unavailable is a FAILURE, not a skip: a run that was supposed
// to exercise the product must not report green without having done so.
//
// Fixtures are built inside the page with the build's own SheetJS, so the
// suite needs no files beyond the two HTML tools. Every download is read back
// from disk: the test inspects what a user would open, not an object in memory.
const BROWSER_EXPECTED = 32;   // v182 — +10 for Change Pedigree Alignment
const BROWSER_SUITE = 'Browser \u2014 the product actually runs';

async function browserCases() {
  let pw;
  try { pw = require('playwright'); }
  catch (e) {
    try { pw = require('playwright-core'); }
    catch (e2) {
      return [{ name: 'Playwright is installed (npm install playwright)', error: new Error('require("playwright") failed: ' + e.message) }];
    }
  }
  const launchOpts = process.env.COMPARATOR_BROWSER ? { executablePath: process.env.COMPARATOR_BROWSER } : {};
  let browser;
  try { browser = await pw.chromium.launch(launchOpts); }
  catch (e) { return [{ name: 'a browser can be launched', error: e }]; }

  const errors = [];
  const results = [];
  const check = async (name, fn) => {
    try { await fn(); results.push({ name }); }
    catch (e) { results.push({ name, error: e }); }
  };
  const assert = (c, msg) => { if (!c) throw new Error(msg); };
  const url = p => 'file://' + path.resolve(p).replace(/\\/g, '/');
  const watch = (page, label) => {
    page.on('pageerror', e => errors.push(label + ': ' + e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push(label + ' console: ' + m.text()); });
  };
  const download = async (page, trigger) => {
    const [d] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), page.evaluate(trigger)]);
    return fs.readFileSync(await d.path());
  };
  // Parse a downloaded workbook with the page's own SheetJS.
  const readXlsx = (page, buf) => page.evaluate(b64 => {
    const wb = XLSX.read(b64, { type: 'base64' });
    const o = {};
    wb.SheetNames.forEach(n => { o[n] = XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: '' }); });
    return o;
  }, buf.toString('base64'));

  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'comparator-browser-'));
  try {
    const ctx = await browser.newContext({ acceptDownloads: true });
    const page = await ctx.newPage();
    watch(page, 'build');
    await page.goto(url(BUILD));
    await page.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");

    await check('the build opens and names its own version', async () => {
      const pill = await page.evaluate("document.getElementById('app-version-pill').textContent");
      const v = await page.evaluate('APP_VERSION');
      assert(pill === v, 'pill says ' + pill + ', APP_VERSION is ' + v);
    });

    // A small program: two structural levels, three parts, one child.
    // P100 fully built · P200 built under an OPEN work order · P300 never built.
    await page.evaluate(async () => {
      const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
      const book = (w, rows) => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
        return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
      };
      const E = [['A', 'TOP', '', 1], ['B', 'ASM1', 'TOP', 1], ['C', 'P100', 'ASM1', 2], ['C', 'P200', 'ASM1', 1], ['C', 'P300', 'ASM1', 3], ['D', 'P101', 'P100', 4]];
      const files = {
        ebom: book(40, E.map(([i, pn, nh, q]) => ({ 0: i, 1: pn, 2: 'desc ' + pn, 3: nh, 7: q, 8: String(q) }))),
        mbom: book(40, [['P100', 'ASM1', 2, 'WO1'], ['P200', 'ASM1', 1, 'WO2'], ['P300', 'ASM1', 3, 'WO3'], ['P101', 'P100', 4, 'WO1']]
          .map(([pn, nh, q, wo]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: 'CLOSED' }))),
        abom: book(40, [['P100', 'ASM1', 2, 'WO1', 'CLOSED'], ['P200', 'ASM1', 1, 'WO2', 'OPEN'], ['P101', 'P100', 4, 'WO1', 'CLOSED']]
          .map(([pn, nh, q, wo, st]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: st }))),
        ci: book(3, [{ 0: 'CI-1', 1: 'P100', 2: 'ASM1' }, { 0: 'CI-2', 1: 'P300', 2: 'ASM1' }]),
      };
      for (const k of ['ebom', 'mbom', 'abom', 'ci']) {
        handleFile(k, files[k]);
        const t0 = Date.now();
        while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) {
          if (Date.now() - t0 > 20000) throw new Error(k + ' did not load');
          await new Promise(r => setTimeout(r, 50));
        }
      }
    });
    await check('four Excel files load into their zones', async () => {
      const n = await page.evaluate("['ebom','mbom','abom','ci'].map(k => state.boms[k].data.length).join(',')");
      assert(n === '6,4,3,2', 'rows loaded: ' + n);
    });

    await page.click('#run-btn');
    await page.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
    const status = await page.evaluate("Object.fromEntries(state.results.map(r => [r.pn, [r.overall, r.ms, r.as].join('/')]))");
    await check('a comparison runs to completion in the browser', async () => {
      assert(Object.keys(status).length === 6, 'rows: ' + JSON.stringify(status));
    });
    await check('the engine reaches the right verdict for each kind of line', async () => {
      // P100 is also P101's next higher, so pass 2 finds it as a used-on parent.
      const want = { TOP: 'collector', ASM1: 'collector', P100: 'pn_as_usedon/ok/ok', P200: 'wo_open/ok/wo_open', P300: 'missing/ok/missing', P101: 'ok/ok/ok' };
      const bad = Object.keys(want).filter(k => !String(status[k]).startsWith(want[k]));
      assert(!bad.length, 'unexpected: ' + bad.map(k => k + '=' + status[k]).join(', '));
    });
    await check('the dashboard renders the counts it computed', async () => {
      const t = await page.evaluate("document.getElementById('m-total').textContent.trim()");
      assert(t === '6', 'EBOM line items card shows ' + JSON.stringify(t));
    });
    await check('after a real run the funnel bars and counts are placed with no help', async () => {
      // v181 review — the first placement runs while the results are still
      // hidden (tracks 0px wide); only the ResizeObserver puts the counts right.
      // So: nothing forced, nothing called. Bars must be their --pct length and
      // every count must be where it fits — first as rendered, then after a
      // window resize.
      const probe = () => page.evaluate(() => {
        const out = [];
        document.querySelectorAll('.funnel-bar-track.cov').forEach(tr => {
          const fl = tr.querySelector('.funnel-bar-fill-cov'), sp = tr.querySelector('.funnel-bar-inline-count');
          const id = (tr.closest('[id]') || {}).id;
          const pct = parseFloat(getComputedStyle(tr).getPropertyValue('--pct'));
          const want = tr.clientWidth * pct / 100, got = fl.getBoundingClientRect().width;
          if (!(pct > 0) || Math.abs(got - want) > 1.5) out.push(id + ' bar ' + got.toFixed(0) + 'px, want ' + want.toFixed(0));
          if (!sp) return;
          const fr = fl.getBoundingClientRect(), sr = sp.getBoundingClientRect(), t = tr.getBoundingClientRect();
          const fits = sr.width + 16 <= fr.width;
          const room = fits || sr.width + 10 <= t.width - fr.width;
          if (room && getComputedStyle(sp).visibility === 'hidden') { out.push(id + ' hidden though it has room'); return; }
          const inside = sr.left >= fr.left - 0.5 && sr.right <= fr.right + 0.5;
          if (fits && !inside) out.push(id + ' fits its bar but is not on it');
          if (!fits && sr.left < fr.right - 0.5) out.push(id + ' does not fit its bar but is on it');
          if (getComputedStyle(sp).visibility !== 'hidden' && (sr.right > t.right + 0.5 || sr.left < t.left - 0.5)) out.push(id + ' clipped');
        });
        if (!document.querySelector('.funnel-bar-track.cov')) out.push('no ladder bars');
        return out;
      });
      const settle = () => page.evaluate(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))));
      await settle();
      const first = await probe();
      await page.setViewportSize({ width: 1024, height: 720 }); await settle();
      const resized = await probe();
      await page.setViewportSize({ width: 1280, height: 720 }); await settle();
      const bad = first.map(x => 'as rendered: ' + x).concat(resized.map(x => 'after resize: ' + x));
      assert(!bad.length, bad.slice(0, 6).join('; '));
    });
    await check('every funnel bar count is readable where it lands, in every theme and width', async () => {
      // v181 — the owner's photo: counts on 19% and 30% bars were grey on green.
      // A fixed percentage cannot say whether a count fits its bar (a 19% bar
      // holds it at 1920px, not at 1440px), so this measures what is drawn. For
      // each bar at several widths: the count sits wholly on the fill or wholly
      // on the track, is not clipped, and clears 4.5:1 against what is behind it.
      const theme0 = await page.evaluate("document.documentElement.getAttribute('data-theme') || 'dark'");
      const bad = [];
      for (const w of [760, 1024, 1440, 1920]) {
        await page.setViewportSize({ width: w, height: 900 });
        for (const th of ['dark', 'light', 'mono']) {
          await page.evaluate(t => { setTheme(t); renderFunnel(); }, th);
          const r = await page.evaluate(() => {
            const rgb = c => (c.match(/[\d.]+/g) || []).map(Number);
            const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
            const L = c => 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
            const cr = (a, b) => { const x = L(a), y = L(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
            const out = [];
            const fills = [...document.querySelectorAll('.funnel-bar-fill-cov')];
            if (!fills.length) return ['no ladder bars rendered'];
            for (const pct of [19, 30, 57, 100]) {
              fills.forEach(fl => {
                fl.style.transition = 'none'; fl.style.width = pct + '%';
                const tk = fl.closest('.funnel-bar-track'); if (tk) tk.style.setProperty('--pct', pct + '%');
              });
              if (typeof placeFunnelCounts === 'function') placeFunnelCounts();
              fills.forEach(fl => {
                const track = fl.closest('.funnel-bar-track');
                const sp = track && track.querySelector('.funnel-bar-inline-count');
                if (!sp) return;
                sp.textContent = pct + '% \u00b7 15,754';   // a realistic width
                if (typeof placeFunnelCounts === 'function') placeFunnelCounts();
                const fr = fl.getBoundingClientRect(), sr = sp.getBoundingClientRect(), tr = track.getBoundingClientRect();
                const id = (fl.closest('[id]') || {}).id + ' @' + pct + '%';
                // Below 1024px a count that fits neither on nor beside its bar is
                // hidden (the tooltip carries it); at 1024px and up none may be.
                if (getComputedStyle(sp).visibility === 'hidden') {
                  if (innerWidth >= 1024) out.push(id + ' hidden at ' + innerWidth + 'px');
                  return;
                }
                if (sr.left < tr.left - 0.5 || sr.right > tr.right + 0.5) { out.push(id + ' clipped by the track'); return; }
                const inside = sr.left >= fr.left - 0.5 && sr.right <= fr.right + 0.5;
                const beside = sr.left >= fr.right - 0.5;
                if (!inside && !beside) { out.push(id + ' straddles the end of the bar'); return; }
                const bg = rgb(getComputedStyle(inside ? fl : track).backgroundColor);
                const c = cr(rgb(getComputedStyle(sp).color), bg);
                if (!(c >= 4.5)) out.push(id + (inside ? ' on the fill ' : ' on the track ') + c.toFixed(2) + ':1');
              });
            }
            return out;
          });
          r.forEach(x => bad.push(w + 'px ' + th + ': ' + x));
        }
      }
      await page.setViewportSize({ width: 1280, height: 720 });
      await page.evaluate(t => { setTheme(t); renderFunnel(); }, theme0);
      assert(!bad.length, bad.length + ' unreadable: ' + bad.slice(0, 6).join('; '));
    });

    await page.evaluate(() => {
      state.adjudications.push({ id: 'adj_b1', rowKey: 'P300||ASM1', reason: 'abom_missing', leg: 'abom', createdFrom: 'missing_abom',
        sme: 'Browser Test', smeRole: 'CM', timestamp: '2026-09-23T10:00:00Z', rationale: 'fixture', woNo: 'WO9',
        woPn: 'P300', woUsedOn: 'ASM1', claimedQty: 3, applied: false });
      // On P300, not P200: P200 must stay under an open work order, or the
      // open-WO comparison below compares 0 with 0 and cannot fail.
      state.adjudications.push({ id: 'imp_77_abom', type: 'row', rowKey: 'P300||ASM1', leg: 'abom', reason: 'abom_missing', claimedQty: 3,
        sme: 'ME, Person', smeRole: 'Mfg Engineer', rationale: 'imported', timestamp: '2026-09-01', createdFrom: 'external_import',
        applied: false, extClaimNo: '77', extStatus: 'APPROVED' });
      state.adjManualMap = { pn: 0, claimNo: 1 };
      _adjProcessClaims();
    });
    await check('processing a claim changes the verdict it targets', async () => {
      const as = await page.evaluate("state.results.find(r => r.pn === 'P300').as");
      assert(as === 'direct_adjudicated', 'P300 ABOM leg is ' + as);
    });

    const sessA = JSON.parse((await download(page, 'exportSessionJson()')).toString('utf8'));
    await check('the session file is stamped with the running build', async () => {
      assert(sessA.toolVersion === await page.evaluate('APP_VERSION'), 'toolVersion ' + sessA.toolVersion);
    });
    await check('the session file carries every column map, including ME ADJ', async () => {
      assert(JSON.stringify(sessA.adjManualMap) === '{"pn":0,"claimNo":1}', 'adjManualMap ' + JSON.stringify(sessA.adjManualMap));
    });

    await page.evaluate("window.prompt = () => 'Browser Auditor'");
    await page.evaluate('freezeReport()');
    await page.waitForFunction('state.isLocked && state.auditCert && state.auditCert.hash', null, { timeout: 30000 });
    const certRows = await page.evaluate('_auditCertRows(state.auditCert)');
    await check('freezing shows the build on the certificate banner', async () => {
      const b = await page.evaluate("document.getElementById('cert-build').textContent");
      assert(b === await page.evaluate('APP_VERSION'), 'banner build ' + b);
    });

    const mainX = await readXlsx(page, await download(page, 'exportXLSX()'));
    const ciX = await readXlsx(page, await download(page, 'exportCIReport()'));
    // Trailing empty cells are the reader's padding (defval), not content.
    const norm = rows => JSON.stringify((rows || []).map(r => { const a = r.map(String); while (a.length && a[a.length - 1] === '') a.pop(); return a; })
      .filter(r => r.length));
    const certStr = norm(certRows);
    await check('the Excel export carries the full certificate', async () => {
      assert(norm(mainX['Audit Certificate']) === certStr, 'main export certificate differs from _auditCertRows: ' + norm(mainX['Audit Certificate']).slice(0, 400));
    });
    await check('the CI Traceability Report carries the identical certificate', async () => {
      assert(norm(ciX['Audit Certificate']) === certStr, 'CI report certificate differs');
    });
    await check('the CSV export opens with the full certificate', async () => {
      const csv = (await download(page, 'exportCSV()')).toString('utf8');
      const lines = csv.split('\n').slice(0, certRows.length);
      const want = certRows.map(r => r.map(v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"').join(','));
      assert(JSON.stringify(lines) === JSON.stringify(want), 'CSV certificate: ' + lines.slice(0, 5).join(' | '));
    });
    await check('the HTML report carries the full certificate', async () => {
      const html = (await download(page, 'exportHTML()')).toString('utf8');
      // The report prints the mode in display form (EBOM MBOM ABOM); every other value verbatim.
      const shown = r => r[0] === 'Mode' ? String(r[1]).replace(/_/g, ' ').toUpperCase() : String(r[1]);
      const missing = certRows.slice(1).map(shown).filter(v => v && html.indexOf(v.replace(/&/g, '&amp;')) < 0);
      assert(!missing.length, 'not in the HTML report: ' + missing.join(', '));
    });

    const frozenPath = path.join(tmp, 'frozen.json');
    fs.writeFileSync(frozenPath, await download(page, 'exportSessionJson()'));
    const page2 = await ctx.newPage();
    watch(page2, 'reimport');
    await page2.goto(url(BUILD));
    await page2.waitForFunction("typeof state !== 'undefined'");
    await page2.setInputFiles('#adj-import-input', frozenPath);
    await page2.waitForFunction('state.isLocked === true && state.results.length > 0', null, { timeout: 60000 });
    await check('a frozen session re-opens frozen, with the same results and certificate', async () => {
      const r = await page2.evaluate("({ n: state.results.length, hash: state.auditCert.hash, build: document.getElementById('cert-build').textContent, map: JSON.stringify(state.adjManualMap) })");
      assert(r.n === 6, 'results ' + r.n);
      assert(r.hash === await page.evaluate('state.auditCert.hash'), 'hash changed on re-import');
      assert(r.build === await page.evaluate('APP_VERSION'), 'banner build ' + r.build);
      assert(r.map === '{"pn":0,"claimNo":1}', 'ME ADJ map ' + r.map);
    });

    // ── The delta tool, reading what the build wrote ──
    const A = Object.assign({}, sessA, { toolVersion: 'v142', exportedAt: '2026-09-01T00:00:00.000Z' });
    const B = JSON.parse(fs.readFileSync(frozenPath, 'utf8'));
    B.adjudications.forEach(c => { if (c.id === 'adj_b1') c.woPn = 'P301'; if (c.id === 'imp_77_abom') c.extStatus = 'WITHDRAWN'; });
    const aPath = path.join(tmp, 'A.json'), bPath = path.join(tmp, 'B.json');
    fs.writeFileSync(aPath, JSON.stringify(A)); fs.writeFileSync(bPath, JSON.stringify(B));

    const dhtml = fs.readFileSync(DELTA, 'utf8');
    let deltaDefaultSummary = null;   // v182 — read by the alignment checks below
    const THRESH = 'const NATIVE_SAFE_BYTES = 400 * 1000 * 1000;';
    for (const mode of ['normal', 'streaming']) {
      const dp = await ctx.newPage();
      watch(dp, 'delta ' + mode);
      if (mode === 'normal') await dp.goto(url(DELTA));
      else {
        // Same page with the large-file threshold at 1 KB, so these small
        // sessions take the streaming route a 500 MB session would.
        if (dhtml.indexOf(THRESH) < 0) throw new Error('BUILD MARKER MOVED in delta tool: ' + THRESH);
        await dp.setContent(dhtml.replace(THRESH, 'const NATIVE_SAFE_BYTES = 1000;'), { waitUntil: 'load' });
      }
      await dp.setInputFiles('#A-file', aPath);
      await dp.waitForFunction("document.getElementById('card-A').classList.contains('loaded')", null, { timeout: 30000 });
      await dp.setInputFiles('#B-file', bPath);
      await dp.waitForFunction("document.getElementById('card-B').classList.contains('loaded')", null, { timeout: 30000 });
      await dp.click('#run-btn');
      await dp.waitForSelector('#results section');
      const [d] = await Promise.all([dp.waitForEvent('download'), dp.click('#export-btn')]);
      const wb = await readXlsx(page, fs.readFileSync(await d.path()));
      const summ = Object.fromEntries(wb['Summary'].filter(r => r[0]).map(r => [r[0], r]));
      const claims = wb['Claims Delta']; const hdr = claims[0];
      const byId = Object.fromEntries(claims.slice(1).map(r => [r[hdr.indexOf('Claim ID')], Object.fromEntries(hdr.map((h, i) => [h, r[i]]))]));
      if (mode === 'normal') {
        deltaDefaultSummary = summ;
        await check('the delta tool names the builds behind both sessions', async () => {
          const r = summ['Comparator build'] || [];
          assert(r[1] === 'v142\u2013v177 (exact build not recorded)' && r[2] === B.toolVersion && r[3] === 'different', JSON.stringify(r));
        });
        await check('the delta tool reports a claim whose work-order target moved', async () => {
          assert(byId.adj_b1 && byId.adj_b1.Change === 'Modified', JSON.stringify(byId.adj_b1));
        });
        await check('the delta tool shows where an imported claim came from', async () => {
          assert(byId.imp_77_abom && byId.imp_77_abom.Origin === 'ME adjudication import' && byId.imp_77_abom['External Status'] === 'WITHDRAWN', JSON.stringify(byId.imp_77_abom));
        });
        await check('the delta Summary counts open work orders as the dashboard card does', async () => {
          const card = await page.evaluate("state.results.filter(x => !['pt_collector','pt_reference','pt_bulk','pt_removal','collector'].includes(x.overall) && (x.as === 'wo_open' || x.asUsedOn === 'wo_open')).length");
          const r = summ['Part WO Status: Not Closed'] || [];
          assert(card > 0, 'the fixture has no open work order left to count');
          assert(r[2] === card, 'delta ' + r[2] + ' vs dashboard ' + card);
        });
      } else {
        await check('the delta tool opens sessions through the streaming route', async () => {
          assert(summ['Comparator build'] && byId.adj_b1 && byId.adj_b1.Change === 'Modified', 'streamed run produced a different report');
        });
      }
      await dp.close();
    }

    // ── v182 — a drawing + ECR program, under Change Pedigree Alignment ──
    // Its own page and its own files. The CHP extract carries only a drawing
    // number, revision, ECR and ECR status: no part number at all. Files the
    // page writes are read at the Blob it hands the browser (headless Chromium
    // drops roughly one download in ten; the bytes are the same either way).
    await check('a default run prints no alignment row and writes no alignment field', async () => {
      assert(!certRows.some(r => r[0] === 'Change Pedigree Alignment'), 'default certificate has an alignment row');
      assert(!('chpAlign' in sessA), 'default session carries chpAlign');
      assert(deltaDefaultSummary && !deltaDefaultSummary['Change Pedigree alignment'], 'default delta Summary names an alignment rule');
    });
    const dwp = await ctx.newPage();
    watch(dwp, 'drawing');
    await dwp.goto(url(BUILD));
    await dwp.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
    await dwp.evaluate(() => {
      const orig = URL.createObjectURL.bind(URL);
      URL.createObjectURL = b => { if (b instanceof Blob) (window.__blobs = window.__blobs || []).push(b); return orig(b); };
    });
    const written = async trigger => {
      const b64 = await dwp.evaluate(async t => {
        window.__blobs = [];
        await eval(t);
        for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(r => setTimeout(r, 50));
        const b = window.__blobs[window.__blobs.length - 1];
        if (!b) return null;
        const u = new Uint8Array(await b.arrayBuffer()); let s = '';
        for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
        return btoa(s);
      }, trigger);
      return b64 === null ? null : Buffer.from(b64, 'base64');
    };
    await dwp.evaluate(async () => {
      const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
      const book = (w, rows, hdr) => {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([hdr || row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
        return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
      };
      // P100 and P101 share drawing D-100; P200's drawing is written in lower
      // case; P400 is a COTS part with no drawing; P500's drawing has no ECR.
      const E = [['A','TOP','',1,'',''],['B','ASM1','TOP',1,'D-ASM','A'],['C','P100','ASM1',2,'D-100','A'],
                 ['C','P200','ASM1',1,'d-200','B'],['C','P300','ASM1',3,'D-300','A'],['D','P101','P100',4,'D-100','A'],
                 ['C','P400','ASM1',1,'',''],['C','P500','ASM1',1,'D-500','C']];
      const eh = new Array(40).fill('').map((_, i) => 'H' + i); eh[10] = 'Drawing PL Rev'; eh[12] = 'Drawing No.';
      window.__files = {
        ebom: book(40, E.map(([i, pn, nh, q, dw, rv]) => ({ 0: i, 1: pn, 2: 'desc ' + pn, 3: nh, 7: q, 8: String(q), 10: rv, 12: dw })), eh),
        mbom: book(40, [['P100','ASM1',2,'WO1'],['P200','ASM1',1,'WO2'],['P300','ASM1',3,'WO3'],['P101','P100',4,'WO1'],['P400','ASM1',1,'WO4'],['P500','ASM1',1,'WO5']]
          .map(([pn, nh, q, wo]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: 'CLOSED' }))),
        abom: book(40, [['P100','ASM1',2,'WO1','CLOSED'],['P200','ASM1',1,'WO2','CLOSED'],['P101','P100',4,'WO1','CLOSED'],['P400','ASM1',1,'WO4','CLOSED'],['P500','ASM1',1,'WO5','CLOSED']]
          .map(([pn, nh, q, wo, st]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: st }))),
        chp: book(4, [{0:'D-100',1:'A',2:'R1',3:'APPROVED'},{0:'D-100',1:'A',2:'R2',3:'OPEN'},{0:'D-200',1:'B',2:'R4',3:'OPEN'},
                      {0:'D-300',1:'B',2:'R3',3:'OPEN'},{0:'D-999',1:'A',2:'R7',3:'OPEN'},{0:'',1:'',2:'R0',3:''}],
                  ['Drawing Number', 'Rev', 'ECR', 'ECR Status']),
      };
    });
    const loadZone = k => dwp.evaluate(async k => {
      const before = state.boms[k];
      handleFile(k, window.__files[k]);
      const t0 = Date.now();
      while (!(state.boms[k] && state.boms[k] !== before)) { if (Date.now() - t0 > 20000) throw new Error(k + ' did not load'); await new Promise(r => setTimeout(r, 50)); }
      return state.boms[k].data.length;
    }, k);
    for (const k of ['ebom', 'mbom', 'abom']) await loadZone(k);
    await dwp.evaluate("toggleChpAlignPanel(); setChpAlignRule('drawing');" +
      "openSuppManualMap('chp'); ['docNo:A','docRev:B','ecr:C','ecrStatus:D'].forEach(p => { const [k, v] = p.split(':'); document.getElementById('chp-map-' + k).value = v; });" +
      "_saveSuppManualMap('chp');");
    const chpRows = await loadZone('chp');
    await check('a drawing + ECR extract loads by drawing number, and switching the rule re-reads it', async () => {
      assert(chpRows === 5, 'rows kept under the drawing rule: ' + chpRows);
      const n = await dwp.evaluate("setChpAlignRule('pn_nh'); const a = state.boms.chp.data.length; setChpAlignRule('drawing'); [a, state.boms.chp.data.length, document.getElementById('rows-chp').textContent].join('|')");
      assert(n === '0|5|5 rows loaded', 'rows by rule (default|drawing|label): ' + n);
    });
    await check('the run is blocked, in words, until the EBOM drawing column is chosen', async () => {
      const r = await dwp.evaluate("hideError(); runComparison(); [document.getElementById('error-box').style.display, document.getElementById('error-box').textContent, (state.results || []).length].join('|')");
      assert(/^block\|.*Choose the EBOM column that holds the drawing number.*\|0$/.test(r), r);
      const panel = await dwp.evaluate("document.getElementById('chpa-body').textContent");
      assert(panel.indexOf('Run is blocked') >= 0 && panel.indexOf('M · Drawing No.') >= 0, 'panel: ' + panel.slice(0, 300));
    });
    await dwp.evaluate("setChpAlignCol('draw', '12'); hideError(); runComparison()");
    await dwp.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
    const dres = await dwp.evaluate("Object.fromEntries(state.results.map(r => [r.pn, [JSON.stringify(r.chpVia), [...r.trace.ecr.keys()].join(','), chpHistoryState(r).label].join(' ')]))");
    await check('an ECR reaches every EBOM line on its drawing, and nothing else', async () => {
      const want = { P100: '["D-100"] R1,R2 ECR ONLY', P101: '["D-100"] R1,R2 ECR ONLY', P200: '["D-200"] R4 ECR ONLY',
                     P300: '["D-300"] R3 ECR ONLY', P400: '[]  NO DRAWING', P500: '["D-500"]  NO HISTORY' };
      const bad = Object.keys(want).filter(k => dres[k] !== want[k]);
      assert(!bad.length, bad.map(k => k + ': ' + dres[k]).join('; '));
    });
    await check('the panel reports the match, and the Change Pedigree tab names the unmatched drawing', async () => {
      const p = await dwp.evaluate("document.getElementById('chpa-body').textContent");
      assert(/4 of 5 Change Pedigree rows matched an EBOM drawing\. 1 drawing not in the EBOM\./.test(p), 'panel: ' + p.slice(-300));
      const tab = await dwp.evaluate("renderChpTable(0); [...document.querySelectorAll('#chp-table-wrap tbody tr')].map(tr => tr.lastElementChild.textContent).join(',')");
      assert(tab === 'ECR ONLY,ECR ONLY,ECR ONLY,ECR ONLY,NO MATCH', 'tab badges: ' + tab);
    });
    await check('the Excel export shows the EBOM drawing and the new badges', async () => {
      const x = await readXlsx(dwp, await written('exportXLSX()'));
      const s = x['Comparison Summary'], h = s[0];
      const by = Object.fromEntries(s.slice(1).map(r => [r[h.indexOf('Part Number')], r[h.indexOf('Drawing')] + '|' + r[h.indexOf('CHP History')]]));
      assert(by.P101 === 'D-100|ECR ONLY' && by.P400 === '|NO DRAWING' && by.P200 === 'D-200|ECR ONLY', JSON.stringify(by));
    });
    await check('the ECN reports say they are not available instead of exporting an empty report', async () => {
      const f = await written('hideError(); exportChangeCommitmentClosures()');
      const msg = await dwp.evaluate("document.getElementById('error-box').textContent");
      assert(f === null && /Not available: this program.s Change Pedigree carries no ECNs/.test(msg), 'file written: ' + !!f + ', message: ' + msg);
    });
    await check('revision matching attaches only where the revision agrees, and counts the misses', async () => {
      const r = await dwp.evaluate(async () => {
        setChpAlignMatchRev(true); setChpAlignCol('rev', '10'); hideError(); runComparison();
        const t0 = Date.now();
        while (!(state.results.length && state.results[0].chpVia && state.results.some(x => (x.chpVia || []).some(k => k.indexOf('||') > 0)))) {
          if (Date.now() - t0 > 30000) throw new Error('re-run did not finish'); await new Promise(z => setTimeout(z, 50));
        }
        await new Promise(z => setTimeout(z, 200));
        const p3 = state.results.find(x => x.pn === 'P300');
        const out = [p3.trace.ecr.size, chpHistoryState(p3).label, chpAlignStats().revMiss].join('|');
        setChpAlignMatchRev(false); hideError(); runComparison();
        return out;
      });
      assert(r === '0|NO HISTORY|1', 'P300 (EBOM rev A, CHP rev B): ' + r);
      await dwp.waitForFunction("state.results.length && state.results.every(x => (x.chpVia || []).every(k => k.indexOf('||') < 0)) && state.results.find(x => x.pn === 'P300').trace.ecr.size === 1", null, { timeout: 30000 });
    });
    const dSess = JSON.parse((await written('exportSessionJson()')).toString('utf8'));
    await dwp.evaluate("window.prompt = () => 'Drawing Auditor'");
    await dwp.evaluate('freezeReport()');
    await dwp.waitForFunction('state.isLocked && state.auditCert && state.auditCert.hash', null, { timeout: 30000 });
    const dCert = await dwp.evaluate('_auditCertRows(state.auditCert)');
    const dFrozen = path.join(tmp, 'drawing_frozen.json');
    fs.writeFileSync(dFrozen, await written('exportSessionJson()'));
    await check('the rule travels in the session, prints on the certificate, and reopens', async () => {
      assert(JSON.stringify(dSess.chpAlign) === '{"rule":"drawing","ebomDrawCol":12,"matchRev":false,"ebomRevCol":10,"label":"Drawing number"}',
             'session: ' + JSON.stringify(dSess.chpAlign));
      const row = dCert.find(r => r[0] === 'Change Pedigree Alignment');
      assert(row && row[1] === 'Drawing number · EBOM drawing column M (Drawing No.)', 'certificate: ' + JSON.stringify(row));
      const p3 = await ctx.newPage(); watch(p3, 'drawing reimport');
      await p3.goto(url(BUILD)); await p3.waitForFunction("typeof state !== 'undefined'");
      await p3.setInputFiles('#adj-import-input', dFrozen);
      await p3.waitForFunction('state.isLocked === true && state.results.length > 0', null, { timeout: 60000 });
      const r = await p3.evaluate("[state.chpAlign.rule, document.getElementById('chpa-summary').textContent, state.results.find(x => x.pn === 'P101').chpVia.join(','), _auditCertRows(state.auditCert).find(x => x[0] === 'Change Pedigree Alignment')[1]].join('|')");
      assert(r === 'drawing|Drawing number|D-100|Drawing number · EBOM drawing column M (Drawing No.)', r);
      await p3.evaluate('resetAll()');
      const after = await p3.evaluate("state.chpAlign.rule + '|' + document.getElementById('chpa-summary').textContent");
      assert(after === 'pn_nh|Default', 'after Reset: ' + after);
      await p3.close();
    });
    await check('the delta tool names both rules and warns when they differ', async () => {
      const aP = path.join(tmp, 'align_A.json'), bP = path.join(tmp, 'align_B.json');
      fs.writeFileSync(aP, JSON.stringify(Object.assign({}, sessA, { exportedAt: '2026-09-01T00:00:00.000Z' })));
      fs.writeFileSync(bP, fs.readFileSync(dFrozen));
      const dp = await ctx.newPage(); watch(dp, 'delta alignment');
      await dp.goto(url(DELTA));
      await dp.setInputFiles('#A-file', aP);
      await dp.waitForFunction("document.getElementById('card-A').classList.contains('loaded')", null, { timeout: 30000 });
      await dp.setInputFiles('#B-file', bP);
      await dp.waitForFunction("document.getElementById('card-B').classList.contains('loaded')", null, { timeout: 30000 });
      const warn = await dp.evaluate("document.body.textContent");
      assert(/different Change Pedigree Alignment rules/.test(warn), 'no load warning');
      await dp.click('#run-btn');
      await dp.waitForSelector('#results section');
      const [d] = await Promise.all([dp.waitForEvent('download'), dp.click('#export-btn')]);
      const wb = await readXlsx(page, fs.readFileSync(await d.path()));
      const row = wb['Summary'].find(r => r[0] === 'Change Pedigree alignment') || [];
      assert(row[1] === 'Part number + next higher' && row[2] === 'Drawing number (EBOM drawing column M)' && row[3] === 'DIFFERENT', JSON.stringify(row));
      await dp.close();
    });
    await dwp.close();

    await check('no page error or console error anywhere in the run', async () => {
      assert(!errors.length, errors.slice(0, 5).join(' | '));
    });
    await ctx.close();
  } catch (e) {
    results.push({ name: 'the browser run completed', error: e });
  } finally {
    await browser.close();
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {}
  }
  return results;
}

// ── REFERENCE — default output matches a reference build ───────────────────
// v182. Opt-in: node comparator-tests.js --reference=path/to/previous_build.html
// Runs one program through the reference build and the build under test, with
// every setting at its default, and compares every output a user can take away:
// the results, the rendered Comparison Summary and Change Pedigree tab, the
// Excel, CSV and HTML exports, the CI Traceability Report and As-Built Records
// Guide, both ECN reports, the context export, the session file, the certificate
// hash payload and every certificate-bearing export after freezing. Time stamps,
// the build number and the hash itself are masked; nothing else is.
//
// This is how v182 showed that Change Pedigree Alignment changes nothing for a
// program on the default rule. The fixture exercises every CHP join the build
// makes, including the two v181 disagreements kept on purpose (KI-1, KI-2).
// Keep a copy of the previous build under another file name to use it.
const REFERENCE = (ARGS.find(a => a.startsWith('--reference=')) || '').slice('--reference='.length) || null;
const REFERENCE_EXPECTED = 51;   // 50 outputs compared, plus the page-error check
const REFERENCE_SUITE = 'Reference — default output matches a reference build';

async function referenceCollect(browser, buildFile) {
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve(buildFile).replace(/\\/g, '/'));
  await page.waitForFunction("typeof state !== 'undefined' && typeof XLSX !== 'undefined'");
  await page.evaluate(() => {
    const orig = URL.createObjectURL.bind(URL);
    URL.createObjectURL = b => { if (b instanceof Blob) (window.__blobs = window.__blobs || []).push(b); return orig(b); };
  });
  await page.evaluate(async () => {
    const row = (w, cells) => { const r = new Array(w).fill(''); Object.keys(cells).forEach(k => { r[k] = cells[k]; }); return r; };
    const book = (w, rows) => {
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([row(w, {}).map((_, i) => 'H' + i)].concat(rows.map(r => row(w, r)))), 'S');
      return new File([XLSX.write(wb, { type: 'array', bookType: 'xlsx' })], 'fixture.xlsx');
    };
    const E = [['A','TOP','',1,'',''],['B','ASM1','TOP',1,'D-ASM','A'],['C','P100','ASM1',2,'D-100','A'],
               ['C','P200','ASM1',1,'D-200','B'],['C','P300','ASM1',3,'D-300','A'],['D','P101','P100',4,'D-100','A'],
               ['C','P400','ASM1',1,'',''],['C','P400','ASM1',1,'',''],['C','P500','ASM1',1,'D-500','C']];
    const C = (pn, nh, o) => Object.assign({ 1: 'X', 3: pn, 4: 'name ' + pn, 5: nh, 7: '1' }, o);
    // Row by row: a blank drawing before a filled one (first non-blank wins);
    // P200 under the wrong next higher (KI-1: engine falls back, tab and
    // Drawing do not); p300 in lower case (KI-2); P999 not in the EBOM (an
    // incomplete ECN); a blank part number (dropped at upload); ASM1 for the
    // next-higher sheet; P500 with a blank next higher (document fallback).
    const CHP = [
      C('P100','ASM1',{10:'',11:'',15:'DCN1',16:'2024-03-15',17:'E1',18:'OPEN',19:'R1',20:'APPROVED'}),
      C('P100','ASM1',{10:'D-100',11:'A',12:'1',13:'A',15:'DCN1',16:'2024-03-15',17:'E1',18:'OPEN',19:'R1',20:'APPROVED'}),
      C('P101','P100',{10:'D-100',11:'A',17:'E1',18:'OPEN',19:'R2',20:'OPEN'}),
      C('P200','ASMX',{10:'D-200',11:'B',15:'DCN2',16:'',19:'R4'}),
      C('p300','asm1',{10:'D-300',11:'A',17:'E2',18:'CLOSED',19:'R3'}),
      C('P999','ASM1',{10:'D-999',11:'A',17:'E2',18:'CLOSED'}),
      C('','ASM1',{10:'D-777',19:'R9'}),
      C('ASM1','TOP',{10:'D-ASM',11:'A',17:'E3',18:'OPEN',19:'R8'}),
      C('P500','',{10:'D-500',11:'C',19:'R5',20:'OPEN'}),
    ];
    const files = {
      ebom: book(40, E.map(([i, pn, nh, q, dw, rv]) => ({ 0: i, 1: pn, 2: 'desc ' + pn, 3: nh, 7: q, 8: String(q), 10: rv, 12: dw }))),
      mbom: book(40, [['P100','ASM1',2,'WO1'],['P200','ASM1',1,'WO2'],['P300','ASM1',3,'WO3'],['P101','P100',4,'WO1'],['P400','ASM1',2,'WO4'],['P500','ASM1',1,'WO5']]
        .map(([pn, nh, q, wo]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: 'CLOSED' }))),
      abom: book(40, [['P100','ASM1',2,'WO1','CLOSED'],['P200','ASM1',1,'WO2','OPEN'],['P101','P100',4,'WO1','CLOSED'],['P400','ASM1',2,'WO4','CLOSED'],['P500','ASM1',1,'WO5','CLOSED']]
        .map(([pn, nh, q, wo, st]) => ({ 5: 'J-' + wo, 8: nh, 9: pn, 10: 'd', 13: q, 35: wo, 36: st }))),
      chp: book(25, CHP),
      ci: book(3, [{0:'CI-1',1:'P100',2:'ASM1'},{0:'CI-2',1:'P300',2:'ASM1'},{0:'CI-3',1:'P500',2:''},{0:'CI-4',1:'P200',2:'ASM1'}]),
    };
    for (const k of ['ebom','mbom','abom','chp','ci']) {
      handleFile(k, files[k]);
      const t0 = Date.now();
      while (!(state.boms[k] && state.boms[k].data && state.boms[k].data.length)) {
        if (Date.now() - t0 > 20000) throw new Error(k + ' did not load');
        await new Promise(r => setTimeout(r, 50));
      }
    }
  });
  await page.click('#run-btn');
  await page.waitForFunction('state.results && state.results.length > 0', null, { timeout: 60000 });
  await page.waitForTimeout(800);
  const written = async trigger => {
    const b64 = await page.evaluate(async t => {
      window.__blobs = [];
      await eval(t);
      for (let i = 0; i < 100 && !window.__blobs.length; i++) await new Promise(r => setTimeout(r, 50));
      const b = window.__blobs[window.__blobs.length - 1];
      if (!b) throw new Error('no file written by ' + t);
      const u = new Uint8Array(await b.arrayBuffer()); let s = '';
      for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
      return btoa(s);
    }, trigger);
    return Buffer.from(b64, 'base64');
  };
  const book = async trigger => page.evaluate(b64 => {
    const wb = XLSX.read(b64, { type: 'base64' }); const o = {};
    wb.SheetNames.forEach(n => { o[n] = XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: '' }); });
    return o;
  }, (await written(trigger)).toString('base64'));
  const text = async trigger => (await written(trigger)).toString('utf8');
  const out = {};
  out['results (raw)'] = await page.evaluate('JSON.stringify(state.resultsRaw.map(_serializeResultRowForJson))');
  out['results (effective)'] = await page.evaluate('JSON.stringify(state.results.map(_serializeResultRowForJson))');
  out['Comparison Summary, as rendered'] = await page.evaluate("renderSummaryTable(); document.getElementById('summary-table-wrap').innerHTML");
  out['Change Pedigree tab, as rendered'] = await page.evaluate("renderChpTable(0); document.getElementById('chp-table-wrap').innerHTML");
  out['Excel export'] = await book('exportXLSX()');
  out['CSV export'] = await text('exportCSV()');
  out['HTML report'] = await text('exportHTML()');
  out['CI Traceability Report'] = await book('exportCIReport()');
  out['CI As-Built Records Guide'] = await book('exportCIAsBuiltGuide()');
  out['Change Commitment List'] = await book('exportChangeCommitmentClosures()');
  out['Premature ECN Closures'] = await book('exportPrematureEcnClosures()');
  await page.evaluate("document.getElementById('search-input').value = 'ASM1'; setSearchMode('context'); onSearchInput();");
  await page.waitForTimeout(400);
  out['context export'] = await book('exportContextResults()');
  const strip = s => { const o = JSON.parse(s); delete o.exportedAt; delete o.toolVersion; return JSON.stringify(o); };
  out['session file'] = strip(await text('exportSessionJson()'));
  await page.evaluate(() => {
    const orig = crypto.subtle.digest.bind(crypto.subtle);
    crypto.subtle.digest = (a, b) => { window.__hashMsg = new TextDecoder().decode(b); return orig(a, b); };
    window.prompt = () => 'Reference Auditor';
  });
  await page.evaluate('freezeReport()');
  await page.waitForFunction('state.isLocked && state.auditCert && state.auditCert.hash', null, { timeout: 30000 });
  const hm = JSON.parse(await page.evaluate('window.__hashMsg')); delete hm.freezeInitiated;
  out['certificate hash payload'] = JSON.stringify(hm);
  out['certificate rows'] = await page.evaluate('JSON.stringify(_auditCertRows(state.auditCert))');
  out['Excel export, frozen'] = await book('exportXLSX()');
  out['CSV export, frozen'] = await text('exportCSV()');
  out['HTML report, frozen'] = await text('exportHTML()');
  out['CI Traceability Report, frozen'] = await book('exportCIReport()');
  out['session file, frozen'] = strip(await text('exportSessionJson()'));
  out.__errors = errors;
  await ctx.close();
  return out;
}

async function referenceCases() {
  if (!fs.existsSync(REFERENCE)) return [{ name: 'the reference build exists', error: new Error('not found: ' + REFERENCE) }];
  let pw;
  try { pw = require('playwright'); } catch (e) {
    try { pw = require('playwright-core'); } catch (e2) { return [{ name: 'Playwright is installed (npm install playwright)', error: e }]; }
  }
  const launchOpts = process.env.COMPARATOR_BROWSER ? { executablePath: process.env.COMPARATOR_BROWSER } : {};
  const browser = await pw.chromium.launch(launchOpts);
  try {
    const a = await referenceCollect(browser, REFERENCE), b = await referenceCollect(browser, BUILD);
    const mask = s => String(s)
      .replace(/\b\d{1,2}\/\d{1,2}\/\d{4},? \d{1,2}:\d{2}:\d{2}\s?[AP]M\b/g, '<time>')
      .replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z/g, '<time>')
      .replace(/\bv\d{2,3}\b/g, '<build>')
      .replace(/\b[0-9a-f]{64}\b/g, '<hash>');
    const out = [];
    const cmp = (label, x, y) => {
      const sx = mask(typeof x === 'string' ? x : JSON.stringify(x)), sy = mask(typeof y === 'string' ? y : JSON.stringify(y));
      if (sx === sy) { out.push({ name: label + ' is identical' }); return; }
      let i = 0; while (i < sx.length && sx[i] === sy[i]) i++;
      out.push({ name: label + ' is identical', error: new Error('differs at ' + i + '\n          reference: ' +
        sx.slice(Math.max(0, i - 80), i + 120) + '\n          this build: ' + sy.slice(Math.max(0, i - 80), i + 120)) });
    };
    Object.keys(a).filter(k => k !== '__errors').forEach(k => {
      if (a[k] && typeof a[k] === 'object') {
        [...new Set(Object.keys(a[k]).concat(Object.keys(b[k] || {})))]
          .forEach(sh => cmp(k + ' · ' + sh, a[k][sh], (b[k] || {})[sh]));
      } else cmp(k, a[k], b[k]);
    });
    out.push({ name: 'neither build logged an error',
      error: (a.__errors.length || b.__errors.length) ? new Error(a.__errors.concat(b.__errors).slice(0, 4).join(' | ')) : undefined });
    return out.map(r => r.error ? r : { name: r.name });
  } catch (e) {
    return [{ name: 'the reference run completed', error: e }];
  } finally {
    await browser.close();
  }
}

// ── summary ────────────────────────────────────────────────────────────────
// EXPECTED_TESTS exists because a crashed suite costs ONE reported failure but
// silently skips every test after it. Without this, losing a third of the suite
// still prints a believable total. Bump it deliberately when adding tests.
const EXPECTED_TESTS = 581;
function summary() {
  console.log('═'.repeat(60));
  console.log('TOTAL: ' + TP + ' passed, ' + TF + ' failed');
  // v179 — the browser suite is opt-in and counted on top when it runs.
  const expected = EXPECTED_TESTS + (BROWSER_RUN ? BROWSER_EXPECTED : 0) + (REFERENCE ? REFERENCE_EXPECTED : 0);
  if (TP + TF !== expected) {
    console.log('');
    console.log('COUNT MISMATCH: ' + (TP + TF) + ' tests ran, ' + expected + ' expected.');
    console.log(TP + TF < expected
      ? 'Tests went missing — a suite crashed before finishing. Treat this as a failure.'
      : 'Tests were added without updating EXPECTED_TESTS. Update it.');
    process.exit(1);
  }
  if (FAILED.length) { console.log('Failing suites: ' + FAILED.join(', ')); process.exit(1); }
  console.log('All suites green.');
}
// v178 — the streaming-reader cases are async, so they settle first and the
// summary runs after them. The HARNESS.md table check runs last of all because
// it compares the table with every suite's final count.
streamCases().then(res => {
  suite('Tier 21 — streaming session reader', t => res.forEach(r => t(r.name, () => { if (r.error) throw r.error; })));
}, e => {
  suite('Tier 21 — streaming session reader', t => t('the streaming cases ran at all', () => { throw e; }));
}).then(() => BROWSER_RUN ? browserCases().then(res => {
  suite(BROWSER_SUITE, t => res.forEach(r => t(r.name, () => { if (r.error) throw r.error; })));
}) : null).then(() => REFERENCE ? referenceCases().then(res => {
  suite(REFERENCE_SUITE, t => res.forEach(r => t(r.name, () => { if (r.error) throw r.error; })));
}) : null).then(() => { harnessDocSuite(); summary(); });
