# Comparator test harness

**One file: `comparator-tests.js`.** Node only — no install, no network, no
other files. 533 tests. A further 20 browser tests run with `--browser`.

```bash
node comparator-tests.js                          # finds the newest ./comparator_offline*.html
                                                  # and the newest ./comparator_delta_v*.html beside it
node comparator-tests.js path/to/build.html       # or point it anywhere
node comparator-tests.js --browser                # also drive both tools in a real browser (below)
```

Re-run after any change to the build, the delta tool or the user guide.

### Optional companions it reads when they sit beside it

- `HARNESS.md` — this file. Its headline count and coverage table are checked.
- `Comparator_User_Guide.md` — the user guide's source. Checked against the
  build (suite "User guide agrees with the build"). `build_guide.py` turns it
  into the .docx; it needs pandoc and nothing else.

Neither is required. If one is absent, the checks that read it say so and pass.

### The browser suite (`--browser`)

Needs Playwright, which is the one thing this harness does not carry:

```bash
npm install playwright                   # once, in this folder or globally
npx playwright install chromium          # once, unless you point it at a browser you have:
COMPARATOR_BROWSER="C:/Program Files/Google/Chrome/Application/chrome.exe" node comparator-tests.js --browser
```

Asked for and unavailable is a **failure**, not a skip. A run that was meant to
exercise the product must not come back green without having done so.

The harness picks the **newest** delta file by version number, so leaving
`comparator_delta_v3_3.html` beside `v3_4` is harmless to the run — but remove
stale copies from the Project so nobody opens the wrong one.

## Why one file

Comparator ships as a single self-contained HTML, and this follows suit so it
can live in a Project beside it. A split-file version was lost between sessions,
taking 72 tests with it — the whole point of this format is that it survives.

## How it works

The build's testable functions are lifted out of the HTML by marker, then run in
a per-suite sandbox that stubs the browser globals they touch (`document`,
`state`, `COL`, `XLSX`). Each suite gets its own sandbox because the modules
expect different `COL` shapes.

If a marker moves, extraction **fails loudly and names it, and no tests run at
all** — the build was refactored and the marker needs updating. That is
deliberate: an empty module would let every suite pass while testing nothing.

This was only half-true before v154. Four boundary lookups used raw `indexOf`,
which returns `-1` on a miss and turns into a zero-length slice. Pointed at a
build where one marker had been renamed, the old harness printed
**"21 passed, 5 failed"** — a believable summary. In fact 33 tests never
executed, because a crashed suite costs exactly one reported failure no matter
how many tests it contained. Every boundary now goes through `at()` / `lastAt()`
/ `span()`, and `span()` refuses a slice that is inverted or implausibly small.

`EXPECTED_TESTS` is the backstop: if the number of tests that actually ran is
not the number expected, the run fails and says so. **Bump it when you add
tests** — that is deliberate friction, because a silently shrinking suite is the
failure mode this harness is most vulnerable to.

## Coverage

| Suite | Tests | Covers |
|---|---|---|
| Engine — tagging changes reconciliation output | 9 | **Core correctness.** Tagging a proc code actually changes `buildAbomMap` output; swap-as-add second pass; founding program unaffected; worker table in lockstep |
| Proc code panel — job number samples | 16 | Job-number sampling, dedup, HTML escaping, Mapping 2 (where the old description column was always blank) |
| Tier 1 — proc code profile name is provenance | 13 | **Regression guards for two v153 defects.** Cancel on the profile-name prompt; profile name surviving a session round-trip; the name/override split |
| Tier 2 — EBOM indenture map (the real one) | 11 | **The real `buildEbomIndentureMap`,** not a stand-in. Parent/child linking, shared PN under two NHs, self-referencing rows, first-occurrence rules |
| Tier 2 — extraction integrity | 13 | **The harness's own safety net.** Module contracts, marker guards, worker-bundle closure, build is still self-contained, HARNESS.md headline count |
| Tier 3 — CHP release state | 19 | Badge states, latest-DCN selection, undated-DCN warning, and **timezone-stable release dates** |
| Tier 3 — proc table under lock, bad input, and session reuse | 14 | Lock behaviour, hand-edited profile files, provenance leaks between loads, stale-results flag |
| Tier 4 — delta tool | 29 | **Baseline drift between the two shipped files**, proc table diffing, claim change detection, indenture scope, label agreement with the main build |
| Tier 6 — delta tool report assembly | 26 | Two-pass EBOM matcher, KPI counters, NCR disposition diff, **mode vocabulary drift**, pre-rename CHP sessions |
| Tier 7 — Detailed View markers and raw-BOM badges | 15 | The single `↑ parent` marker style, the neutral catch-all badge, part-type exclusions, **and the explanation modal matching the code** |
| Tier 8 — CI Traceability Report columns | 18 | Header/row width parity across every sheet, plus the v155 column removals and renames |
| Tier 9 — MBOM column order across every surface | 8 | Job Number's position pinned across all four surfaces, header and row builder together |
| Tier 10 — badge guide completeness | 16 | Guide entries derived from the badge maps, so a new badge cannot ship undocumented; one text source for guide and tooltips |
| Tier 11 — chart rendering and label crispness | 14 | **Executes** both chart renderers against a recording 2D context; buffer/CSS parity, reflow, label pixel-snapping |
| Tier 12 — colour tokens | 31 | Nothing bypasses the palette; **three palettes** (dark / light / Black & White) complete, distinct and legible; mono fills and outlines; the exported report's own palette; the theme kept out of the session and the hash; canvas colours equal token values |
| Tier 13 — summary table type scale | 12 | One cell size, header smaller, badges matched; plus a **syntax check of every inline script block** |
| Tier 14 — Detailed View table structure | 12 | All eight table views wired identically; captions outside the scroll container; row selection; uniform pagination |
| Tier 15 — reconciliation engine | 24 | **The engine itself**: three passes, quantity shortfall, proc codes, scope exclusions, the worst-leg rollup |
| Tier 16 — effective results and the duplicated rollup | 14 | **The duplicated rollup**, compared exhaustively against the engine's; claim overlay behaviour |
| Tier 17 — session restore | 11 | Exporter/importer field parity, the frozen flag, pre-v153 sessions, malformed payloads |
| Tier 18 — indenture scope and normalisation | 16 | The configurable collector rule and numeric→alpha indenture normalisation |
| Tier 19 — ME adjudication import | 39 | PN→position resolution, deficient-leg claims, the narrative scanner, scoped re-import, provenance values derived from the build |
| NCR dispositions without EBOM trace — one row per disposition | 12 | Export grain is **one row per disposition**, not per file row; merged values joined not dropped |
| ECN footprint completeness | 7 | CHP-listed items that never joined to an EBOM row |
| Many EBOM line items to one ECN | 6 | Many EBOM line items → one ECN; one bad item excludes the whole ECN |
| Stylesheet and chrome integrity | 64 | Brace balance **located by line**; orphan keyframes; undefined CSS vars; ME ADJ zone placement; workbench blocks; funnel legend and **residual measured and rendered**; open-WO colour; mapping modal; Job Number search; RFV rules; filter-count scoping; Claim Ledger naming; uniform upload zones; export-menu wiring |
| Tier 20 — provenance: version, certificate and claims | 17 | **v178/v179.** Session and certificate stamped from `APP_VERSION`; one certificate definition for Excel, CSV and HTML; the hash covers every field a claim is written with (derived); claim-source labels; every column map saved, restored and reset; one Proc Removed glyph |
| Tier 4b — delta tool follows the main build | 19 | **Delta v3.4.** Identical streaming reader; claim signature derived from the certificate hash; Origin column; honest tool-version labels; one `DELTA_VERSION`; KPI rows named and counted as the dashboard; purple kept for human decisions; palette equal to the main build's |
| v177 visual grammar | 4 | Metric bar stays gone; component primitives exist; jump links are text; the 7 remaining 8px rules (all in the funnel) pinned by name |
| User guide agrees with the build | 8 | **v179.** The guide's source against the build: version stamps, delta version, every badge and status label, theme names, section references and numbering, the certificate description, a history row for this build |
| Version single-source | 4 | Single-source version string; guards the header pill against drift |
| Tier 21 — streaming session reader | 10 | **The hand-written JSON parser large sessions go through**, against `JSON.parse`, at chunk sizes down to 1 character; truncated files rejected |
| HARNESS.md describes this run | 2 | This table: every suite by exact name with the count it ran |
| Browser — the product actually runs | 20 | **v179, `--browser` only.** Loads four Excel files built in the page, runs a comparison through the real worker, checks the engine's verdicts and a dashboard card, processes a claim, exports and re-reads the session, freezes, opens the Excel, CI report, CSV and HTML files it wrote, re-imports the frozen session, and compares two sessions in the delta tool, including through the streaming route |

The table is checked. Suite names must match the harness output exactly, and
each count must be what that suite ran. The browser suite is listed but is
only compared when `--browser` is given. Add or remove a test and this table,
the headline count and `EXPECTED_TESTS` all have to move together.

## v179 — running the product, and checking the guide

### Two more certificate copies

v178 found two Excel certificate sheets that had drifted and gave them one
definition. The test it added looked for Excel sheets named "Audit
Certificate", so it could not see that the **CSV** and **HTML** exports each
wrote their own certificate too. Those still printed auditor, date, mode and
hash only, without the build, proc code profile, codes or scope. The CSV copy
also did not escape quotes.

The Tier 20 test now searches for the certificate's title text, which every
copy has to print, and allows it in one place. Searching by what an artefact
must contain finds copies that searching by their names does not.

### The browser suite

HARNESS.md has said for several builds that "a test that reads or sandboxes the
source is not a test that runs the product". v160 to v163 could not run a
comparison at all while 397 tests passed. `--browser` now runs the product.

- **Fixtures are built in the page** with the build's own SheetJS, so the suite
  needs no files. The program is small but has one of each: structural apex and
  major assembly, a fully built part, a part under an open work order, a part
  never built, and a child whose parent is its used-on assembly.
- **Every download is read back from disk.** The Excel, CI report and CSV
  certificates are compared with `_auditCertRows` row by row. The HTML report is
  checked more loosely: every certificate value must appear in it, but not in a
  particular position.
- **Every comparison must have something to compare.** An independent review
  found that the open-work-order check compared 0 with 0: a processed claim had
  cleared the only open work order in the fixture. The claim moved to another
  part, and the test now fails if the count is zero.
- **The delta tool runs twice**: once as shipped, and once with its large-file
  threshold lowered to 1 KB, so the streaming reader runs in a real browser.

Run against v177 and delta v3.3 it fails where those builds were wrong: the
session stamp, the missing column map, then a crash where v178's certificate
function did not yet exist. Run with the v179 build and the v3.3 delta tool, it
fails all four delta checks.

Two of its first expectations were wrong, and the product was right. P100 is
also P101's next higher, so pass 2 finds it as a used-on parent and its overall
is `pn_as_usedon`, not `ok`. The HTML report prints the mode as "EBOM MBOM
ABOM" by design. The fix was to the tests, and each now says why.

### The guide has a source, and the source is checked

The user guide drifted for twenty builds. It carried a stale version stamp,
the wrong Proc Removed symbol, theme and colour names from before v173,
missing section numbers, and a chapter 3 section inside chapter 4. Nothing
compared the guide with the tool, and the Project held only the .docx, which
nothing can read reliably.

The guide now ships as `Comparator_User_Guide.md`, and `build_guide.py` makes
the .docx from it. The suite "User guide agrees with the build" checks it
against the build, deriving every expectation from the build itself:
`APP_VERSION`, `DELTA_VERSION`, `BADGE_HELP`, the theme menu's options and
`_auditCertRows`.

Pointed at the v176 guide's text, all eight tests fail, each on a defect that
guide really had. The chapter-placement check was added after that run showed
the numbering test alone missed the misplaced §3.6.

### The last small labels

Seven labels outside the funnel were raised from 8px to the 9px floor. They
were checked in before-and-after screenshots at real widths, and none
overflowed or clipped. The pinned list is now the seven funnel rules only.

## v178 — the drift audit

A drift audit of v177 against the delta tool, this harness, the test inventory
and the user guide found 35 places where the files disagreed. The reported
symptom was a session exported from v177 that the delta tool said came from
v142. Every fix in v178 and delta v3.4 has a guard here, and each guard was run
against the unfixed v177 files first and seen to fail there.

### The version stamp nobody could see

The header pill was moved to `APP_VERSION` at v153 because it had been stale
for 33 releases. The session exporter was not moved. `toolVersion` said `v83`
until v142 and `v142` from v142 to v177. The delta tool printed it faithfully.

The version guard read only the header markup, so it certified the one place
that was already fixed. Tier 20 now requires `APP_VERSION` to be the **only**
quoted version string anywhere in the code, and the certificate records the
build too, beside the hash rather than inside it.

The delta tool labels `v142` as "v142–v177 (exact build not recorded)" and
`v83` as "v83–v141 (exact build not recorded)". **That is correct and must not
be "fixed".** The information was never written, so it cannot be recovered.

### The claim schema outgrew both of its signatures

Claims gained fields at v84, v85, v87 and v162. Two hand-maintained lists were
supposed to track them: the certificate hash's per-claim projection and the
delta tool's `claimSig`. Both stopped growing. A CI-to-NCR trace moved to a
different CI hashed identically, because its `rowKey` is null and `ciKey` was
not hashed. The delta tool reported claims unchanged when their reason, their
second disposition or their WO target row had changed.

Both lists are now derived. Tier 20 reads every object literal that creates a
claim and requires each field to be hashed or listed in `HASH_EXEMPT` with a
reason. Tier 4b requires `claimSig` to compare every hashed field except `id`
and `timestamp`, and changes each field in turn to check that the claim is
reported as Modified.

### Two certificate sheets, drifting

`exportXLSX` and `exportCIReport` each built the Audit Certificate sheet
inline. The CI report's copy printed EBOM Indenture Scope twice and dropped the
removal and swap proc codes. A Tier 18 test counted **two** scope rows and
passed partly because of the duplicate. There is now one `_auditCertRows`,
and Tier 20 finds every `'Audit Certificate'` sheet in the build and requires
it to come from that function.

### A reader that could not open the file

The main build moved to chunked export at v142 and streaming import at v143.
The delta tool kept `readAsText`, so it could not open the largest sessions,
which belong to the largest programs. It now carries a verbatim copy of the
main build's reader, and Tier 4b fails if the copies differ.

The reader's own comment said it was verified by `session_stream_test.js`.
That file was lost like the split-file harness. Tier 21 now compares the
parser with `JSON.parse` across escapes, non-ASCII text and truncated input, at
chunk sizes down to one character; sabotaging the `\t` escape fails two of its
tests. It feeds text, not bytes, so a multi-byte character split between raw
file chunks (the browser's `TextDecoder`) is not covered — see Not covered.

### Three palettes, one set of names (v173–v175)

Tier 12 went from 7 tests to 31 when the build gained light and Black & White
themes. Every theme defines every token. No theme collapses two tokens onto
one value or borrows another theme's value. Body text stays legible in each.
Mono identifies findings by label, and only ✗ MISSING keeps a fill. The theme
is a view, not a record: it stays out of the session and the certificate hash.
Canvas colours are re-resolved on a palette change.

### v176 and v177

v176 deleted `drawBarChart`, unused since v47.1. "the deleted renderer stayed
deleted" pins it.

v177 was a visual refactor with no tests. It added component primitives,
removed the metric bars and turned the section links into text. Its own note
said all fourteen remaining 8px rules were in the funnel. **Only seven are.**
The v177 visual grammar suite pins the real list of 14 by selector: the list
may shrink as each is checked on a screen, and it may not grow.

### Hand lists, again

Tier 19's "every native provenance value survives a replace" named seven
`createdFrom` values. The build has eight, and `missing_abom` was absent while
the test passed. It now derives the set from the build. The same audit found
`external_import` missing from the claim-source labels, so ME-imported claims
printed the raw code as their source in the CI report. Tier 20 now requires
every emitted `createdFrom` to have a label.

The first version of that test was itself a hand list in disguise: it looked
for quoted `createdFrom: '…'` values and the `_ADJ_CREATED_FROM` map, and so
missed `nh_mismatch_helper_paired` and `dash_suffix_helper_paired`, which the
helpers pick with a ternary into a variable before filing the paired MBOM
claim. An independent review of v178 caught it. `createdFromValues()` now also
reads any `*CreatedFrom = …` assignment, and both values have labels.

A hand list can only ever be as complete as the person writing it. In this
audit alone that was true of the native provenance list, the claim-source
labels, the certificate hash projection and the delta claim signature.

## Five defects these tests were written for

All five were live in v153. Four were fixed in v154; the delta tool's
`claimSig` defect was fixed in delta v3.2. Eight tests across Tiers 1
and 3 fail against a v153 build — that is the check that they are real guards
and not decoration. Run the suite against an old build occasionally to confirm
they still bite.

- **The release date was wrong east of Greenwich.** `formatDcnDate` read UTC
  components off a date built at *local* midnight, so a DCN released 15 March
  displayed as **MARCH 14** in Tokyo, Sydney and Kolkata. It reached the badge,
  the tooltip and the freeze certificate. Both the parser and the formatter now
  normalise date-only values to local midnight and read local components.
- **A profile name leaked between loads.** `setProcCodeMap` fell back to
  `|| state.procProfileName`, which no caller needed. Load "Program Falcon",
  then import an unnamed custom session, and the certificate still claimed
  Falcon. The argument is now the only source of the name.
- **The delta tool displayed a field it never compared.** `claimRow` prints
  `c.dispNo || c.ncrDispNo`; `claimSig` compared only `c.dispNo`. On
  `ebom_ncr_trace` claims — the ones the main build actually creates — the
  field is always `ncrDispNo`, so a changed NCR disposition number was declared
  unchanged and omitted from the Claims sheet entirely. `applied` had the same
  problem. The rule now under test: **every field `claimRow` prints must be a
  field `claimSig` compares.**
- **Cancel exported a file anyway.** `exportProcProfile()` read
  `(prompt(...) || '').trim()` and then tested the result for `null`. The
  coercion happened first, so the guard could never fire: Cancel wrote a
  `proc_code_profile.json` and overwrote the profile name with
  "Unnamed profile".
- **The profile name did not survive a session.** `setProcCodeMap(map, name)`
  ignored `name` whenever `map` was null, and the session importer calls
  exactly that path. Proc code *behaviour* travelled with the session; the label
  saying whose behaviour it was did not.

The rule both defects broke, now pinned by tests: **the name is provenance, the
overrides are the deviation, and they are separable.** A shared profile whose
codes happen to equal the baseline still has a name. Callers that mean "start
clean" — `resetProcCodesToBaseline`, `resetAll` — pass no name and still clear it.

## The stylesheet was never the stylesheet

`SRC.indexOf('<style')` matches **`<style:master-page`** — an OpenDocument XML
tag inside the vendored SheetJS library on line 28. Every CSS test was scanning
~58KB of minified JavaScript with the real stylesheet appended to it.

That is where the `-2` brace baseline came from. It was not "the counter is not
a real CSS parser" — it was JS object literals being counted as CSS rules. Both
real style blocks balance at exactly **0**.

The check now finds blocks with `<style(?:\s[^>]*)?>`, which the XML tags cannot
match, and scans them with a comment- and string-aware pass that returns the
**line numbers** of unmatched braces. Compared with the old baseline it:

- **locates** the problem instead of reporting a delta
- catches one stray `{` and one stray `}` in the same file, which cancel to a
  delta of 0 and passed the old check
- does not break when the vendored library changes. Editing a single string
  inside SheetJS — touching no CSS — shifted the old delta to 0 and failed the
  build.

Both style blocks are now checked. The second one, which styles the exported
HTML report, was never examined at all.

## Four naming conventions for one thing

Seven header arrays in the CI Traceability Report carry NCR disposition
columns, and they use **four different names for the same field**:
`NCR Disp#` (detail, CSA, claims), `NCR Disposition #` (no-ABOM NCRs),
`Disposition #` (adjudications), and — as of v159 — `Disposition Number` on the
two sheets that were reordered.

v159 changed only the two sheets in scope. The other five are pinned by a test
that names the exact string each one uses, so the next rename is a decision
rather than a drift. Reducing four conventions to one is a worthwhile change; it
is not one to make unasked, since every one of these is a column heading someone
may be filtering on downstream.

## Column counts are checked, because XLSX will not check them

Removing a column from an export sheet means editing the header **and every row
builder**. Miss one and `aoa_to_sheet` writes the rows regardless, shifting
every value after it one column left — a spreadsheet that looks plausible and
is wrong. Nothing in the export path validates this.

Tier 8 counts the top-level elements of each `*Hdr` array literal and of every
matching `*Rows.push([...])`, and fails naming the sheet when they disagree. It
covers all 14 sheets of the CI Traceability Report, not only the ones v155
touched.

The splitter respects quotes, parentheses and nested brackets, and is itself
under test. A naive comma split turns the real header
`'Part Qty (ABOM, per WO)'` into two columns, which would miscount every sheet
that carries it — a test helper that mis-parses is as dangerous as the defect
it is meant to catch.

**Paired sheets** are pinned to identical column names: `CI ABOM Claims
Processed` is the SME-adjudicated counterpart of `CIs Embodied as WO Parts`,
and the As-Built Records Guide states that pairing outright. Renaming one and
not the other would leave a single workbook disagreeing with itself.

## One column, four surfaces

The MBOM Traceability / Reconciliation Notes / Job Number trio appears on the
on-screen Detailed View, the context export, the CSV export and the XLSX
export. Each has its **own header list and its own row builder**, and nothing
links them — move a header without its row builder and every column to the
right of it shifts one place, silently.

v155 moved Job Number to the right of Reconciliation Notes so the two companion
columns stay adjacent. Tier 9 pins header order, row order and the on-screen
`<td>` order together on every surface, and counts them against each other. A
half-applied move fails three tests independently.

The HTML report carries the Traceability/Notes pair and has never had a Job
Number column; it is excluded by name rather than by arithmetic, so it cannot
quietly acquire one without a row builder.

## Two views sat inside their own scrollbar

`.table-wrap` is `overflow-x: auto; overflow-y: auto; max-height: 68vh`, and
`attachTopScrollbar` inserts its mirror as the wrap's **previous sibling**.

Six of the eight Detailed View tables put only the table and pager inside the
wrap. Two — the I/R ABOM Discrepancy view and the RFV Information view — put a
caption there as the first child. Three consequences, all visible:

- the caption scrolled sideways with the table and off the screen
- it slid under the sticky header row on vertical scroll
- the top scrollbar appeared above the *caption* rather than on the table

Those two are exactly the two that were reported as formatted differently. Both
captions now write to a `.table-caption` element declared outside the wrapper,
via a shared `setTableCaption` helper, so the eight views are structurally
identical.

Pagination was never the difference — seven of the eight already shared
`PAGE_SIZE` and the same `page-bar`. The real outlier is **renderCITraceTable**,
which paginates not at all; that is now a named exception with a test that fails
if it ever gains a pager, rather than an unremarked gap.

## The engine is under test

`runReconciliationCore` is 543 lines and decides whether a part is reconciled.
Until v159 **not one test executed it** — every suite tested the code around it:
the proc table that feeds it, the badges that display its output, the exports
that format it.

It is pure: one params object in, a results array out, no globals and no DOM. It
was testable the whole time.

**Fixtures go through the real map builders, never hand-built.** Building them
by hand got the shapes wrong twice while this suite was being written — a `Map`
where the engine wants a plain object, and an object where `primaryQtyMap` wants
a bare number. Both times the engine ran without error and returned
plausible-but-wrong results, and a defect was nearly reported against correct
code. Two tests now pin the builder output shapes for that reason.

Behaviour worth knowing, now asserted rather than assumed:

- **Quantity mismatch means a shortfall** (`aq < eq`), not any difference. More
  in the build than the design is not a reconciliation failure.
- **By default, indenture A and B are structural collectors**, excluded from
  scope (v160 made this the EBOM Indenture Scope setting). The Tier 15 fixtures
  rely on the default: a fixture using indenture B silently produces
  `overall: collector` on every row.
- **REF lines produce no row at all** — they are excluded from the results, not
  reported as excluded.
- **A SWAP proc code is not a removal**; an install alongside a removal nets out.

Verified by breaking the engine three ways — the shortfall rule, the priority
rollup, and proc-removal detection. Each failed the matching test by name.

## The duplicated rollup is now compared, not trusted

`computeEffectiveResults` applies SME claims on top of raw engine output, and
its Phase C comment says it *"mirrors runReconciliationCore's priority rollup"*
— the same shape of risk as the duplicated `PROC_CODE_BASELINE` in the delta
tool, which did drift.

Tier 16 compares the two ladders **exhaustively**: 12 leg statuses across 4
legs, 20,736 combinations, every one asserted equal. Today they agree exactly.
A second test compares the rung ORDER as source text, so a reordering that is
behaviourally equivalent today still fails as drift. Swapping `qty_mismatch` and
`wo_open` in one copy produces 1,202 disagreements and a named order mismatch.

**A trap worth knowing.** `computeEffectiveResults` returns early when the claim
list is empty:

    if (!adjudications || !adjudications.length) return effective;

So Phase C never runs without a claim, and any test of the rollup that passes an
empty claim list **silently tests nothing**. The exhaustive comparison supplies a
claim targeting a non-existent row — enough to get past the guard, changing no
leg. Two tests written without it passed while exercising no code at all.

## Importing someone else's adjudications

Manufacturing Engineering adjudicates in a separate COTS tool. Its export is
keyed on **part number only** — no next higher, no quantity, no leg. v162 infers
all three rather than asking ME to change their tool, so every inference is
tested: an adjudication landing on the wrong position changes the numbers.

- **Position** comes from the EBOM, scoped to positions that actually fail
  passes 1-3. A part at three positions where only one is broken needs no human
  input, which is what keeps the picker small.
- **Quantity** is the line's EBOM qty — "make the line whole". Over-claiming is
  accepted by the residual model, so one rule covers a missing leg and a short one.
- **Leg** is whichever legs fail. A claim is **not** emitted for a healthy leg:
  it would be a harmless no-op, but it would record ME as having adjudicated
  something they did not. On an audit artefact that is the difference between a
  record and a fiction.

The **narrative scanner** searches for KNOWN values — the next-highers of the
failing positions plus their WO and job numbers — rather than guessing what an
identifier looks like in prose. Hyphens and dots are part of an identifier, never
boundaries, which is what stops `88421-7` matching inside `588421-70`.

It **suggests only when the prose names exactly one candidate**. Narrative
routinely rules one out in words — *"...under 88421-7, not 88421-9 as originally
routed"* — and no matcher reads negation. When several are named it shows the
sentences and suggests nothing. Finding the relevant sentence in three
paragraphs is the real value; guessing the answer is not.

**CI-to-NCR tracing is Configuration Management's, not ME's.** An imported batch
must never withdraw it. `replaceImportedClaims` drops only claims that
`isImportedClaim` accepts, and that check vetoes on claim TYPE as well as
provenance: a claim of type `ncr_ci_trace` or `ebom_ncr_trace` is protected even
if its `createdFrom` were somehow wrong. Provenance alone would have been
sufficient in practice, but the failure mode — silently deleting another team's
work on an audit artefact — is bad enough to justify the second check. The
review panel states the guarantee in words and names the count.

**Scale is a real constraint here.** A production ME export runs to ~3,000 rows.
Resolving each by scanning the full result set is O(rows x results) — measured
at **3.2 seconds** against an 80k-line EBOM, which would freeze the tab.
`planAdjImport` indexes results by part number once, taking the same work to
**194ms**.

Two tests guard it: a timing test at production scale, and a structural test
that the index is *passed to the resolver*. The first version of the structural
test checked only that the index was **built** — and passed while the planner
rescanned per row and took three seconds. Building a thing and using it are
different claims.

**Re-import replaces the imported batch and nothing else.** Claims filed inside
Comparator, CI/NCR traces especially, are native work and survive. A test asserts
every one of the seven native `createdFrom` values is preserved.

## Two halves of one omission, three builds apart

v165: staging added claims to `state.adjudications` and never told the
workbench, so **Process Adjudications** stayed greyed out.

v171: processing flipped those claims to applied and never told the import
panel, so it reported *"none applied yet"* for ever.

The same omission in both directions — a component that owns state, and a
component that reports it, with nothing connecting them. The second was fixed by
hanging `renderAdjImportPanel()` off `_adjRefreshWorkbench()`, which **every**
state-changing path already calls: submit, process, revert, remove, stage,
session import. Patching each caller would have left the next one to be written
broken again.

The message itself was correct the whole time. It simply never re-rendered,
which is the more dangerous shape of wrong: a UI that is confidently stale reads
as a fact about the data rather than a fact about the rendering.

## Checking one surface is how a half-done change passes

Making the RFV pass badges uniform touched three places, and v167 changed two:
the summary column and the legend line above the RFV Information table. The
**MATCH PASS column** in that same table is built somewhere else entirely, from
`addMatch()`, and stayed blue and red.

The test passed, because it checked the legend line only. A test that inspects
one of a change's surfaces certifies the change while half of it is undone.
It now checks the legend AND the badge builders.

That audit also surfaced a **fourth** pass nobody had mentioned: SME-Linked WO,
in `--adj` purple. It keeps its colour deliberately — purple is the
manual-provenance contract across the whole tool, and that pass exists *because*
a person linked it. A provenance distinction is not a pass ranking, so it
survives the flattening, and the test asserts it stays distinct.

A related duplicate: the Candidates Helpers zone already carried a subhead
inside it, and v167 added a second outside, so it rendered twice. The subhead
test now COUNTS rather than checking presence.

## One unresolvable call killed every filter count

v169 added `has_rfv: r.filter(x => getRowRfvLinks(x).length > 0).length` to the
counts object. `getRowRfvLinks` is **local to `renderSummaryTable`**, and
`renderAll` calls `updateFilterCounts` **before** it. So the call threw
`getRowRfvLinks is not defined` while the counts object was still being built —
before a single button was labelled.

The reported symptom was "no Has RFV button". The actual damage was **every
filter count on the page**, plus the count-based reveals for Removal Items and
Proc Removed. A screenshot showing bare labels on `ALL`, `ISSUES ONLY` and
`RECONCILED` was the tell.

The count is now `_rfvLinkedRowCount()`, top-level, building its own index over
the same three geometries (PN+NH, NCR disposition, work order).

A new test walks every bare call `updateFilterCounts` makes and fails if any
resolves to a function declared at an indent — i.e. nested in another scope.
That is a general guard: the counts object is one literal, so any unresolvable
call anywhere in it takes the whole page's filter counts with it.

## A filter gated on the wrong thing looks unimplemented

The Has RFV filter was gated on `state.boms.rfv` — on the FILE being loaded.
Every other conditional filter (`pt_removal`, `abom_proc_removed`) gates on
**count > 0** and carries its count in the label. Two consequences:

- With no RFV file the button was invisible, which to a reviewer is
  indistinguishable from the feature not being built. That is how it was
  reported.
- With a file loaded that matched nothing, it would have offered a filter
  returning an empty table.

It also had no entry in the `counts` object, so even when visible it rendered a
bare label while every neighbour showed `Label (n)` — it would not have looked
like a peer even if it appeared.

v169 counts it and reveals it by count. A second test asserts that **every**
conditional filter is revealed the same way, because a control revealed by a
different rule is the one that surprises the reader.

## A legend drawn in emoji cannot track the chart

The funnel explain modal described its bars with emoji squares — 🟥 🟧 🟪 🟨 ⬛ ▒ —
none of which were connected to the colours the bars use. Auditing all six
against the code found five wrong:

- **Three different swatches all stood for `var(--warn)`**, teaching a
  distinction the chart does not draw.
- **`WO Not Closed` cannot be one swatch**: the segment is split, teal for
  RFV-authorised open WOs and amber for bare ones.
- **The reference bars were given category colours they do not have.** Every
  reference bar renders in one neutral fill because it is *context, not a
  finding* — so the legend was showing colour where the tool draws none. That
  was the worst of the five, and the one the owner spotted.

Swatches are now `<span class="fn-sw">` elements taking the same `var(--x)`
token the bar takes, so the legend cannot drift from the chart. Four tests bind
them: no emoji, every residual colour has a swatch, `WO Not Closed` shows two,
and reference-bar entries match the neutral fill.

**The first audit was wrong too.** It treated the modal as describing one bar
and reported five mismatches in one family. There are two families — the
residual risk block and the reference bars — and the owner caught that before
any fix was written. Reference bars are not badly coloured; they are not
coloured at all.

## Placement can enforce an ordering that a message only asks for

The ME adjudication export sat in the pre-run upload grid alongside the nine BOM
sources, which is what it looks like — and is not what it is. An ME export is a
batch of claims **about a run that must already exist**, so the ordering had to
be enforced with an error message: *"Run the comparison first."*

v166 moves the zone and its review panel inside the Adjudication Workbench,
between the Candidates Helpers and the Claim Ledger. That section does not
render until a comparison has run, so the ordering now enforces itself and the
error is a backstop reachable only via a restored session. Same principle as
deriving a rule instead of restating it.

One consequence had to be handled: the section previously appeared only when
there was *something to adjudicate*. A clean run with no helper candidates is
exactly when an SME may still want to import ME's decisions, so visibility now
keys on whether a run exists.

The action bar was also renamed **Claim Ledger**: it had carried the same name
as the section it sits inside, which made "the workbench" ambiguous in both the
UI and the explanation modal.

## Adding a claim is not the same as making it usable

`stageAdjImport` pushed imported claims onto `state.adjudications` and told
nobody. The workbench only re-reads that array when `_adjRefreshWorkbench()` is
called, and it only becomes visible via `_adjShowWorkbench()` — which matters
because the section stays hidden when the run produced no helper candidates of
its own. So claims staged from an import sat pending with **Process
Adjudications greyed out**, and no way to apply them.

Every native claim path calls both. The import path called neither. v165 adds a
test that any function adding claims must call `_adjRefreshWorkbench`, and that
staging reveals the section.

The first version of the second test **passed against the broken build** — the
function body explains *why* it calls `_adjShowWorkbench`, and the test matched
that comment. Both checks now strip comments and require an actual call. That is
the third time in this project a test has matched prose instead of code.

## The worker runs a hand-listed bundle, and it broke twice

The comparison engine runs in a Web Worker built by serialising a **hand-listed**
set of functions with `.toString()`. A bundled function that calls another
top-level function *not on that list* throws inside the worker and kills every
comparison run.

That has now happened twice: `buildEbomLineNoMap` in v145, and `normIndenture`
in v160 — which **shipped broken through v163**. Every suite in this harness
loads functions directly into a sandbox, so none of them exercise the worker
path; 397 tests passed against a build that could not run a comparison at all.

v164 adds a closure check: for every function in the bundle, every bare call it
makes to another top-level function must also be in the bundle. Method calls are
excluded — `map.set(...)` is not the top-level `set()`. Removing `normIndenture`
now fails naming the exact call, `buildEbomIndentureMap() calls normIndenture()`.

The lesson is the one this project keeps relearning: a test that reads or
sandboxes the source is not a test that runs the product.

## The delta tool had to learn about the scope too

v160 made the collector rule a per-program setting. The delta tool's whole job
is telling two sessions apart, and it knew nothing about it — so two sessions
run under different scopes would have been diffed silently, showing rows moving
between COLLECTOR and reconciled as though the build had changed.

v3.3 treats it exactly like the proc code table: a provenance row in the summary
naming both scopes, and a load-time warning. It is deliberately **not** gated on
an ABOM leg being present, unlike the proc code row — the scope governs the EBOM
side, which every comparison mode has.

Sessions written before v160 carry no field and are read as the fixed A/B rule.
Defaulting to an empty list would claim every level reconciled, which is the
opposite of what those sessions did.

**What did not need changing:** the delta tool excludes structural rows by the
`collector` STATUS, not by inspecting indenture letters, so it inherits the
setting automatically. A test asserts it never starts deriving the rule itself —
that would be a second copy to keep in sync, which is how
`PROC_CODE_BASELINE` drifted.

## Two program conventions, v160

**Which indenture levels are collectors** was one hardcoded line —
`(indenture === 'A' || indenture === 'B')`. Every other reference in the build
keys off the resulting `'collector'` status, so making it configurable touched
one decision point rather than seventy-five.

It is modelled as a LIST, not a boolean: a program may treat A as an apex
collector while B holds real parts, which a boolean cannot express. The setting
travels in the session and is named on the certificate, because two people with
different settings comparing the same files get different answers.

**Numeric indenture** (1, 2, 3…) is normalised to alpha at every read, so one
rule describes the hierarchy whichever convention the source file uses. Values
outside 1–26 are left alone rather than remapped to something meaningless.

Both engine call sites — the worker and the synchronous fallback — pass the
setting, and a test counts them. Passing it to only one would mean a worker
failure silently reconciling a different set of rows.

## The session file is the audit artefact

`importSessionJson` is async and DOM-heavy, but the part that matters — the
state restore that reconstitutes a certified report — is the first 96 lines and
runs unmodified against a stub `document`. Tier 17 extracts it by marker and
executes the real code rather than a paraphrase.

The guard worth having is **field parity**: every key the importer reads must be
a key the exporter writes. A field saved but never restored, or restored but
never saved, is a silently wrong answer months later rather than a crash.
`cpManualMap` is the single documented exception — a deliberate back-compat read
for sessions written before the `cp` → `chp` rename.

Verified by regression: removing `isLocked` from the exporter fails naming the
field; removing the `cp` → `chp` mapping fails on the pre-v153 session; and
relaxing the column-mapping check from `=== 2 ? 2 : 1` to `|| 1` lets a
corrupted session select a mapping that does not exist.

## The build is now syntax-checked

v155 stripped 26 inline `font-size` overrides out of `renderSummaryTable` with a
regex. A regex loose enough to do that is loose enough to break a template
literal, and **nothing in the harness would have noticed** — every other suite
matches patterns in the source rather than parsing it.

Tier 13 runs `node --check` over each inline `<script>` block. Removing a single
closing quote now fails with the file and line. This is a general guard, not a
type-scale one: it covers any future edit to the build.

## The Comparison Summary type scale

Cells were nominally 11px, but **26 inline declarations overrode that** at 10px,
9px and 8px — the em-dash for empty cells, stacked multi-value entries,
disposition status, part-type code. No principle, just accumulation. All 26 are
gone; every cell inherits `--fs-cell`.

Two decisions worth recording:

- **The header stays smaller than the cell** (`--fs-head: 9px`). A header is a
  label, not content, and is already distinguished by uppercase,
  letter-spacing, a surface fill and muted colour. It is also `position:
  sticky`, so enlarging it costs permanent vertical space on every screen.
- **Badge tracking dropped from 0.12em to 0.04em** when badges went from 8px to
  `--fs-cell`. Size and tracking compound: matching size alone widened
  `↑ PARENT IND. EMBODIED` from 141px to 188px, and the Traceability and
  Reconciliation Notes columns stack several badges per cell in a table that
  already scrolls horizontally. At 0.04em the increase is 20% instead of 33%.
  Weight 700 and uppercase remain as the non-size difference.

## Two text tiers in the summary table

v155 introduced a third tier (`--text-faint`) to formalise a grey already in
use. On review that was wrong for the table: three tiers in one data row is the
mush it was meant to fix. v156 sets the rule from the reader's side —

- **White (`--text`)**, via `td.cell-key`: part numbers, next highers,
  quantities, work order numbers and statuses, NCR disposition numbers and
  statuses, RFV numbers. The values you compare or act on.
- **Dim (`--text-muted`)**: everything else, by making it the `td` default. It
  is context, not the point.

`--text-faint` survives for **chrome only** — chart axis captions and funnel
footnotes, where it is the sole grey against a panel rather than one of three
competing tiers in a row. A test fails if it appears inside a `<td>`. Retiring
it entirely was over-reach on my part: five canvas `fillStyle` values referenced
it, and the token check caught that immediately.

Cells that carry their own semantic colour — disposition status greens and
ambers, mismatch highlights — still override both tiers, which is why NCR
disposition numbers and statuses need no white marking.

## The palette was good; 99 declarations ignored it

The build defines 28 colour tokens. v155 found **99 inline declarations using
raw hex instead** — 87 of them exact duplicates of a token that already
existed, and the rest near-misses that nobody chose:

- a second muted grey (`#7d8590`) 15 luminance from `--text-muted`
- a second accent blue (`#58a6ff`) beside `--accent`
- **a second teal for RFV** (`#39c5cf`) while `--rfv` was `#2dd4bf`

Five text levels were in play where the system defined two. `--text-faint` now
formalises the third that was already being used as a bare `#484f58`, and the
test requires the three levels to be at least 40 luminance apart so they read as
deliberate.

**Canvas colours are the exception and are tested differently.** A 2D context
silently ignores an unresolvable `fillStyle` and keeps the previous colour, so
chart colours must stay literal hex. Tier 12 instead requires every canvas hex
to equal a defined token value, and fails if any `fillStyle` tries to use
`var()`.

The KPI render-error banner is exempt by name: it reports that rendering has
failed, so making it depend on the stylesheet resolving would risk an invisible
error message. The exemption is narrow and itself asserted.

## One suite runs the code instead of reading it

Every other suite inspects the build as text. Tier 11 executes the two chart
renderers against a fake canvas that records `fillText` calls.

That capability exists because of a mistake made writing v155: a string
replacement intended for `drawWoStatusRollup` landed in
`drawNcrCauseCodeChart` instead, leaving a reference to an undefined `_ly`.
**All 228 tests stayed green** — nothing had ever executed a renderer, so a
guaranteed runtime crash was invisible. Tier 11 now fails three tests naming
`_ly is not defined`.

The fuzzy labels had two independent causes, both confirmed numerically:

- **The buffer was resampled.** `setupHiDpiCanvas` rounded the backing buffer
  but set the CSS size unrounded. A 703.328px canvas at dpr 2 got a 1407px
  buffer displayed across 1406.656 device pixels — the browser rescaled the
  whole canvas by 0.99976. Fractional widths are the normal case inside a flex
  row. The CSS size is now snapped so the two agree exactly.
- **Labels sat on half pixels.** Bar height is `max(14, floor(...) - 3)`, often
  odd, and a centred baseline at `y + barH/2` then lands mid-pixel. Bar widths
  are fractional too. Label coordinates are now snapped to the device grid via
  `_crisp`, while the bars stay fractional — geometry is fine at sub-pixel
  precision, text is not.

## One source for the guide and the tooltips

v158 gives every badge a native hover tooltip. The strings come from a single
`BADGE_HELP` map keyed by the exact badge label, and the **badge guide renders
from the same map** — so a badge cannot be explained one way in a tooltip and
another way in the guide. That is the structural fix for the drift below, not
just a feature.

**The first version of this test named its call sites by hand** — four helpers I
had found by reading. It passed, and `tracBadge` still rendered every badge in
the Traceability and Reconciliation Notes columns with no tooltip at all,
because I had not found it. A hardcoded list can only ever be as complete as the
person writing it.

The rule is now derived: scan every badge span in the build; if its label is one
`BADGE_HELP` explains, it must carry a title, and any helper taking a `label`
that emits a badge span must consult `BADGE_HELP`. That immediately found five
more sites the hand list had missed, including four badge families —
`▲ INSTALLED`, `▼ REMOVED`, `✓ MATCHED`, `— UNMATCHED` — with no explanation
anywhere in the product. The badge guide's own preview badges are exempt by
position, since the description sits in the next cell.

Six render paths now attach it: `badgeBom`, `badgeAbom`, `badgeOverall`,
`tracBadge`, `adjTracBadge`, plus the inline sites in the raw BOM, CHP, WO5,
NCR, CI trace and RFV views. The last already built a multi-line title from adjudication
metadata (who claimed it, when, the rationale, the WO and NCR numbers); the
explanation is **prepended** to that, not substituted for it, and a test asserts
the detail survives.

Native `title` was chosen over a styled panel deliberately: badges live inside
`.table-wrap`, which is `overflow: auto`, so a CSS tooltip would be clipped at
the scroll edges and would need body-level positioning in JS. That is the
difference between an hour and half a day, and the delay is the only thing lost.

## Glyph-insensitive matching is how the guide drifted

Tier 10 compared guide entries to badge labels with leading glyphs stripped, and
never compared CLASSES at all. So when v156 moved the used-on badges to
`--success-2`, the guide kept showing them in `badge-ok` green and every test
passed. Three entries were wrong; a reader comparing the guide to the table
would have seen two different greens for the same badge.

v157 compares **exact labels and exact classes**. It immediately found a
fourth drift the looser test had also been hiding — `⬇ PROC REMOVED`
documented without its glyph.

Green badges now carry no glyph at all: green already says "fine", so a tick
adds nothing. Glyphs are reserved for states that need a second look — `⚠`, `✗`,
`⊘`, `⚑` — and a test asserts those were not stripped along with the rest.

## The badge guide is derived from the badge maps

The guide was titled "Comparison Summary — Badge Guide" and scoped to that one
table. But `badgeBom` and `badgeAbom` are used **only** by `renderFullBom`, so
the raw BOM vocabulary never reached the guide at all — which is why the
catch-all badge and the Change Pedigree `NO MATCH` had no explanation anywhere
in the product. It was not that entries had gone stale; every existing entry
checked out. Whole surfaces were missing.

v155 retitles it "Detailed View — Badge Guide" and adds sections for the raw
BOM views, the Change Pedigree view, and the `? UNKNOWN` fallback that appears
when the engine returns a status the badge maps do not know.

Tier 10 derives the expected entries from `badgeBom` / `badgeAbom` /
`badgeOverall` and from `chpReleaseState`, so adding a badge without
documenting it fails the build by name. A documented entry may be a *more*
informative form of the emitted label — the badge renders
`RELEASED MARCH 15, 2024`, the guide writes `RELEASED ⟨date⟩` — so matching
allows that, while still failing when a state is absent.

## Documentation is under test too

The v149 explanation modal claimed the `↑ parent` marker carried "exactly two
styles, the same on both BOM sides." Three shipped on the MBOM side: the
orthogonal `nhMismatchMbom` flag was tested *before* the covered/collector
branches, so a covered row with an NH mismatch rendered `hl-parentage`.

v155 collapsed the marker to one muted-italic style on both sides and derives
the class from what is actually rendered, which removes the precedence trap
rather than documenting it. The covered-vs-collector distinction was never lost
— it is stated in words by the Reconciliation badge on the same row.

Two Tier 7 tests now assert the modal text against the code. Prose that
describes behaviour is as capable of drifting as a duplicated constant, and
harder to notice when it does.

## Two vocabularies live in both files

The main build owns them; the delta tool re-states them. Nothing enforced
agreement until v154, and a divergence is silent in both cases:

- **`PROC_CODE_BASELINE`** — if the main build gains a code and the delta copy
  does not, the delta tool reports two sessions as agreeing on proc codes when
  they do not.
- **The mode vocabulary.** The main build's `getModeRequired` table names four
  modes; the delta tool re-states it as `mode !== 'ebom_abom'` and
  `mode !== 'ebom_mbom'`. Add a fifth mode and the delta tool reports a full set
  of zeroed MBOM KPIs for it, as though everything failed. The test reads the
  main build's table and checks both predicates against every mode in it.

A session with no `mode` recorded fails open — both sides are reported. That is
pinned by a test so the behaviour is a decision rather than an accident.

## Two guards worth keeping

- **Brace balance**, as above — now an assertion against zero rather than a
  magic number, and it names the line.
- **Version literal check** fails if a version string appears anywhere in the UI
  chrome. The header pill was stale for 33 releases before this existed.

## Not covered

- **`timestamp` is deliberately excluded from the claim signature.** It moves
  on every re-save and would mark every claim as modified. The main build's
  certificate hash **does** include it, so two sessions can differ by cert hash
  while the delta tool reports the claims as unchanged. That is a judgement
  call worth revisiting, not a defect. From v178 the rule is explicit: the
  delta signature is the certificate hash's claim projection minus `id` and
  `timestamp`, and Tier 4b derives it.
- **The streaming reader's browser plumbing** — `FileReader`, `file.stream()`,
  `TextDecoder` and `_readSessionPayload` — runs only under `--browser`, which
  opens sessions in the delta tool with the large-file threshold lowered to
  1 KB. A multi-byte character split between raw file chunks is still not
  constructed deliberately.
- **Export menu counts** are now derived from the build rather than pinned to
  13, so adding an export is not a failure — leaving one unwired is.

- **The sheet builders** — `buildSummaryRows`,
  `buildProgress`, `gatedSection`, `exportXlsx`. Tiers 4 and 6 cover the
  comparison and assembly layers; the final formatting into worksheets is
  still untested.
- **`inScopeSet`, `fscope` and `computeKpis` read `session.results` unguarded**,
  so a malformed session throws rather than returning a note the way the
  missing-file paths do. Treated as a documented precondition, not a defect —
  every real session carries `results`.

Without `--browser`, nothing in the UI layer is covered: no DOM rendering, no
click paths, no Excel file is opened and inspected. With it, the main path is —
load, run, claim, export, freeze, re-import, delta — but not every card, modal
or report.
