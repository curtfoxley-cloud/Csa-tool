# Comparator test harness

**One file: `comparator-tests.js`.** Node only — no install, no network, no
other files. 628 tests. A further 41 browser tests run with `--browser`, and 57
comparisons against a previous build run with `--reference=`.

```bash
node comparator-tests.js                          # finds the newest ./comparator_offline*.html
                                                  # and the newest ./comparator_delta_v*.html beside it
node comparator-tests.js path/to/build.html       # or point it anywhere
node comparator-tests.js --browser                # also drive both tools in a real browser (below)
node comparator-tests.js --reference=old/comparator_offline83.html   # v188 is ..._offline84.html
                                                  # compare every default output with a previous build (below)
```

Re-run after any change to the build, the delta tool or the user guide.

### Optional companions it reads when they sit beside it

- `HARNESS.md` — this file. Its headline count and coverage table are checked.
- `Comparator_User_Guide.md` — the user guide's source. Checked against the
  build (suite "User guide agrees with the build"). `build_guide.py` turns it
  into the .docx; it needs pandoc and nothing else.

Neither is required. If one is absent, the checks that read it say so and pass.

### The browser suite (`--browser`)

Needs Playwright, which is the one thing this harness does not carry:

```bash
npm install playwright                   # once, in this folder or globally
npx playwright install chromium          # once, unless you point it at a browser you have:
COMPARATOR_BROWSER="C:/Program Files/Google/Chrome/Application/chrome.exe" node comparator-tests.js --browser
```

Asked for and unavailable is a **failure**, not a skip. A run that was meant to
exercise the product must not come back green without having done so.

The harness picks the **newest** delta file by version number, so leaving
`comparator_delta_v3_6.html` beside `v3_7` is harmless to the run — but remove
stale copies from the Project so nobody opens the wrong one.

### The reference suite (`--reference=`)

Also needs Playwright. Give it the previous build, kept under another name or
in another folder (builds up to v187 were all called `comparator_offline83.html`;
from v188 the file is `comparator_offline84.html`, and the harness picks the
highest-numbered file in a folder, so a previous build beside it would be
skipped rather than compared). It runs one program through both
builds with every setting at its default and compares every output a user can
take away: the results, the rendered Comparison Summary and Change Pedigree
tab, the Excel, CSV and HTML exports, the CI Traceability Report and As-Built
Records Guide, both ECN reports, the context export, the session file, the
certificate's hash payload, and every certificate-bearing export after
freezing. From v186 the fixture also loads an NCR file and an RFV file, and the
CI tab, the RFV tab and the RFV Traceability Report are compared too. Time stamps, the build number and the hash itself are masked;
nothing else is. Any difference fails, and the failure shows both texts at the
first character that differs.

Use it whenever a build promises "no change for programs on the default". The
fixture exercises every Change Pedigree join the build makes, including the two
v181 disagreements kept on purpose (see v182 below).

## Why one file

Comparator ships as a single self-contained HTML, and this follows suit so it
can live in a Project beside it. A split-file version was lost between sessions,
taking 72 tests with it — the whole point of this format is that it survives.

## How it works

The build's testable functions are lifted out of the HTML by marker, then run in
a per-suite sandbox that stubs the browser globals they touch (`document`,
`state`, `COL`, `XLSX`). Each suite gets its own sandbox because the modules
expect different `COL` shapes.

If a marker moves, extraction **fails loudly and names it, and no tests run at
all** — the build was refactored and the marker needs updating. That is
deliberate: an empty module would let every suite pass while testing nothing.

This was only half-true before v154. Four boundary lookups used raw `indexOf`,
which returns `-1` on a miss and turns into a zero-length slice. Pointed at a
build where one marker had been renamed, the old harness printed
**"21 passed, 5 failed"** — a believable summary. In fact 33 tests never
executed, because a crashed suite costs exactly one reported failure no matter
how many tests it contained. Every boundary now goes through `at()` / `lastAt()`
/ `span()`, and `span()` refuses a slice that is inverted or implausibly small.

`EXPECTED_TESTS` is the backstop: if the number of tests that actually ran is
not the number expected, the run fails and says so. **Bump it when you add
tests** — that is deliberate friction, because a silently shrinking suite is the
failure mode this harness is most vulnerable to.

## Coverage

| Suite | Tests | Covers |
|---|---|---|
| Engine — tagging changes reconciliation output | 9 | **Core correctness.** Tagging a proc code actually changes `buildAbomMap` output; swap-as-add second pass; founding program unaffected; worker table in lockstep |
| Proc code panel — job number samples | 16 | Job-number sampling, dedup, HTML escaping, Mapping 2 (where the old description column was always blank) |
| Tier 1 — proc code profile name is provenance | 13 | **Regression guards for two v153 defects.** Cancel on the profile-name prompt; profile name surviving a session round-trip; the name/override split |
| Tier 2 — EBOM indenture map (the real one) | 11 | **The real `buildEbomIndentureMap`,** not a stand-in. Parent/child linking, shared PN under two NHs, self-referencing rows, first-occurrence rules |
| Tier 2 — extraction integrity | 13 | **The harness's own safety net.** Module contracts, marker guards, worker-bundle closure, build is still self-contained, HARNESS.md headline count |
| Tier 3 — CHP release state | 19 | Badge states, latest-DCN selection, undated-DCN warning, and **timezone-stable release dates** |
| Tier 3 — proc table under lock, bad input, and session reuse | 14 | Lock behaviour, hand-edited profile files, provenance leaks between loads, stale-results flag |
| Tier 4 — delta tool | 29 | **Baseline drift between the two shipped files**, proc table diffing, claim change detection, indenture scope, label agreement with the main build |
| Tier 6 — delta tool report assembly | 30 | Two-pass EBOM matcher, KPI counters, NCR disposition diff, **mode vocabulary drift**, pre-rename CHP sessions; **v3.6:** a Disposition Code change is reported with the old code, case and spaces are not a change, a status and code change together is one row, the Summary counts code changes |
| Tier 7 — Detailed View markers and raw-BOM badges | 15 | The single `↑ parent` marker style, the neutral catch-all badge, part-type exclusions, **and the explanation modal matching the code** |
| Tier 8 — CI Traceability Report columns | 18 | Header/row width parity across every sheet, plus the v155 column removals and renames |
| Tier 9 — MBOM column order across every surface | 8 | Job Number's position pinned across all four surfaces, header and row builder together |
| Tier 10 — badge guide completeness | 16 | Guide entries derived from the badge maps, so a new badge cannot ship undocumented; one text source for guide and tooltips |
| Tier 11 — dashboard charts and NCR lists | 13 | **Runs** the dashboard's chart renderers. **v185:** the WO status roll-up is an HTML strip and list: one row per status, segment widths are the counts, RFV-authorized WOs their own share, a caption when there is no data; **v186:** the NCR by disposition code list counts every non-cancelled entry in both pools by trimmed, upper-cased code, lists every code with UNSPECIFIED last, escapes codes; **v188:** the NCR by cause code list does the same with each code's first description, both lists share one counter and one markup and their totals agree, the row is three across down to 900px, and nothing on the page draws to a canvas (the canvas crispness tests went with the last canvas) |
| Tier 12 — colour tokens | 40 | Nothing bypasses the palette; **three palettes** (dark / light / Black & White) complete, distinct and legible; mono fills and outlines; the exported report's own palette; the theme kept out of the session and the hash; canvas colours equal token values; **v188:** a palette change needs no redraw: no chart writes a resolved colour into its markup; **v180:** two text tiers only, both 4.5:1 on page and panel in every theme; text on coverage fills 4.5:1; reference bars visible; no faded funnel text; one disabled-opacity token and no other literal opacity; the exported report writes the type scale; **v181:** ladder counts coloured only by the two dedicated funnel count tokens, each checked against the background it lands on; hover does not change a fill; bar length comes from --pct |
| Tier 13 — summary table type scale | 12 | One cell size, header smaller, badges matched; plus a **syntax check of every inline script block** |
| Tier 14 — Detailed View table structure | 12 | All eight table views wired identically; captions outside the scroll container; row selection; uniform pagination |
| Tier 15 — reconciliation engine | 24 | **The engine itself**: three passes, quantity shortfall, proc codes, scope exclusions, the worst-leg rollup |
| Tier 16 — effective results and the duplicated rollup | 14 | **The duplicated rollup**, compared exhaustively against the engine's; claim overlay behaviour |
| Tier 17 — session restore | 11 | Exporter/importer field parity, the frozen flag, pre-v153 sessions, malformed payloads |
| Tier 18 — indenture scope and normalisation | 16 | The configurable collector rule and numeric→alpha indenture normalisation |
| Tier 19 — ME adjudication import | 39 | PN→position resolution, deficient-leg claims, the narrative scanner, scoped re-import, provenance values derived from the build |
| NCR dispositions without EBOM trace — one row per disposition | 12 | Export grain is **one row per disposition**, not per file row; merged values joined not dropped |
| ECN footprint completeness | 7 | CHP-listed items that never joined to an EBOM row |
| Many EBOM line items to one ECN | 6 | Many EBOM line items → one ECN; one bad item excludes the whole ECN |
| Stylesheet and chrome integrity | 66 | Brace balance **located by line**; orphan keyframes; undefined CSS vars; ME ADJ zone placement; workbench blocks; funnel legend and **residual measured and rendered**; open-WO colour; mapping modal; Job Number search; RFV rules; filter-count scoping; Claim Ledger naming; uniform upload zones; export-menu wiring; **v185:** no summary search box carries its own border colour; per-leg reference bars drawn as a share of Active Scope |
| Tier 20 — provenance: version, certificate and claims | 17 | **v178/v179.** Session and certificate stamped from `APP_VERSION`; one certificate definition for Excel, CSV and HTML; the hash covers every field a claim is written with (derived); claim-source labels; every column map saved, restored and reset; one Proc Removed glyph |
| Tier 4b — delta tool follows the main build | 25 | **Delta v3.4.** Identical streaming reader; claim signature derived from the certificate hash; Origin column; honest tool-version labels; one `DELTA_VERSION`; KPI rows named and counted as the dashboard; purple kept for human decisions; palette equal to the main build's; **v3.5:** Change Pedigree Alignment named in the main build's words, absent means default, nothing added for two default sessions, a caveat and Via Drawing column when the rules differ; **v3.6:** two Disposition Codes are the same in the delta exactly when the dashboard card counts them as one |
| Visual grammar and type scale | 6 | Metric bar stays gone; component primitives exist; jump links are text; **v180:** a four-step type scale with an 11px floor; every size under 14px comes from the scale (one named exception, the render-error banner); every size token resolves at or above the floor |
| User guide agrees with the build | 8 | **v179.** The guide's source against the build: version stamps, delta version, every badge and status label, theme names, section references and numbering, the certificate description, a history row for this build |
| Version single-source | 4 | Single-source version string; guards the header pill against drift |
| Tier 22 — Change Pedigree Alignment | 32 | **v182.** No code outside the module reads the CHP join columns (and the guard catches a planted read); every former join site calls it; each site's v181 rule reproduced, including KI-1 and KI-2, the Change Pedigree tab search and its column headings; the drawing rule: every line on a drawing, exact match, no part-number fallback, revision matching, merged duplicates, Mapping 2 read from raw, run blocked in words; the badges; the plan on both engine paths; session, hash and certificate carry the rule only when it is not the default; Reset, freeze lock, stale results, freeze refused after a change |
| Tier 23 — ACN columns in the Comparison Summary | 9 | **v183/v184.** ACN Level, ACN Record Number and ACN Record Revision: the part-number join the ACN cards use, one entry per distinct level + record + revision, the three cells aligned; right of CHP History in the Detailed View, the Excel export (one header and row builder shared by its three sheets) and the context export; CSV and HTML report pinned unchanged |
| Tier 24 — CI and RFV column mapping | 12 | **v186.** The CI and RFV zones carry the NCR/ACN Default / Manual control and do not open the file picker; the fields are `COL.ci` and `COL.rfv` in order (CI all required, RFV only the RFV Number); Apply stores indexes and keeps default positions for blank optional fields; missing and duplicate columns refused; a loaded file is re-read at once, rows filtered on the mapped identity column and the zone count updated; Default re-reads as uploaded; upload and re-read share the same lines; the window's wording per source, NCR's unchanged; frozen reports refuse; session written only when set, restored and cleared on Reset; the column mapping reference |
| Tier 25 — headings over re-laid rows | 7 | **v187.** Rows as uploaded keep the file's header row (the same array) for every source; every manual map and EBOM/ABOM Mapping 2 count as re-laid, WO5 never (the set derived from `state`); every COL position of every mappable source is headed by its mapping-window label and an empty position by —; the export heading row spans the widest row; the three tabs and the raw-sheet loop go through the one helper and nothing else reads `bom.header[i]` except the WO5 tab; all three mapping windows share `.map-col-input`, wide enough for "DEFAULT: AAA" |
| Tier 26 — delta tool EBOM to EBOM | 13 | **Delta v3.7.** The map builders, `normIndenture` and the column-letter helpers are the main build's, character for character; `EBOM_COL` and the field list are `COL.ebom` and `_ebomFieldDefs()`; the upload (filter and re-lay) equals the main build's `_reparseBomFromRaw` under Mapping 1, Mapping 2 and a Manual map; typed letters give the main build's Manual map and its refusals word for word; a line item is merged as the engine merges it; each compared field reported, Comparator's spellings of the same value not; re-parenting one to one; change order and line numbers; the Summary; the page's two modes and controls |
| Tier 21 — streaming session reader | 10 | **The hand-written JSON parser large sessions go through**, against `JSON.parse`, at chunk sizes down to 1 character; truncated files rejected |
| HARNESS.md describes this run | 2 | This table: every suite by exact name with the count it ran |
| Browser — the product actually runs | 41 | **v179, `--browser` only.** Loads four Excel files built in the page, runs a comparison through the real worker, checks the engine's verdicts and a dashboard card, processes a claim, exports and re-reads the session, freezes, opens the Excel, CI report, CSV and HTML files it wrote, re-imports the frozen session, and compares two sessions in the delta tool, including through the streaming route; **v181:** measures every funnel bar count at four window widths and three themes, and checks bar lengths and count placement after a real run and a resize with nothing forced; **v182:** a default run writes no alignment row or field; a drawing + ECR program end to end: loads by drawing number, re-reads on a rule change, blocked until the column is chosen, ECRs on every line of a drawing, panel match summary, CHP tab, Excel export, ECN reports refused, revision matching, session, certificate, reopen, Reset, and the delta tool naming both rules; **v183/v184:** the three ACN columns right of CHP History on screen and in all three Excel sheets and the context export; **v186:** CI and RFV files in their own layouts mapped through the real Manual window, re-laid and counted on the CI cards with no file picker opened; the Disposition Code card counts what the run's entries say, three across at 1440px, cause chart full width at 1200px, stacked at 800px, nothing scrolling sideways; both maps in the session, cleared by Reset, back on import; **v187:** a re-laid NCR file headed by field name on its tab and in its raw sheet (with the inserted qty column), the CI raw sheet the same, an EBOM in its own layout keeping its headings, and the mapping box's placeholder measured against the box; **Delta v3.7:** two EBOM files written to disk, one in Mapping 2 and one through a Manual map typed into the delta tool, compared: each change type once, on screen and in both sheets, and the line-item count the same as Comparator's for the same file |
| Reference — default output matches a reference build | 57 | **v182, `--reference=` only.** Every output a user can take away, from the same files, compared with a previous build at default settings: 56 outputs plus a page-error check. v182 against v181: all identical. v186 against v185, with NCR and RFV files added to the fixture: all identical |

The table is checked. Suite names must match the harness output exactly, and
each count must be what that suite ran. The browser suite is listed but is
only compared when `--browser` is given. Add or remove a test and this table,
the headline count and `EXPECTED_TESTS` all have to move together.

## Delta v3.7 — EBOM to EBOM

The owner asked whether the Delta tool could compare EBOM to EBOM at just the
EBOM level. It could only partly: its EBOM Changes sheet needs two full
Comparator sessions in the same mode, reads reconciled lines (REF lines drop
out), and compares part number, next higher and quantity only. The owner chose
by poll: load two EBOM Excel files; also compare indenture, drawing PL rev and
quantity text; merge duplicates as Comparator does; show the result on screen
and in Excel.

- **A second mode**, "Two EBOM files", beside "Two sessions". The sessions
  report is unchanged; its controls moved into a pane and kept their ids.
- **One meaning of "line item".** The EBOM is read by Comparator's rules, and
  the harness checks each rule against the main build rather than restating
  it: the four map builders and `normIndenture` are verbatim copies (Tier 26
  compares the source text), the upload's filter and re-lay is run beside the
  main build's `_reparseBomFromRaw` for all three mappings, the Manual map's
  rules beside `_saveEbomManualMap`, and the browser check loads the same file
  into Comparator and compares the line-item count. Merging follows the
  Comparison Summary: quantities summed, last quantity text, first indenture
  and drawing PL rev, every line number.
- **What is a change.** Quantity, quantity text, indenture and drawing PL rev,
  on lines matched by part number + next higher; re-parenting by part number
  alone, one to one in file order, as the session delta does. Values
  Comparator reads as the same are not changes: case and spaces, 3 for C, "ar"
  for AR. Description is shown, not compared (not chosen).
- **Seen on screen** at 1440 and 800px. The 16-column changes table pushed the
  page 450px wider than the window, so every delta table now sits in its own
  sideways scroller (the sessions report's tables too).

Tests: Tier 26 (13) is new; browser +3 (38 to 41). Planted defects caught: a
later drawing PL rev overwriting the first, quantity text compared case-
sensitively, Mapping 2 reading the next higher from the wrong column, and
re-parenting switched off. The main build did not change (v188).

## v188 — NCR by cause code as a count list; file renamed

The owner asked for the cause code bar chart to become a count list like NCR
by disposition code, and for the file to be named `comparator_offline84.html`.

- **The list.** One counter, `_ncrEntryCodeCounts`, now serves both lists, and
  one markup builder, `_ncrCodeListHtml`. The cause list keeps the chart's
  population exactly (pool 1 + pool 2, no dedup between pools, CANCELLED left
  out) and changes three things the owner's "similar to the disposition code"
  implies: every code is listed, not a top 6; codes are grouped trimmed and
  upper-cased, where the chart grouped the raw "code: description" label; and
  a blank code is UNSPECIFIED, always last. Where one code carries more than
  one description, the first one found is shown on its line.
- **The row.** Three lists need no width to stay legible, so the v186 fold
  (the chart taking a row of its own below 1400px) is gone: three across down
  to 900px, stacked below. Checked on screen at 1920, 1440, 1280, 1024, 920 and
  800px in all three themes, with a 58-character disposition code.
- **The canvas machinery went with the last canvas.** `setupHiDpiCanvas`,
  `registerChartRedraw`, `redrawAllCharts`, `_crisp`, `drawNcrCauseCodeChart`,
  the hidden disposition-status canvas and the `.chart-card canvas` rule are
  deleted, as v176 deleted `drawBarChart`. `tok()` stays: the exported report's
  palette and the RFV views read resolved colours.
- **A defect found doing it.** The NCR disposition status list wrote resolved
  hex colours (`tok()`) into its markup, and nothing re-rendered it on a theme
  change, so it kept the old theme's colours until the next run. It now writes
  `var(--…)`. The Tier 12 test that required charts to redraw on a palette
  change now requires the opposite: no chart renderer writes a resolved colour.

Tests: Tier 11 renamed "dashboard charts and NCR lists", 20 to 13. Ten canvas
tests (buffer parity, reflow, pixel snapping, the chart-text floor and the
renderer smoke test) went with the canvas; four cause-list tests and one guard
that no canvas returns came in. Tier 12's redraw test rewritten (count
unchanged). The browser check reads both lists and finds no canvas, and expects
three across at 1200px. Planted defects caught: a resolved colour back in the
status list, a later description overwriting the first, a canvas put back.
The reference suite against v187 found every output identical. The Delta tool
is unchanged (v3.6): the cause code counts are a dashboard view of data the
sessions already carried.

## v187 — headings that match the data; a readable mapping box

The owner asked for the two issues v186 reported to be fixed.

1. **Headings over re-laid rows (KI-3, KI-4).** A manual map, or Mapping 2,
   re-lays each row into the default COL positions at upload, but five
   surfaces printed the file's own header row over those rows: the Change
   Pedigree tab (KI-3, fixed only under the drawing rule in v182), the Excel
   export's raw sheets (KI-4), and the EBOM / MBOM / ABOM and NCR tabs, which
   had the same defect and had not been recorded. All five now ask one helper,
   `sourceHeaderLabel` / `sourceHeaderRow`. Over re-laid rows a column is
   headed by its mapping-window label, and a position no field uses by —
   rather than a column letter, which would read as a column of the user's
   file. Over rows as uploaded the helper returns the file's header row
   itself, so nothing changes for a file in its own layout; WO5 has no
   mapping and keeps its own code. "Re-laid" is read from the mapping state,
   which the session restores with the rows it produced.
2. **The mapping box.** The column-letter input in all three mapping windows
   was 90px and clipped its own placeholder ("DEFAULT: B…"). The three
   identical inline styles are now one class, `.map-col-input`, 12ch + 20px
   wide in the mono face.

Tests: Tier 25 (7) is new; Tier 22's CHP heading test now expects field names
under a manual map with either rule; browser +1 (37 to 38), which measures the
placeholder's drawn width against the box. Both old defects were planted back
and caught: the raw-sheet loop reading `bom.header` (two tests), and a 90px
box (two tests, the browser one reporting 85.8px needed in 72px). The
reference suite against v186 found every default output identical. The Delta
tool is unchanged (v3.6): it reads session data, not headings.

## v186 — Disposition Code card; CI and RFV manual column mapping

The owner asked for two changes, and for any knock-on changes in the other
files.

1. **NCR by disposition code.** A new card that counts NCR entries for each
   Disposition Code (NCR column BZ under the default map). The owner settled
   four questions by poll before work began: count disposition entries (the
   cause code chart's population), show a count list, sit three across with
   the two NCR charts, display only. It is HTML, like the v185 WO strip, so it
   follows the theme through the tokens and needs no redraw.
   - **Same population as the cause chart**: pool 1 + pool 2 entries, no
     dedup between pools, CANCELLED left out. The two totals agree, and Tier 11
     checks that by summing the cause chart's own drawn values.
   - **Every code is listed**, not a top 6. Codes are grouped trimmed and
     upper-cased. A blank code is UNSPECIFIED and is always last.
   - **Layout, checked on screen** at 1920, 1440, 1280, 1024 and 800px in all
     three themes. Three across at full width, the chart in the widest
     column. Below 1400px the chart takes the full row and the two lists share
     the next one; below 900px everything stacks. Two defects the screenshots
     found and fixed before shipping: at full row width the cause chart's
     canvas (height:auto) scaled to 555px tall, so in this row it now has a
     fixed 240px height; and a count pinned to the far edge of a wide card was
     hard to read across, so the list is two content-width columns.
2. **CI and RFV manual column mapping.** Both zones gain the Default /
   Manual… control NCR and ACN already have, and use the same window and the
   same remap-at-ingest code (`_applySuppManualMap`). CI requires all three of
   its fields. RFV requires only the RFV Number: a variance can reach a line by
   any of its three keys (P1 PN + NH, P2 disposition number, P3 work order), so
   none of them alone can be required. The row filter at upload and re-read
   uses the mapped identity column. The maps are written to the session only
   when set, so a default session file is v185's, byte for byte.

**The Delta tool, v3.6.** The new card makes Disposition Code a dashboard
figure. The delta exists to explain what moved between two sessions, and its
NCR Disposition Delta reported status changes only, so a code that moved was
invisible. It now reports a **Disposition code changed** row, an **Old
Disposition Code** column, and the count on the Summary. "The same code" means
what the card means: trimmed, case ignored. The CI and RFV maps need nothing in
the delta tool: sessions store data already re-laid into the default
positions, and the delta tool reads neither CI nor RFV data.

**Not changed, found while building (KI-4).** With the "include raw sheets"
box ticked, the Excel export writes each source file's own header row above
its re-laid rows, so under any manual map the headings sit over the wrong
columns. This is the KI-3 defect on a different surface, and it affects every
manual map (EBOM, MBOM, ABOM, CHP, NCR, ACN), not only the two new ones. Left
as it is for the owner's call. **Fixed in v187.**

Tests: Tier 11 +5 (15 to 20), Tier 6 +4 (26 to 30), Tier 4b +1 (24 to 25), a
new Tier 24 with 12, browser +3 (34 to 37). The reference fixture gained an NCR
file and an RFV file and three outputs (the CI tab, the RFV tab and the RFV
Traceability Report's four sheets), 51 to 57; against v185, every output is
identical. Planted defects, one at a time, each caught by a named test: the CI
remap dropped from the re-read path, UNSPECIFIED sorted by count, cancelled
entries counted, the delta dropping code changes, the delta comparing codes
case-sensitively, an empty CI map written to the session, and the narrow-window
rule removed. No independent review agent was run for this build.

## v185 — Three display fixes

The owner asked for three changes. None changes a result, export or report.

1. **Funnel reference bars.** Under "Reference — full per-leg KPI totals", the
   Part Qty Mismatch and Part WO Not Closed bars were drawn full width. They
   are now drawn as a share of Active Scope, and the count reads "N · P% of
   scope". A share under 1% reads "<1%". Total EBOM and Active Scope are
   unchanged.
2. **Search boxes.** The NCR Disp # box lost its red outline. The RFV # box
   lost its teal outline, for the same reason. Every Comparison Summary search
   box now has the same look.
3. **WO status roll-up.** The canvas bar chart is gone. In its place: one thin
   strip split by share of work orders, and a list beneath it with status,
   count, percent and the RFV-authorized count on each non-closed status. It
   is HTML, so it follows the theme through the colour tokens and needs no
   redraw on resize.

Tests: Tier 11 lost the WO roll-up pixel-snapping test and gained four for the
strip and list (14 to 15). Stylesheet and chrome integrity gained two (64 to
66). The reference suite against v184 found every output identical.

## v184 — ACN Record Revision

The owner asked for the ACN record revision beside the record number. It is a
third column, `ACN Record Revision`, right of `ACN Record Number`, on the same
surfaces as v183. An ACN entry is now one distinct level + record + revision,
so a new revision of the same record is listed as its own entry. Tier 23 and
the two browser checks now expect three columns; no test was added. With no
ACN file loaded, the reference suite against v183 found every output
identical.

## v183 — ACN Level and ACN Record Number

The owner asked for two ACN columns to the right of CHP History, on screen and
in the Excel exports of the Comparison Summary. The ACN data was already read
and joined for the ACN cards; it was not shown per line.

- **The join is the cards' join**: ACN part number against the line's part
  number, after `normPN`. An ACN file has no next higher, so a part at several
  positions shows the same records at each. One entry per distinct level +
  record pair, in file order.
- **Surfaces**: the Detailed View (stacked, one entry per line), the Excel
  export's Comparison Summary, Issues Only and WO Status Not Closed sheets
  (one shared header and `buildRows`), and the context-search export. Several
  entries are joined with `; `, and a blank inside a list shows as `—` so the
  two cells still line up.
- **Not added to the CSV export or the HTML report.** They were not asked for.
  Tier 23 pins them unchanged, so adding them is a decision rather than drift.
- **Nothing else changes.** With no ACN file loaded the columns are absent,
  and the reference suite against v182 found every output identical.

Tier 23 checks the header and the row builder move together on each surface;
moving the Excel cells to the far side of WO Action fails it. Two browser
checks read the real table and the real workbooks.

## v182 — Change Pedigree Alignment

The owner has a few programs whose Change Pedigree extract carries only a
drawing number and an ECR on each row. For those programs the ECR belongs to a
drawing, and the drawing links it to EBOM line items. The rest of the programs
must see no change at all.

### Twelve joins, four rules

Before adding anything, the join had to live in one place. It did not. Twelve
places each worked out which CHP rows belong to an EBOM line:

| Site | v181 rule, kept |
|---|---|
| Engine trace (worker and fallback) | PN + NH, else part number alone |
| Drawing column: Detailed View and four exports | PN + NH exact, first non-blank drawing |
| Change Pedigree tab (NO MATCH) | PN + NH exact, trimmed but **case-sensitive** |
| CI Traceability detail | PN + NH, else part number alone |
| CI report, EBOM Drawings sheet | part number, filtered to the CI's next higher |
| CI report, Next-Higher sheet | part number alone |
| ECN completeness | part number alone |
| ECN report document lookup | PN + NH, else PN with a blank next higher |
| Upload and re-read filters | part number column filled in |

They now call one module, marked `CHANGE PEDIGREE ALIGNMENT`. Each call keeps
its own v181 rule exactly, including two disagreements that were **recorded,
not fixed**, because fixing them would change results for default programs:

- **KI-1.** A CHP row under a different next higher gives the EBOM line its
  history through the engine's part-number fallback, while the Change Pedigree
  tab marks the row NO MATCH and the Drawing column stays blank.
- **KI-2.** The Change Pedigree tab compares part numbers case-sensitively; the
  engine upper-cases. A lower-case CHP part number reads NO MATCH.
- **KI-3.** Under any CHP manual map, the Change Pedigree tab prints the file's
  own headings over the re-laid default columns, so they sit over the wrong
  data. Kept for the default rule; fixed under the drawing rule, whose extracts
  always need a manual map. **Fixed for both rules in v187.**

A Tier 22 guard fails if code outside the module reads `COL.chp.pn`, `.nh`,
`.docNo`, `.docRev` or the old hard-coded `cr[10]`, and a second test plants
such a read to prove the guard sees it.

### The proof for default programs: `--reference=`

A test that reads the source can say the rules look the same. It cannot say the
outputs are the same. The new reference suite runs one program through v181 and
v182 in a real browser and compares 50 outputs: the results, the rendered
Comparison Summary and Change Pedigree tab, every export and report, the
session file, the certificate's hash payload and every frozen export. The
fixture exercises every join above, KI-1 and KI-2 included. **All 50 are
identical.** Planting one change to a default rule (a part-number fallback in
the Drawing column) failed ten of them.

The certificate, the hash payload and the session file gain nothing for a
default program: each writes the rule only when it is not the default, and
`undefined` is dropped by `JSON.stringify`.

### The drawing rule

- **An ECR attaches to every EBOM line on its drawing.** The EBOM drawing
  number comes from a column picked in the panel, read from the file as
  uploaded (`bom.raw`), so Mapping 1, Mapping 2 and Manual are untouched. The
  raw rows must line up with the parsed EBOM row for row, or the run is refused
  rather than guessed.
- **Exact match after `normPN`**: trim and upper-case, nothing more. No fuzzy
  matching, no dash stripping. Optionally drawing number + revision.
- **No part-number fallback.** `buildChpTraceMapByDrawing` returns an empty
  `pnMap`, so the engine is unchanged and cannot fall back.
- **Results carry `chpVia`**, the drawing keys of each line. Its presence is
  what marks a result as computed under the drawing rule, so every consumer
  follows the rule the results were computed under, not the panel's current
  state. A default run never carries the field.
- **Two new History states**, `ECR ONLY` and `NO DRAWING`, through
  `chpHistoryState`, which is `chpReleaseState` for a default result.
- **Blocked in words**: no EBOM in the mode, no drawing column, no revision
  column in revision mode, or a CHP map without Drawing Number and ECR.
- **Under this rule a blank CHP manual-map field stays empty.** The v120
  fallback to default positions would have read a DCN or ECN from whatever
  column sat there.
- **ECN reports** say *Not available* when the extract has no ECNs. With ECNs
  the footprint and its completeness check are by drawing.
- **Freeze** is refused when the rule changed after the run, or when an
  imported session's rule does not match its results.
- **Reset** returns the rule to the default (unlike indenture scope).

### Headless Chromium drops downloads

Measured while writing these tests: in headless Chromium, about one download
in ten never fires a download event, then the next succeeds. The existing
browser checks read files through the download event and have not tripped it.
The v182 checks and the reference suite read each file at the `Blob` the page
hands the browser instead, which is the same bytes without the dropped event.

### Checked by breaking it

Ten planted defects, one at a time, each caught by a named Tier 22 test: a
part-number fallback in the Drawing column, an upper-cased CHP tab, a
part-number fallback under the drawing rule, fuzzy drawing matching, results
stamped after the raw snapshot, a default session writing the field, ECR ONLY
despite an ECN, Reset keeping the rule, a certificate row printed for the
default, and the document lookup losing its blank-NH fallback.

No independent review agent was run for this build. The reference comparison
and the planted defects stand in for it.

## v181 — the counts on the funnel bars

The owner sent a photo: on the Direct, Used-On and Ancestor bars, the counts
on 19% and 30% bars were grey on green and could not be read. The 57% bar was
fine.

### Why v180 missed it

The count had two colours, chosen by the bar's percentage: at 40% and above
`--on-fill` (dark ink in the dark theme), and from 18% to 39% a `.light`
modifier that used `--text-muted` — the app's general secondary grey, about
1.1:1 on the dark theme's green. v180's test checked the base rule only. The
modifier existed because a short bar may be too narrow to hold its count, so
the count spills onto the dark track, where dark ink would fail. But a fixed
percentage cannot tell: a 19% bar holds its count at 1920px and not at 1440px.
And at 1024px the old layout clipped the count's first digit ("9%" for "19%").

### The fix

- **Two dedicated tokens, one per background.** `--funnel-count-ink` for a
  count on the fill (dark on the dark theme's greens; white on the light and
  Black & White themes' darker fills), and `--funnel-count-track` for a count
  beside a short bar, on the empty track. Nothing else uses either one, so
  they can be retuned without moving any other text. They replace `--on-fill`,
  which only this count used, and the use of `--text-muted` here.
- **Placement is measured, not guessed.** The count now sits in the track, not
  inside the fill. `placeFunnelCounts()` puts it at the end of the bar when it
  fits (with 8px each side) and just past the end when it does not. A
  ResizeObserver re-runs it when a track changes size — window resize, or a
  panel shown after being hidden.
- **Hover is an outline.** `brightness(1.18)` on hover lifted the light
  theme's fills enough to pull a white count under 4.5:1.

### Tests

Written first, each confirmed failing on v180:

- *A ladder count is coloured by the two funnel count tokens and nothing else*
  — every colour rule on the count, including modifiers; the two tokens colour
  nothing else. It names the photographed defect: `var(--text-muted)`.
- *Text drawn on a coverage fill clears 4.5:1* — now also checks the track
  token against the track.
- *Hovering a ladder bar does not change its fill colour.*
- **Browser:** *every funnel bar count is readable where it lands* — at 1024,
  1440 and 1920px, in all three themes, with bars forced to 19%, 30%, 57% and
  100% and a realistic count: the count sits wholly on the fill or wholly on
  the track, is not clipped, and clears 4.5:1 against what is actually behind
  it. On v180 it found 54 failures.

### What the independent review caught

No defect in what users see, but two regressions the tests could not detect,
plus one older limit:

- **Bar length.** It moved from an inline width to a CSS rule
  (`width: var(--pct)`). Deleting that rule drew every ladder bar at zero
  length and passed all tests, because the browser test sets widths itself. A
  Node test now requires the rule and the markup that feeds it.
- **The first placement runs blind.** The funnel is drawn while the results
  are still hidden, so the first measurement sees 0px tracks; only the
  ResizeObserver puts the counts right once they appear. Disabling it passed
  all tests. A new browser test forces nothing and calls nothing: after a real
  run, then after a window resize, every bar must be its `--pct` length and
  every count must be where it fits, and visible if it has room anywhere.
- **Very narrow windows** (below about 900px, where the page stops
  shrinking). A count could fit neither on nor beside its bar and was clipped,
  as it was in v180. It is now hidden instead (the bar's tooltip carries the
  same figures), and placement re-runs for printing.

Both regressions were confirmed caught by reintroducing them.

Two palette rules gained a narrow allowance: the dark palette's "no two tokens
share a value" rule names the two count tokens as deliberate copies of `--bg`
and `--text`, and the collision rule now checks every pair in a group of three.

## v180 — one floor for type, one ladder for grey

The owner listed eight hard-to-read areas: the EBOM funnel's delta, pass and bar
labels; the Proc Code Behavior and EBOM Indenture Scope panels; the restore-a-
session hint; "ranked non-closed WOs"; the Claim Ledger buttons; the Exports &
Reports menu; and the green adjudication banner. Measured in the running build,
all eight rendered at 8–10px, and several were also faded.

### The shared cause: there was no type scale

The stylesheet had about 630 font sizes. Seven used a token (`--fs-cell`,
`--fs-head`); the rest were literals, chosen one panel at a time. With no
floor, nothing stopped a new panel from arriving at 8px, and the eight areas
simply accumulated. Fixing them one by one would have made eight more literals.

v180 adds a four-step scale in `:root` and moves every size below 14px onto it:

| Token | Size | Replaces |
|---|---|---|
| `--fs-xs` | 11px | 8px, 9px — the floor |
| `--fs-sm` | 12px | 10px, 11px, 11.5px |
| `--fs-md` | 13px | 12px |
| `--fs-lg` | 14px | 13px |

`--fs-cell`, `--fs-head` and `--fs-badge` are now aliases onto the scale. The
render-error banner keeps a literal 13px on purpose: it must still draw when
the stylesheet's variables do not, and the test names it as the only
exception. The exported HTML report writes the scale into its own `:root`, as it
already did for colour.

Three tests hold the line: the scale has four steps and an 11px floor; no size
below 14px is a literal; every size token resolves at or above the floor. The
chart-text test now reads its floor from `--fs-xs` instead of a number of its
own. The old test that pinned "the 7 remaining 8px rules by name" was
protecting the defect, and is gone.

### The second cause: a third grey that could not be read

`--text-faint` measured 2.1:1 against the panel. A v156 test required it to sit
at least 40 luminance steps below `--text-muted` — that is, it required the
colour to be illegible. The token is retired in all three themes; its six CSS
uses and four canvas uses are now `--text-muted`. The replacement test says
what matters: **two text tiers, both at 4.5:1 or better on page and panel, in
dark, light and Black & White.** Light-theme muted text was darkened slightly
(`#56666f`) because it measured 4.49:1 on the banner tint.

Three related colour fixes in the funnel:

- **Text on a coloured bar** used `--bg`. That works on dark and fails on the
  light theme's pale greens. A new `--on-fill` token (dark: `var(--bg)`, light
  and mono: white) is the text colour for filled bars, and the light theme's
  success ramp was deepened so white counts clear 4.5:1.
- **Reference bars** (`--neutral-fill`) were 1.2–1.3:1 against their panel,
  so the "what EBOM expected" bar was nearly invisible. They now carry a 1px
  `--text-muted` edge; a test requires 3:1 for that edge (the WCAG graphics
  rule).
- **Opacity fades** on funnel text (the delta percentage at 0.75, among
  others) are gone; a test rejects `opacity` below 1 in any funnel text rule.

### Everything that dims for "inactive" uses one token

Disabled and inactive controls used 0.3, 0.4 and 0.5 opacity in 3 CSS rules and
19 script sites. All now use `--disabled-opacity` (0.5). A disabled control is
meant to look unavailable, so it is the one place text may fall below 4.5:1.

### What the independent review caught

The review found no defect in what shipped, but three gaps:

- **Four inactive controls** still wrote their own opacity in markup (0.3, 0.35,
  0.4), and **Comparison Summary pass-2 cells** were faded to 0.78–0.85 —
  measured at 3.97:1 in the light theme, below the minimum. The inactive ones
  now use the token; the fades are gone (the two text tiers carry emphasis).
  The test now rejects any literal opacity in app code except four named,
  non-text cases: Run-button hover, a pulse animation, the ⓘ glyph, and the
  funnel's coverage curve.
- **The export test could not fail.** It counted the type tokens as written
  without checking `exportPaletteCss()` wrote them. A new test runs the
  function and looks for each token in its output.
- **Sizes set from script** (`el.style.fontSize = '9px'`, or a canvas font
  outside the chart functions) slipped past the literal-size test. Both are now
  scanned across all app code; canvas sizes may be literal (canvas cannot read
  CSS variables) but not below 11px.

Each gap was confirmed by reintroducing the defect and watching the test fail.

Unavailable KPI cards (e.g. NCR cards before an NCR file is loaded) still dim
to `--disabled-opacity`, which takes their text to about 2.5:1. That is the
intended "not available" signal, and it is now a single dial.

### Knock-on changes the larger type forced

- **Letter-spacing** is two tokens: `--track-caps` (0.04em, for uppercase
  labels) and `--track-tight` (0.02em). 155 literals moved onto them. Wide
  tracking at the old small sizes would have pushed labels off their panels at
  the new ones.
- **Funnel label column** widened from 116px to `--funnel-label-w` (148px),
  shared by the stage, ladder and residual rows. "WO Not Closed (bare)" was
  clipping.
- **Claim Ledger** button padding and gap tightened (8px) so the whole ledger
  stays on one row at 1440px with claims applied.
- **Comparison Summary** grew wider, from 3419px to 4317px at 1440px, because
  its cells moved from 11px to 12px and its headers and badges from 9px to 11px.
  It already scrolls horizontally; this is the visible cost of one floor
  everywhere.

## v179 — running the product, and checking the guide

### Two more certificate copies

v178 found two Excel certificate sheets that had drifted and gave them one
definition. The test it added looked for Excel sheets named "Audit
Certificate", so it could not see that the **CSV** and **HTML** exports each
wrote their own certificate too. Those still printed auditor, date, mode and
hash only, without the build, proc code profile, codes or scope. The CSV copy
also did not escape quotes.

The Tier 20 test now searches for the certificate's title text, which every
copy has to print, and allows it in one place. Searching by what an artefact
must contain finds copies that searching by their names does not.

### The browser suite

HARNESS.md has said for several builds that "a test that reads or sandboxes the
source is not a test that runs the product". v160 to v163 could not run a
comparison at all while 397 tests passed. `--browser` now runs the product.

- **Fixtures are built in the page** with the build's own SheetJS, so the suite
  needs no files. The program is small but has one of each: structural apex and
  major assembly, a fully built part, a part under an open work order, a part
  never built, and a child whose parent is its used-on assembly.
- **Every download is read back from disk.** The Excel, CI report and CSV
  certificates are compared with `_auditCertRows` row by row. The HTML report is
  checked more loosely: every certificate value must appear in it, but not in a
  particular position.
- **Every comparison must have something to compare.** An independent review
  found that the open-work-order check compared 0 with 0: a processed claim had
  cleared the only open work order in the fixture. The claim moved to another
  part, and the test now fails if the count is zero.
- **The delta tool runs twice**: once as shipped, and once with its large-file
  threshold lowered to 1 KB, so the streaming reader runs in a real browser.

Run against v177 and delta v3.3 it fails where those builds were wrong: the
session stamp, the missing column map, then a crash where v178's certificate
function did not yet exist. Run with the v179 build and the v3.3 delta tool, it
fails all four delta checks.

Two of its first expectations were wrong, and the product was right. P100 is
also P101's next higher, so pass 2 finds it as a used-on parent and its overall
is `pn_as_usedon`, not `ok`. The HTML report prints the mode as "EBOM MBOM
ABOM" by design. The fix was to the tests, and each now says why.

### The guide has a source, and the source is checked

The user guide drifted for twenty builds. It carried a stale version stamp,
the wrong Proc Removed symbol, theme and colour names from before v173,
missing section numbers, and a chapter 3 section inside chapter 4. Nothing
compared the guide with the tool, and the Project held only the .docx, which
nothing can read reliably.

The guide now ships as `Comparator_User_Guide.md`, and `build_guide.py` makes
the .docx from it. The suite "User guide agrees with the build" checks it
against the build, deriving every expectation from the build itself:
`APP_VERSION`, `DELTA_VERSION`, `BADGE_HELP`, the theme menu's options and
`_auditCertRows`.

Pointed at the v176 guide's text, all eight tests fail, each on a defect that
guide really had. The chapter-placement check was added after that run showed
the numbering test alone missed the misplaced §3.6.

### The last small labels

Seven labels outside the funnel were raised from 8px to the 9px floor. They
were checked in before-and-after screenshots at real widths, and none
overflowed or clipped. The pinned list is now the seven funnel rules only.

## v178 — the drift audit

A drift audit of v177 against the delta tool, this harness, the test inventory
and the user guide found 35 places where the files disagreed. The reported
symptom was a session exported from v177 that the delta tool said came from
v142. Every fix in v178 and delta v3.4 has a guard here, and each guard was run
against the unfixed v177 files first and seen to fail there.

### The version stamp nobody could see

The header pill was moved to `APP_VERSION` at v153 because it had been stale
for 33 releases. The session exporter was not moved. `toolVersion` said `v83`
until v142 and `v142` from v142 to v177. The delta tool printed it faithfully.

The version guard read only the header markup, so it certified the one place
that was already fixed. Tier 20 now requires `APP_VERSION` to be the **only**
quoted version string anywhere in the code, and the certificate records the
build too, beside the hash rather than inside it.

The delta tool labels `v142` as "v142–v177 (exact build not recorded)" and
`v83` as "v83–v141 (exact build not recorded)". **That is correct and must not
be "fixed".** The information was never written, so it cannot be recovered.

### The claim schema outgrew both of its signatures

Claims gained fields at v84, v85, v87 and v162. Two hand-maintained lists were
supposed to track them: the certificate hash's per-claim projection and the
delta tool's `claimSig`. Both stopped growing. A CI-to-NCR trace moved to a
different CI hashed identically, because its `rowKey` is null and `ciKey` was
not hashed. The delta tool reported claims unchanged when their reason, their
second disposition or their WO target row had changed.

Both lists are now derived. Tier 20 reads every object literal that creates a
claim and requires each field to be hashed or listed in `HASH_EXEMPT` with a
reason. Tier 4b requires `claimSig` to compare every hashed field except `id`
and `timestamp`, and changes each field in turn to check that the claim is
reported as Modified.

### Two certificate sheets, drifting

`exportXLSX` and `exportCIReport` each built the Audit Certificate sheet
inline. The CI report's copy printed EBOM Indenture Scope twice and dropped the
removal and swap proc codes. A Tier 18 test counted **two** scope rows and
passed partly because of the duplicate. There is now one `_auditCertRows`,
and Tier 20 finds every `'Audit Certificate'` sheet in the build and requires
it to come from that function.

### A reader that could not open the file

The main build moved to chunked export at v142 and streaming import at v143.
The delta tool kept `readAsText`, so it could not open the largest sessions,
which belong to the largest programs. It now carries a verbatim copy of the
main build's reader, and Tier 4b fails if the copies differ.

The reader's own comment said it was verified by `session_stream_test.js`.
That file was lost like the split-file harness. Tier 21 now compares the
parser with `JSON.parse` across escapes, non-ASCII text and truncated input, at
chunk sizes down to one character; sabotaging the `\t` escape fails two of its
tests. It feeds text, not bytes, so a multi-byte character split between raw
file chunks (the browser's `TextDecoder`) is not covered — see Not covered.

### Three palettes, one set of names (v173–v175)

Tier 12 went from 7 tests to 31 when the build gained light and Black & White
themes. Every theme defines every token. No theme collapses two tokens onto
one value or borrows another theme's value. Body text stays legible in each.
Mono identifies findings by label, and only ✗ MISSING keeps a fill. The theme
is a view, not a record: it stays out of the session and the certificate hash.
Canvas colours are re-resolved on a palette change.

### v176 and v177

v176 deleted `drawBarChart`, unused since v47.1. "the deleted renderer stayed
deleted" pins it.

v177 was a visual refactor with no tests. It added component primitives,
removed the metric bars and turned the section links into text. Its own note
said all fourteen remaining 8px rules were in the funnel. **Only seven are.**
The v177 visual grammar suite pins the real list of 14 by selector: the list
may shrink as each is checked on a screen, and it may not grow. (*v180:* the list is now empty — no
size below 11px remains — and the pin is replaced by the type-scale tests.)

### Hand lists, again

Tier 19's "every native provenance value survives a replace" named seven
`createdFrom` values. The build has eight, and `missing_abom` was absent while
the test passed. It now derives the set from the build. The same audit found
`external_import` missing from the claim-source labels, so ME-imported claims
printed the raw code as their source in the CI report. Tier 20 now requires
every emitted `createdFrom` to have a label.

The first version of that test was itself a hand list in disguise: it looked
for quoted `createdFrom: '…'` values and the `_ADJ_CREATED_FROM` map, and so
missed `nh_mismatch_helper_paired` and `dash_suffix_helper_paired`, which the
helpers pick with a ternary into a variable before filing the paired MBOM
claim. An independent review of v178 caught it. `createdFromValues()` now also
reads any `*CreatedFrom = …` assignment, and both values have labels.

A hand list can only ever be as complete as the person writing it. In this
audit alone that was true of the native provenance list, the claim-source
labels, the certificate hash projection and the delta claim signature.

## Five defects these tests were written for

All five were live in v153. Four were fixed in v154; the delta tool's
`claimSig` defect was fixed in delta v3.2. Eight tests across Tiers 1
and 3 fail against a v153 build — that is the check that they are real guards
and not decoration. Run the suite against an old build occasionally to confirm
they still bite.

- **The release date was wrong east of Greenwich.** `formatDcnDate` read UTC
  components off a date built at *local* midnight, so a DCN released 15 March
  displayed as **MARCH 14** in Tokyo, Sydney and Kolkata. It reached the badge,
  the tooltip and the freeze certificate. Both the parser and the formatter now
  normalise date-only values to local midnight and read local components.
- **A profile name leaked between loads.** `setProcCodeMap` fell back to
  `|| state.procProfileName`, which no caller needed. Load "Program Falcon",
  then import an unnamed custom session, and the certificate still claimed
  Falcon. The argument is now the only source of the name.
- **The delta tool displayed a field it never compared.** `claimRow` prints
  `c.dispNo || c.ncrDispNo`; `claimSig` compared only `c.dispNo`. On
  `ebom_ncr_trace` claims — the ones the main build actually creates — the
  field is always `ncrDispNo`, so a changed NCR disposition number was declared
  unchanged and omitted from the Claims sheet entirely. `applied` had the same
  problem. The rule now under test: **every field `claimRow` prints must be a
  field `claimSig` compares.**
- **Cancel exported a file anyway.** `exportProcProfile()` read
  `(prompt(...) || '').trim()` and then tested the result for `null`. The
  coercion happened first, so the guard could never fire: Cancel wrote a
  `proc_code_profile.json` and overwrote the profile name with
  "Unnamed profile".
- **The profile name did not survive a session.** `setProcCodeMap(map, name)`
  ignored `name` whenever `map` was null, and the session importer calls
  exactly that path. Proc code *behaviour* travelled with the session; the label
  saying whose behaviour it was did not.

The rule both defects broke, now pinned by tests: **the name is provenance, the
overrides are the deviation, and they are separable.** A shared profile whose
codes happen to equal the baseline still has a name. Callers that mean "start
clean" — `resetProcCodesToBaseline`, `resetAll` — pass no name and still clear it.

## The stylesheet was never the stylesheet

`SRC.indexOf('<style')` matches **`<style:master-page`** — an OpenDocument XML
tag inside the vendored SheetJS library on line 28. Every CSS test was scanning
~58KB of minified JavaScript with the real stylesheet appended to it.

That is where the `-2` brace baseline came from. It was not "the counter is not
a real CSS parser" — it was JS object literals being counted as CSS rules. Both
real style blocks balance at exactly **0**.

The check now finds blocks with `<style(?:\s[^>]*)?>`, which the XML tags cannot
match, and scans them with a comment- and string-aware pass that returns the
**line numbers** of unmatched braces. Compared with the old baseline it:

- **locates** the problem instead of reporting a delta
- catches one stray `{` and one stray `}` in the same file, which cancel to a
  delta of 0 and passed the old check
- does not break when the vendored library changes. Editing a single string
  inside SheetJS — touching no CSS — shifted the old delta to 0 and failed the
  build.

Both style blocks are now checked. The second one, which styles the exported
HTML report, was never examined at all.

## Four naming conventions for one thing

Seven header arrays in the CI Traceability Report carry NCR disposition
columns, and they use **four different names for the same field**:
`NCR Disp#` (detail, CSA, claims), `NCR Disposition #` (no-ABOM NCRs),
`Disposition #` (adjudications), and — as of v159 — `Disposition Number` on the
two sheets that were reordered.

v159 changed only the two sheets in scope. The other five are pinned by a test
that names the exact string each one uses, so the next rename is a decision
rather than a drift. Reducing four conventions to one is a worthwhile change; it
is not one to make unasked, since every one of these is a column heading someone
may be filtering on downstream.

## Column counts are checked, because XLSX will not check them

Removing a column from an export sheet means editing the header **and every row
builder**. Miss one and `aoa_to_sheet` writes the rows regardless, shifting
every value after it one column left — a spreadsheet that looks plausible and
is wrong. Nothing in the export path validates this.

Tier 8 counts the top-level elements of each `*Hdr` array literal and of every
matching `*Rows.push([...])`, and fails naming the sheet when they disagree. It
covers all 14 sheets of the CI Traceability Report, not only the ones v155
touched.

The splitter respects quotes, parentheses and nested brackets, and is itself
under test. A naive comma split turns the real header
`'Part Qty (ABOM, per WO)'` into two columns, which would miscount every sheet
that carries it — a test helper that mis-parses is as dangerous as the defect
it is meant to catch.

**Paired sheets** are pinned to identical column names: `CI ABOM Claims
Processed` is the SME-adjudicated counterpart of `CIs Embodied as WO Parts`,
and the As-Built Records Guide states that pairing outright. Renaming one and
not the other would leave a single workbook disagreeing with itself.

## One column, four surfaces

The MBOM Traceability / Reconciliation Notes / Job Number trio appears on the
on-screen Detailed View, the context export, the CSV export and the XLSX
export. Each has its **own header list and its own row builder**, and nothing
links them — move a header without its row builder and every column to the
right of it shifts one place, silently.

v155 moved Job Number to the right of Reconciliation Notes so the two companion
columns stay adjacent. Tier 9 pins header order, row order and the on-screen
`<td>` order together on every surface, and counts them against each other. A
half-applied move fails three tests independently.

The HTML report carries the Traceability/Notes pair and has never had a Job
Number column; it is excluded by name rather than by arithmetic, so it cannot
quietly acquire one without a row builder.

## Two views sat inside their own scrollbar

`.table-wrap` is `overflow-x: auto; overflow-y: auto; max-height: 68vh`, and
`attachTopScrollbar` inserts its mirror as the wrap's **previous sibling**.

Six of the eight Detailed View tables put only the table and pager inside the
wrap. Two — the I/R ABOM Discrepancy view and the RFV Information view — put a
caption there as the first child. Three consequences, all visible:

- the caption scrolled sideways with the table and off the screen
- it slid under the sticky header row on vertical scroll
- the top scrollbar appeared above the *caption* rather than on the table

Those two are exactly the two that were reported as formatted differently. Both
captions now write to a `.table-caption` element declared outside the wrapper,
via a shared `setTableCaption` helper, so the eight views are structurally
identical.

Pagination was never the difference — seven of the eight already shared
`PAGE_SIZE` and the same `page-bar`. The real outlier is **renderCITraceTable**,
which paginates not at all; that is now a named exception with a test that fails
if it ever gains a pager, rather than an unremarked gap.

## The engine is under test

`runReconciliationCore` is 543 lines and decides whether a part is reconciled.
Until v159 **not one test executed it** — every suite tested the code around it:
the proc table that feeds it, the badges that display its output, the exports
that format it.

It is pure: one params object in, a results array out, no globals and no DOM. It
was testable the whole time.

**Fixtures go through the real map builders, never hand-built.** Building them
by hand got the shapes wrong twice while this suite was being written — a `Map`
where the engine wants a plain object, and an object where `primaryQtyMap` wants
a bare number. Both times the engine ran without error and returned
plausible-but-wrong results, and a defect was nearly reported against correct
code. Two tests now pin the builder output shapes for that reason.

Behaviour worth knowing, now asserted rather than assumed:

- **Quantity mismatch means a shortfall** (`aq < eq`), not any difference. More
  in the build than the design is not a reconciliation failure.
- **By default, indenture A and B are structural collectors**, excluded from
  scope (v160 made this the EBOM Indenture Scope setting). The Tier 15 fixtures
  rely on the default: a fixture using indenture B silently produces
  `overall: collector` on every row.
- **REF lines produce no row at all** — they are excluded from the results, not
  reported as excluded.
- **A SWAP proc code is not a removal**; an install alongside a removal nets out.

Verified by breaking the engine three ways — the shortfall rule, the priority
rollup, and proc-removal detection. Each failed the matching test by name.

## The duplicated rollup is now compared, not trusted

`computeEffectiveResults` applies SME claims on top of raw engine output, and
its Phase C comment says it *"mirrors runReconciliationCore's priority rollup"*
— the same shape of risk as the duplicated `PROC_CODE_BASELINE` in the delta
tool, which did drift.

Tier 16 compares the two ladders **exhaustively**: 12 leg statuses across 4
legs, 20,736 combinations, every one asserted equal. Today they agree exactly.
A second test compares the rung ORDER as source text, so a reordering that is
behaviourally equivalent today still fails as drift. Swapping `qty_mismatch` and
`wo_open` in one copy produces 1,202 disagreements and a named order mismatch.

**A trap worth knowing.** `computeEffectiveResults` returns early when the claim
list is empty:

    if (!adjudications || !adjudications.length) return effective;

So Phase C never runs without a claim, and any test of the rollup that passes an
empty claim list **silently tests nothing**. The exhaustive comparison supplies a
claim targeting a non-existent row — enough to get past the guard, changing no
leg. Two tests written without it passed while exercising no code at all.

## Importing someone else's adjudications

Manufacturing Engineering adjudicates in a separate COTS tool. Its export is
keyed on **part number only** — no next higher, no quantity, no leg. v162 infers
all three rather than asking ME to change their tool, so every inference is
tested: an adjudication landing on the wrong position changes the numbers.

- **Position** comes from the EBOM, scoped to positions that actually fail
  passes 1-3. A part at three positions where only one is broken needs no human
  input, which is what keeps the picker small.
- **Quantity** is the line's EBOM qty — "make the line whole". Over-claiming is
  accepted by the residual model, so one rule covers a missing leg and a short one.
- **Leg** is whichever legs fail. A claim is **not** emitted for a healthy leg:
  it would be a harmless no-op, but it would record ME as having adjudicated
  something they did not. On an audit artefact that is the difference between a
  record and a fiction.

The **narrative scanner** searches for KNOWN values — the next-highers of the
failing positions plus their WO and job numbers — rather than guessing what an
identifier looks like in prose. Hyphens and dots are part of an identifier, never
boundaries, which is what stops `88421-7` matching inside `588421-70`.

It **suggests only when the prose names exactly one candidate**. Narrative
routinely rules one out in words — *"...under 88421-7, not 88421-9 as originally
routed"* — and no matcher reads negation. When several are named it shows the
sentences and suggests nothing. Finding the relevant sentence in three
paragraphs is the real value; guessing the answer is not.

**CI-to-NCR tracing is Configuration Management's, not ME's.** An imported batch
must never withdraw it. `replaceImportedClaims` drops only claims that
`isImportedClaim` accepts, and that check vetoes on claim TYPE as well as
provenance: a claim of type `ncr_ci_trace` or `ebom_ncr_trace` is protected even
if its `createdFrom` were somehow wrong. Provenance alone would have been
sufficient in practice, but the failure mode — silently deleting another team's
work on an audit artefact — is bad enough to justify the second check. The
review panel states the guarantee in words and names the count.

**Scale is a real constraint here.** A production ME export runs to ~3,000 rows.
Resolving each by scanning the full result set is O(rows x results) — measured
at **3.2 seconds** against an 80k-line EBOM, which would freeze the tab.
`planAdjImport` indexes results by part number once, taking the same work to
**194ms**.

Two tests guard it: a timing test at production scale, and a structural test
that the index is *passed to the resolver*. The first version of the structural
test checked only that the index was **built** — and passed while the planner
rescanned per row and took three seconds. Building a thing and using it are
different claims.

**Re-import replaces the imported batch and nothing else.** Claims filed inside
Comparator, CI/NCR traces especially, are native work and survive. A test asserts
every one of the seven native `createdFrom` values is preserved.

## Two halves of one omission, three builds apart

v165: staging added claims to `state.adjudications` and never told the
workbench, so **Process Adjudications** stayed greyed out.

v171: processing flipped those claims to applied and never told the import
panel, so it reported *"none applied yet"* for ever.

The same omission in both directions — a component that owns state, and a
component that reports it, with nothing connecting them. The second was fixed by
hanging `renderAdjImportPanel()` off `_adjRefreshWorkbench()`, which **every**
state-changing path already calls: submit, process, revert, remove, stage,
session import. Patching each caller would have left the next one to be written
broken again.

The message itself was correct the whole time. It simply never re-rendered,
which is the more dangerous shape of wrong: a UI that is confidently stale reads
as a fact about the data rather than a fact about the rendering.

## Checking one surface is how a half-done change passes

Making the RFV pass badges uniform touched three places, and v167 changed two:
the summary column and the legend line above the RFV Information table. The
**MATCH PASS column** in that same table is built somewhere else entirely, from
`addMatch()`, and stayed blue and red.

The test passed, because it checked the legend line only. A test that inspects
one of a change's surfaces certifies the change while half of it is undone.
It now checks the legend AND the badge builders.

That audit also surfaced a **fourth** pass nobody had mentioned: SME-Linked WO,
in `--adj` purple. It keeps its colour deliberately — purple is the
manual-provenance contract across the whole tool, and that pass exists *because*
a person linked it. A provenance distinction is not a pass ranking, so it
survives the flattening, and the test asserts it stays distinct.

A related duplicate: the Candidates Helpers zone already carried a subhead
inside it, and v167 added a second outside, so it rendered twice. The subhead
test now COUNTS rather than checking presence.

## One unresolvable call killed every filter count

v169 added `has_rfv: r.filter(x => getRowRfvLinks(x).length > 0).length` to the
counts object. `getRowRfvLinks` is **local to `renderSummaryTable`**, and
`renderAll` calls `updateFilterCounts` **before** it. So the call threw
`getRowRfvLinks is not defined` while the counts object was still being built —
before a single button was labelled.

The reported symptom was "no Has RFV button". The actual damage was **every
filter count on the page**, plus the count-based reveals for Removal Items and
Proc Removed. A screenshot showing bare labels on `ALL`, `ISSUES ONLY` and
`RECONCILED` was the tell.

The count is now `_rfvLinkedRowCount()`, top-level, building its own index over
the same three geometries (PN+NH, NCR disposition, work order).

A new test walks every bare call `updateFilterCounts` makes and fails if any
resolves to a function declared at an indent — i.e. nested in another scope.
That is a general guard: the counts object is one literal, so any unresolvable
call anywhere in it takes the whole page's filter counts with it.

## A filter gated on the wrong thing looks unimplemented

The Has RFV filter was gated on `state.boms.rfv` — on the FILE being loaded.
Every other conditional filter (`pt_removal`, `abom_proc_removed`) gates on
**count > 0** and carries its count in the label. Two consequences:

- With no RFV file the button was invisible, which to a reviewer is
  indistinguishable from the feature not being built. That is how it was
  reported.
- With a file loaded that matched nothing, it would have offered a filter
  returning an empty table.

It also had no entry in the `counts` object, so even when visible it rendered a
bare label while every neighbour showed `Label (n)` — it would not have looked
like a peer even if it appeared.

v169 counts it and reveals it by count. A second test asserts that **every**
conditional filter is revealed the same way, because a control revealed by a
different rule is the one that surprises the reader.

## A legend drawn in emoji cannot track the chart

The funnel explain modal described its bars with emoji squares — 🟥 🟧 🟪 🟨 ⬛ ▒ —
none of which were connected to the colours the bars use. Auditing all six
against the code found five wrong:

- **Three different swatches all stood for `var(--warn)`**, teaching a
  distinction the chart does not draw.
- **`WO Not Closed` cannot be one swatch**: the segment is split, teal for
  RFV-authorised open WOs and amber for bare ones.
- **The reference bars were given category colours they do not have.** Every
  reference bar renders in one neutral fill because it is *context, not a
  finding* — so the legend was showing colour where the tool draws none. That
  was the worst of the five, and the one the owner spotted.

Swatches are now `<span class="fn-sw">` elements taking the same `var(--x)`
token the bar takes, so the legend cannot drift from the chart. Four tests bind
them: no emoji, every residual colour has a swatch, `WO Not Closed` shows two,
and reference-bar entries match the neutral fill.

**The first audit was wrong too.** It treated the modal as describing one bar
and reported five mismatches in one family. There are two families — the
residual risk block and the reference bars — and the owner caught that before
any fix was written. Reference bars are not badly coloured; they are not
coloured at all.

## Placement can enforce an ordering that a message only asks for

The ME adjudication export sat in the pre-run upload grid alongside the nine BOM
sources, which is what it looks like — and is not what it is. An ME export is a
batch of claims **about a run that must already exist**, so the ordering had to
be enforced with an error message: *"Run the comparison first."*

v166 moves the zone and its review panel inside the Adjudication Workbench,
between the Candidates Helpers and the Claim Ledger. That section does not
render until a comparison has run, so the ordering now enforces itself and the
error is a backstop reachable only via a restored session. Same principle as
deriving a rule instead of restating it.

One consequence had to be handled: the section previously appeared only when
there was *something to adjudicate*. A clean run with no helper candidates is
exactly when an SME may still want to import ME's decisions, so visibility now
keys on whether a run exists.

The action bar was also renamed **Claim Ledger**: it had carried the same name
as the section it sits inside, which made "the workbench" ambiguous in both the
UI and the explanation modal.

## Adding a claim is not the same as making it usable

`stageAdjImport` pushed imported claims onto `state.adjudications` and told
nobody. The workbench only re-reads that array when `_adjRefreshWorkbench()` is
called, and it only becomes visible via `_adjShowWorkbench()` — which matters
because the section stays hidden when the run produced no helper candidates of
its own. So claims staged from an import sat pending with **Process
Adjudications greyed out**, and no way to apply them.

Every native claim path calls both. The import path called neither. v165 adds a
test that any function adding claims must call `_adjRefreshWorkbench`, and that
staging reveals the section.

The first version of the second test **passed against the broken build** — the
function body explains *why* it calls `_adjShowWorkbench`, and the test matched
that comment. Both checks now strip comments and require an actual call. That is
the third time in this project a test has matched prose instead of code.

## The worker runs a hand-listed bundle, and it broke twice

The comparison engine runs in a Web Worker built by serialising a **hand-listed**
set of functions with `.toString()`. A bundled function that calls another
top-level function *not on that list* throws inside the worker and kills every
comparison run.

That has now happened twice: `buildEbomLineNoMap` in v145, and `normIndenture`
in v160 — which **shipped broken through v163**. Every suite in this harness
loads functions directly into a sandbox, so none of them exercise the worker
path; 397 tests passed against a build that could not run a comparison at all.

v164 adds a closure check: for every function in the bundle, every bare call it
makes to another top-level function must also be in the bundle. Method calls are
excluded — `map.set(...)` is not the top-level `set()`. Removing `normIndenture`
now fails naming the exact call, `buildEbomIndentureMap() calls normIndenture()`.

The lesson is the one this project keeps relearning: a test that reads or
sandboxes the source is not a test that runs the product.

## The delta tool had to learn about the scope too

v160 made the collector rule a per-program setting. The delta tool's whole job
is telling two sessions apart, and it knew nothing about it — so two sessions
run under different scopes would have been diffed silently, showing rows moving
between COLLECTOR and reconciled as though the build had changed.

v3.3 treats it exactly like the proc code table: a provenance row in the summary
naming both scopes, and a load-time warning. It is deliberately **not** gated on
an ABOM leg being present, unlike the proc code row — the scope governs the EBOM
side, which every comparison mode has.

Sessions written before v160 carry no field and are read as the fixed A/B rule.
Defaulting to an empty list would claim every level reconciled, which is the
opposite of what those sessions did.

**What did not need changing:** the delta tool excludes structural rows by the
`collector` STATUS, not by inspecting indenture letters, so it inherits the
setting automatically. A test asserts it never starts deriving the rule itself —
that would be a second copy to keep in sync, which is how
`PROC_CODE_BASELINE` drifted.

## Two program conventions, v160

**Which indenture levels are collectors** was one hardcoded line —
`(indenture === 'A' || indenture === 'B')`. Every other reference in the build
keys off the resulting `'collector'` status, so making it configurable touched
one decision point rather than seventy-five.

It is modelled as a LIST, not a boolean: a program may treat A as an apex
collector while B holds real parts, which a boolean cannot express. The setting
travels in the session and is named on the certificate, because two people with
different settings comparing the same files get different answers.

**Numeric indenture** (1, 2, 3…) is normalised to alpha at every read, so one
rule describes the hierarchy whichever convention the source file uses. Values
outside 1–26 are left alone rather than remapped to something meaningless.

Both engine call sites — the worker and the synchronous fallback — pass the
setting, and a test counts them. Passing it to only one would mean a worker
failure silently reconciling a different set of rows.

## The session file is the audit artefact

`importSessionJson` is async and DOM-heavy, but the part that matters — the
state restore that reconstitutes a certified report — is the first 96 lines and
runs unmodified against a stub `document`. Tier 17 extracts it by marker and
executes the real code rather than a paraphrase.

The guard worth having is **field parity**: every key the importer reads must be
a key the exporter writes. A field saved but never restored, or restored but
never saved, is a silently wrong answer months later rather than a crash.
`cpManualMap` is the single documented exception — a deliberate back-compat read
for sessions written before the `cp` → `chp` rename.

Verified by regression: removing `isLocked` from the exporter fails naming the
field; removing the `cp` → `chp` mapping fails on the pre-v153 session; and
relaxing the column-mapping check from `=== 2 ? 2 : 1` to `|| 1` lets a
corrupted session select a mapping that does not exist.

## The build is now syntax-checked

v155 stripped 26 inline `font-size` overrides out of `renderSummaryTable` with a
regex. A regex loose enough to do that is loose enough to break a template
literal, and **nothing in the harness would have noticed** — every other suite
matches patterns in the source rather than parsing it.

Tier 13 runs `node --check` over each inline `<script>` block. Removing a single
closing quote now fails with the file and line. This is a general guard, not a
type-scale one: it covers any future edit to the build.

## The Comparison Summary type scale

Cells were nominally 11px, but **26 inline declarations overrode that** at 10px,
9px and 8px — the em-dash for empty cells, stacked multi-value entries,
disposition status, part-type code. No principle, just accumulation. All 26 are
gone; every cell inherits `--fs-cell`.

Two decisions worth recording:

- **The header stays smaller than the cell** (`--fs-head`, 9px until v180, now 11px against a 12px cell). A header is a
  label, not content, and is already distinguished by uppercase,
  letter-spacing, a surface fill and muted colour. It is also `position:
  sticky`, so enlarging it costs permanent vertical space on every screen.
- **Badge tracking dropped from 0.12em to 0.04em** when badges went from 8px to
  `--fs-cell`. Size and tracking compound: matching size alone widened
  `↑ PARENT IND. EMBODIED` from 141px to 188px, and the Traceability and
  Reconciliation Notes columns stack several badges per cell in a table that
  already scrolls horizontally. At 0.04em the increase is 20% instead of 33%.
  Weight 700 and uppercase remain as the non-size difference.

## Two text tiers in the summary table

v155 introduced a third tier (`--text-faint`) to formalise a grey already in
use. On review that was wrong for the table: three tiers in one data row is the
mush it was meant to fix. v156 sets the rule from the reader's side —

- **White (`--text`)**, via `td.cell-key`: part numbers, next highers,
  quantities, work order numbers and statuses, NCR disposition numbers and
  statuses, RFV numbers. The values you compare or act on.
- **Dim (`--text-muted`)**: everything else, by making it the `td` default. It
  is context, not the point.

`--text-faint` survives for **chrome only** — chart axis captions and funnel
footnotes, where it is the sole grey against a panel rather than one of three
competing tiers in a row. A test fails if it appears inside a `<td>`. Retiring
it entirely was over-reach on my part: five canvas `fillStyle` values referenced
it, and the token check caught that immediately.

*v180:* retired after all. As a grey it measured 2.1:1, so every place it was
used was unreadable; the five canvas uses and the funnel footnotes now use
`--text-muted`. See the v180 section.

Cells that carry their own semantic colour — disposition status greens and
ambers, mismatch highlights — still override both tiers, which is why NCR
disposition numbers and statuses need no white marking.

## The palette was good; 99 declarations ignored it

The build defines 28 colour tokens. v155 found **99 inline declarations using
raw hex instead** — 87 of them exact duplicates of a token that already
existed, and the rest near-misses that nobody chose:

- a second muted grey (`#7d8590`) 15 luminance from `--text-muted`
- a second accent blue (`#58a6ff`) beside `--accent`
- **a second teal for RFV** (`#39c5cf`) while `--rfv` was `#2dd4bf`

Five text levels were in play where the system defined two. `--text-faint` now
formalises the third that was already being used as a bare `#484f58`, and the
test requires the three levels to be at least 40 luminance apart so they read as
deliberate.

**Canvas colours are the exception and are tested differently.** A 2D context
silently ignores an unresolvable `fillStyle` and keeps the previous colour, so
chart colours must stay literal hex. Tier 12 instead requires every canvas hex
to equal a defined token value, and fails if any `fillStyle` tries to use
`var()`.

The KPI render-error banner is exempt by name: it reports that rendering has
failed, so making it depend on the stylesheet resolving would risk an invisible
error message. The exemption is narrow and itself asserted.

## One suite runs the code instead of reading it

*(v188: the cause code chart is now an HTML list, and the canvas tests this
section describes were removed with the canvas. Kept as history.)*

Every other suite inspects the build as text. Tier 11 executes the two chart
renderers against a fake canvas that records `fillText` calls. (Since v185 the
WO status roll-up is HTML, so Tier 11 runs it and reads the markup it writes.)

That capability exists because of a mistake made writing v155: a string
replacement intended for `drawWoStatusRollup` landed in
`drawNcrCauseCodeChart` instead, leaving a reference to an undefined `_ly`.
**All 228 tests stayed green** — nothing had ever executed a renderer, so a
guaranteed runtime crash was invisible. Tier 11 now fails three tests naming
`_ly is not defined`.

The fuzzy labels had two independent causes, both confirmed numerically:

- **The buffer was resampled.** `setupHiDpiCanvas` rounded the backing buffer
  but set the CSS size unrounded. A 703.328px canvas at dpr 2 got a 1407px
  buffer displayed across 1406.656 device pixels — the browser rescaled the
  whole canvas by 0.99976. Fractional widths are the normal case inside a flex
  row. The CSS size is now snapped so the two agree exactly.
- **Labels sat on half pixels.** Bar height is `max(14, floor(...) - 3)`, often
  odd, and a centred baseline at `y + barH/2` then lands mid-pixel. Bar widths
  are fractional too. Label coordinates are now snapped to the device grid via
  `_crisp`, while the bars stay fractional — geometry is fine at sub-pixel
  precision, text is not.

## One source for the guide and the tooltips

v158 gives every badge a native hover tooltip. The strings come from a single
`BADGE_HELP` map keyed by the exact badge label, and the **badge guide renders
from the same map** — so a badge cannot be explained one way in a tooltip and
another way in the guide. That is the structural fix for the drift below, not
just a feature.

**The first version of this test named its call sites by hand** — four helpers I
had found by reading. It passed, and `tracBadge` still rendered every badge in
the Traceability and Reconciliation Notes columns with no tooltip at all,
because I had not found it. A hardcoded list can only ever be as complete as the
person writing it.

The rule is now derived: scan every badge span in the build; if its label is one
`BADGE_HELP` explains, it must carry a title, and any helper taking a `label`
that emits a badge span must consult `BADGE_HELP`. That immediately found five
more sites the hand list had missed, including four badge families —
`▲ INSTALLED`, `▼ REMOVED`, `✓ MATCHED`, `— UNMATCHED` — with no explanation
anywhere in the product. The badge guide's own preview badges are exempt by
position, since the description sits in the next cell.

Six render paths now attach it: `badgeBom`, `badgeAbom`, `badgeOverall`,
`tracBadge`, `adjTracBadge`, plus the inline sites in the raw BOM, CHP, WO5,
NCR, CI trace and RFV views. The last already built a multi-line title from adjudication
metadata (who claimed it, when, the rationale, the WO and NCR numbers); the
explanation is **prepended** to that, not substituted for it, and a test asserts
the detail survives.

Native `title` was chosen over a styled panel deliberately: badges live inside
`.table-wrap`, which is `overflow: auto`, so a CSS tooltip would be clipped at
the scroll edges and would need body-level positioning in JS. That is the
difference between an hour and half a day, and the delay is the only thing lost.

## Glyph-insensitive matching is how the guide drifted

Tier 10 compared guide entries to badge labels with leading glyphs stripped, and
never compared CLASSES at all. So when v156 moved the used-on badges to
`--success-2`, the guide kept showing them in `badge-ok` green and every test
passed. Three entries were wrong; a reader comparing the guide to the table
would have seen two different greens for the same badge.

v157 compares **exact labels and exact classes**. It immediately found a
fourth drift the looser test had also been hiding — `⬇ PROC REMOVED`
documented without its glyph.

Green badges now carry no glyph at all: green already says "fine", so a tick
adds nothing. Glyphs are reserved for states that need a second look — `⚠`, `✗`,
`⊘`, `⚑` — and a test asserts those were not stripped along with the rest.

## The badge guide is derived from the badge maps

The guide was titled "Comparison Summary — Badge Guide" and scoped to that one
table. But `badgeBom` and `badgeAbom` are used **only** by `renderFullBom`, so
the raw BOM vocabulary never reached the guide at all — which is why the
catch-all badge and the Change Pedigree `NO MATCH` had no explanation anywhere
in the product. It was not that entries had gone stale; every existing entry
checked out. Whole surfaces were missing.

v155 retitles it "Detailed View — Badge Guide" and adds sections for the raw
BOM views, the Change Pedigree view, and the `? UNKNOWN` fallback that appears
when the engine returns a status the badge maps do not know.

Tier 10 derives the expected entries from `badgeBom` / `badgeAbom` /
`badgeOverall` and from `chpReleaseState`, so adding a badge without
documenting it fails the build by name. A documented entry may be a *more*
informative form of the emitted label — the badge renders
`RELEASED MARCH 15, 2024`, the guide writes `RELEASED ⟨date⟩` — so matching
allows that, while still failing when a state is absent.

## Documentation is under test too

The v149 explanation modal claimed the `↑ parent` marker carried "exactly two
styles, the same on both BOM sides." Three shipped on the MBOM side: the
orthogonal `nhMismatchMbom` flag was tested *before* the covered/collector
branches, so a covered row with an NH mismatch rendered `hl-parentage`.

v155 collapsed the marker to one muted-italic style on both sides and derives
the class from what is actually rendered, which removes the precedence trap
rather than documenting it. The covered-vs-collector distinction was never lost
— it is stated in words by the Reconciliation badge on the same row.

Two Tier 7 tests now assert the modal text against the code. Prose that
describes behaviour is as capable of drifting as a duplicated constant, and
harder to notice when it does.

## Two vocabularies live in both files

The main build owns them; the delta tool re-states them. Nothing enforced
agreement until v154, and a divergence is silent in both cases:

- **`PROC_CODE_BASELINE`** — if the main build gains a code and the delta copy
  does not, the delta tool reports two sessions as agreeing on proc codes when
  they do not.
- **The mode vocabulary.** The main build's `getModeRequired` table names four
  modes; the delta tool re-states it as `mode !== 'ebom_abom'` and
  `mode !== 'ebom_mbom'`. Add a fifth mode and the delta tool reports a full set
  of zeroed MBOM KPIs for it, as though everything failed. The test reads the
  main build's table and checks both predicates against every mode in it.

A session with no `mode` recorded fails open — both sides are reported. That is
pinned by a test so the behaviour is a decision rather than an accident.

## Two guards worth keeping

- **Brace balance**, as above — now an assertion against zero rather than a
  magic number, and it names the line.
- **Version literal check** fails if a version string appears anywhere in the UI
  chrome. The header pill was stale for 33 releases before this existed.

## Not covered

- **`timestamp` is deliberately excluded from the claim signature.** It moves
  on every re-save and would mark every claim as modified. The main build's
  certificate hash **does** include it, so two sessions can differ by cert hash
  while the delta tool reports the claims as unchanged. That is a judgement
  call worth revisiting, not a defect. From v178 the rule is explicit: the
  delta signature is the certificate hash's claim projection minus `id` and
  `timestamp`, and Tier 4b derives it.
- **The streaming reader's browser plumbing** — `FileReader`, `file.stream()`,
  `TextDecoder` and `_readSessionPayload` — runs only under `--browser`, which
  opens sessions in the delta tool with the large-file threshold lowered to
  1 KB. A multi-byte character split between raw file chunks is still not
  constructed deliberately.
- **Export menu counts** are now derived from the build rather than pinned to
  13, so adding an export is not a failure — leaving one unwired is.
- **The reference suite compares one fixture.** It proves the outputs it
  produces are identical, not every possible program. It covers every Change
  Pedigree join the build makes; it does not cover NCR, WO5, RFV or ACN files.

- **The sheet builders** — `buildSummaryRows`,
  `buildProgress`, `gatedSection`, `exportXlsx`. Tiers 4 and 6 cover the
  comparison and assembly layers; the final formatting into worksheets is
  still untested.
- **`inScopeSet`, `fscope` and `computeKpis` read `session.results` unguarded**,
  so a malformed session throws rather than returning a note the way the
  missing-file paths do. Treated as a documented precondition, not a defect —
  every real session carries `results`.

Without `--browser`, nothing in the UI layer is covered: no DOM rendering, no
click paths, no Excel file is opened and inspected. With it, the main path is —
load, run, claim, export, freeze, re-import, delta — but not every card, modal
or report.
