# Comparator test harness

**One file: `comparator-tests.js`.** Node only — no install, no network, no
other files. 262 tests.

```bash
node comparator-tests.js                          # finds the newest ./comparator_offline*.html
                                                  # and ./comparator_delta_v*.html beside it
node comparator-tests.js path/to/build.html       # or point it anywhere
```

Re-run after any change to the build.

## Why one file

Comparator ships as a single self-contained HTML, and this follows suit so it
can live in a Project beside it. A split-file version was lost between sessions,
taking 72 tests with it — the whole point of this format is that it survives.

## How it works

The build's testable functions are lifted out of the HTML by marker, then run in
a per-suite sandbox that stubs the browser globals they touch (`document`,
`state`, `COL`, `XLSX`). Each suite gets its own sandbox because the modules
expect different `COL` shapes.

If a marker moves, extraction **fails loudly and names it, and no tests run at
all** — the build was refactored and the marker needs updating. That is
deliberate: an empty module would let every suite pass while testing nothing.

This was only half-true before v154. Four boundary lookups used raw `indexOf`,
which returns `-1` on a miss and turns into a zero-length slice. Pointed at a
build where one marker had been renamed, the old harness printed
**"21 passed, 5 failed"** — a believable summary. In fact 33 tests never
executed, because a crashed suite costs exactly one reported failure no matter
how many tests it contained. Every boundary now goes through `at()` / `lastAt()`
/ `span()`, and `span()` refuses a slice that is inverted or implausibly small.

`EXPECTED_TESTS` is the backstop: if the number of tests that actually ran is
not the number expected, the run fails and says so. **Bump it when you add
tests** — that is deliberate friction, because a silently shrinking suite is the
failure mode this harness is most vulnerable to.

## Coverage

| Suite | Tests | Covers |
|---|---|---|
| Tier 14 — Detailed View structure | 8 | All eight table views wired identically; captions outside the scroll container; uniform pagination |
| Tier 13 — summary table type scale | 9 | One cell size, header smaller, badges matched; plus a **syntax check of every inline script block** |
| Tier 12 — colour tokens | 7 | Nothing bypasses the palette; canvas colours checked against tokens since they cannot use `var()` |
| Tier 11 — chart rendering | 10 | **Executes** both chart renderers against a recording 2D context; buffer/CSS parity and label pixel-snapping |
| Tier 10 — badge guide | 8 | Guide entries derived from the badge maps, so a new badge cannot ship undocumented |
| Tier 9 — MBOM column order | 8 | Job Number's position pinned across all four surfaces, header and row builder together |
| Tier 8 — CI report columns | 14 | Header/row width parity across every sheet, plus the v155 column removals and renames |
| Tier 7 — view markers and badges | 15 | The single `↑ parent` marker style, the neutral catch-all badge, part-type exclusions, **and the explanation modal matching the code** |
| Tier 6 — delta report assembly | 26 | Two-pass EBOM matcher, KPI counters, NCR disposition diff, **mode vocabulary drift**, pre-rename CHP sessions |
| Tier 4 — delta tool | 21 | **Baseline drift between the two shipped files**, proc table diffing, claim change detection, label agreement with the main build |
| Tier 3 — CHP release state | 19 | Badge states, latest-DCN selection, undated-DCN warning, and **timezone-stable release dates** |
| Tier 3 — proc table hardening | 14 | Lock behaviour, hand-edited profile files, provenance leaks between loads, stale-results flag |
| Tier 2 — indenture map | 11 | **The real `buildEbomIndentureMap`,** not a stand-in. Parent/child linking, shared PN under two NHs, self-referencing rows, first-occurrence rules |
| Tier 2 — extraction | 10 | **The harness's own safety net.** Module contracts, marker guards, "no global without its module", build is still self-contained |
| Tier 1 — profile name | 13 | **Regression guards for two v153 defects.** Cancel on the profile-name prompt; profile name surviving a session round-trip; the name/override split |
| Engine | 9 | **Core correctness.** Tagging a proc code actually changes `buildAbomMap` output; swap-as-add second pass; founding program unaffected; worker table in lockstep |
| Proc code panel | 16 | Job-number sampling, dedup, HTML escaping, Mapping 2 (where the old description column was always blank) |
| NCR untraced | 12 | Export grain is **one row per disposition**, not per file row; merged values joined not dropped |
| ECN completeness | 7 | CHP-listed items that never joined to an EBOM row |
| ECN aggregation | 6 | Many EBOM line items → one ECN; one bad item excludes the whole ECN |
| Stylesheet/chrome | 15 | Brace balance **located by line**, across both style blocks; orphan keyframes; undefined CSS vars; export-menu wiring derived from the build |
| Version | 4 | Single-source version string; guards the header pill against drift |

## Two defects these tests were written for

All four were live in v153 and are fixed in v154. Eight tests across Tiers 1
and 3 fail against a v153 build — that is the check that they are real guards
and not decoration. Run the suite against an old build occasionally to confirm
they still bite.

- **The release date was wrong east of Greenwich.** `formatDcnDate` read UTC
  components off a date built at *local* midnight, so a DCN released 15 March
  displayed as **MARCH 14** in Tokyo, Sydney and Kolkata. It reached the badge,
  the tooltip and the freeze certificate. Both the parser and the formatter now
  normalise date-only values to local midnight and read local components.
- **A profile name leaked between loads.** `setProcCodeMap` fell back to
  `|| state.procProfileName`, which no caller needed. Load "Program Falcon",
  then import an unnamed custom session, and the certificate still claimed
  Falcon. The argument is now the only source of the name.
- **The delta tool displayed a field it never compared.** `claimRow` prints
  `c.dispNo || c.ncrDispNo`; `claimSig` compared only `c.dispNo`. On
  `ebom_ncr_trace` claims — the ones the main build actually creates — the
  field is always `ncrDispNo`, so a changed NCR disposition number was declared
  unchanged and omitted from the Claims sheet entirely. `applied` had the same
  problem. The rule now under test: **every field `claimRow` prints must be a
  field `claimSig` compares.**
- **Cancel exported a file anyway.** `exportProcProfile()` read
  `(prompt(...) || '').trim()` and then tested the result for `null`. The
  coercion happened first, so the guard could never fire: Cancel wrote a
  `proc_code_profile.json` and overwrote the profile name with
  "Unnamed profile".
- **The profile name did not survive a session.** `setProcCodeMap(map, name)`
  ignored `name` whenever `map` was null, and the session importer calls
  exactly that path. Proc code *behaviour* travelled with the session; the label
  saying whose behaviour it was did not.

The rule both defects broke, now pinned by tests: **the name is provenance, the
overrides are the deviation, and they are separable.** A shared profile whose
codes happen to equal the baseline still has a name. Callers that mean "start
clean" — `resetProcCodesToBaseline`, `resetAll` — pass no name and still clear it.

## The stylesheet was never the stylesheet

`SRC.indexOf('<style')` matches **`<style:master-page`** — an OpenDocument XML
tag inside the vendored SheetJS library on line 28. Every CSS test was scanning
~58KB of minified JavaScript with the real stylesheet appended to it.

That is where the `-2` brace baseline came from. It was not "the counter is not
a real CSS parser" — it was JS object literals being counted as CSS rules. Both
real style blocks balance at exactly **0**.

The check now finds blocks with `<style(?:\s[^>]*)?>`, which the XML tags cannot
match, and scans them with a comment- and string-aware pass that returns the
**line numbers** of unmatched braces. Compared with the old baseline it:

- **locates** the problem instead of reporting a delta
- catches one stray `{` and one stray `}` in the same file, which cancel to a
  delta of 0 and passed the old check
- does not break when the vendored library changes. Editing a single string
  inside SheetJS — touching no CSS — shifted the old delta to 0 and failed the
  build.

Both style blocks are now checked. The second one, which styles the exported
HTML report, was never examined at all.

## Column counts are checked, because XLSX will not check them

Removing a column from an export sheet means editing the header **and every row
builder**. Miss one and `aoa_to_sheet` writes the rows regardless, shifting
every value after it one column left — a spreadsheet that looks plausible and
is wrong. Nothing in the export path validates this.

Tier 8 counts the top-level elements of each `*Hdr` array literal and of every
matching `*Rows.push([...])`, and fails naming the sheet when they disagree. It
covers all 14 sheets of the CI Traceability Report, not only the ones v155
touched.

The splitter respects quotes, parentheses and nested brackets, and is itself
under test. A naive comma split turns the real header
`'Part Qty (ABOM, per WO)'` into two columns, which would miscount every sheet
that carries it — a test helper that mis-parses is as dangerous as the defect
it is meant to catch.

**Paired sheets** are pinned to identical column names: `CI ABOM Claims
Processed` is the SME-adjudicated counterpart of `CIs Embodied as WO Parts`,
and the As-Built Records Guide states that pairing outright. Renaming one and
not the other would leave a single workbook disagreeing with itself.

## One column, four surfaces

The MBOM Traceability / Reconciliation Notes / Job Number trio appears on the
on-screen Detailed View, the context export, the CSV export and the XLSX
export. Each has its **own header list and its own row builder**, and nothing
links them — move a header without its row builder and every column to the
right of it shifts one place, silently.

v155 moved Job Number to the right of Reconciliation Notes so the two companion
columns stay adjacent. Tier 9 pins header order, row order and the on-screen
`<td>` order together on every surface, and counts them against each other. A
half-applied move fails three tests independently.

The HTML report carries the Traceability/Notes pair and has never had a Job
Number column; it is excluded by name rather than by arithmetic, so it cannot
quietly acquire one without a row builder.

## Two views sat inside their own scrollbar

`.table-wrap` is `overflow-x: auto; overflow-y: auto; max-height: 68vh`, and
`attachTopScrollbar` inserts its mirror as the wrap's **previous sibling**.

Six of the eight Detailed View tables put only the table and pager inside the
wrap. Two — the I/R ABOM Discrepancy view and the RFV Information view — put a
caption there as the first child. Three consequences, all visible:

- the caption scrolled sideways with the table and off the screen
- it slid under the sticky header row on vertical scroll
- the top scrollbar appeared above the *caption* rather than on the table

Those two are exactly the two that were reported as formatted differently. Both
captions now write to a `.table-caption` element declared outside the wrapper,
via a shared `setTableCaption` helper, so the eight views are structurally
identical.

Pagination was never the difference — seven of the eight already shared
`PAGE_SIZE` and the same `page-bar`. The real outlier is **renderCITraceTable**,
which paginates not at all; that is now a named exception with a test that fails
if it ever gains a pager, rather than an unremarked gap.

## The build is now syntax-checked

v155 stripped 26 inline `font-size` overrides out of `renderSummaryTable` with a
regex. A regex loose enough to do that is loose enough to break a template
literal, and **nothing in the harness would have noticed** — every other suite
matches patterns in the source rather than parsing it.

Tier 13 runs `node --check` over each inline `<script>` block. Removing a single
closing quote now fails with the file and line. This is a general guard, not a
type-scale one: it covers any future edit to the build.

## The Comparison Summary type scale

Cells were nominally 11px, but **26 inline declarations overrode that** at 10px,
9px and 8px — the em-dash for empty cells, stacked multi-value entries,
disposition status, part-type code. No principle, just accumulation. All 26 are
gone; every cell inherits `--fs-cell`.

Two decisions worth recording:

- **The header stays smaller than the cell** (`--fs-head: 9px`). A header is a
  label, not content, and is already distinguished by uppercase,
  letter-spacing, a surface fill and muted colour. It is also `position:
  sticky`, so enlarging it costs permanent vertical space on every screen.
- **Badge tracking dropped from 0.12em to 0.04em** when badges went from 8px to
  `--fs-cell`. Size and tracking compound: matching size alone widened
  `↑ PARENT IND. EMBODIED` from 141px to 188px, and the Traceability and
  Reconciliation Notes columns stack several badges per cell in a table that
  already scrolls horizontally. At 0.04em the increase is 20% instead of 33%.
  Weight 700 and uppercase remain as the non-size difference.

## Two text tiers in the summary table

v155 introduced a third tier (`--text-faint`) to formalise a grey already in
use. On review that was wrong for the table: three tiers in one data row is the
mush it was meant to fix. v156 sets the rule from the reader's side —

- **White (`--text`)**, via `td.cell-key`: part numbers, next highers,
  quantities, work order numbers and statuses, NCR disposition numbers and
  statuses, RFV numbers. The values you compare or act on.
- **Dim (`--text-muted`)**: everything else, by making it the `td` default. It
  is context, not the point.

`--text-faint` survives for **chrome only** — chart axis captions and funnel
footnotes, where it is the sole grey against a panel rather than one of three
competing tiers in a row. A test fails if it appears inside a `<td>`. Retiring
it entirely was over-reach on my part: five canvas `fillStyle` values referenced
it, and the token check caught that immediately.

Cells that carry their own semantic colour — disposition status greens and
ambers, mismatch highlights — still override both tiers, which is why NCR
disposition numbers and statuses need no white marking.

## The palette was good; 99 declarations ignored it

The build defines 28 colour tokens. v155 found **99 inline declarations using
raw hex instead** — 87 of them exact duplicates of a token that already
existed, and the rest near-misses that nobody chose:

- a second muted grey (`#7d8590`) 15 luminance from `--text-muted`
- a second accent blue (`#58a6ff`) beside `--accent`
- **a second teal for RFV** (`#39c5cf`) while `--rfv` was `#2dd4bf`

Five text levels were in play where the system defined two. `--text-faint` now
formalises the third that was already being used as a bare `#484f58`, and the
test requires the three levels to be at least 40 luminance apart so they read as
deliberate.

**Canvas colours are the exception and are tested differently.** A 2D context
silently ignores an unresolvable `fillStyle` and keeps the previous colour, so
chart colours must stay literal hex. Tier 12 instead requires every canvas hex
to equal a defined token value, and fails if any `fillStyle` tries to use
`var()`.

The KPI render-error banner is exempt by name: it reports that rendering has
failed, so making it depend on the stylesheet resolving would risk an invisible
error message. The exemption is narrow and itself asserted.

## One suite runs the code instead of reading it

Every other suite inspects the build as text. Tier 11 executes the two chart
renderers against a fake canvas that records `fillText` calls.

That capability exists because of a mistake made writing v155: a string
replacement intended for `drawWoStatusRollup` landed in
`drawNcrCauseCodeChart` instead, leaving a reference to an undefined `_ly`.
**All 228 tests stayed green** — nothing had ever executed a renderer, so a
guaranteed runtime crash was invisible. Tier 11 now fails three tests naming
`_ly is not defined`.

The fuzzy labels had two independent causes, both confirmed numerically:

- **The buffer was resampled.** `setupHiDpiCanvas` rounded the backing buffer
  but set the CSS size unrounded. A 703.328px canvas at dpr 2 got a 1407px
  buffer displayed across 1406.656 device pixels — the browser rescaled the
  whole canvas by 0.99976. Fractional widths are the normal case inside a flex
  row. The CSS size is now snapped so the two agree exactly.
- **Labels sat on half pixels.** Bar height is `max(14, floor(...) - 3)`, often
  odd, and a centred baseline at `y + barH/2` then lands mid-pixel. Bar widths
  are fractional too. Label coordinates are now snapped to the device grid via
  `_crisp`, while the bars stay fractional — geometry is fine at sub-pixel
  precision, text is not.

## The badge guide is derived from the badge maps

The guide was titled "Comparison Summary — Badge Guide" and scoped to that one
table. But `badgeBom` and `badgeAbom` are used **only** by `renderFullBom`, so
the raw BOM vocabulary never reached the guide at all — which is why the
catch-all badge and the Change Pedigree `NO MATCH` had no explanation anywhere
in the product. It was not that entries had gone stale; every existing entry
checked out. Whole surfaces were missing.

v155 retitles it "Detailed View — Badge Guide" and adds sections for the raw
BOM views, the Change Pedigree view, and the `? UNKNOWN` fallback that appears
when the engine returns a status the badge maps do not know.

Tier 10 derives the expected entries from `badgeBom` / `badgeAbom` /
`badgeOverall` and from `chpReleaseState`, so adding a badge without
documenting it fails the build by name. A documented entry may be a *more*
informative form of the emitted label — the badge renders
`RELEASED MARCH 15, 2024`, the guide writes `RELEASED ⟨date⟩` — so matching
allows that, while still failing when a state is absent.

## Documentation is under test too

The v149 explanation modal claimed the `↑ parent` marker carried "exactly two
styles, the same on both BOM sides." Three shipped on the MBOM side: the
orthogonal `nhMismatchMbom` flag was tested *before* the covered/collector
branches, so a covered row with an NH mismatch rendered `hl-parentage`.

v155 collapsed the marker to one muted-italic style on both sides and derives
the class from what is actually rendered, which removes the precedence trap
rather than documenting it. The covered-vs-collector distinction was never lost
— it is stated in words by the Reconciliation badge on the same row.

Two Tier 7 tests now assert the modal text against the code. Prose that
describes behaviour is as capable of drifting as a duplicated constant, and
harder to notice when it does.

## Two vocabularies live in both files

The main build owns them; the delta tool re-states them. Nothing enforced
agreement until v154, and a divergence is silent in both cases:

- **`PROC_CODE_BASELINE`** — if the main build gains a code and the delta copy
  does not, the delta tool reports two sessions as agreeing on proc codes when
  they do not.
- **The mode vocabulary.** The main build's `getModeRequired` table names four
  modes; the delta tool re-states it as `mode !== 'ebom_abom'` and
  `mode !== 'ebom_mbom'`. Add a fifth mode and the delta tool reports a full set
  of zeroed MBOM KPIs for it, as though everything failed. The test reads the
  main build's table and checks both predicates against every mode in it.

A session with no `mode` recorded fails open — both sides are reported. That is
pinned by a test so the behaviour is a decision rather than an accident.

## Two guards worth keeping

- **Brace balance**, as above — now an assertion against zero rather than a
  magic number, and it names the line.
- **Version literal check** fails if a version string appears anywhere in the UI
  chrome. The header pill was stale for 33 releases before this existed.

## Not covered

- **CHP release-state badge** (~18 tests, lost). Straightforward to rewrite —
  `chpReleaseState` is already reachable.
`timestamp` is deliberately excluded from the claim signature: it moves on
every re-save and would mark every claim as modified. Note that the main
build's certificate hash **does** include it, so two sessions can differ by
cert hash while the delta tool reports the claims as unchanged. That is a
judgement call worth revisiting, not a defect.
- **Export menu counts** are now derived from the build rather than pinned to
  13, so adding an export is not a failure — leaving one unwired is.

- **`pedigreeDelta` and the sheet builders** — `buildSummaryRows`,
  `buildProgress`, `gatedSection`, `exportXlsx`. Tiers 4 and 6 cover the
  comparison and assembly layers; the final formatting into worksheets is
  still untested.
- **`inScopeSet`, `fscope` and `computeKpis` read `session.results` unguarded**,
  so a malformed session throws rather than returning a note the way the
  missing-file paths do. Treated as a documented precondition, not a defect —
  every real session carries `results`.

Nothing in the UI layer is covered: no DOM rendering, no click paths, no Excel
file is opened and inspected. These suites test logic, not the interface.
