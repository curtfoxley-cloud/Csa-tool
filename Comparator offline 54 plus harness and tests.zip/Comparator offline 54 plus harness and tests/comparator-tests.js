#!/usr/bin/env node
/**
 * comparator-tests.js — complete, self-contained test harness for Comparator.
 *
 *   node comparator-tests.js [path-to-build.html]
 *
 * Finds the highest-numbered ./comparator_offline*.html, then ../ .
 * Node only: no install, no network, no other files. 94 tests.
 *
 * WHY ONE FILE: Comparator ships as a single self-contained HTML, and this
 * harness follows suit so it can live in a Project alongside it. An earlier
 * split-file version was lost between sessions, taking 72 tests with it.
 *
 * HOW IT WORKS: the build's testable functions are lifted out of the HTML by
 * marker, then evaluated in a per-suite sandbox that stubs the browser globals
 * they touch (document, state, COL, XLSX...). Each suite gets its own sandbox
 * because the modules expect different COL shapes.
 *
 * IF EXTRACTION FAILS: the error names the marker that moved. The build was
 * refactored; update the marker below. Failing loudly is deliberate — an empty
 * module would let every suite pass while testing nothing.
 */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');

// Explicit argument or env var wins. Otherwise find the HIGHEST-numbered
// comparator_offline*.html in ./ or ../ — so a version bump does not require
// editing this harness, and a stale older build sitting beside a new one is
// not silently picked up. The version-pin test still catches a wrong build.
function discover(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => /^comparator_offline\d+\.html$/.test(f))
      .sort((a, b) => parseInt(b.match(/\d+/)[0], 10) - parseInt(a.match(/\d+/)[0], 10))
      .map(f => path.join(dir, f));
  } catch (e) { return []; }
}
const CANDIDATES = [process.argv[2], process.env.COMPARATOR_BUILD].filter(Boolean)
  .concat(discover(__dirname), discover(path.join(__dirname, '..')));
const BUILD = CANDIDATES.find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
if (!BUILD) {
  console.error('Build HTML not found. Looked for comparator_offline*.html in:\n  ' +
                __dirname + '\n  ' + path.join(__dirname, '..') +
                '\nPass one: node comparator-tests.js path/to/comparator_offline54.html');
  process.exit(1);
}
const SRC = fs.readFileSync(BUILD, 'utf8');

// The delta tool is a SECOND shipped file that carries its own copy of
// PROC_CODE_BASELINE. Nothing checked the two for drift until v154.
function discoverDelta(dir) {
  try {
    return fs.readdirSync(dir)
      .filter(f => /^comparator_delta_v[\d_]+\.html$/.test(f))
      .sort((a, b) => (b.match(/[\d_]+/)[0].replace(/_/g, '.') * 1) -
                      (a.match(/[\d_]+/)[0].replace(/_/g, '.') * 1))
      .map(f => path.join(dir, f));
  } catch (e) { return []; }
}
const DELTA = [process.env.COMPARATOR_DELTA].filter(Boolean)
  .concat(discoverDelta(path.dirname(BUILD)), discoverDelta(__dirname),
          discoverDelta(path.join(__dirname, '..')))
  .find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
if (!DELTA) {
  console.error('Delta tool not found. Looked for comparator_delta_v*.html beside the build.\n' +
                'Set COMPARATOR_DELTA=path to point at it.');
  process.exit(1);
}
console.log('Delta tool under test: ' + DELTA);
const DSRC = fs.readFileSync(DELTA, 'utf8');
console.log('Build under test: ' + BUILD + '\n');

// ── extraction ─────────────────────────────────────────────────────────────
// EVERY boundary goes through at() / lastAt() / span(). A raw SRC.indexOf that
// misses returns -1, and -1 silently becomes a zero-length or inverted slice —
// which is the empty module this harness exists to prevent. v154 closed four
// such holes; the 'Tier 2 — extraction integrity' suite keeps them closed.
function at(marker, from) {
  const i = typeof marker === 'string'
    ? SRC.indexOf(marker, from || 0)
    : (function () { const m = SRC.slice(from || 0).match(marker); return m ? m.index + (from || 0) : -1; })();
  if (i < 0) throw new Error('BUILD MARKER MOVED: ' + marker);
  return i;
}
function lastAt(marker, before, label) {
  const i = SRC.lastIndexOf(marker, before);
  if (i < 0) throw new Error('BUILD MARKER MOVED (searching backwards from ' +
                             (label || before) + '): ' + marker);
  return i;
}
// A named slice that refuses a degenerate result. `label` is what gets printed,
// so a failure says which module lost its boundary rather than surfacing later
// as "P is not defined" inside an unrelated suite.
const MIN_SPAN = 200;
function span(a, b, label) {
  if (b <= a) throw new Error('BUILD MARKERS CROSSED for ' + label + ': end (' + b +
    ') is not after start (' + a + '). The build was reordered — fix the markers.');
  const s = SRC.slice(a, b);
  if (s.length < MIN_SPAN) throw new Error('MODULE SLICE TOO SMALL for ' + label +
    ': ' + s.length + ' chars, expected at least ' + MIN_SPAN + '.');
  return s;
}
function grabFrom(src, name, label) {
  const i = src.indexOf('function ' + name + '(');
  if (i < 0) throw new Error('BUILD MARKER MOVED in ' + (label || 'build') +
                             ': function ' + name);
  let d = 0, k = src.indexOf('{', i);
  if (k < 0) throw new Error('NO BODY FOUND for function ' + name);
  for (;; k++) {
    if (k >= src.length) throw new Error('UNBALANCED BRACES while reading function ' + name);
    if (src[k] === '{') d++; else if (src[k] === '}') { d--; if (!d) break; }
  }
  return src.slice(i, k + 1);
}
function grabFn(name) { return grabFrom(SRC, name, 'main build'); }
function grabDelta(name) { return grabFrom(DSRC, name, 'delta tool'); }
const MOD = {};
try {
{ // proc code table + behaviour panel
  const a = at('const PROC_CODE_BASELINE = {');
  const g = at('function getProcBehavior');
  const b = at('}', at('return PROC_CODE_EXCEPTIONS', g)) + 1;
  const m1 = at(/\/\/ ═+\n\/\/ v\d+ — PROC CODE BEHAVIOR PANEL/);
  const m2 = at('// ── EBOM manual column mapping (proof of concept)', m1);
  MOD.proc = span(a, b, 'proc:table') + '\n' + span(m1, m2, 'proc:panel') + `
globalThis.P = { abomProcCodeInventory, _procRowHtml, _procHeaderRow, PROC_JOB_SAMPLES,
  get PROC_CODE_EXCEPTIONS(){return PROC_CODE_EXCEPTIONS;},
  get PROC_CODE_BASELINE(){return PROC_CODE_BASELINE;},
  get dirty(){return _procDirtySinceRun;}, set dirty(v){_procDirtySinceRun=v;},
  setProcCodeMap, setProcCodeBehavior, getProcBehavior, isProcMapCustom,
  _procProfileLabel, _procCodesWithBehavior, _procCodeListText,
  exportProcProfile, importProcProfile, resetProcCodesToBaseline, _procMapEqualsBaseline,
  toggleProcCodePanel, renderProcCodePanel };`;
}
// v154 — buildEbomIndentureMap is now lifted from the build. It used to be a
// six-line stand-in written into the sandbox, and the ECN inheritance suites
// were certifying that stand-in rather than the shipping function. The two
// diverge on a self-referencing row (PN === NH), which is a real extract defect.
MOD.engine = grabFn('normPN') + '\n' + grabFn('buildAbomMap') + '\n' +
  grabFn('buildEbomIndentureMap') +
  '\nglobalThis.E = { normPN, buildAbomMap, buildEbomIndentureMap };';
// The delta tool's pure comparison layer. Its own file, its own baseline copy.
MOD.delta = (function () {
  // `var` here, `const` in the main build — hence the tolerant marker.
  const m = DSRC.match(/(?:var|const|let)\s+PROC_CODE_BASELINE\s*=\s*\{/);
  if (!m) throw new Error('BUILD MARKER MOVED in delta tool: PROC_CODE_BASELINE');
  const i = m.index;
  const j = DSRC.indexOf('}', i) + 1;
  // Status/column constants the report layer depends on.
  function constBlock(name) {
    const m = DSRC.match(new RegExp('(?:var|const|let)\\s+' + name + '\\s*=\\s*\\{'));
    if (!m) throw new Error('BUILD MARKER MOVED in delta tool: ' + name);
    const end = DSRC.indexOf('}', m.index);
    if (end < 0) throw new Error('unterminated ' + name + ' in delta tool');
    return DSRC.slice(m.index, end + 1) + ';';
  }
  const FNS = ['dNorm', 'normPN', 'pct', 'procTableOf', 'procProfileLabel', 'procTableDiff',
               'claimSig', 'claimRow', 'claimsDelta',
               'fscope', 'modeHasMbom', 'modeHasAbom', 'computeKpis', 'countByType',
               'ebomChanges', 'chpBom', 'ncrDispositionDelta'];
  return DSRC.slice(i, j) + ';\n' +
    ['DIRECT_OK', 'COVERED_OK', 'SCOPE_EXCLUDED', 'NCR_COL'].map(constBlock).join('\n') + '\n' +
    FNS.map(grabDelta).join('\n') +
    '\nglobalThis.D = { ' + FNS.join(', ') + ',' +
    ' get PROC_CODE_BASELINE(){return PROC_CODE_BASELINE;},' +
    ' get NCR_COL(){return NCR_COL;} };';
})();

// CHP release-state badge. Pure, and it drives a user-visible warning plus the
// release date printed on the freeze certificate.
MOD.chp = grabFn('_chpParseReleaseDate') + '\n' + grabFn('formatDcnDate') + '\n' +
  grabFn('chpReleaseState') + '\n' + grabFn('chpStateClass') + '\n' +
  '\nglobalThis.C = { _chpParseReleaseDate, formatDcnDate, chpReleaseState, chpStateClass };';
{ // ECN footprints
  const hit = at(/\/\/ v\d+ — ECN FOOTPRINT \(B1 \/ B2 \/ B4\)/);
  const a = lastAt('// ═══', hit, 'ECN FOOTPRINT header');
  MOD.ecn = span(a, at('function exportChangeCommitmentClosures()'), 'ecn:footprints') + '\n' +
    span(at('function _ecnStatusLooksClosed('), at('function exportPrematureEcnClosures('), 'ecn:status') +
    '\nglobalThis.B = { buildEcnFootprints, _chpEcnItemIndex, _ecnOpenDispositions, _ecnStatusLooksClosed };';
}
{ // untraced NCR dispositions
  const a = at('function computeUntracedNcrs()');
  const b = at(/\/\/ ── v\d+ — NCR DISPOSITIONS WITHOUT EBOM TRACE \(EXPORT\)/, a);
  const c = at('function exportUntracedNcrDispositions()');
  MOD.ncr = span(a, b, 'ncr:helper') + '\n' + span(c, at('// ── ACN KPI HELPER', c), 'ncr:export') +
    '\nglobalThis.N = { computeUntracedNcrs, exportUntracedNcrDispositions };';
}
} catch (e) {
  // Fail loudly, in words, and stop. A partial extraction is worse than no run:
  // in v153 a moved marker produced "21 passed, 5 failed" while 33 tests never
  // executed at all — a plausible-looking summary hiding a third of the suite.
  console.error('═'.repeat(60));
  console.error('EXTRACTION FAILED — NO TESTS WERE RUN.');
  console.error('');
  console.error('  ' + e.message);
  console.error('');
  console.error('The build was refactored and a marker in this harness needs');
  console.error('updating. This is not a fault in the build. Fix the marker in');
  console.error('the extraction block near the top of comparator-tests.js.');
  console.error('═'.repeat(60));
  process.exit(1);
}

// v154 — REAL stylesheet blocks. The old code used SRC.indexOf('<style'),
// which matches `<style:master-page` — an OpenDocument XML tag inside the
// vendored SheetJS library on line 28. The "stylesheet" every CSS test scanned
// was therefore ~58KB of minified JavaScript with the real CSS appended. That
// is where the mysterious -2 brace baseline came from: JS object literals, not
// CSS. Requiring `>` or whitespace after the tag name excludes the XML tags.
const STYLE_BLOCKS = (function () {
  const out = [];
  const re = /<style(?:\s[^>]*)?>([\s\S]*?)<\/style>/g;
  let m;
  while ((m = re.exec(SRC))) out.push({ css: m[1], at: m.index,
                                        line: SRC.slice(0, m.index).split('\n').length });
  if (!out.length) throw new Error('NO STYLE BLOCK FOUND — the build has no <style> tag?');
  return out;
})();

// Comment- and string-aware brace scan. Returns the LINE NUMBERS of unmatched
// braces rather than a net delta, so a failure says where to look. A net delta
// can also be zero when one stray `{` and one stray `}` cancel out.
function scanCss(text) {
  let i = 0, line = 1; const open = [], close = [];
  while (i < text.length) {
    const c = text[i];
    if (c === '\n') { line++; i++; continue; }
    if (c === '/' && text[i + 1] === '*') {                       // comment
      const e = text.indexOf('*/', i + 2);
      line += (text.slice(i, e < 0 ? text.length : e).match(/\n/g) || []).length;
      i = e < 0 ? text.length : e + 2; continue;
    }
    if (c === '"' || c === "'") {                                 // quoted string
      const q = c; i++;
      while (i < text.length && text[i] !== q) {
        if (text[i] === '\\') i++;
        if (text[i] === '\n') line++;
        i++;
      }
      i++; continue;
    }
    if (c === '{') { open.push(line); i++; continue; }
    if (c === '}') { open.length ? open.pop() : close.push(line); i++; continue; }
    i++;
  }
  return { unmatchedOpen: open, unmatchedClose: close,
           balanced: !open.length && !close.length };
}

// What each module must contain and must define once evaluated. Checked by the
// 'Tier 2 — extraction integrity' suite, so a module that extracts to something
// plausible-but-wrong is caught before its suite quietly passes.
const MODULE_CONTRACT = {
  proc:   { min: 6000, global: 'P',
            needs: ['PROC_CODE_BASELINE', 'function setProcCodeMap', 'function exportProcProfile'],
            exports: ['setProcCodeMap', 'exportProcProfile', '_procProfileLabel', 'getProcBehavior'] },
  engine: { min: 1000, global: 'E',
            needs: ['function normPN', 'function buildAbomMap', 'function buildEbomIndentureMap'],
            exports: ['normPN', 'buildAbomMap', 'buildEbomIndentureMap'] },
  ecn:    { min: 2000, global: 'B',
            needs: ['function buildEcnFootprints', 'function _ecnStatusLooksClosed'],
            exports: ['buildEcnFootprints', '_ecnStatusLooksClosed'] },
  ncr:    { min: 2000, global: 'N',
            needs: ['function computeUntracedNcrs', 'function exportUntracedNcrDispositions'],
            exports: ['computeUntracedNcrs', 'exportUntracedNcrDispositions'] },
  delta:  { min: 1500, global: 'D',
            needs: ['PROC_CODE_BASELINE', 'function claimSig', 'function procTableDiff'],
            exports: ['procTableOf', 'procTableDiff', 'claimSig', 'claimsDelta', 'dNorm',
                      'ebomChanges', 'computeKpis', 'ncrDispositionDelta', 'chpBom'] },
  chp:    { min: 1500, global: 'C',
            needs: ['function chpReleaseState', 'function formatDcnDate'],
            exports: ['chpReleaseState', 'formatDcnDate', '_chpParseReleaseDate', 'chpStateClass'] },
};

// ── sandbox ────────────────────────────────────────────────────────────────
function el() { return { textContent:'', innerHTML:'', value:'',
  classList:{ c:new Set(), toggle(n,v){v?this.c.add(n):this.c.delete(n);}, add(n){this.c.add(n);}, remove(n){this.c.delete(n);} } }; }
function sandbox(extra, mods) {
  const els = {};
  const ctx = Object.assign({
    console, JSON, Math, Date, Set, Map, Array, Object, String, Number, Boolean,
    RegExp, Error, isNaN, parseFloat, parseInt, Buffer, prompt: () => 'Test',
    document: { getElementById: id => (els[id] = els[id] || el()), querySelectorAll: () => [] },
    toast: () => {}, showError: () => {}, applySheetFont: () => {},
    // Captures what a download would have contained, so a test can read the
    // exported payload rather than merely confirm a call happened.
    Blob: class { constructor(parts, opts) {
      this.parts = parts || []; this.type = (opts || {}).type || '';
      this.text = this.parts.join(''); } },
    tsFilename: (b, e) => b + '.' + e, downloadFile: () => {}, FileReader: class { readAsText(f){ this.onload({target:{result:f._text}}); } },
    _STATUS_ADJUDICATED_LEAF: new Set(['adj_ok']),
    // NOTE: buildEbomIndentureMap used to be stubbed here. It is now extracted
    // from the build in MOD.engine, so any suite needing it must load 'engine'.
    __els: els,
  }, extra);
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  (mods || []).forEach(m => vm.runInContext(MOD[m], ctx, { filename: m + '.js' }));
  return ctx;
}

// ── runner ─────────────────────────────────────────────────────────────────
let TP = 0, TF = 0; const FAILED = [];
function suite(name, fn) {
  console.log('── ' + name + ' ' + '─'.repeat(Math.max(0, 56 - name.length)));
  let pass = 0, fail = 0;
  const t = (n, f) => { try { f(); console.log('  PASS  ' + n); pass++; }
                        catch (e) { console.log('  FAIL  ' + n + '\n        ' + e.message); fail++; } };
  const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b))
    throw new Error((m || '') + ' expected ' + JSON.stringify(b) + ' got ' + JSON.stringify(a)); };
  try { fn(t, eq); }
  catch (e) { console.log('  FAIL  SUITE CRASHED — its remaining tests did NOT run\n        ' + e.message); fail++; }
  console.log('  ' + pass + ' passed, ' + fail + ' failed\n');
  TP += pass; TF += fail; if (fail) FAILED.push(name);
}


suite('Engine — tagging changes reconciliation output', (t, eq) => {
  const ctx = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,procOverrides:null,procProfileName:null} },
    ['proc','engine']);
  const P = ctx.P, buildAbomMap = ctx.E.buildAbomMap;
  // usedOn=8 pn=9 procCode=12 qty=13 woNo=35 woStatus=36
  const arow=(pn,nh,proc,qty,wo)=>{const r=new Array(40).fill('');
    r[8]=nh;r[9]=pn;r[12]=proc;r[13]=qty;r[35]=wo||'WO1';r[36]='CLOSED';return r;};
  const build = rows => buildAbomMap(rows, 9, 8, 13, 35, 36, 12);
  const K='P100||A1';

  console.log('\n== A new program\'s removal code, before and after tagging ==');
  t('untagged XR behaves as an install', ()=>{
    P.setProcCodeMap(null);
    const m=build([arow('P100','A1','XR',2)]);
    eq(m[K].allProcsAreRemovalOrSwap,false); eq(m[K].qty,2);
  });
  t('tagging XR as remove flips the same rows to proc-removed', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const m=build([arow('P100','A1','XR',2)]);
    eq(m[K].allProcsAreRemovalOrSwap,true,'flagged:'); eq(m[K].qty,-2,'net qty:');
  });
  t('an install row alongside the removal nets out', ()=>{
    const m=build([arow('P100','A1','AI',3),arow('P100','A1','XR',1)]);
    eq(m[K].allProcsAreRemovalOrSwap,false); eq(m[K].qty,2);
  });

  console.log('\n== Swap semantics on a user-tagged code ==');
  t('swap-only key is treated as present, not removed', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('TSW','swap');
    const m=build([arow('P100','A1','TSW',4)]);
    eq(m[K].allProcsAreRemovalOrSwap,false,'swap-only must not read as removed:');
    eq(m[K].qty,4);
  });
  t('swap alongside an install is net-zero', ()=>{
    const m=build([arow('P100','A1','AI',5),arow('P100','A1','TSW',5)]);
    eq(m[K].qty,5); eq(m[K].allProcsAreRemovalOrSwap,false);
  });

  console.log('\n== The founding program is unaffected ==');
  t('baseline codes produce identical maps', ()=>{
    P.setProcCodeMap(null);
    const m=build([arow('P1','A','BR',2),arow('P1','A','AI',5),arow('P2','A','DR',3),
                   arow('P3','A','MR',1),arow('P4','A','OTHER',7)]);
    eq(m['P1||A'].qty,3,'5 installed - 2 removed:');
    eq(m['P2||A'].allProcsAreRemovalOrSwap,false,'swap-only present:');
    eq(m['P3||A'].allProcsAreRemovalOrSwap,true,'removal-only:');
    eq(m['P4||A'].qty,7,'unknown code installs:');
  });
  t('untagging one default changes that code and nothing else', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('BR','add');
    const m=build([arow('P1','A','BR',2),arow('P2','A','MR',2)]);
    eq(m['P1||A'].qty,2); eq(m['P2||A'].allProcsAreRemovalOrSwap,true,'MR still removes:');
  });

  console.log('\n== Dedup reaches the engine ==');
  t('mixed-case spellings of a tagged code are all classified', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const m=build([arow('P100','A1','xr',1),arow('P100','A1',' XR ',1)]);
    eq(m[K].allProcsAreRemovalOrSwap,true); eq(m[K].qty,-2);
  });

  console.log('\n== Worker stays in lockstep ==');
  t('the serialized worker table is the ACTIVE table', ()=>{
    P.setProcCodeMap(null); P.setProcCodeBehavior('XR','remove');
    const decl='const PROC_CODE_EXCEPTIONS = '+JSON.stringify(P.PROC_CODE_EXCEPTIONS)+';';
    if(!decl.includes('"XR":"remove"')) throw new Error('worker would not see XR');
    const box={}; new Function('o', decl+' o.map = PROC_CODE_EXCEPTIONS;')(box);
    eq(box.map['XR'],'remove'); eq(box.map['BR'],'remove','defaults carried:');
  });
});

suite('Proc code panel — job number samples', (t, eq) => {
  const ctx = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,procOverrides:null,procProfileName:null} }, ['proc']);
  const T = ctx.P, state = ctx.state, els = ctx.__els;
  // Mapping 1 row: job at 5, desc at 10, proc at 12
  const row=(proc,job,desc)=>{const r=new Array(40).fill('');r[12]=proc;r[5]=job||'';r[10]=desc||'';return r;};
  const load=rows=>{state.boms.abom={data:rows};};
  const jobsOf=c=>[...(T.abomProcCodeInventory().codes.find(x=>x.code===c)||{jobs:new Set()}).jobs];

  console.log('\n== Job numbers collected and deduplicated ==');
  t('distinct job numbers only', ()=>{
    load([row('XR','J100'),row('XR','J100'),row('XR','J200'),row('XR','J100')]);
    eq(jobsOf('XR'),['J100','J200']);
  });
  t('job numbers are kept verbatim (no normalising)', ()=>{
    load([row('XR',' J-100/A ')]);
    eq(jobsOf('XR'),['J-100/A'],'trimmed but not uppercased:');
  });
  t('blank job numbers are skipped, not stored as empty', ()=>{
    load([row('XR',''),row('XR','   '),row('XR','J1')]);
    eq(jobsOf('XR'),['J1']);
  });
  t('each proc code keeps its own job set', ()=>{
    load([row('XR','J1'),row('TSW','J2'),row('XR','J3')]);
    eq(jobsOf('XR'),['J1','J3']); eq(jobsOf('TSW'),['J2']);
  });

  console.log('\n== Panel renders at most 3, one per line ==');
  function cell(html){const m=html.match(/<span class="pcm-jobs">([\s\S]*?)<\/span><span class="pcm-seg">/);return m?m[1]:'';}
  t('exactly 3 shown when more exist, with overflow count', ()=>{
    load([1,2,3,4,5,6,7].map(i=>row('XR','J'+i)));
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    const shown=(c.match(/class="pcm-job"/g)||[]).length;
    eq(shown,3,'job lines rendered:');
    if(!c.includes('+4 more')) throw new Error('overflow missing: '+c);
  });
  t('fewer than 3 renders only what exists, no overflow', ()=>{
    load([row('XR','J1'),row('XR','J2')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,2);
    if(c.includes('more')) throw new Error('false overflow');
  });
  t('exactly 3 shows no overflow', ()=>{
    load([row('XR','J1'),row('XR','J2'),row('XR','J3')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,3);
    if(c.includes('more')) throw new Error('false overflow at exactly 3');
  });
  t('each job is its own element (stacks as a row)', ()=>{
    load([row('XR','J1'),row('XR','J2')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq(c.match(/<span class="pcm-job">/g).length,2,'separate elements:');
  });
  t('no job numbers on the rows says so', ()=>{
    load([row('XR','')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    if(!c.includes('No job number')) throw new Error(c);
  });
  t('a code absent from the file says so', ()=>{
    load([row('XR','J1')]);
    const c=cell(T._procRowHtml({code:'BR',rows:0,jobs:new Set(),variants:new Set()}));
    if(!c.includes('Not present in this ABOM')) throw new Error(c);
  });
  t('job numbers are HTML-escaped', ()=>{
    load([row('XR','<script>x</script>')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    if(c.includes('<script>')) throw new Error('unescaped');
    if(!c.includes('&lt;script&gt;')) throw new Error('not escaped: '+c);
  });

  console.log('\n== The removed hint is gone ==');
  t('no removal hint anywhere in the rendered row', ()=>{
    load([row('XR','J1','PANEL, REMOVABLE, LH'),row('XR','J2','COVER, REMOVABLE')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(/desc says removal|removalish/i.test(h)) throw new Error('hint still present');
  });
  t('description is not rendered at all', ()=>{
    load([row('XR','J1','BRACKET, SUPPORT, LH')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(h.includes('BRACKET')) throw new Error('description still shown');
  });
  t('spellings-merged note survives (moved onto the code cell)', ()=>{
    load([row('XR','J1'),row('xr','J2')]);
    const h=T._procRowHtml(T.abomProcCodeInventory().codes[0]);
    if(!h.includes('2 spellings merged')) throw new Error('lost the variant note');
  });

  console.log('\n== Mapping 2: description is blank, job numbers are not ==');
  t('panel still informative under Mapping 2 (desc always empty)', ()=>{
    // Mapping 2 sets COL.abom.desc = '' but populates jobNo from source col A.
    load([row('XR','J900',''),row('XR','J901','')]);
    const c=cell(T._procRowHtml(T.abomProcCodeInventory().codes[0]));
    eq((c.match(/class="pcm-job"/g)||[]).length,2,'jobs present where desc never was:');
  });

  console.log('\n== Header aligns to the grid ==');
  t('header has the same 4 cells as a row', ()=>{
    const hd=T._procHeaderRow();
    eq((hd.match(/<span/g)||[]).length,4);
    if(!hd.includes('Job Numbers (samples)')) throw new Error('title wrong: '+hd);
  });
});

// ── TIER 1 ─────────────────────────────────────────────────────────────────
// Regression guards for two defects found in v153 and fixed in v154.
//
//   A. exportProcProfile()'s Cancel guard was dead code. `(prompt(...) || '')
//      .trim()` turned a null return into '' BEFORE the `=== null` check ran,
//      so pressing Cancel still downloaded a file and still overwrote
//      state.procProfileName with 'Unnamed profile'.
//
//   B. setProcCodeMap(map, profileName) ignored profileName on the `!map`
//      path and hard-set state.procProfileName = null. The session importer
//      calls exactly that path, so a profile NAME did not survive an export →
//      import round-trip even though the proc code BEHAVIOUR did. A re-opened
//      session reported 'Program baseline' where the original said the
//      program's name.
//
// The name is provenance; the overrides are the deviation. These tests pin
// that separation, because both defects were failures of exactly that
// distinction.
suite('Tier 1 — proc code profile name is provenance', (t, eq) => {
  // The two lines the session exporter writes and the one line the importer
  // reads. Lifted verbatim so that REWIRING the session — not just breaking
  // setProcCodeMap — also fails this suite.
  const SESSION_WRITE = ['procOverrides:   state.procOverrides   || null',
                         'procProfileName: state.procProfileName || null'];
  const SESSION_READ  = 'setProcCodeMap(payload.procOverrides || null, ' +
                        'payload.procProfileName || null)';

  let DL = [], PROMPT = null;
  const ctx = sandbox({
    COL: { abom: { procCode: 12, desc: 10, jobNo: 5 } },
    state: { boms:{abom:null}, results:[], isLocked:false,
             procOverrides:null, procProfileName:null },
    prompt: () => PROMPT,
    downloadFile: (n, b) => DL.push({ name: n, text: b && b.text }),
  }, ['proc']);
  const P = ctx.P, state = ctx.state;

  const reset = () => { DL = []; PROMPT = null; P.setProcCodeMap(null); };
  const payloadOf = () => JSON.parse(DL[0].text);
  // Push state through JSON exactly as a session file does, then restore it
  // the way the importer does, in a context that has been wiped first.
  function roundTrip() {
    ctx.__j = JSON.stringify({ procOverrides:   state.procOverrides   || null,
                               procProfileName: state.procProfileName || null });
    P.setProcCodeMap(null);                       // a fresh browser
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
  }
  ctx.__run = src => require('vm').runInContext(src, ctx, { filename: 'session.js' });

  console.log('\n== Defect A: Cancel must export nothing and change nothing ==');
  t('Cancel downloads no file', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = null;                                 // user pressed Cancel
    P.exportProcProfile();
    eq(DL.length, 0, 'files written on Cancel:');
  });
  t('Cancel leaves the existing profile name untouched', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    PROMPT = null;
    P.exportProcProfile();
    eq(state.procProfileName, 'Program Falcon', 'name after Cancel:');
  });
  t('confirming an EMPTY name still exports, as Unnamed profile', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = '';                                   // user pressed OK on a blank box
    P.exportProcProfile();
    eq(DL.length, 1, 'blank-but-confirmed must still export:');
    eq(payloadOf().profileName, 'Unnamed profile');
  });
  t('a real name reaches the payload and the state', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    PROMPT = '  Program Falcon  ';                 // and is trimmed
    P.exportProcProfile();
    eq(payloadOf().profileName, 'Program Falcon');
    eq(state.procProfileName, 'Program Falcon');
    eq(payloadOf().basedOn, 'custom', 'a tagged table is a deviation:');
  });

  console.log('\n== Defect B: the name survives a session round-trip ==');
  t('the session still carries both proc fields', () => {
    SESSION_WRITE.forEach(s => {
      if (!SRC.includes(s)) throw new Error('exporter no longer writes: ' + s); });
    if (!SRC.includes(SESSION_READ)) throw new Error('importer no longer reads it');
  });
  t('a CUSTOM profile keeps its name through export and import', () => {
    reset(); P.setProcCodeMap({ XR:'remove', TSW:'swap' }, 'Program Falcon');
    roundTrip();
    eq(state.procProfileName, 'Program Falcon', 'name after round-trip:');
    eq(P.PROC_CODE_EXCEPTIONS.XR, 'remove', 'and the behaviour came with it:');
    eq(P.isProcMapCustom(), true);
  });
  t('a BASELINE-EQUAL profile keeps its name through export and import', () => {
    // importProcProfile drops the custom flag but keeps the name when the
    // shared file happens to match the baseline. That is the exact shape that
    // hit the null path in setProcCodeMap and lost the name.
    reset();
    P.importProcProfile({ _text: JSON.stringify({
      schema: 'bom-comparator-proc-profile', profileName: 'Program Falcon',
      procCodes: P.PROC_CODE_BASELINE }) });
    eq(P.isProcMapCustom(), false, 'baseline-equal is not a deviation:');
    eq(state.procProfileName, 'Program Falcon', 'but the name is kept:');
    roundTrip();
    eq(state.procProfileName, 'Program Falcon', 'and survives the session:');
    eq(P.isProcMapCustom(), false, 'still not a deviation:');
  });
  t('a session with no proc fields at all restores as clean baseline', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = '{}';                                // a pre-v153 session file
    P.setProcCodeMap(null);
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq([state.procProfileName, state.procOverrides], [null, null]);
    eq(P.PROC_CODE_EXCEPTIONS.BR, 'remove', 'baseline is live:');
  });

  console.log('\n== The name/override split, stated directly ==');
  t('setProcCodeMap(null, name) keeps the name; setProcCodeMap(null) clears it', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.setProcCodeMap(null, 'Program Falcon');
    eq([state.procProfileName, state.procOverrides], ['Program Falcon', null],
       'named null-path:');
    P.setProcCodeMap(null);
    eq(state.procProfileName, null, 'bare null-path still clears:');
  });
  t('untagging back to baseline keeps the name, but Reset clears it', () => {
    // Two different acts. Editing your way back is not the same as declaring
    // you are done with the profile, and only the second should erase it.
    reset();
    P.setProcCodeMap(P.PROC_CODE_BASELINE, 'Program Falcon');
    P.setProcCodeBehavior('XR', 'remove');
    eq(P.isProcMapCustom(), true, 'tagging forks the table:');
    P.setProcCodeBehavior('XR', 'add');            // untag it again
    eq(P.isProcMapCustom(), false, 'back to baseline, flag dropped:');
    eq(state.procProfileName, 'Program Falcon', 'name held:');
    P.resetProcCodesToBaseline();
    eq(state.procProfileName, null, 'explicit Reset clears it:');
  });
  t('the freeze certificate label is identical before and after a round-trip', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    const before = P._procProfileLabel();
    roundTrip();
    eq(P._procProfileLabel(), before, 'label drift:');
    eq(before, 'Program Falcon');
  });
  t('an unnamed custom table reads as Custom, not as the baseline', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P._procProfileLabel(), 'Custom');
    roundTrip();
    eq(P._procProfileLabel(), 'Custom', 'and stays Custom after a round-trip:');
  });
  t('a rejected profile file changes nothing', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.importProcProfile({ _text: JSON.stringify({ schema: 'something-else',
      profileName: 'Hostile', procCodes: { BR:'swap' } }) });
    eq(state.procProfileName, 'Program Falcon', 'name untouched:');
    eq(P.PROC_CODE_EXCEPTIONS.XR, 'remove', 'table untouched:');
  });
});

// ── TIER 2 ─────────────────────────────────────────────────────────────────
// Until v154 the sandbox defined its own six-line buildEbomIndentureMap and the
// ECN inheritance suites tested THAT. The real function is ~60 lines and returns
// three structures, not one. They agree on clean data and diverge on a
// self-referencing row. These tests exercise the shipping function.
suite('Tier 2 — EBOM indenture map (the real one)', (t, eq) => {
  const ctx = sandbox({}, ['engine']);
  const build = ctx.E.buildEbomIndentureMap;
  // indenture=0, pn=1, nh=3 — the shape COL.ebom uses elsewhere in this file.
  const row = (ind, pn, nh) => { const r = new Array(10).fill('');
    r[0] = ind; r[1] = pn; r[3] = nh; return r; };
  const map  = rows => build(rows, 0, 1, 3);
  const kids = (m, k) => (m.keyInfo[k] ? [...m.keyInfo[k].childKeys].sort() : '(no such key)');

  console.log('\n== Structure the build actually consumes ==');
  t('returns all three structures, not just keyInfo', () => {
    const m = map([row('A', 'TOP', '')]);
    eq(Object.keys(m).sort(), ['keyInfo', 'pnToIndenture', 'pnToNh']);
  });
  t('a clean three-level tree links each level to the next, not transitively', () => {
    const m = map([row('A','TOP',''), row('B','MID','TOP'), row('C','LEAF','MID')]);
    eq(kids(m, 'TOP||'),     ['MID||TOP'], 'top:');
    eq(kids(m, 'MID||TOP'),  ['LEAF||MID'], 'middle:');
    eq(kids(m, 'LEAF||MID'), [], 'leaf:');
  });
  t('a deep chain stays one link per level', () => {
    const rows = [row('A','L0','')];
    for (let i = 1; i <= 8; i++) rows.push(row('B','L'+i,'L'+(i-1)));
    const m = map(rows);
    for (let i = 0; i < 8; i++)
      eq(kids(m, 'L'+i+'||'+(i ? 'L'+(i-1) : '')), ['L'+(i+1)+'||L'+i], 'level '+i+':');
  });
  t('a PN under two different NHs makes the child a child of BOTH keys', () => {
    const m = map([row('A','TOP',''), row('B','P1','TOP'), row('B','P1','OTHER'), row('C','KID','P1')]);
    eq(kids(m, 'P1||TOP'),   ['KID||P1'], 'first parent key:');
    eq(kids(m, 'P1||OTHER'), ['KID||P1'], 'second parent key:');
  });

  console.log('\n== Where the old stand-in was wrong ==');
  t('a self-referencing row (PN === NH) becomes its own child', () => {
    // A part listed as its own next-higher assembly — a real extract defect.
    // The shipping function creates a self-loop here. The old stand-in excluded
    // self and reported ["Y||X"], so this behaviour was invisible to the harness.
    const m = map([row('A','X','X'), row('B','Y','X')]);
    eq(kids(m, 'X||X'), ['X||X', 'Y||X'], 'self-loop is real:');
  });
  t('the ECN inheritance walk terminates on that self-loop and still inherits', () => {
    const c = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3}, chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
      state:{results:[], boms:{ebom:null, chp:null}} }, ['proc','engine','ecn']);
    const R = (pn, nh, ecn) => ({ key: pn+'||'+nh, pn, nh, overall:'ok', as:'ok',
      woStatus:'closed', woValues:['W1'],
      trace: ecn ? { dcn:new Map(), ecn:new Map(ecn), ecr:new Map() } : null,
      ncrEntriesPool1:[], ncrEntriesPool2:[] });
    c.state.results = [R('X','X',[['E1','']]), R('Y','X',null)];
    c.state.boms.ebom = { data:[row('A','X','X'), row('B','Y','X')] };
    const e = c.B.buildEcnFootprints().ecnMap.get('E1');   // must return, not hang
    eq(e.items.length, 2, 'child inherited across the self-loop:');
    eq(e.items.map(x => x.r.key).sort(), ['X||X', 'Y||X']);
    // Y holds no ECN of its own — it must be marked as inherited from X.
    const y = e.items.find(x => x.r.key === 'Y||X');
    eq(y.inheritedVia, 'X||X', 'inheritance provenance:');
    eq(e.items.find(x => x.r.key === 'X||X').inheritedVia, '', 'the anchor is direct:');
  });

  console.log('\n== Indexing rules ==');
  t('a row with a blank NH is indexed but never linked as a child', () => {
    const m = map([row('A','TOP',''), row('B','ORPHAN','')]);
    eq(kids(m, 'TOP||'), [], 'a blank NH must not read as "child of everything":');
    if (!m.keyInfo['ORPHAN||']) throw new Error('the orphan row was dropped from keyInfo');
  });
  t('a row with a blank PN is skipped entirely', () => {
    const m = map([row('A','TOP',''), row('B','','TOP')]);
    eq(Object.keys(m.keyInfo).sort(), ['TOP||']);
  });
  t('pnToIndenture keeps the FIRST occurrence and does not overwrite', () => {
    const m = map([row('B','P1','TOP'), row('E','P1','OTHER')]);
    eq(m.pnToIndenture['P1'], 'B', 'later rows must not win:');
  });
  t('pnToNh keeps the FIRST occurrence and does not overwrite', () => {
    const m = map([row('B','P1','TOP'), row('B','P1','OTHER')]);
    eq(m.pnToNh['P1'], 'TOP');
  });
  t('case and whitespace variants collapse to one key', () => {
    const m = map([row('a',' top ',''), row('b','MID','TOP'), row('b','mid','top')]);
    eq(Object.keys(m.keyInfo).sort(), ['MID||TOP', 'TOP||'], 'normalised:');
    eq(kids(m, 'TOP||'), ['MID||TOP']);
  });
});

// The harness's own safety net. HARNESS.md promises that a moved marker "fails
// loudly and names it" — before v154 that was true only for markers routed
// through at(). Four boundaries used raw indexOf, where a miss returns -1 and
// produces a silently EMPTY module: every suite green, nothing tested.
suite('Tier 2 — extraction integrity', (t, eq) => {
  const DEPS = { proc:['proc'], engine:['engine'],
                 ecn:['proc','engine','ecn'], ncr:['ncr'], chp:['chp'], delta:['delta'] };

  t('every module is substantial and contains what it claims', () => {
    Object.keys(MODULE_CONTRACT).forEach(name => {
      const c = MODULE_CONTRACT[name], src = MOD[name];
      if (!src || src.length < c.min)
        throw new Error(name + ': ' + (src ? src.length : 0) + ' chars, expected >= ' + c.min);
      c.needs.forEach(n => { if (!src.includes(n))
        throw new Error(name + ' is missing ' + JSON.stringify(n) + ' — wrong slice'); });
    });
  });
  t('every module defines its global once evaluated', () => {
    Object.keys(MODULE_CONTRACT).forEach(name => {
      const c = MODULE_CONTRACT[name];
      const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3}, abom:{procCode:12,desc:10,jobNo:5},
        chp:{pn:3,nh:5,ecn:18}, ncr:{ncrNum:60,dispNo:71}},
        state:{results:[], boms:{}, isLocked:false, procOverrides:null, procProfileName:null} },
        DEPS[name]);
      if (!ctx[c.global]) throw new Error(name + ' did not define globalThis.' + c.global);
      c.exports.forEach(fn => { if (typeof ctx[c.global][fn] !== 'function')
        throw new Error(name + '.' + c.global + '.' + fn + ' is not a function'); });
    });
  });
  t('no global exists without its module — an empty run cannot pass', () => {
    const c = sandbox({}, []);
    ['P','E','B','N'].forEach(g => { if (c[g])
      throw new Error(g + ' exists with no module loaded'); });
  });

  console.log('\n== The guards themselves ==');
  const throws = (fn, want, label) => {
    let msg = null;
    try { fn(); } catch (e) { msg = e.message; }
    if (msg === null) throw new Error(label + ' did not throw');
    if (msg.indexOf(want) < 0) throw new Error(label + ' threw the wrong thing: ' + msg);
  };
  t('a missing marker throws and names itself', () => {
    throws(() => at('NO SUCH MARKER IN THIS BUILD'), 'BUILD MARKER MOVED', 'at()');
    throws(() => at('NO SUCH MARKER IN THIS BUILD'), 'NO SUCH MARKER', 'at() naming');
  });
  t('a backwards marker search is guarded too', () => {
    throws(() => lastAt('NO SUCH MARKER IN THIS BUILD', 5000, 'probe'),
           'BUILD MARKER MOVED', 'lastAt()');
  });
  t('crossed boundaries are refused, not silently emptied', () => {
    // This is the exact shape a raw indexOf miss produced: end before start.
    throws(() => span(1124358, 400, 'probe'), 'BUILD MARKERS CROSSED', 'span()');
  });
  t('a suspiciously small slice is refused', () => {
    throws(() => span(0, 50, 'probe'), 'MODULE SLICE TOO SMALL', 'span()');
  });
  t('grabFn refuses a function that is not there', () => {
    throws(() => grabFn('thisFunctionDoesNotExistAnywhere'), 'BUILD MARKER MOVED', 'grabFn()');
  });

  console.log('\n== The build is still what it claims to be ==');
  t('no external script or stylesheet — the file is genuinely offline', () => {
    const ext = [...SRC.matchAll(/<script[^>]*\ssrc\s*=/gi)].length +
                [...SRC.matchAll(/<link[^>]*rel=["']stylesheet["']/gi)].length;
    if (ext) throw new Error(ext + ' external reference(s) — the build is no longer self-contained');
  });
  t('the file read is the file reported', () => {
    eq(fs.readFileSync(BUILD, 'utf8').length, SRC.length);
    if (!/^<!DOCTYPE html/i.test(SRC.trim())) throw new Error('not an HTML document');
  });
});

// ── TIER 3 ─────────────────────────────────────────────────────────────────
// The CHP release badge. Pure logic, user-visible warning, and the release date
// it produces is printed on the freeze certificate — an audit artefact.
suite('Tier 3 — CHP release state', (t, eq) => {
  const C = sandbox({}, ['chp']).C;
  const trace = (dcn, ecn, ecr) => ({
    dcn: new Map(dcn || []), ecn: new Map(ecn || []), ecr: new Map(ecr || []) });
  const st = (...a) => C.chpReleaseState(trace(...a));

  console.log('\n== No history, and history without a DCN ==');
  t('a null trace reads as NO HISTORY, not as a warning', () => {
    const s = C.chpReleaseState(null);
    eq([s.state, s.label, s.warn, s.dcnCount], ['none', 'NO HISTORY', false, 0]);
  });
  t('a trace with three empty maps also reads as NO HISTORY', () => {
    eq(st([], [], []).state, 'none');
  });
  t('an ECN with no DCN reads as NO DCN and is NOT a warning', () => {
    // Expected for COTS parts: release is held by the parent that owns the DCN.
    const s = st([], [['E1', 'Open']], []);
    eq([s.state, s.label, s.warn], ['no_dcn', 'NO DCN', false]);
  });
  t('an ECR alone also reads as NO DCN', () => {
    eq(st([], [], [['R1', '']]).state, 'no_dcn');
  });

  console.log('\n== Released ==');
  t('one dated DCN reads as RELEASED with no count suffix', () => {
    const s = st([['D1', '2024-03-15']]);
    eq([s.state, s.warn, s.dcnCount], ['released', false, 1]);
    eq(s.label, 'RELEASED MARCH 15, 2024');
  });
  t('several dated DCNs report the LATEST date and the count', () => {
    const s = st([['D1', '2024-01-05'], ['D2', '2024-06-30'], ['D3', '2024-03-15']]);
    eq(s.date, 'JUNE 30, 2024', 'latest wins:');
    eq(s.label, 'RELEASED JUNE 30, 2024 \u00b7 3 DCNs');
    eq(s.dcnCount, 3);
  });
  t('order of arrival does not change which date wins', () => {
    const a = st([['D1', '2024-06-30'], ['D2', '2024-01-05']]).date;
    const b = st([['D1', '2024-01-05'], ['D2', '2024-06-30']]).date;
    eq(a, b);
  });

  console.log('\n== Unreleased: the warning that matters ==');
  t('an undated DCN raises the warning and names the offender', () => {
    const s = st([['D1', 'Unknown']]);
    eq([s.state, s.warn, s.label], ['unreleased', true, '\u26a0 DCN NOT RELEASED']);
    eq(s.undated, ['D1']);
    if (!s.note.includes('D1')) throw new Error('the note must name the DCN');
  });
  t('ONE undated DCN outweighs any number of dated ones', () => {
    // The safe direction: a partially-scoped extract must not read as released.
    const s = st([['D1', '2024-03-15'], ['D2', ''], ['D3', '2024-06-30']]);
    eq([s.state, s.warn], ['unreleased', true]);
    eq(s.undated, ['D2']);
  });
  t('every undated DCN is listed, not just the first', () => {
    eq(st([['D1', ''], ['D2', 'TBD'], ['D3', '2024-03-15']]).undated, ['D1', 'D2']);
  });
  t('unparseable text counts as undated, not as a date', () => {
    ['Unknown', 'TBD', 'N/A', 'RELEASED', '   ', ''].forEach(v => {
      eq(C.chpReleaseState(trace([['D1', v]])).state, 'unreleased', JSON.stringify(v) + ':');
    });
  });

  console.log('\n== Date shapes the extract actually produces ==');
  t('a Date object from cellDates:true is accepted', () => {
    eq(st([['D1', new Date(2024, 2, 15)]]).date, 'MARCH 15, 2024');
  });
  t('a stringified Date is accepted — this is the real path', () => {
    // buildChpTraceMap does String(row[...]) before storing, so the Date object
    // branch is mostly bypassed in practice.
    eq(st([['D1', String(new Date(2024, 2, 15))]]).date, 'MARCH 15, 2024');
  });
  t('ISO, slash and DD-MON forms all give the same calendar date', () => {
    ['2024-03-15', '2024-03-15T08:30:00Z', '2024-03-15 08:30:00',
     '3/15/2024', '15-MAR-2024'].forEach(v => {
      eq(C.formatDcnDate(v), 'MARCH 15, 2024', JSON.stringify(v) + ':');
    });
  });
  t('an invalid Date object is treated as undated', () => {
    eq(st([['D1', new Date('nonsense')]]).state, 'unreleased');
  });

  console.log('\n== Defect C: the same day everywhere on earth ==');
  t('the displayed date does not depend on the reader\'s timezone', () => {
    // v153 read UTC components off a date built at LOCAL midnight, so a DCN
    // released 15 March showed as MARCH 14 in Tokyo, Sydney and Kolkata.
    // Node reads process.env.TZ at first Date use, so this runs a child.
    const cp = require('child_process');
    const probe = 'const v=process.argv[1];' + MOD.chp +
      ';console.log(formatDcnDate(v==="obj"?new Date(2024,2,15):v));';
    ['2024-03-15', '3/15/2024', '15-MAR-2024', 'obj'].forEach(shape => {
      ['UTC', 'America/New_York', 'Asia/Tokyo', 'Australia/Sydney', 'Asia/Kolkata',
       'Pacific/Kiritimati'].forEach(tz => {
        const got = cp.execFileSync(process.execPath, ['-e', probe, shape],
                     { env: Object.assign({}, process.env, { TZ: tz }) }).toString().trim();
        if (got !== 'MARCH 15, 2024')
          throw new Error(shape + ' in ' + tz + ' -> ' + got);
      });
    });
  });
  t('no UTC component read survives in the date formatter', () => {
    if (/getUTC(Month|Date|FullYear)/.test(MOD.chp))
      throw new Error('formatDcnDate is reading UTC components again');
  });

  console.log('\n== Badge styling ==');
  t('only the unreleased state is styled as a warning', () => {
    eq(C.chpStateClass('unreleased'), 'badge badge-chp-warn');
    eq(C.chpStateClass('none'), '', 'no history gets no badge:');
    eq(C.chpStateClass('released'), 'badge badge-history');
    eq(C.chpStateClass('no_dcn'), 'badge badge-history', 'NO DCN is not a warning:');
  });
  t('every state chpReleaseState can return has a class', () => {
    ['none', 'no_dcn', 'released', 'unreleased'].forEach(s => {
      if (typeof C.chpStateClass(s) !== 'string')
        throw new Error('no class for state ' + s);
    });
  });
});

// The proc code table under adversarial conditions: a frozen report, a
// hand-edited profile file, and a session carrying someone else's provenance.
suite('Tier 3 — proc table under lock, bad input, and session reuse', (t, eq) => {
  const SESSION_READ = 'setProcCodeMap(payload.procOverrides || null, ' +
                       'payload.procProfileName || null)';
  const ctx = sandbox({
    COL: { abom: { procCode: 12, desc: 10, jobNo: 5 } },
    state: { boms:{abom:null}, results:[], isLocked:false,
             procOverrides:null, procProfileName:null },
  }, ['proc']);
  const P = ctx.P, state = ctx.state;
  ctx.__run = src => require('vm').runInContext(src, ctx, { filename: 'session.js' });
  const reset = () => { state.isLocked = false; state.results = []; P.dirty = false;
                        P.setProcCodeMap(null); };
  const profile = o => ({ _text: JSON.stringify(Object.assign(
    { schema: 'bom-comparator-proc-profile' }, o)) });

  console.log('\n== A frozen report must not move ==');
  t('tagging a code is refused while the report is locked', () => {
    reset(); state.isLocked = true;
    P.setProcCodeBehavior('XR', 'remove');
    eq([P.isProcMapCustom(), state.procOverrides], [false, null], 'table changed under lock:');
  });
  t('reset to baseline is refused while the report is locked', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    state.isLocked = true;
    P.resetProcCodesToBaseline();
    eq([P.isProcMapCustom(), state.procProfileName], [true, 'Program Falcon'], 'reset ran anyway:');
  });
  t('unlocking restores both operations', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P.getProcBehavior('XR'), 'remove');
    P.resetProcCodesToBaseline();
    eq(P.isProcMapCustom(), false);
  });

  console.log('\n== A hand-edited profile file ==');
  t('a wrong schema is rejected and changes nothing', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    P.importProcProfile(profile({ schema:'something-else', procCodes:{ BR:'swap' } }));
    eq([P.PROC_CODE_EXCEPTIONS.XR, state.procProfileName], ['remove', 'Program Falcon']);
  });
  t('an invalid behaviour value is dropped, not installed', () => {
    reset();
    P.importProcProfile(profile({ profileName:'Bad', procCodes:{ XR:'remove', TSW:'delete' } }));
    eq(P.getProcBehavior('XR'), 'remove', 'the valid entry survives:');
    eq(P.getProcBehavior('TSW'), 'add', '"delete" is not a behaviour:');
  });
  t('an empty procCodes map installs a table with no removal codes', () => {
    // A deliberate act — every code untagged — not the same as the baseline.
    reset();
    P.importProcProfile(profile({ profileName:'Nothing', procCodes:{} }));
    eq(P.isProcMapCustom(), true, 'still a deviation:');
    eq(P.getProcBehavior('BR'), 'add', 'baseline BR no longer removes:');
  });
  t('a profile identical to the baseline keeps its name but drops the flag', () => {
    reset();
    P.importProcProfile(profile({ profileName:'Program Falcon',
                                  procCodes: P.PROC_CODE_BASELINE }));
    eq([P.isProcMapCustom(), state.procProfileName], [false, 'Program Falcon']);
  });

  console.log('\n== Defect D: provenance must not leak between loads ==');
  t('an unnamed custom session does NOT inherit the previous profile name', () => {
    // v153: setProcCodeMap fell back to `|| state.procProfileName`, so loading
    // "Program Falcon" and then importing an unnamed session left the freeze
    // certificate still claiming Falcon.
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = JSON.stringify({ procOverrides:{ TSW:'swap' }, procProfileName:null });
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq(state.procProfileName, null, 'stale name survived:');
    eq(P._procProfileLabel(), 'Custom');
  });
  t('a named session overwrites the previous name rather than merging', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = JSON.stringify({ procOverrides:{ TSW:'swap' }, procProfileName:'Program Kestrel' });
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq(state.procProfileName, 'Program Kestrel');
  });
  t('a baseline session clears a previously loaded profile entirely', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, 'Program Falcon');
    ctx.__j = '{}';
    ctx.__run(`var payload = JSON.parse(__j); ${SESSION_READ};`);
    eq([state.procProfileName, state.procOverrides], [null, null]);
    eq(P.getProcBehavior('BR'), 'remove', 'baseline is live again:');
  });

  console.log('\n== The stale-results flag ==');
  t('tagging with no results on screen does not raise the dirty flag', () => {
    reset(); P.setProcCodeBehavior('XR', 'remove');
    eq(P.dirty, false, 'nothing to invalidate yet:');
  });
  t('tagging AFTER a run marks the results stale', () => {
    reset(); state.results = [{}];
    P.setProcCodeBehavior('XR', 'remove');
    eq(P.dirty, true);
  });
  t('resetting after a run also marks the results stale', () => {
    reset(); P.setProcCodeMap({ XR:'remove' }, null); state.results = [{}];
    P.resetProcCodesToBaseline();
    eq(P.dirty, true);
  });
  t('a locked report cannot be made dirty', () => {
    reset(); state.results = [{}]; state.isLocked = true;
    P.setProcCodeBehavior('XR', 'remove');
    P.resetProcCodesToBaseline();
    eq(P.dirty, false);
  });
});

// ── TIER 4 ─────────────────────────────────────────────────────────────────
// The delta tool: a second shipped file with no coverage at all until v154.
// Its whole job is to tell two sessions apart, so a field it fails to compare
// is a wrong answer, not a missing feature.
suite('Tier 4 — delta tool', (t, eq) => {
  const D = sandbox({}, ['delta']).D;
  const P = sandbox({ COL:{abom:{procCode:12,desc:10,jobNo:5}},
    state:{boms:{abom:null},results:[],isLocked:false,
           procOverrides:null,procProfileName:null} }, ['proc']).P;

  console.log('\n== The duplicated baseline ==');
  t('the delta tool\'s PROC_CODE_BASELINE matches the main build\'s, key for key', () => {
    // The delta tool ships its own copy. Its own comment says it "mirrors the
    // main build's shipped proc code table" — nothing enforced that. If the
    // main build gains a code and this copy does not, the delta tool reports
    // two sessions as agreeing on proc codes when they do not.
    const a = P.PROC_CODE_BASELINE, b = D.PROC_CODE_BASELINE;
    const ka = Object.keys(a).sort(), kb = Object.keys(b).sort();
    const onlyMain = ka.filter(k => !(k in b)), onlyDelta = kb.filter(k => !(k in a));
    if (onlyMain.length || onlyDelta.length)
      throw new Error('BASELINES HAVE DRIFTED — only in main build: [' + onlyMain +
                      ']; only in delta tool: [' + onlyDelta + ']');
    const differ = ka.filter(k => a[k] !== b[k]).map(k => k + ' (' + a[k] + ' vs ' + b[k] + ')');
    if (differ.length) throw new Error('BEHAVIOURS HAVE DRIFTED: ' + differ.join(', '));
  });
  t('both copies still classify every code as remove or swap', () => {
    Object.keys(D.PROC_CODE_BASELINE).forEach(k => {
      const v = D.PROC_CODE_BASELINE[k];
      if (v !== 'remove' && v !== 'swap') throw new Error(k + ' is "' + v + '"');
    });
  });

  console.log('\n== procTableOf and procTableDiff ==');
  t('a session with no overrides runs under the baseline', () => {
    eq(D.procTableOf({ procOverrides: null }), D.PROC_CODE_BASELINE);
    eq(D.procTableOf(null), D.PROC_CODE_BASELINE, 'a missing session too:');
  });
  t('overrides replace the baseline outright, they do not merge into it', () => {
    const tbl = D.procTableOf({ procOverrides: { XR: 'remove' } });
    eq(Object.keys(tbl), ['XR']);
    eq(tbl.BR, undefined, 'baseline BR must not leak through:');
  });
  t('codes are normalised and invalid behaviours dropped', () => {
    const tbl = D.procTableOf({ procOverrides: { ' xr ': 'REMOVE', TSW: 'delete', '': 'swap' } });
    eq(tbl, { XR: 'remove' });
  });
  t('two identical sessions report no proc difference', () => {
    eq(D.procTableDiff({ procOverrides: null }, { procOverrides: null }).same, true);
  });
  t('absent means install, so a code added on one side is a difference', () => {
    const d = D.procTableDiff({ procOverrides: { XR:'remove' } },
                              { procOverrides: { XR:'remove', TSW:'swap' } });
    eq(d.same, false);
    eq(d.codes, [{ code:'TSW', a:'install', b:'swap' }]);
  });
  t('a code reclassified from remove to swap is reported with both sides', () => {
    const d = D.procTableDiff({ procOverrides:{ XR:'remove' } }, { procOverrides:{ XR:'swap' } });
    eq(d.codes, [{ code:'XR', a:'remove', b:'swap' }]);
  });
  t('differences are sorted so the sheet is stable between runs', () => {
    const d = D.procTableDiff({ procOverrides:{} },
                              { procOverrides:{ ZZ:'swap', AA:'remove', MM:'swap' } });
    eq(d.codes.map(c => c.code), ['AA', 'MM', 'ZZ']);
  });
  t('a baseline session versus a custom one is a difference, not a match', () => {
    eq(D.procTableDiff({ procOverrides:null }, { procOverrides:{ XR:'remove' } }).same, false);
  });

  console.log('\n== procProfileLabel agrees with the main build ==');
  t('the two tools label the same session identically', () => {
    [[null, null], [{ XR:'remove' }, null], [{ XR:'remove' }, 'Program Falcon'],
     [null, 'Program Falcon']].forEach(([ov, nm]) => {
      P.setProcCodeMap(ov, nm);
      const main = P._procProfileLabel();
      const delta = D.procProfileLabel({ procOverrides: ov, procProfileName: nm });
      if (main !== delta)
        throw new Error('label drift for ' + JSON.stringify([ov, nm]) +
                        ': main says ' + JSON.stringify(main) +
                        ', delta says ' + JSON.stringify(delta));
    });
  });

  console.log('\n== Defect E: displayed but not compared ==');
  const claim = o => Object.assign({ id:'adj_1', type:'ebom_ncr_trace', mode:'embodiment',
    leg:'A', rowKey:'P1||TOP', reason:'ebom_ncr_trace', sme:'J.Doe',
    rationale:'traced', applied:false }, o);
  t('a changed NCR disposition number is reported as a modification', () => {
    // v3.1 compared c.dispNo only. On ebom_ncr_trace claims — the ones the
    // main build actually creates — the field is ncrDispNo, so this change
    // was invisible and the claim was omitted from the Claims sheet.
    const rows = D.claimsDelta({ adjudications:[claim({ ncrDispNo:'DISP-100' })] },
                               { adjudications:[claim({ ncrDispNo:'DISP-999' })] });
    eq(rows.length, 1, 'modification missed:');
    eq(rows[0].Change, 'Modified');
    eq(rows[0]['NCR Disp No'], 'DISP-999');
  });
  t('a claim moving from pending to applied is reported', () => {
    const rows = D.claimsDelta({ adjudications:[claim({ applied:false })] },
                               { adjudications:[claim({ applied:true })] });
    eq(rows.length, 1);
    eq(rows[0].Applied, 'yes');
  });
  t('every field the Claims sheet prints is a field the signature compares', () => {
    // The rule the defect broke. Vary one field at a time and require the
    // signature to move. Timestamp is excluded deliberately — see HARNESS.md.
    const base = claim({ ncrDispNo:'D1', woNo:'W1', claimedQty:2, ciKey:'C1',
                         smeRole:'Lead', rowKeys:['a','b'] });
    const vary = { type:'other', leg:'B', rowKey:'X||Y', ciKey:'C2', ncrDispNo:'D2',
                   woNo:'W2', claimedQty:5, sme:'A.Nother', smeRole:'Peer',
                   rationale:'different', applied:true };
    Object.keys(vary).forEach(f => {
      const changed = Object.assign({}, base); changed[f] = vary[f];
      if (D.claimSig(base) === D.claimSig(changed))
        throw new Error('claimSig ignores "' + f + '", which claimRow displays');
    });
  });
  t('an unchanged claim produces no row at all', () => {
    eq(D.claimsDelta({ adjudications:[claim({ ncrDispNo:'D1' })] },
                     { adjudications:[claim({ ncrDispNo:'D1' })] }).length, 0);
  });

  console.log('\n== claimsDelta bookkeeping ==');
  t('added, removed and modified claims are each labelled', () => {
    const A = { adjudications:[claim({ id:'a1' }), claim({ id:'a2', rationale:'old' })] };
    const B = { adjudications:[claim({ id:'a2', rationale:'new' }), claim({ id:'a3' })] };
    const rows = D.claimsDelta(A, B);
    eq(rows.map(r => r.Change + ':' + r['Claim ID']).sort(),
       ['Added in B:a3', 'Modified:a2', 'Removed in B:a1']);
  });
  t('claims with no id are ignored rather than crashing', () => {
    eq(D.claimsDelta({ adjudications:[{ rationale:'orphan' }] },
                     { adjudications:[] }).length, 0);
  });
  t('a session with no adjudications key is treated as empty', () => {
    eq(D.claimsDelta({}, {}).length, 0);
    eq(D.claimsDelta({}, { adjudications:[claim({ id:'z' })] }).length, 1);
  });

  console.log('\n== Small helpers ==');
  t('dNorm and normPN normalise identically to the main build', () => {
    ['  p1 ', 'p1', 'P1', '', null, undefined, 0, 123].forEach(v => {
      eq(D.dNorm(v), D.normPN(v), JSON.stringify(v) + ':');
    });
    eq(D.dNorm('  abc '), 'ABC');
  });
  t('pct guards against divide-by-zero', () => {
    eq(D.pct(1, 0), '\u2014', 'zero denominator:');
    eq(D.pct(1, 4), '25.0%');
    eq(D.pct(0, 4), '0.0%');
  });
  t('the delta tool reports a version consistent with its filename', () => {
    const m = DSRC.match(/<title>([^<]*)<\/title>/);
    const fileV = DELTA.match(/v([\d_]+)\.html$/)[1].replace(/_/g, '.');
    if (m[1].indexOf(fileV) < 0)
      throw new Error('title says ' + JSON.stringify(m[1]) +
                      ' but the file is v' + fileV);
  });
});

// ── TIER 6 ─────────────────────────────────────────────────────────────────
// The delta tool's report assembly: the two-pass EBOM matcher, the KPI counters
// and the NCR disposition diff. Tier 4 covered the comparison layer; this is
// what actually fills the sheets.
suite('Tier 6 — delta tool report assembly', (t, eq) => {
  const D = sandbox({}, ['delta']).D;
  const row = (pn, nh, o) => Object.assign({ key: pn + '||' + nh, pn, nh, eq: 1 }, o);
  const sess = (rows, o) => Object.assign({ results: rows }, o);
  const changes = (a, b) => D.ebomChanges(sess(a), sess(b));
  const typesOf = rows => rows.map(r => r['Change Type'] + ':' + r['Part Number']);

  console.log('\n== The four EBOM change types ==');
  t('an unchanged BOM produces no rows at all', () => {
    const r = [row('P1','TOP'), row('P2','TOP')];
    eq(changes(r, r).length, 0);
  });
  t('a quantity change is reported with both old and new values', () => {
    const out = changes([row('P1','TOP',{eq:2})], [row('P1','TOP',{eq:5})]);
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Old Qty'], out[0]['New Qty']], ['Qty Changed','2','5']);
  });
  t('eqText wins over eq, so display text drives the comparison', () => {
    // A row carrying '2 EA' as text must not read as quantity 2.
    const out = changes([row('P1','TOP',{eq:2, eqText:'2 EA'})],
                        [row('P1','TOP',{eq:2, eqText:'3 EA'})]);
    eq([out.length, out[0]['Old Qty'], out[0]['New Qty']], [1, '2 EA', '3 EA']);
  });
  t('a part only in B is Added, a part only in A is Removed', () => {
    const out = changes([row('GONE','TOP')], [row('NEW','TOP')]);
    eq(typesOf(out), ['Removed:GONE', 'Added:NEW']);
  });
  t('the same PN under a new parent is ONE Re-parented row, not add plus remove', () => {
    const out = changes([row('P1','OLD')], [row('P1','NEW')]);
    eq(out.length, 1, 'must not double-report:');
    eq([out[0]['Change Type'], out[0]['Old Next Higher'], out[0]['New Next Higher']],
       ['Re-parented', 'OLD', 'NEW']);
  });
  t('re-parenting carries the quantity change across with it', () => {
    const out = changes([row('P1','OLD',{eq:2})], [row('P1','NEW',{eq:7})]);
    eq([out[0]['Old Qty'], out[0]['New Qty']], ['2', '7']);
  });
  t('rows are ordered Removed, Re-parented, Qty Changed, Added', () => {
    const out = changes(
      [row('AGONE','T'), row('BMOVE','OLD'), row('CQTY','T',{eq:1})],
      [row('BMOVE','NEW'), row('CQTY','T',{eq:9}), row('DNEW','T')]);
    eq(out.map(r => r['Change Type']),
       ['Removed', 'Re-parented', 'Qty Changed', 'Added']);
  });

  console.log('\n== The greedy matcher\'s edges ==');
  t('two removals and one addition of the same PN leave one Removed row', () => {
    const out = changes([row('P1','A'), row('P1','B')], [row('P1','C')]);
    eq(typesOf(out).sort(), ['Re-parented:P1', 'Removed:P1']);
  });
  t('one removal and two additions of the same PN leave one Added row', () => {
    const out = changes([row('P1','A')], [row('P1','B'), row('P1','C')]);
    eq(typesOf(out).sort(), ['Added:P1', 'Re-parented:P1']);
  });
  t('a PN whose case or padding differs still matches as re-parented', () => {
    const out = changes([row(' p1 ','OLD')], [row('P1','NEW')]);
    eq(out[0]['Change Type'], 'Re-parented', 'normPN must drive the pairing:');
  });
  t('duplicate keys keep the FIRST row, matching the main build convention', () => {
    const out = changes([row('P1','TOP',{eq:1}), row('P1','TOP',{eq:99})],
                        [row('P1','TOP',{eq:1})]);
    eq(out.length, 0, 'the second duplicate must be ignored:');
  });
  t('EBOM line numbers are joined for the sheet', () => {
    const out = changes([row('P1','T',{eq:1})],
                        [row('P1','T',{eq:2, ebomLineNos:[10,20]})]);
    eq(out[0]['EBOM Line No(s)'], '10; 20');
    const bare = changes([row('P2','T',{eq:1})], [row('P2','T',{eq:2})]);
    eq(bare[0]['EBOM Line No(s)'], '', 'absent line numbers give an empty cell:');
  });

  console.log('\n== KPI counters ==');
  const kpiRow = (o) => Object.assign({ overall:'ok', ms:'ok', as:'ok' }, o);
  t('structural rows are excluded from the KPI scope', () => {
    const k = D.computeKpis(sess([kpiRow({}), kpiRow({overall:'pt_collector'}),
      kpiRow({overall:'pt_reference'}), kpiRow({overall:'pt_bulk'}),
      kpiRow({overall:'pt_removal'}), kpiRow({overall:'collector'})],
      { mode:'ebom_mbom_abom' }));
    eq(k.scopeTotal, 1, 'only the real line item counts:');
  });
  t('direct, covered and used-on all count toward "any", but only direct counts as direct', () => {
    const k = D.computeKpis(sess([
      kpiRow({ ms:'ok' }), kpiRow({ ms:'covered' }),
      kpiRow({ ms:'missing', msUsedOn:'pn_as_usedon' }), kpiRow({ ms:'missing' })],
      { mode:'ebom_mbom' }));
    eq([k.mbomDirect, k.mbomAny, k.mbomMissing], [1, 3, 2]);
  });
  t('adjudicated statuses count as satisfied', () => {
    const k = D.computeKpis(sess([kpiRow({ms:'direct_adjudicated'}),
      kpiRow({ms:'qty_mismatch_accepted'}), kpiRow({ms:'flex_ok'}),
      kpiRow({ms:'covered_adjudicated'})], { mode:'ebom_mbom' }));
    eq([k.mbomDirect, k.mbomAny], [3, 4]);
  });
  t('ABOM-only counters are reported separately', () => {
    const k = D.computeKpis(sess([kpiRow({as:'wo_open'}), kpiRow({as:'proc_removed'}),
      kpiRow({as:'qty_mismatch'})], { mode:'ebom_abom' }));
    eq([k.abomOpen, k.abomProcRemoved, k.abomQty], [1, 1, 1]);
    eq(k.mbomDirect, undefined, 'MBOM counters must be absent in an ABOM-only session:');
  });
  t('claims are counted and their applied state reported', () => {
    eq(D.computeKpis(sess([], { mode:'ebom_mbom' })).claims, 0);
    const k = D.computeKpis(sess([], { mode:'ebom_mbom',
      adjudications:[{id:'a'},{id:'b'}], adjudicationsApplied:true }));
    eq([k.claims, k.claimsApplied], [2, 'applied']);
  });

  console.log('\n== Mode vocabulary must not drift between the two files ==');
  t('the delta tool agrees with the main build about every mode it knows', () => {
    // Same class of risk as the duplicated PROC_CODE_BASELINE: the main build
    // owns the mode vocabulary in getModeRequired's table, and the delta tool
    // re-states it as two negative tests. Add a fifth mode to the main build
    // and the delta tool would silently report both MBOM and ABOM KPIs for it.
    const start = at('const modeZones = {');
    const block = SRC.slice(start, at('};', start));
    const modes = [...block.matchAll(/'([a-z_]+)':\s*\[([^\]]*)\]/g)]
      .map(m => ({ mode: m[1], zones: m[2].split(',').map(z => z.trim().replace(/'/g, '')) }));
    if (modes.length < 4) throw new Error('only found ' + modes.length + ' modes — table moved?');
    modes.forEach(({ mode, zones }) => {
      eq(D.modeHasMbom(mode), zones.indexOf('mbom') >= 0, mode + ' MBOM:');
      eq(D.modeHasAbom(mode), zones.indexOf('abom') >= 0, mode + ' ABOM:');
    });
  });
  t('a session with no mode recorded reports both sides rather than neither', () => {
    // Fail-open. Documented, not necessarily desirable: an old session missing
    // `mode` shows a full set of zeroed MBOM KPIs as though everything failed.
    eq([D.modeHasMbom(undefined), D.modeHasAbom(undefined)], [true, true]);
  });

  console.log('\n== Pre-rename sessions and missing files ==');
  t('the CHP zone is read under both its old and new key', () => {
    // v3.1 renamed 'cp' -> 'chp'. Sessions exported before that carry the old one.
    eq(D.chpBom({ boms:{ chp:{ data:[1] } } }).data, [1], 'new key:');
    eq(D.chpBom({ boms:{ cp:{ data:[2] } } }).data, [2], 'old key:');
    eq(D.chpBom({ boms:{} }), null, 'neither:');
    eq(D.chpBom(null), null, 'no session:');
  });
  t('a new-key CHP wins over a stale old-key one', () => {
    eq(D.chpBom({ boms:{ chp:{ data:['new'] }, cp:{ data:['old'] } } }).data, ['new']);
  });
  t('a missing NCR file returns a note naming which session lacked it', () => {
    const only = D.ncrDispositionDelta({ boms:{} }, { boms:{ ncr:{ data:[] } } });
    if (!only.note || only.note.indexOf('Session A') < 0)
      throw new Error('must name Session A: ' + JSON.stringify(only.note));
    const both = D.ncrDispositionDelta({ boms:{} }, { boms:{} });
    if (both.note.indexOf('Session A or Session B') < 0)
      throw new Error('must name both: ' + JSON.stringify(both.note));
  });
  t('NCR rows without a number are skipped rather than counted', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    // `results` is mandatory throughout the delta tool — inScopeSet, fscope and
    // computeKpis all read it unguarded, so a session without it is malformed.
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('', 'D1'), mk('N1', 'D1')]),
                                      s([mk('N1', 'D1')]));
    if (out.note) throw new Error('unexpected note: ' + out.note);
    eq(out.rows.length, 0, 'the blank-numbered row must not appear as a change:');
  });
  t('a disposition status change is reported with both statuses', () => {
    const N = D.NCR_COL;
    const mk = st => { const r = []; r[N.ncrNum] = 'N1'; r[N.dispNo] = 'D1';
                       r[N.dispStatus] = st; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('OPEN')]), s([mk('CLOSED')])).rows;
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Old Disposition Status'],
        out[0]['New Disposition Status']],
       ['Disposition status changed', 'OPEN', 'CLOSED']);
  });
  t('a brand new NCR is distinguished from a new disposition on an existing one', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('N1','D1')]),
                                      s([mk('N1','D1'), mk('N1','D2'), mk('N2','D9')])).rows;
    const byType = {}; out.forEach(r => { byType[r['Change Type']] = r['NCR Number']; });
    eq(byType['New disposition on existing NCR'], 'N1');
    eq(byType['New NCR'], 'N2');
  });
  t('a disposition present in A but not B is flagged for investigation', () => {
    const N = D.NCR_COL;
    const mk = (num, disp) => { const r = []; r[N.ncrNum] = num; r[N.dispNo] = disp; return r; };
    const s = b => ({ results: [], boms:{ ncr:{ data:b } } });
    const out = D.ncrDispositionDelta(s([mk('N1','D1'), mk('N1','D2')]), s([mk('N1','D1')])).rows;
    eq(out.length, 1);
    eq([out[0]['Change Type'], out[0]['Disposition No']],
       ['Dropped from B — investigate', 'D2']);
  });
});

suite('NCR dispositions without EBOM trace — one row per disposition', (t, eq) => {
  let SHEET = null;
  const ctx = sandbox({
    XLSX:{utils:{book_new:()=>({}),aoa_to_sheet:a=>{SHEET=a;return{};},book_append_sheet:()=>{}},writeFile:()=>{}},
    COL:{ncr:{ncrNum:60,ncrStatus:61,originatingWo:62,discrepantPart:63,discNum:64,discStatus:65,
      discSummary:66,defectQty:67,causeCode:68,causeCodeDesc:69,defectCode:74,defectCodeDesc:75,
      discrepancyText:70,dispNo:71,dispStatus:72,dispType:76,dispCode:77,dispText:82}},
    state:{results:[],boms:{ncr:null}} }, ['ncr']);
  const M = ctx.N, COL = ctx.COL, state = ctx.state;
  function nrow(o){const r=new Array(90).fill('');const N=COL.ncr;
   r[N.ncrNum]=o.ncr;r[N.dispNo]=o.disp;r[N.ncrStatus]=o.ncrStatus||'OPEN';
   r[N.dispStatus]=o.dispStatus||'WORKING';r[N.discrepantPart]=o.part||'';
   r[N.originatingWo]=o.wo||'';r[N.dispText]=o.text||'';return r;}
  function run(ncrRows,results){state.boms.ncr={data:ncrRows};
   state.results=(results&&results.length)?results:[{ncrEntriesPool1:[],ncrEntriesPool2:[]}];
   SHEET=null;M.exportUntracedNcrDispositions();
   const hi=SHEET.findIndex(r=>r[0]==='NCR Number');
   return {hdr:SHEET[hi],rows:SHEET.slice(hi+1),meta:Object.fromEntries(SHEET.filter(r=>r.length===2).map(r=>[r[0],r[1]]))};}

  console.log('\n== Grain: one row per disposition number ==');
  t('4 file rows for 1 disposition collapse to 1 export row', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'}),
                 nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'})]);
    eq(r.rows.length,1,'export rows:');
    eq(r.meta['Dispositions without EBOM trace'],1);
    eq(r.meta['Source NCR file rows'],4,'source count still reported:');
    eq(r.rows[0][18],4,'Source Rows Merged:');
  });
  t('distinct dispositions under one NCR stay separate', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N1',disp:'D2'}),nrow({ncr:'N1',disp:'D3'})]);
    eq(r.rows.length,3);
    eq(r.rows.map(x=>x[1]),['D1','D2','D3']);
  });
  t('same disposition number under different NCRs stays separate', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D1'})]);
    eq(r.rows.length,2,'must not collapse across NCRs:');
  });
  t('differing values are joined, not dropped', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P2'})]);
    eq(r.rows.length,1);
    eq(r.rows[0][8],'P1 | P2','discrepant parts merged:');
    eq(r.rows[0][18],2);
  });
  t('identical values do not duplicate in the join', ()=>{
    const r=run([nrow({ncr:'N1',disp:'D1',part:'P1'}),nrow({ncr:'N1',disp:'D1',part:'P1'})]);
    eq(r.rows[0][8],'P1');
  });
  t('Source Rows Merged is 1 when nothing collapsed', ()=>{
    eq(run([nrow({ncr:'N1',disp:'D1'})]).rows[0][18],1);
  });

  console.log('\n== Predicate matches the on-screen helper ==');
  t('a traced disposition is excluded', ()=>{
    const res=[{ncrEntriesPool1:[{ncrNum:'N1',dispNo:'D1'}],ncrEntriesPool2:[]}];
    eq(run([nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D9'})],res).rows.length,1);
  });
  t('Pool 2 traces also exclude', ()=>{
    const res=[{ncrEntriesPool1:[],ncrEntriesPool2:[{ncrNum:'N1',dispNo:'D1'}]}];
    eq(run([nrow({ncr:'N1',disp:'D1'})],res).rows.length,0);
  });
  t('CANCELLED NCRs are excluded', ()=>{
    eq(run([nrow({ncr:'N1',disp:'D1',ncrStatus:'CANCELLED'}),nrow({ncr:'N2',disp:'D2'})]).rows.length,1);
  });
  t('export count equals the helper count', ()=>{
    const rows=[nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N1',disp:'D1'}),nrow({ncr:'N2',disp:'D2'})];
    state.boms.ncr={data:rows};state.results=[{ncrEntriesPool1:[],ncrEntriesPool2:[]}];
    const helper=M.computeUntracedNcrs().length;
    const r=run(rows);
    eq(helper,3,'helper is per file row:');
    eq(r.rows.length,2,'export is per disposition:');
    eq(r.meta['Source NCR file rows'],helper,'and reconciles to the helper:');
  });
  t('sorted by NCR then disposition, numerically', ()=>{
    const r=run([nrow({ncr:'N10',disp:'D2'}),nrow({ncr:'N2',disp:'D10'}),nrow({ncr:'N2',disp:'D2'})]);
    eq(r.rows.map(x=>x[0]+'/'+x[1]),['N2/D2','N2/D10','N10/D2']);
  });
  t('empty result set produces headers and a zero count', ()=>{
    const res=[{ncrEntriesPool1:[{ncrNum:'N1',dispNo:'D1'}],ncrEntriesPool2:[]}];
    const r=run([nrow({ncr:'N1',disp:'D1'})],res);
    eq(r.rows.length,0); eq(r.meta['Dispositions without EBOM trace'],0);
  });
});

suite('ECN footprint completeness', (t, eq) => {
  const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3},chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
    state:{results:[],boms:{ebom:null,chp:null}} }, ['proc','engine','ecn']);
  const B = ctx.B, state = ctx.state, normPN = ctx.E.normPN;
  function R(pn,nh,o){o=o||{};return{key:normPN(pn)+'||'+normPN(nh),pn,nh,overall:'ok',as:'ok',
   woStatus:o.wo===undefined?'closed':o.wo,woValues:['W1'],
   trace:o.ecn?{dcn:new Map(),ecn:new Map(o.ecn),ecr:new Map()}:null,
   ncrEntriesPool1:o.ncr||[],ncrEntriesPool2:[]};}
  const chpRow=(pn,nh,ecn)=>{const r=new Array(25).fill('');r[3]=pn;r[5]=nh;r[18]=ecn;return r;};

  console.log('\n== The completeness hole is now closed ==');
  t('CHP lists 12, only 9 joined: ECN NO LONGER recommended', ()=>{
    const rows=[];for(let i=1;i<=9;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;state.boms.ebom=null;
    state.boms.chp={data:Array.from({length:12},(_,i)=>chpRow('P'+(i+1),'A','E1'))};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.allAccepted,true,'joined items all fine:');
    eq(e.complete,false,'but footprint incomplete:');
    eq(e.chpItemCount,12); eq(e.items.length,9);
    eq(e.unjoined,['P10','P11','P12'],'unmatched parts named:');
  });
  t('all 12 join: ECN qualifies', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    state.boms.chp={data:Array.from({length:12},(_,i)=>chpRow('P'+(i+1),'A','E1'))};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq([e.allAccepted,e.complete],[true,true]);
  });
  t('the two failure reasons stay distinguishable', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']],wo:'open'})];
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('P9','A','E1')]};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.allAccepted,false,'unembodied item:'); eq(e.complete,false,'AND missing item:');
  });
  t('PN-only matching: different NH still counts as joined', ()=>{
    state.results=[R('P1','ASSY-X',{ecn:[['E1','']]})];
    state.boms.chp={data:[chpRow('P1','ASSY-Y','E1')]};
    eq(B.buildEcnFootprints().ecnMap.get('E1').complete,true,'NH mismatch must not false-alarm:');
  });
  t('no CHP loaded: degrades without false alarms', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]})]; state.boms.chp=null;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq([e.complete,e.chpItemCount],[true,0]);
  });
  t('inherited COTS children count toward coverage', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]}),R('C1','P1',{})];
    state.boms.ebom={data:[[0,'P1',0,'A'],[0,'C1',0,'P1']].map(r=>{const x=new Array(30).fill('');x[1]=r[1];x[3]=r[3];return x;})};
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('C1','P1','E1')]};
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.complete,true,'child joined via inheritance:'); eq(e.items.length,2);
  });
  t('incompleteEcns is counted for the report footer', ()=>{
    state.results=[R('P1','A',{ecn:[['E1','']]})]; state.boms.ebom=null;
    state.boms.chp={data:[chpRow('P1','A','E1'),chpRow('P2','A','E1')]};
    eq(B.buildEcnFootprints().incompleteEcns,1);
  });
});

suite('Many EBOM line items to one ECN', (t, eq) => {
  const ctx = sandbox({ COL:{ebom:{indenture:0,pn:1,nh:3},chp:{pn:3,nh:5,ecn:18,docNo:10,docRev:11}},
    state:{results:[],boms:{ebom:null,chp:null}} }, ['proc','engine','ecn']);
  const B = ctx.B, state = ctx.state, normPN = ctx.E.normPN;
  function R(pn,nh,o){o=o||{};return{key:normPN(pn)+'||'+normPN(nh),pn,nh,overall:'ok',as:'ok',
   woStatus:o.wo===undefined?'closed':o.wo,woValues:['W1'],
   trace:o.ecn?{dcn:new Map(),ecn:new Map(o.ecn),ecr:new Map()}:null,
   ncrEntriesPool1:o.ncr||[],ncrEntriesPool2:[]};}

  console.log('\n== Many EBOM line items -> one ECN ==');
  t('12 items all embodied: ECN qualifies', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','OPEN']]}));
    state.results=rows;state.boms.ebom=null;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,12,'footprint size:');eq(e.allAccepted,true);
  });
  t('12 items, ONE open WO: ECN excluded', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','OPEN']],wo:i===7?'open':'closed'}));
    state.results=rows;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,12);eq(e.allAccepted,false,'one bad item must exclude:');
    eq(e.items.filter(x=>!x.accepted).length,1);
  });
  t('12 items, ONE open disposition: ECN excluded', ()=>{
    const rows=[];for(let i=1;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']],
      ncr:i===3?[{ncrNum:'N1',dispNo:'D1',dispStatus:'WORKING'}]:[]}));
    state.results=rows;
    eq(B.buildEcnFootprints().ecnMap.get('E1').allAccepted,false);
  });
  t('order independent: bad item first still excludes', ()=>{
    const rows=[R('P1','A',{ecn:[['E1','']],wo:'open'})];
    for(let i=2;i<=12;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    eq(B.buildEcnFootprints().ecnMap.get('E1').allAccepted,false);
  });
  t('an item on TWO ECNs blocks both', ()=>{
    state.results=[R('P1','A',{ecn:[['E1',''],['E2','']],wo:'open'}),R('P2','A',{ecn:[['E1','']]})];
    const m=B.buildEcnFootprints().ecnMap;
    eq(m.get('E1').allAccepted,false);eq(m.get('E2').allAccepted,false);
  });

  console.log('\n== COMPLETENESS: can a CHP-listed item be missing from the footprint? ==');
  t('CHP lists 12 items for E1 but only 9 are EBOM result rows', ()=>{
    // Simulates: CHP file rows for P1..P12 under E1, but P10-P12 have no EBOM
    // result row (no key match). Those three never enter the footprint.
    const rows=[];for(let i=1;i<=9;i++)rows.push(R('P'+i,'A',{ecn:[['E1','']]}));
    state.results=rows;
    const e=B.buildEcnFootprints().ecnMap.get('E1');
    eq(e.items.length,9,'footprint sees only the joined rows:');
    eq(e.allAccepted,true,'and therefore RECOMMENDS closure:');
    console.log('        >> CHP says 12 items, footprint counted 9, ECN recommended anyway');
  });
});

suite('Stylesheet and chrome integrity', (t, eq) => {
  const css = STYLE_BLOCKS.map(b => b.css).join('\n');   // ALL blocks, not just the first

  console.log('\n== The slice is CSS, not the vendored spreadsheet library ==');
  t('the naive "<style" search still lands inside vendored JavaScript', () => {
    // Documents the trap this suite fell into for its whole existence. If
    // SheetJS is ever removed and this starts failing, the guarded regex in
    // STYLE_BLOCKS can be simplified — but not before.
    const naive = SRC.indexOf('<style');
    if (naive === STYLE_BLOCKS[0].at)
      throw new Error('naive search is now safe — re-check whether the guard is still needed');
    if (!/^<style:/.test(SRC.slice(naive, naive + 8)))
      throw new Error('naive search hit something unexpected: ' + JSON.stringify(SRC.substr(naive, 40)));
  });
  t('every extracted block is a stylesheet, not markup', () => {
    STYLE_BLOCKS.forEach((b, i) => {
      if (b.css.includes('<style') || b.css.includes('<script'))
        throw new Error('block ' + (i + 1) + ' contains markup — the slice is wrong');
      if (!b.css.includes('{'))
        throw new Error('block ' + (i + 1) + ' has no rules at all');
    });
  });
  t('both style blocks are found and neither is trivial', () => {
    eq(STYLE_BLOCKS.length, 2, 'block count:');
    STYLE_BLOCKS.forEach((b, i) => { if (b.css.length < 500)
      throw new Error('block ' + (i + 1) + ' is only ' + b.css.length + ' chars'); });
  });

  console.log('\n== Brace balance: an assertion, not a baseline ==');
  t('every style block is brace-balanced', () => {
    // Replaces the old "delta must equal -2". That -2 was never a real
    // imbalance; it was minified JS being counted as CSS. Both real blocks
    // balance exactly, so the correct expectation is zero.
    STYLE_BLOCKS.forEach((b, i) => {
      const r = scanCss(b.css);
      if (r.balanced) return;
      const fileLine = l => l + b.line - 1;
      const parts = [];
      if (r.unmatchedOpen.length)  parts.push('unclosed rule opened at file line(s) ' +
        r.unmatchedOpen.map(fileLine).join(', '));
      if (r.unmatchedClose.length) parts.push('stray closing brace at file line(s) ' +
        r.unmatchedClose.map(fileLine).join(', '));
      throw new Error('block ' + (i + 1) + ': ' + parts.join('; '));
    });
  });
  t('the scanner ignores braces inside quoted strings', () => {
    eq(scanCss('a{content:"{"}').balanced, true, 'quoted open:');
    eq(scanCss("a{content:'}'}").balanced, true, 'quoted close:');
  });
  t('the scanner ignores braces inside comments', () => {
    eq(scanCss('a{color:red} /* } stray in a comment { */').balanced, true);
  });
  t('a stray closing brace is caught and located', () => {
    const r = scanCss('a{color:red}\nb{color:blue}\n}\n');
    eq([r.balanced, r.unmatchedClose], [false, [3]], 'line of the stray }:');
  });
  t('an unclosed rule is caught and located', () => {
    const r = scanCss('a{color:red}\n\nb{color:blue;\n');
    eq([r.balanced, r.unmatchedOpen], [false, [3]], 'line of the unclosed {:');
  });
  t('one stray open and one stray close do not cancel out', () => {
    // A net-delta counter reports 0 here and passes. This is why the check
    // tracks positions rather than a total.
    const r = scanCss('}\na{color:red\n');
    eq(r.balanced, false, 'a delta-based check would have said 0:');
  });

  console.log('\n== Variables and keyframes, across every block ==');
  t('no orphaned keyframes remain', () => {
    const defs = [...new Set([...css.matchAll(/@keyframes\s+([\w-]+)/g)].map(m => m[1]))];
    const orphans = defs.filter(k => !new RegExp('animation:[^;]*\\b' + k + '\\b').test(SRC));
    if (orphans.length) throw new Error('orphans: ' + orphans.join(', '));
  });
  t('--text-dim is fully retired', () => {
    if (SRC.includes('var(--text-dim)')) throw new Error('references remain');
    if (/^\s*--text-dim:/m.test(SRC)) throw new Error('definition remains');
  });
  t('no CSS var is referenced without a definition', () => {
    const defined = new Set([...css.matchAll(/^\s*(--[\w-]+):/gm)].map(m => m[1]));
    const used = new Set([...SRC.matchAll(/var\((--[\w-]+)\)/g)].map(m => m[1]));
    const missing = [...used].filter(v => !defined.has(v));
    if (missing.length) throw new Error('undefined vars used: ' + missing.join(', '));
  });

  console.log('\n== Export menu wiring ==');
  t('every menu item is wired, and every wire has a button', () => {
    // The count is derived from the build, not pinned to 13, so ADDING an
    // export is not a failure — leaving one unwired is.
    const items = [...SRC.matchAll(/class="export-menu-item"[^>]*>\s*([^<]{1,60})/g)].map(m => m[1].trim());
    const wired = [...SRC.matchAll(/id="(export-menu-[\w-]+)"[^>]*onclick="invokeExport\('([^']+)'\)/g)];
    if (!items.length) throw new Error('no export menu items found at all');
    eq(wired.length, items.length, 'menu items vs invokeExport wires:');
    const dead = wired.filter(w => !SRC.includes('id="' + w[2] + '"')).map(w => w[2]);
    if (dead.length) throw new Error('wired to missing button(s): ' + dead.join(', '));
  });
  t('menu ids are unique', () => {
    const ids = [...SRC.matchAll(/id="(export-menu-[\w-]+)"/g)].map(m => m[1]);
    const dupes = ids.filter((v, i) => ids.indexOf(v) !== i);
    if (dupes.length) throw new Error('duplicate menu ids: ' + [...new Set(dupes)].join(', '));
  });
  t('export menu uses one arrow convention', () => {
    const items = [...SRC.matchAll(/class="export-menu-item"[^>]*>\s*([^<]{1,60})/g)].map(m => m[1].trim());
    const arr = items.filter(i => i.startsWith('\u2b07'));
    if (arr.length !== 0 && arr.length !== items.length)
      throw new Error('mixed: ' + arr.length + '/' + items.length);
  });
});

suite('Version single-source', (t, eq) => {
  t('exactly one hardcoded version string in the file', ()=>{
    const m = SRC.match(/const APP_VERSION = '(v\d+)'/);
    if(!m) throw new Error('APP_VERSION not found');
    // no other vNNN literal in visible markup
    const body = SRC.slice(SRC.indexOf('<div class="header"'), SRC.indexOf('<script', SRC.indexOf('<div class="header"')));
    const stripped = body.replace(/<!--[\s\S]*?-->/g,'');
    // Dev/Logic tooltip blocks legitimately cite the release a behaviour landed
    // in ("v66 pre-filters the ABOM"). Those are provenance prose, not a claim
    // about which version is running. Exclude them; anything else is a drift risk.
    const noDev = stripped.replace(/<div class="metric-tooltip-dev"[\s\S]*?<\/div>\s*<\/div>/g,'');
    const vis = noDev.replace(/<[^>]+>/g,' ');
    const hits = vis.match(/\bv\d{2,3}\b/g) || [];
    if(hits.length) throw new Error('version literals still in chrome: '+hits.join(', '));
  });
  t('the pill has an id and no literal', ()=>{
    if(!SRC.includes('id="app-version-pill"')) throw new Error('no id');
    if(/<span class="pill">v\d+<\/span>/.test(SRC)) throw new Error('literal pill remains');
  });
  t('renderVersionPill is called at boot', ()=>{
    if(!/renderVersionPill\(\);/.test(SRC)) throw new Error('never called');
  });
  t('APP_VERSION matches the build', ()=>{
    const m=SRC.match(/const APP_VERSION = '(v\d+)'/);
    if(m[1]!=='v154') throw new Error('says '+m[1]);
  });
});


// ── summary ────────────────────────────────────────────────────────────────
// EXPECTED_TESTS exists because a crashed suite costs ONE reported failure but
// silently skips every test after it. Without this, losing a third of the suite
// still prints a believable total. Bump it deliberately when adding tests.
const EXPECTED_TESTS = 183;
console.log('═'.repeat(60));
console.log('TOTAL: ' + TP + ' passed, ' + TF + ' failed');
if (TP + TF !== EXPECTED_TESTS) {
  console.log('');
  console.log('COUNT MISMATCH: ' + (TP + TF) + ' tests ran, ' + EXPECTED_TESTS + ' expected.');
  console.log(TP + TF < EXPECTED_TESTS
    ? 'Tests went missing — a suite crashed before finishing. Treat this as a failure.'
    : 'Tests were added without updating EXPECTED_TESTS. Update it.');
  process.exit(1);
}
if (FAILED.length) { console.log('Failing suites: ' + FAILED.join(', ')); process.exit(1); }
console.log('All suites green.');
