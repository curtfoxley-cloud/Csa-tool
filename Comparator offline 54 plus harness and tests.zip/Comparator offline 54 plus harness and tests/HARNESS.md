# Comparator test harness

**One file: `comparator-tests.js`.** Node only — no install, no network, no
other files. 183 tests.

```bash
node comparator-tests.js                          # finds the newest ./comparator_offline*.html
                                                  # and ./comparator_delta_v*.html beside it
node comparator-tests.js path/to/build.html       # or point it anywhere
```

Re-run after any change to the build.

## Why one file

Comparator ships as a single self-contained HTML, and this follows suit so it
can live in a Project beside it. A split-file version was lost between sessions,
taking 72 tests with it — the whole point of this format is that it survives.

## How it works

The build's testable functions are lifted out of the HTML by marker, then run in
a per-suite sandbox that stubs the browser globals they touch (`document`,
`state`, `COL`, `XLSX`). Each suite gets its own sandbox because the modules
expect different `COL` shapes.

If a marker moves, extraction **fails loudly and names it, and no tests run at
all** — the build was refactored and the marker needs updating. That is
deliberate: an empty module would let every suite pass while testing nothing.

This was only half-true before v154. Four boundary lookups used raw `indexOf`,
which returns `-1` on a miss and turns into a zero-length slice. Pointed at a
build where one marker had been renamed, the old harness printed
**"21 passed, 5 failed"** — a believable summary. In fact 33 tests never
executed, because a crashed suite costs exactly one reported failure no matter
how many tests it contained. Every boundary now goes through `at()` / `lastAt()`
/ `span()`, and `span()` refuses a slice that is inverted or implausibly small.

`EXPECTED_TESTS` is the backstop: if the number of tests that actually ran is
not the number expected, the run fails and says so. **Bump it when you add
tests** — that is deliberate friction, because a silently shrinking suite is the
failure mode this harness is most vulnerable to.

## Coverage

| Suite | Tests | Covers |
|---|---|---|
| Tier 6 — delta report assembly | 26 | Two-pass EBOM matcher, KPI counters, NCR disposition diff, **mode vocabulary drift**, pre-rename CHP sessions |
| Tier 4 — delta tool | 21 | **Baseline drift between the two shipped files**, proc table diffing, claim change detection, label agreement with the main build |
| Tier 3 — CHP release state | 19 | Badge states, latest-DCN selection, undated-DCN warning, and **timezone-stable release dates** |
| Tier 3 — proc table hardening | 14 | Lock behaviour, hand-edited profile files, provenance leaks between loads, stale-results flag |
| Tier 2 — indenture map | 11 | **The real `buildEbomIndentureMap`,** not a stand-in. Parent/child linking, shared PN under two NHs, self-referencing rows, first-occurrence rules |
| Tier 2 — extraction | 10 | **The harness's own safety net.** Module contracts, marker guards, "no global without its module", build is still self-contained |
| Tier 1 — profile name | 13 | **Regression guards for two v153 defects.** Cancel on the profile-name prompt; profile name surviving a session round-trip; the name/override split |
| Engine | 9 | **Core correctness.** Tagging a proc code actually changes `buildAbomMap` output; swap-as-add second pass; founding program unaffected; worker table in lockstep |
| Proc code panel | 16 | Job-number sampling, dedup, HTML escaping, Mapping 2 (where the old description column was always blank) |
| NCR untraced | 12 | Export grain is **one row per disposition**, not per file row; merged values joined not dropped |
| ECN completeness | 7 | CHP-listed items that never joined to an EBOM row |
| ECN aggregation | 6 | Many EBOM line items → one ECN; one bad item excludes the whole ECN |
| Stylesheet/chrome | 15 | Brace balance **located by line**, across both style blocks; orphan keyframes; undefined CSS vars; export-menu wiring derived from the build |
| Version | 4 | Single-source version string; guards the header pill against drift |

## Two defects these tests were written for

All four were live in v153 and are fixed in v154. Eight tests across Tiers 1
and 3 fail against a v153 build — that is the check that they are real guards
and not decoration. Run the suite against an old build occasionally to confirm
they still bite.

- **The release date was wrong east of Greenwich.** `formatDcnDate` read UTC
  components off a date built at *local* midnight, so a DCN released 15 March
  displayed as **MARCH 14** in Tokyo, Sydney and Kolkata. It reached the badge,
  the tooltip and the freeze certificate. Both the parser and the formatter now
  normalise date-only values to local midnight and read local components.
- **A profile name leaked between loads.** `setProcCodeMap` fell back to
  `|| state.procProfileName`, which no caller needed. Load "Program Falcon",
  then import an unnamed custom session, and the certificate still claimed
  Falcon. The argument is now the only source of the name.
- **The delta tool displayed a field it never compared.** `claimRow` prints
  `c.dispNo || c.ncrDispNo`; `claimSig` compared only `c.dispNo`. On
  `ebom_ncr_trace` claims — the ones the main build actually creates — the
  field is always `ncrDispNo`, so a changed NCR disposition number was declared
  unchanged and omitted from the Claims sheet entirely. `applied` had the same
  problem. The rule now under test: **every field `claimRow` prints must be a
  field `claimSig` compares.**
- **Cancel exported a file anyway.** `exportProcProfile()` read
  `(prompt(...) || '').trim()` and then tested the result for `null`. The
  coercion happened first, so the guard could never fire: Cancel wrote a
  `proc_code_profile.json` and overwrote the profile name with
  "Unnamed profile".
- **The profile name did not survive a session.** `setProcCodeMap(map, name)`
  ignored `name` whenever `map` was null, and the session importer calls
  exactly that path. Proc code *behaviour* travelled with the session; the label
  saying whose behaviour it was did not.

The rule both defects broke, now pinned by tests: **the name is provenance, the
overrides are the deviation, and they are separable.** A shared profile whose
codes happen to equal the baseline still has a name. Callers that mean "start
clean" — `resetProcCodesToBaseline`, `resetAll` — pass no name and still clear it.

## The stylesheet was never the stylesheet

`SRC.indexOf('<style')` matches **`<style:master-page`** — an OpenDocument XML
tag inside the vendored SheetJS library on line 28. Every CSS test was scanning
~58KB of minified JavaScript with the real stylesheet appended to it.

That is where the `-2` brace baseline came from. It was not "the counter is not
a real CSS parser" — it was JS object literals being counted as CSS rules. Both
real style blocks balance at exactly **0**.

The check now finds blocks with `<style(?:\s[^>]*)?>`, which the XML tags cannot
match, and scans them with a comment- and string-aware pass that returns the
**line numbers** of unmatched braces. Compared with the old baseline it:

- **locates** the problem instead of reporting a delta
- catches one stray `{` and one stray `}` in the same file, which cancel to a
  delta of 0 and passed the old check
- does not break when the vendored library changes. Editing a single string
  inside SheetJS — touching no CSS — shifted the old delta to 0 and failed the
  build.

Both style blocks are now checked. The second one, which styles the exported
HTML report, was never examined at all.

## Two vocabularies live in both files

The main build owns them; the delta tool re-states them. Nothing enforced
agreement until v154, and a divergence is silent in both cases:

- **`PROC_CODE_BASELINE`** — if the main build gains a code and the delta copy
  does not, the delta tool reports two sessions as agreeing on proc codes when
  they do not.
- **The mode vocabulary.** The main build's `getModeRequired` table names four
  modes; the delta tool re-states it as `mode !== 'ebom_abom'` and
  `mode !== 'ebom_mbom'`. Add a fifth mode and the delta tool reports a full set
  of zeroed MBOM KPIs for it, as though everything failed. The test reads the
  main build's table and checks both predicates against every mode in it.

A session with no `mode` recorded fails open — both sides are reported. That is
pinned by a test so the behaviour is a decision rather than an accident.

## Two guards worth keeping

- **Brace balance**, as above — now an assertion against zero rather than a
  magic number, and it names the line.
- **Version literal check** fails if a version string appears anywhere in the UI
  chrome. The header pill was stale for 33 releases before this existed.

## Not covered

- **CHP release-state badge** (~18 tests, lost). Straightforward to rewrite —
  `chpReleaseState` is already reachable.
`timestamp` is deliberately excluded from the claim signature: it moves on
every re-save and would mark every claim as modified. Note that the main
build's certificate hash **does** include it, so two sessions can differ by
cert hash while the delta tool reports the claims as unchanged. That is a
judgement call worth revisiting, not a defect.
- **Export menu counts** are now derived from the build rather than pinned to
  13, so adding an export is not a failure — leaving one unwired is.

- **`pedigreeDelta` and the sheet builders** — `buildSummaryRows`,
  `buildProgress`, `gatedSection`, `exportXlsx`. Tiers 4 and 6 cover the
  comparison and assembly layers; the final formatting into worksheets is
  still untested.
- **`inScopeSet`, `fscope` and `computeKpis` read `session.results` unguarded**,
  so a malformed session throws rather than returning a note the way the
  missing-file paths do. Treated as a documented precondition, not a defect —
  every real session carries `results`.

Nothing in the UI layer is covered: no DOM rendering, no click paths, no Excel
file is opened and inspected. These suites test logic, not the interface.
