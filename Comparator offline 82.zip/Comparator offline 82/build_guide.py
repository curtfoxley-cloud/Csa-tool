#!/usr/bin/env python3
"""Build the Comparator user guide (.docx) from its source, Comparator_User_Guide.md.

    python3 build_guide.py                      # writes Comparator_User_Guide_v<NNN>.docx
    python3 build_guide.py path/to/guide.md     # any source path

Needs pandoc (https://pandoc.org) on the PATH. Nothing else: no Python packages.

Why a source file and a script, not an edited .docx: the guide drifted from the
tool for twenty builds because nothing compared them. The source is plain text
that the test harness reads (suite "User guide agrees with the build"), so the
version stamp, badge labels, symbols, theme names and section references are
checked against the build on every run. Edit the .md, run this, ship the .docx.

The version in the output name is read from the subtitle ("for build vNNN").
"""
import os, re, shutil, subprocess, sys, tempfile, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'Comparator_User_Guide.md')
TOTAL = 9360        # table width in twips: 6.5 in, letter paper with 1 in margins
MINW = 1400         # no column narrower than a short label needs
FONT = 'Arial'
HEAD = '1F3A5F'     # heading colour


def run(*cmd):
    r = subprocess.run(cmd, capture_output=True)
    if r.returncode:
        sys.exit('failed: ' + ' '.join(cmd) + '\n' + r.stderr.decode(errors='replace'))
    return r.stdout


def unzip(path, into):
    with zipfile.ZipFile(path) as z:
        z.extractall(into)


def rezip(folder, path):
    if os.path.exists(path):
        os.remove(path)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(folder):
            for f in sorted(files):
                full = os.path.join(root, f)
                z.write(full, os.path.relpath(full, folder))


def rw(path, fn):
    with open(path, encoding='utf8') as f:
        s = f.read()
    with open(path, 'w', encoding='utf8') as f:
        f.write(fn(s))


def reference_doc(work):
    """pandoc's default reference document, restyled: Arial, one heading colour."""
    ref = os.path.join(work, 'ref.docx')
    with open(ref, 'wb') as f:
        f.write(run('pandoc', '--print-default-data-file', 'reference.docx'))
    d = os.path.join(work, 'ref')
    unzip(ref, d)

    def styles(s):
        s = re.sub(r'<w:rFonts[^>]*/>', '<w:rFonts w:ascii="%s" w:hAnsi="%s" w:eastAsia="%s" w:cs="%s"/>' % ((FONT,) * 4), s)
        for c in ('4F81BD', '365F91', '0F4761'):
            s = s.replace(c, HEAD)
        return s
    rw(os.path.join(d, 'word', 'styles.xml'), styles)
    rezip(d, ref)
    return ref


def tables(s):
    """Bordered, fixed-layout tables with a shaded header row and widths in
    proportion to each column's longest text. pandoc gives every column the
    same width and no borders."""
    bord = '<w:tblBorders>' + ''.join('<w:%s w:val="single" w:sz="4" w:space="0" w:color="BFC5CC"/>' % e
                                       for e in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV')) + '</w:tblBorders>'
    mar = ('<w:tblCellMar><w:top w:w="60" w:type="dxa"/><w:left w:w="100" w:type="dxa"/>'
           '<w:bottom w:w="60" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar>')

    def one(m):
        t = m.group(0)
        ncol = len(re.findall(r'<w:gridCol ', t))
        lens = [0] * ncol
        for r in re.findall(r'<w:tr[ >].*?</w:tr>', t, re.S):
            for i, c in enumerate(re.findall(r'<w:tc>.*?</w:tc>', r, re.S)[:ncol]):
                lens[i] = max(lens[i], min(len(''.join(re.findall(r'<w:t[^>]*>([^<]*)</w:t>', c))), 90))
        w = [max(x, 12) for x in lens]
        widths = [int(TOTAL * x / sum(w)) for x in w]
        short = [i for i, x in enumerate(widths) if x < MINW]
        if short:
            need = sum(MINW - widths[i] for i in short)
            long_ = [i for i in range(len(widths)) if i not in short]
            lt = sum(widths[i] for i in long_)
            for i in short:
                widths[i] = MINW
            for i in long_:
                widths[i] -= int(need * widths[i] / lt)
        widths[-1] += TOTAL - sum(widths)
        t = re.sub(r'<w:tblPr>.*?</w:tblPr>',
                   '<w:tblPr><w:tblStyle w:val="Table"/><w:tblW w:type="dxa" w:w="%d"/><w:jc w:val="left"/>%s'
                   '<w:tblLayout w:type="fixed"/>%s<w:tblLook w:firstRow="1" w:lastRow="0" w:firstColumn="0" '
                   'w:lastColumn="0" w:noHBand="0" w:noVBand="0" w:val="0020"/></w:tblPr>' % (TOTAL, bord, mar),
                   t, count=1, flags=re.S)
        t = re.sub(r'<w:tblGrid>.*?</w:tblGrid>',
                   '<w:tblGrid>' + ''.join('<w:gridCol w:w="%d"/>' % x for x in widths) + '</w:tblGrid>',
                   t, count=1, flags=re.S)
        state = {'first': True}

        def row(rm):
            r, idx, first = rm.group(0), [0], state['first']

            def cell(_):
                i = idx[0]
                idx[0] += 1
                shd = '<w:shd w:val="clear" w:color="auto" w:fill="E8EDF2"/>' if first else ''
                return '<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s</w:tcPr>' % (widths[min(i, len(widths) - 1)], shd)
            r = re.sub(r'<w:tc>\s*<w:tcPr\s*/>', cell, r)
            state['first'] = False
            return r
        return re.sub(r'<w:tr[ >].*?</w:tr>', row, t, flags=re.S)
    return re.sub(r'<w:tbl>.*?</w:tbl>', one, s, flags=re.S)


def pstyle_first(s):
    def f(m):
        b = m.group(1)
        ps = re.search(r'<w:pStyle [^>]*/>', b)
        if ps and not b.startswith(ps.group(0)):
            b = ps.group(0) + b.replace(ps.group(0), '', 1)
        return '<w:pPr>' + b + '</w:pPr>'
    return re.sub(r'<w:pPr>(.*?)</w:pPr>', f, s, flags=re.S)


def styles_schema(s):
    """pandoc's reference styles break the OOXML element order in a few places.
    Word tolerates it; strict validators do not."""
    s = re.sub(r'(<w:color [^>]*/>)&gt;', r'\1', s)

    def tc(m):
        b = m.group(1)
        v = re.search(r'<w:vAlign [^>]*/>', b)
        if v:
            b = b.replace(v.group(0), '', 1) + v.group(0)
        return '<w:tcPr>' + b + '</w:tcPr>'
    s = re.sub(r'<w:tcPr>(.*?)</w:tcPr>', tc, s, flags=re.S)

    def ppr(m):
        b = m.group(1)
        j = re.search(r'<w:jc [^>]*/>', b)
        if j and re.search(r'<w:(spacing|ind) ', b[b.find(j.group(0)):]):
            b = b.replace(j.group(0), '', 1) + j.group(0)
        return '<w:pPr>' + b + '</w:pPr>'
    s = re.sub(r'<w:pPr>(.*?)</w:pPr>', ppr, s, flags=re.S)

    def sty(m):
        b = m.group(0)
        q = re.search(r'\s*<w:qFormat\s*/>', b)
        if q:
            b2 = b.replace(q.group(0), '', 1)
            idx = [b2.find(x) for x in ('<w:pPr', '<w:rPr', '<w:tblPr', '<w:trPr', '<w:tcPr', '<w:tblStylePr', '<w:rsid') if b2.find(x) >= 0]
            k = min(idx) if idx else b2.rfind('</w:style>')
            b = b2[:k] + '<w:qFormat/>' + b2[k:]
        return b
    return re.sub(r'<w:style [^>]*>.*?</w:style>', sty, s, flags=re.S)


def main():
    if not shutil.which('pandoc'):
        sys.exit('pandoc is not on the PATH: https://pandoc.org/installing.html')
    src = open(SRC, encoding='utf8').read()
    m = re.search(r'for build (v\d+)', src)
    if not m:
        sys.exit('no "for build vNNN" in the subtitle of ' + SRC)
    out = os.path.join(os.path.dirname(os.path.abspath(SRC)), 'Comparator_User_Guide_%s.docx' % m.group(1))
    work = tempfile.mkdtemp(prefix='guide-')
    try:
        raw = os.path.join(work, 'raw.docx')
        run('pandoc', SRC, '-o', raw, '--toc', '--toc-depth=2', '--reference-doc=' + reference_doc(work))
        d = os.path.join(work, 'doc')
        unzip(raw, d)
        rw(os.path.join(d, 'word', 'document.xml'), lambda s: pstyle_first(tables(s)))
        rw(os.path.join(d, 'word', 'numbering.xml'),
           lambda s: re.sub(r'(<w:nsid w:val=")([0-9A-Fa-f]{1,7})(")', lambda x: x.group(1) + x.group(2).rjust(8, '0') + x.group(3), s))
        rw(os.path.join(d, 'word', 'styles.xml'), styles_schema)
        # A minimal settings part: pandoc's is out of schema order. updateFields
        # asks Word to fill in the table of contents when the file is opened.
        with open(os.path.join(d, 'word', 'settings.xml'), 'w', encoding='utf8') as f:
            f.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings '
                    'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
                    '<w:defaultTabStop w:val="720"/><w:characterSpacingControl w:val="doNotCompress"/>'
                    '<w:updateFields w:val="true"/></w:settings>')
        rezip(d, out)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    print('wrote ' + out)


if __name__ == '__main__':
    main()
